export default {
  //返回旧版
  asideBottom: {
    old: '返回',
    Version: '旧版'
  },
  //侧边菜单栏
  menuList: {
    home: {
      level1: '主页',
      level1_1: '主页'
    },
    trad: {
      level1: '证券交易',
      level1_1: '证券',
      level2_1: '港A美股',
      level2_2: '其它市场',
      level2_3: '新股申购',
      level2_4: '公司行动',
      level2_5: '按仓比率'
    },
    control: {
      level1: '资金管理',
      level1_1: '资金',
      level2_1: '货币兑换',
      level2_2: '账户转账',
      level2_3: '资金提取',
      level2_4: '资金存入',
      level2_5: '汇款服务'
    },
    query: {
      level1: '我的查询',
      level1_1: '查询',
      level2_1: '我的资产',
      level2_2: '交易记录',
      level2_3: '资金记录',
      level2_4: '证券提存',
      level2_5: '我的结单',
      level2_6: '我的报表'
    },
    seting: {
      level1: '我的设定',
      level1_1: '设定',
      level2_1: '个人资料',
      level2_2: '更改密码',
      level2_3: '密码确认',
      level2_4: '更改信贷额',
      level2_5: '投资者风险取向问卷',
      level2_6: '中华通北向交易同意书'
    }
  },
  //顶部导航栏
  topBar: {
    account: '户名',
    loginOut: '登出',
    userID: '账号',
    checkSetting: '检查我的电脑设定',
    backOld: '返回旧版系统',
    middleman: '经纪人',
    telphone: '直线电话',
    blue: '海通蓝',
    yellow: '贵金色',
    huBlue: '宝石色',
    anhei: '暗黑色',
    notice: '通知',
    contact: '联络我们',
    help: '帮助中心',
    color: '主题色',
    quoteColor: '行情涨跌颜色',
    greenUpColor: '绿涨红跌',
    redUpColor: '红涨绿跌',
    tishi: '您确定是否退出登录?',
    confirm: '确定',
    cancel:'取消'
  },
  //底部版权信息
  bottomBar: {
    company: '©2020海通国际证券集团',
    mianze: '免责声明',
    pernsonInfo: '个人资料私隐政策',
    ji: '及',
    mianzeInfo:
      '免责声明：海通国际证券有限公司、海通国际电子网上服务有限公司、香港交易所资讯服务有限公司、香港联合交易所有限公司及香港期货交易所有限公司及其资料供应商、上海证券交易所及深圳证券交易所尽力确保所提供之资料准确及可靠，但不保证该等资料之准确性或可靠性，亦不对任何因资料不确或遗漏所引致之损失或损害承担任何责任(不论是民事侵权行为责任或合约责任或其他责任)。证券交易平台之内容、新闻及资讯版权均属服务供应商所有，不得向任何人作任何用途之複製、篡改、发佈、发行、散播、宣传、广播或以其它形式传播。'
  },
  //主页
  home: {
    //我的资产
    asset: {
      title: '我的资产',
      total: '合计',
      account: '户口结存',
      available: '可用结存',
      cashTotal: '现金结存',
      purchPower: '购买力',
      stockVal: '证券市值',
      stockHasVal: '证券按仓值',
      explain: '*兑换率(只作参考，最后更新时间',
      cash: '现金',
      aStock: 'A股',
      hkStock: '港股',
      usStock: '美股',
      outsideStock: '场外交易',
      oneMonth: '近一月',
      threeMonth: '近三月',
      halfOfYear: '近半年',
      oneYear: '近一年',
      twoYear: '近两年',
      money: '参考盈亏',
      percent: '盈亏比例'
    },
    //常用功能
    commonFunc: {
      title: '常用功能',
      tradHistory: '交易记录',
      stockPush: '证券提存',
      jiedan: '我的结单',
      baobiao: '我的报表'
    },
    //通知
    notice: {
      title: '通知',
      more: '更多',
      noResult: '暂无通知',
      time: '时间',
      theme: '主题',
      operation: '操作',
      toView: '查看'
    },
    //我的持仓
    volume: {
      title: '我的持仓',
      market: '市场',
      aStock: 'A股',
      hkStock: '港股',
      usStock: '美股',
      outsideStock: '场外市场',
      volumeVal: '持仓市值',
      Profit: '参考盈亏',
      todyProfit: '今日盈亏',
      stock: '股票',
      curPrice: '现价',
      cost: '成本',
      totalNum: '总数量',
      sellNum: '可沽数量',
      stockTodyProfit: '今日盈亏',
      stockProfit: '参考盈亏',
      marketVal: '市值',
      chicangVal: '按仓值',
      operation: '操作',
      sell: '卖出',
      tradHistory: '交易记录',
      noResult: '暂无持仓'
    },
    //新股申购
    ipo: {
      title: '新股申购',
      more: '更多新股',
      rengou: '申购',
      stockPrice: '招股价',
      endDate: '截止申购日期',
      noReulst: '暂无可申购的新股'
    }
  },
  // 登录页
  login: {
    bounced: '阁下的登入密码或登入名称错误', // 错误提示弹框
    bounced1:
      '您的账户已被锁定，请联络海通国际客户服务部，热线电话（852）3583-3388/（86）755 8266 3232',
    bounced2: '您的登入名称未激活。',
    bounced4: '阁下的登入户口暂被停用',
    bounced5:
      '抱歉，「证券网上交易系统」正在进行系统提升。如需下单或查询交易状况，请致电你的经纪人或交易部热线 (852) 2213-8333。如有其他查询，请致电客户服务热线 (852) 3583-3388。',
    bounced6:
      '无法登入网上交易账户为配合监管机构要求，请即登记电邮信箱以接收账户活动通知。 小时交易热线：(852) 2213 8333  客户服务热线：(852) 3583 3388 (香港) / (86) 755 8266 3232 (中国内地) / (86) 755 8266 3232',
    bounced7:
      '系统未能提供服务，请稍后再重试或联络海通国际客户服务部。 热线电话: (852) 3583-3388 / (86) 755 8266-3232[CA SERVER]。',
    bounced8:
      '传送验证码失败。请稍后再重试或联络海通国际客户服务部。热线电话: (852) 3583-3388 / (86) 755 8266-3232。',
    bounced9: '发送验证码太频繁。请稍后再试。',
    bounced10:
      '系统未能提供服务。请联络您的经纪或客户服务部(852) 3583 3388 (香港) / (86) 755 8266 3232 (中国内地)或交易热线(852) 2213 8333。',
    bounced11: '输入旧密码错误',
    bounced12: '您必须更改密码才可以继续',
    bounced13: '密码必须是数字(0-9)+英文字母(A-Z,a-z)之组合，合计8-10位。',
    bounced14:
      '您的网上登入帐户状态特殊，请联络客户服务部以索取网上登入密码。热线电话: (852) 3583-3388 / (86) 755 8266-3232。',
    bounced15:
      '无法重设登入密码﹗为配合监管机构要求，请即登记电邮信箱以接收账户活动通知。 24小时交易热线：(852) 2213 8333 客户服务热线：(852) 3583 3388 / (86) 755 8266 3232。',
    bounced16: '您的密码已重置，请在收到密码信后再登入。',
    bounced17: '阁下的新密码不能与以往所使用的相同。',
    bounced18: '登入记录已失效﹐请重新登入。',
    bounced19: '密码不能为空',
    bounced20: '两次输入密码不一致',
    system: '证券网上交易系统',
    customer: '客户登入',
    name: '名称',
    password: '密码',
    information1: '登录名称必须填写', // 错误提示信息
    information2: '密码必须填写', // 错误提示信息
    ForgetPassword: '忘记密码',
    btn: '登 入',
    Register: '启动流动保安编码注册',
    Unregister: '取消流动保安编码注册',
    Activation: '激活码登入',
    Caution:
      '注意：为免无法使用部分功能，登入前请先暂时关闭电脑内已装置弹出型视窗拦截功能(如：WinXPSP2IE内快显封锁程式、Yahoo工具列、Google工具列、MSN工具列等)。',
    kefu:
      '如客户未能进行网上交易，请致电交易热线 (852) 2213 8333下单。若客户在登入网上交易平台时有任何疑问，可于办公时间致电客户服务热线 (852) 3583 3388或 (86) 755 8266 3232查询。',
    company:
      '海通国际证券有限公司，为一间核准从事证券及期货条例（香港法例第五七一章）中第一类（证券交易）受规管活动之持牌法团（中央编号：AAF806）及香港联合交易所有限公司的交易所参与者。',
    prompt1: '为保障账户安全，本公司建议您定期更改密码，请按指示更改密码。',
    keep: '保留现有密码',
    tishi: '提示'
  },
  // 保安提示弹框
  prompt: {
    title: '手机及平板电脑/桌上电脑交易平台的保安提示',
    content1:
      '1.不要在流动电话或平板电脑/桌上电脑内储存您的海通国际网上交易平台的名称和密码。',
    content2:
      '2.切勿向任何人透露您的个人保安资料（例如户口号码或私人密码），即使有人声称自己是本公司职员或警方人员。',
    content3: '3.避免使用公用的电脑登入海通国际网上交易平台。',
    content4:
      '4.进行网上交易时，需先留意四周环境，切勿让他人得知您所输入的密码；当在任何装置输入密码时，请遮掩按键。',
    content5:
      '5.流动电话或平板电脑/桌上电脑须安装和定期更新防毒软件和防间谍软件。',
    content6:
      '6.避免与他人分享使用流动电话，或使用他人的流动电话或平板电脑/桌上电脑登入海通国际网上交易平台。',
    content7:
      '7.登入网上交易平台后，请不要离开或閒置您的流动电话或平板电脑/桌上电脑。当您使用完网上交易平台后，请谨记登出网上交易平台。',
    content8:
      '8.在转让、出售或循环再用您的流动电话或平板电脑/桌上电脑前，请删除您的旧流动电话或平板电脑/桌上电脑内的所有资料。',
    content9:
      '9.如您遗失流动电话或平板电脑/桌上电脑，请透过网上交易平台查阅账户交易。如发现任何可疑交易，请即致电客户服务热线举报。您亦应立即启动遥控装置删除有关资料及报失流动电话或平板电脑/桌上电脑。',
    content10:
      '10.设立自动上锁和启用密码锁功能，以防止他人在未经许可的情况下使用您的流动电话。',
    content11:
      '11.当使用Wi-Fi无线上网时，请使用可信赖的Wi-Fi无线网络或服务提供者，并启用保安措施，例如尽可能使用Wi-FiProtectedAccess（WPA,一种保护无线电脑网络安全的系统）。',
    content12:
      '12.在毋须使用流动电话或平板电脑/桌上电脑时，请解除蓝芽装置或把蓝芽装置设定为隐藏模式。',
    content13:
      '13.使用流动电话及平板电脑/桌上电脑原厂提供的浏览器，避免安装由其他来源下载的浏览器。',
    content14:
      '14.不应使用已被破解（「破解版」）的手机或平板电脑，以免在登入网上交易平台时出现保安漏洞。',
    content15:
      '15.不要安装来源不明的软件，并在安装软件前清楚有关须知。请不要使用来源不明的虚拟键盘。',
    content16:
      '16.请定时更新您的流动电话或平板电脑/桌上电脑，以及有关的操作系统，并把流动电话或平板电脑/桌上电脑内的资料进行加密。',
    content17: '17.请只在官方应用程式网站下载海通国际流动交易平台。',
    content18: '18.为保安理由，请定期更改密码。',
    content19:
      '19.积极监察您户口的活动，收到月结单后请尽快查阅，若发现有任何不寻常的交易，请立即通知本公司,您可透过海通国际网上交易平台，经常查阅您户口的交易记录。',
    content20:
      '20.当您使用手机短讯收取一次性验证码作爲双重认证登入，切勿设定手机短讯转发。',
    chek: '不再提醒我',
    Close: '关闭'
  },
  // 2FA 页面
  twoFaLogin: {
    // 短讯认证
    phoneLogin: {
      check: '必须填写手机号码',
      check1: '请输入正确的手机号码',
      check2: '必须填写保安编码',
      check3: '请输入正确的保安编码',

      Sms: '短讯认证',
      coding: '流动保安编码认证',
      code: '请输入你于海通国际登记的手机号码收取一次性验证码。',
      phone: '请输入手机号码',
      prompt1:
        '*手机号码毋需提供国家及地区代码。例如，您的手机号码是(86)13912345678，您只需输入13912345678。',
      prompt2:
        '*如阁下未能收到「一次性密码」可转换「一次性密码」的短讯服务供应商，再尝试发送「一次性密码」到阁下登记的手提电话。',
      btn1: '取 消',
      btn2: '确 认',
      supplier1: '短讯服务供应商 1',
      supplier2: '短讯服务供应商 2',
      supplier3: '短讯服务供应商 3',
      supplier4: '短讯服务供应商 4',
      prompt3: '手机号码不正确,请重新登录。'
    },
    // 保安编码认证
    codingLogin: {
      coding1: '请输入6位数字的流动保安编码',
      coding2: '请输入6位数字的流动保安编码',
      bounced1: '系统所需资料错误。'
    }
  },
  // 验证码填写页面
  codeLogin: {
    code: '请输入你于海通国际登记的手机号码所收到的6位数字一次性验证码',
    time: '验证码将于',
    shixiao: '失效。',
    prompt: '请输入一次性验证码', // 提示
    resend: '后重发',
    resend1: '重发',
    no: '没有收到验证码，怎么办? ',
    content1: `1. 一次性验证码的传送速度可能会受网络影响而出现延误，如你在合理时间内仍未能收到一次性验证码，请按「重新发送」。
    2. 如您须更改登记手机号码, 请填妥及签署「更改资料及易结单服务表格」后发予客户经纪或客户服务部跟进。`,
    check1: '必须填写验证码',
    check2: '请输入正确的验证码',
    bounced1:
      '登入渠道失效，请联络海通国际客户服务部。热线电话:(852) 3583-3388 / (86) 755 8266-3232。', // 错误提示弹框
    bounced2:
      '您的网上帐户已被停用，请联络海通国际客户服务部。热线电话:(852) 3583-3388 / (86) 755 8266-3232。',
    bounced3:
      '您的密码信已经作废和重置。请联络海通国际客户服务部。热线电话:(852) 3583-3388 / (86) 755 8266-3232。',
    bounced6:
      '您的验证码尝试次数已经超出限制，您的帐户已被锁定,详情请联络海通国际客户服务部。热线电话:(852) 3583-3388 / (86) 755 8266-3232。',
    bounced7: '您的验证码已失效。请按「重新发送」以收取新的验证码。',
    bounced8: '发送验证码太频繁。请稍后再试。',
    bounced9: '您输入的验证码不正确，请重新输入。',
    bounced10: '验证码发送次数超过限制，请重新登入。'
  },
  // 注册页面
  register: {
    // 弹框
    addDialog: {
      title: '流动保安编码注册',
      content:
        '您尚未注册流动保安编码！请按确定进行注册或按取消收取短讯一次性密码（SMS OTP）。'
    },
    registerCode: {
      name: '登入名称',
      password: '密码',
      phone: '已登记的手机号码',
      email: '已登记的电子邮箱',
      agree: '本人理解并同意接受',
      terms: '使用条款',
      promptName: '请输入登入名称',
      promptPassword: '请输入密码',
      promptPhone: '请输入已登记的手机号码',
      promptEmail: '请输入已登记的电子邮箱',
      check: '必须填写电子邮箱',
      check1: '请输入正确的邮箱地址',
      terms1: '请勾选条款',
      errorMsg1:
        '无法获取登录名称。请稍后再重试或联络海通国际客户服务部。热线电话: (852) 3583-3388 / (86) 755 8266-3232。',
      errorMsg2: '注册流动装置数量超出限制。',
      errorMsg3: '设备已注册。',
      errorMsg4: '首次注册验证码超出发送次数上限。',
      errorMsg5:
        '请输入正确的手机号及电邮地址，如您尚未登记，请联络海通国际客户服务部，热线电话（852）3583-3388/（86）755 8266 3232',
      errorMsg6:
        '暂时未能发送邮件，请稍后再重试或联络海通国际客户服务部。热线电话: (852) 3583-3388 / (86) 755 8266-3232。',
      errorMsg7: '您尚未注册移动认证。',
      errorMsg8: '一次性验证码不正确。'
    },
    success: {
      content1:
        '首次启动程式和启动验证码已发送到您已登记的电子邮箱和流动电话。',
      content2: '请遵循电子邮件中的指示打开链接。',
      content3: '链接打开后，您将被要求输入启动验证码。'
    },
    unregister: {
      title: '取消流动保安编码注册',
      CancelRegister: '确认取消流动保安编码注册？',
      complete: '取消流动保安编码注册完成',
      zaici: '在此设备上注册流动保安编码？'
    }
  },
  // 风险披露页面
  risk: {
    content1: `
    <h4 style="font-family: SourceHanSansCN-Medium;
    font-size: 18px;
    color: #333333;">电子服务风险披露声明</h4>
    1.阁下作为账户持有人为电子服务之唯一授权使用者，将会对本公司发给的交易密码之保密、安全和使用自行承担全部责任。本公司不会就阁下因其他人仕 未经授权使用或尝试使用电子服务可能遭受的任何损失或损害承担责任。
    <br />
    <br />
    2.倘若阁下透过电子交易系统进行交易，阁下将会承受系统相关的风险，包括硬件和软件发生故障的风险。任何系统发生故障的后果可能使阁下的指示不能按其指令执行或者根本没有被执行。
    <br />
    <br />
    3.电子交易的设施是以电脑组成系统来进行交易指示传递、执行、配对、登记或交易结算。然而，所有设施及系统均有可能会暂时中断或失灵，而阁下就此所能获得的赔偿或会受制于系统供应商、市场、结算公司及╱或参与者商号就其所承担的责任所施加的限制。这些责任限制可以各有不同。
    <br />
    <br />
    4.由于无法预计的通讯阻塞或其他原因，电子传送不一定是一种可靠的通讯方法。通过电子工具进行的交易，在传送和接收阁下指示或其他资料时会出现延迟，在执行阁下指示时会出现延迟或以不同于阁下发出指示时的价格执行阁下的指示，通讯设施亦会出现故障或中断。电子传送存在通讯中之误解或错误的风险。
    <br />
    <br />
    5.本公司慎重建议阁下在输入每个指示之前会加以覆核，因为指示一经作出，便可能无法取消。
    <br />
    <br />
    6.本公司不会保证市场数据或任何市场资料(包括透过电子服务提供给阁下的任何资料)的及时性、次序、准确性或完整性。本公司对下述事项所引起或造成之任何损失概不承担任何责任：(1)任何上述数据、资料或信息的不准确性、错误或遗漏；(2)上述数据、资料或信息之传送或交付延误；(3)通讯中断或阻塞；(4)不论是否由于本公司的行为所致之该等数据、资料或信息的无法提供或中断；或(5)本公司无法控制的外力。
    <h4 style="font-family: SourceHanSansCN-Medium;
    font-size: 18px;
    color: #333333;">中国A股交易注意事项：</h4>
    客户在交易中国A股前，必须确保已阅读及明白相关账户条款和条件的互联互通补充文件及风险披露及其他资料，详情可参阅以下内容：
    <br />
    <a style=" font-family: SourceHanSansCN-Medium;
    font-size: 1rem;
    color: #4191ff;
    letter-spacing: 0;
    line-height: 10px;
    border-bottom: 1px solid #4191ff;" href="http://www.htisec.com/sites/default/files/Amendments%20to%20Cash%20Account%20and%20Leveraged%20Foreign%20Exchange%20Trading%20Account%20Terms%20%26%20Conditions_SC.pdf"
    target="_blank">现金账户及槓杆外汇交易账户条款和条件的互联互通补充文件及互联互通风险披露及其他资料</a>
    <br />
    <a style=" font-family: SourceHanSansCN-Medium;
    font-size: 1rem;
    color: #4191ff;
    letter-spacing: 0;
    line-height: 12px;
    border-bottom: 1px solid #4191ff;" href="http://www.htisec.com/sites/default/files/Amendments%20to%20Margin%20Account%20and%20Leveraged%20Foreign%20Exchange%20Trading%20Account%20Terms%20%26%20Conditions_SC.pdf"
    target="_blank">保证金账户及槓杆外汇交易账户条款和条件的互联互通补充文件及互联互通风险披露及其他资料</a>
    <h4 style="font-family: SourceHanSansCN-Medium;
    font-size: 18px;
    color: #333333;">网上美股交易注意事项:</h4>
    本人/吾等明白及同意本「注意事项」的内容：
    <br />
    1.开户及W-8 表格(美国国税局)
    <br />
    如欲使用网上美股交易服务，申请人(非美国公民/居民及非加拿大居民) 于开户时必须填写美国国税局提供的 W-8 表格并须每3年续期一次。拒绝续期将被自动中止服务之使用权，届时客户只可以卖出美股，而账户的出售所得及其它收入必须预扣资本利得税，直至重新递交 W-8 表格。请注意，当投资海外产品时，阁下须遵守当地的税制，并可能会不获豁免美国资本利得税项。阁下亦应视乎情况寻求专业税务意见。查询请联络海通国际客户服务部 (852) 3583-3388 或(86) 755 8266-3232。
    <br />
    <br />
    2.美国税项 (如就所得红利的预扣税)
    <br />
    美国的税制涵盖源于美国的投资产品(不管是可交易证券、互惠基金或债券等)，而投资者无论是否美国公民或永久居民，只要以个人名义持有这些投资产品，均须缴付美国税项。换句话说，所有持有任何形式美国证券的人士，也须就所得红利支付预扣税。
    客户透过本公司收取任何源自美国的收入，如利息或股息，均须为其此等收入缴纳美国税款，因此本公司的美股执行经纪须从付给外国人的收入中预扣最高30%的税款。此外，本公司并不会代表或协助客户向美国税务局申请减免或豁免预扣税。
    阁下应视乎情况寻求专业税务意见。详情请点击证监会以下连结：
    <br />
    <a style=" font-family: SourceHanSansCN-Medium;
    font-size: 1rem;
    color: #4191ff;
    letter-spacing: 0;
    line-height: 12px;
    border-bottom: 1px solid #4191ff;" href="http://www.thechinfamily.hk/web/tc/financial-products/financial-intermediaries/broker/online-trading/trading-process.html"
    target="_blank">(http://www.thechinfamily.hk/web/tc/financial-products/financial-intermediaries/broker/online-trading/trading-process.html)</a>
    <br />
    <br />
    3.结算及託管服务
    <br />
    网上美股交易由 ViewTrade Securities, Inc. 为执行经纪及 APEX Clearing Corporation . 为结算代理人。
    <br />
    阁下需明白海通国际证券有限公司为介绍经纪人及于此安排而引起任何对手风险时会协助客户确定及追讨ViewTrade Securities， Inc. 及APEX Clearing Corporation. 的所有责任及义务。
    <br />
    <br />
    4.服务的提供
    <br />
    (a)   如 阁下之证券账户为保证金账户，网上美股交易服务亦会为阁下提供保证金按仓买卖。详情及利息等信息请参阅海通国际网页<a style=" font-family: SourceHanSansCN-Medium;
    font-size: 1rem;
    color: #4191ff;
    letter-spacing: 0;
    line-height: 12px;
    border-bottom: 1px solid #4191ff;" href="http://www.htisec.com/zh-hk/fees-and-charges"
    target="_blank">http://www.htisec.com/zh-hk/fees-and-charges</a>。
    <br />
    (b)   服务只适用于非美国公民/居民及非加拿大居民。如 阁下之个人资料有任何更改，请联络海通国际客户服务部 (852) 3583-3388 或(86) 755 8266-3232。
    <br />
    (c)   网上美股交易服务只提供于 NASDAQ、NYSE、NYSEMKT 及 BATS 上市之美股买卖交易，服务暂不支持开市前/后交易。于(i) OTC Bulletin Board/OTC BB 及 (ii) OTC Pink (即 NASDAQ、NYSE、NYSEMKT 及 BATS 以外) 交易的美股不支持网上交易服务, 只可致电本公司买入与卖出。
    <br />
    (d)   于(i) OTC Bulletin Board/OTC BB 及 (ii) OTC Pink (即 NASDAQ、NYSE、NYSEMKT 及 BATS 以外) 交易的美股不支持网上交易服务，只可致电本公司买入与卖出。本公司亦不接受交收买入市值低于 5 千万美元及每股股价低于$0.5 美元的美国场外(OTC)股票，如客户仍持有该等美国场外股票并希望卖出，须致电经纪或 24 小时投资服务中心交易热线(电话: (852) 2213-8333)。另外，由于股票价格低于$0.5 美元的美国场外(OTC)股票的交易订单，需通过交易商人工批核才可进入市场，故此通过经纪或交易部落盘所需时间会有所增加。此外，交易商对于批核客户的交易订单有绝对的决定权，所以 阁下的交易订单有可能被拒绝。
    <br />
    (e)   网上美股交易服务免费提供延时美股报价。如需申请实时美国股票报价, 请登入海通国际综合网上服务<a style=" font-family: SourceHanSansCN-Medium;
    font-size: 1rem;
    color: #4191ff;
    letter-spacing: 0;
    line-height: 12px;
    border-bottom: 1px solid #4191ff;" href="https://eservices.htisec.com/"
    target="_blank">https://eservices.htisec.com/</a>。 客户第一次登入网上美股交易服务使用实时美股报价时需填写及递交有关使用者协议。使用者协议只有英文版本，请按此
    <a style=" font-family: SourceHanSansCN-Medium;
    font-size: 1rem;
    color: #4191ff;
    letter-spacing: 0;
    line-height: 12px;
    border-bottom: 1px solid #4191ff;" href="http://www.htisec.com/zh-hk/ real-time-quotes/securities"
    target="_blank">http://www.htisec.com/zh-hk/ real-time-quotes/securities</a>参考填写范例。
    <br />
    <br />
    5.佣金及收费
    <br />
    当指令执行后，客户必须缴付相关佣金及收费，此佣金及收费的更新通知会不时透过海通国际网页<a style=" font-family: SourceHanSansCN-Medium;
    font-size: 1rem;
    color: #4191ff;
    letter-spacing: 0;
    line-height: 12px;
    border-bottom: 1px solid #4191ff;" href="http://www.htisec.com"
    target="_blank">http://www.htisec.com</a>或其他途径发佈。此外，细价股(即股价少于美金1元之股票)及美国预托证券(ADR)等交易会有特别佣金/手续费安排。
    <br />
    <br />
    6.交易时间
    <br />
    美股交易时间为美国东部时间星期一至星期五上午09:30至下午04:00。所有当天未成交之「当日有效单」会在美国东部时间下午04:00收市后无效。
    阁下可于美国东部时间星期一至星期五上午08:00开始输入下单指示 (假期除外)。 下单时请确保 阁下账户持有足够的购买力及持仓， 并于开市后查阅最新之下单状况及账户信息。
    <br />
    <br />
    7.结算日
    <br />
    网上美股交易买卖之交收时间为T+2。未结算之交易所得资金可实时作开新仓之用。
    <br />
    <br />
    8.资金存入/提取
    <br />
    阁下必须于网上户口存入美金或从其它货币兑换成美金，作网上美股交易之用。网上美股交易服务资金(美金)之存入截数时间为香港时间星期一至星期五下午4:30 (公众假期除外)，而货币兑换及资金提出截数时间为香港时间星期一至星期五下午2:00 (公众假期除外)，款项会于当晚美股交易时间前反映。
    <br />
    <br />
    9.户口持仓转拨
    请注意，网上美股交易服务之买卖指示、户口结存、持仓证券等完全独立运作，跟经纪户口分开处理。客户如需将资金/证券持仓等在网上户口及经纪户口之间转拨请于香港时间星期一至星期五下午2:00前发出指示。详情请向阁下经纪或客户服务部查询。
    <br />
    <br />
    10.其他
    <br />
    有关开户及交易详情可参阅开户文件及其它附带文件及其它发佈于海通国际网页<a style=" font-family: SourceHanSansCN-Medium;
    font-size: 1rem;
    color: #4191ff;
    letter-spacing: 0;
    line-height: 12px;
    border-bottom: 1px solid #4191ff;" href="http://www.htisec.com"
    target="_blank">http://www.htisec.com</a>上相关(包括不时更新)的资料。
    <br />
    如欲查询网上美股交易状况， 请于美股交易日香港时间星期一下午6:00至星期六上午6:00致电交易部 (852) 2213-8333。网上服务可能会因应特别节日或个别股票企业活动等暂停服务而不作另行通知。
    <br />
    倘若本注意事项的中文本与英文本在解释或意义方面有任何歧义， 请以英文本为准。
    <h4 style="font-family: SourceHanSansCN-Medium;
    font-size: 18px;
    color: #333333;">即时报价服务之免责声明</h4>
    海通国际证券有限公司、海通国际期货有限公司、海通国际电子网上服务限公司、或其任何控股公司、附属公司或联营公司、其资料供应商、及香港交易所资讯服务有限公司、其控股公司及/或该等控股公司的任何附属公司、上海证券交易所及深圳证券交易所均竭力确保所提供资讯的准确和可靠度，但不能保证其绝对准确和可靠，且亦不会承担因任何不准确或遗漏而引起的任何损失或损害的责任(不管是否侵权法下的责任或合约责任又或其他责任)。证券交易平台之内容、新闻及资讯版权均属服务供应商所有，不得向任何人作任何用途之複製、篡改、发佈、发行、散播宣传广播或以其它形式传播。
    <h4 style="font-family: SourceHanSansCN-Medium;
    font-size: 18px;
    color: #333333;">使用电子服务须知</h4>
    本公司提供的电子服务并不涉及本公司就任何产品作出招揽销售或建议或提供意见，阁下透过电子服务进行的所有交易均以只限执行基准，详情请参阅
    <a style=" font-family: SourceHanSansCN-Medium;
    font-size: 1rem;
    color: #4191ff;
    letter-spacing: 0;
    line-height: 12px;
    border-bottom: 1px solid #4191ff;" href="https://www.htisec.com/sites/all/themes/hitong/files/what-is-news/security_tips_sc.html#es"
    target="_blank"><使用电子服务须知></a> 。
    <h4 style="font-family: SourceHanSansCN-Medium;
    font-size: 18px;
    color: #333333;">关于複杂产品的警告声明</h4>
    
    如阁下进行複杂产品交易 (包括但不限于衍生认股权证、牛熊证、交易所买卖基金、股票挂鈎票据、槓杆及反向产品、期货、股票期权等)，须阅读以下<a style=" font-family: SourceHanSansCN-Medium;
    font-size: 1rem;
    color: #4191ff;
    letter-spacing: 0;
    line-height: 12px;
    border-bottom: 1px solid #4191ff;" href="https://www.htisec.com/sites/all/themes/hitong/files/what-is-news/security_tips_sc.html#cp "
    target="_blank">关于複杂产品的警告声明</a>才可进行交易。
    <br />
    <br />
    `,
    content2: `<a style=" font-family: SourceHanSansCN-Medium;
    font-size: 1rem;
    color: #4191ff;
    letter-spacing: 0;
    line-height: 12px;
    border-bottom: 1px solid #4191ff;" href="http://www.htisec.com/trading/help_menu/help_gb/order.html#pre-mkt"
    target="_blank">交易时段及买卖盘指示功能</a>
     及 <a style=" font-family: SourceHanSansCN-Medium;
     font-size: 1rem;
     color: #4191ff;
     letter-spacing: 0;
     line-height: 12px;
     border-bottom: 1px solid #4191ff;" href="http://www.htisec.com/trading/help_menu/help_gb/order.html#special"
     target="_blank">发盘种类及定义</a>`
  },
  // 联络我们页面
  newContact: {
    title: '联络我们',
    content1: '客户服务热线:',
    content2: '中国客户热线:',
    content3: '电邮查询:'
  },
  // 帮助中心页面
  newHelp: {
    link1: '1.是否必须设定浏览器接受cookies?',
    link2: '2.为何浏览器会自动记忆我的个人户口号码及密码?',
    link3: '3.若需要与别人共用电脑，请问应如何保障个人资料?',
    link4: '4.保护账户资料有何秘诀？',
    link5: '5.更改/取消交易要注意些什么？',
    content1: '是否必须设定浏览器接受cookies?',
    content2: '是，阁下必须将浏览器设定至接受cookies',
    content3: '为何浏览器会自动记忆我的个人户口号码及密码?',
    content4:
      '这是浏览器内「自动完成」的功能。为避免当您键入用户名称时，电脑会自动完成您的密码输入，您应取消浏览器的「自动完成」功能。',
    content16:
      '在Internet Explorer浏览器中，这个「自动完成」功能会储存您过去曾经就网址、表格和密码所输入的资料，然后当您再一次键入这些资料时，「自动完成」功能就会提议可能的配对资料。因此为确保您的户口资料获得适当保护，您应取消浏览器的「自动完成」功能，以避免当您键入用户名称时，电脑会自动完成您的密码输入。要取消「自动完成」功能，请在浏览器内按一下「工具」，按一下「Internet选项」，按一下「内容」，然后按一下「自动完成」按钮，最后取消「表单上的使用者名称和密码」功能。',
    content5: '若需要与别人共用电脑，请问应如何保障个人资料?',
    content6:
      '为了保障您个人户口的资料，请紧记当您登出网上服务后必须删除浏览器内的临时档桉并关闭浏览器。',
    content7: '保护账户资料有何秘诀？',
    content8:
      '我们建议各电子交易服务用户应该採取以下程序，以维持高度安全标准：',
    content9: '•  定期透过网页更改用户密码。',
    content10: '•  切勿向任何人透露密码。',
    content11:
      '•  设定一个容易记得但别人难于以猜测的密码，请勿用重覆数字、出生日期、电话号码或身份证号码来做密码。',
    content12:
      '•  完成网上交易后便退出互联网浏览器，有助避免其他人使用回到前一页」的功能来阅览阁下的账户资料。',
    content13:
      '•  经常键入网址(www.htisec.com)或使用阁下建立之位址连接来浏览海通国际网页。',
    content14: '更改/取消交易要注意些什么？',
    content15:
      '未能即时成交的增强限价盘将成为相同价格的限价盘，更改增强限价买／卖盘时只可输入不高于卖出／不低于买入盘的最佳价格，否则系统将拒绝有关更改．',
    content16:
      '若客户不需要减少交易数量，则毋须更改『最终交易数量』内的数值。最终交易数量应是未完成数量+已成交数量，即系统已自动填入的数量。更改/取消后, 请在「交易状况」按<<重新整理>> 以检视最新交易状况。 更改/取消指令未必被市场接受, 故请阁下留意更新后的交易价及交易状态, 以确定更改是否已成功:',
    content17:
      '1.	「交易状况」中 「状态」出现" * "符号, 表示曾经成功更改交易/取消交易。',
    content18:
      '2.	「交易状况」中 「状态」出现" # "符号, 表示最新更改/取消已被拒绝，未能修改交易股价或数量。',
    content19:
      '3.	「交易状况」中 「状态」出现" @ "符号, 表示最新更改/取消指令正在进行中。'
  },
  //证券交易菜单
  security: {
    // 港A美股
    mainMarket: {
      hkTrading: '港股交易',
      chinaTrading: 'A股交易',
      usTrading: '美股交易',
      refresh: '刷新',
      actionExplain:
        '注意事项：阁下于交易日上午九时二十九分或以前透过电子交易系统传送交易指示，该交易指示可能存在相比阁下或其他客户于上午九时三十分后(香港联合交易所有限公司开市时间)所传送的交易指示较迟被执行之风险，敬请留意。(只适用于港股交易)。',
      //自选股
      watchlists: '自选股',
      stock: '股票',
      prc: '价格',
      prcentChg: '涨跌幅',
      chg: '涨跌额',
      //行情图表
      chart: '行情图表',
      date: '行情数据',
      trading: '交易中',
      minK: '分时',
      addUseStock:'加入到自选股',
      removeUseStock:'移出自选股',
      fiveDate: '五日',
      dateK: '日K',
      weekK: '周K',
      monK: '月K',
      Unopened: '未开盘',
      Trading: '交易中',
      Closed: '已收盘',
      Normal: '正常',
      LimitUp: '涨停',
      LimitDown: '跌停',
      Suspend: '停牌',
      Delisted: '退市',
      IPOPeriod: 'IPO期间',
      AuctionSession: '集合竞价',
      LunchBreak: '午间休市',
      MarkerClosed: '休市中',
      Actual: '不复权',
      AdjFwd: '前复权',
      AdjBwd: '后复权',
      updateTime: '更新时间',
      linkName1: '沪深A股及港股实时基本市场行情',
      alink1: 'http://www.htisec.com/zh-cn/bmp',
      aExplain1:
        '由香港交易所、上海证券交易所及深圳证券交易所提供。美股上日收市价由Orbis提供。',
      linkName2: '(免责申明)',
      alink2: 'http://www.htisec.com/zh-cn/disclaimer-bmp',
      zuigao: '最高',
      jinkai: '今开',
      zuidi: '最低',
      zuoshou: '昨收',
      chenjiaoe: '成交额',
      chenjiaoliang: '成交量',
      shiyinglv: '市盈率',
      xinshijia: '行使价',
      shouhuijia: '收回价',
      shangxianjia: '上限价',
      xiaxianjia: '下限价',
      daoqiri: '到期日',
      meishou: '每手',
      pingjunjia: '平均价',
      shijinlv: '市净率',
      shizhi: '市值',
      huanshoulv: '换手率',
      zhengfu: '振幅',
      liangbi: '量比',
      waipan: '外盘',
      neipan: '内盘',
      weibi: '委比',
      fiveWeekHight: '52周最高',
      fiveWeekLower: '52周最低',
      yijia: '溢价',
      yishenbofu: '引申波幅',
      duichongzhi: '对冲值',
      jiehuobi: '街货比',
      huangubili: '换股比率',
      gangganbili: '杠杆比率',
      jianeijiawai: '价内/价外',
      dahedian: '打和点',
      zuihoujiaoyiri: '最后交易日',
      leibie: '类别',
      lengjinjia: '冷静期参考价',
      lengjinshanxian: '冷静期价格上限',
      lengjinxiaxian: '冷静期价格下限',
      lengjinBshijian: '冷静期开始时间',
      lengjinEshijian: '冷静期结束时间',
      shoushijingjia: '收市竞价参考价',
      shoushishangxian: '收市竞价价格上限',
      shoushixiaxian: '收市竞价价格下限',
      bupinghengliang: '不平衡数量',
      bupinghengfangxiang: '不平衡方向',
      //交易状况
      orderStatus: '交易状况',
      export: '汇出今天成交记录至Excel',
      print: '列印',
      status: '状态',
      all: '全部',
      completed: '已成交',
      queuing: '挂盘中',
      canceled: '已取消',
      noRecords: '无记录',
      action: '操作',
      ordNo: '交易编号',
      buy: '买',
      sell: '卖',
      num: '数量',
      sellNum: '成交量',
      amd: '更改',
      del: '取消',
      buys: '买入',
      guchu: '卖出',
      sells: '卖出',
      explain:
        '*曾成功更改/取消交易  #曾失败更改/取消交易  @更改/取消指令正在进行中',
      //交易状况弹出框内容
      explain1: '曾成功更改/取消交易',
      explain2: '曾失败更改/取消交易',
      explain3: '更改/取消指令正在进行中',
      tradDetail: '交易详情',
      tradExplain: '*未能即时成交的增强限价盘已被转成为相同价格的限价盘',
      account: '户口编号',
      tradId: '交易编号',
      tradStatus: '交易状态',
      detail: '详情',
      tradType: '交易类型',
      market: '市场',
      tradPrice: '交易价',
      condition: '停损/触发条件',
      orignNum: '原交易数量',
      changeNum: '改变/取消数量',
      chejiaojiage: '成交价格',
      sellTotalNum: '成交数量',
      jiaoyiduishou: '交易对手',
      noComplateNum: '未完成数量',
      expired: '到期日',
      refusReson: '拒绝原因',
      aon: '全额或等待',
      channel: '媒介',
      changeTip: '更改交易指示',
      confirmChange: '*确认更改/取消指示前注意',
      chufaPrice: '触发价',
      targePrice: '目标交易股价',
      lastTradNum: '最终交易数量',
      password: '密码',
      placeholder: '请输入密码',
      cancelTradTip: '取消交易提示',
      confirm: '确认',
      //交易面板
      buyAllMoneyHK:'是次买入上限',
      type: '类型',
      code: '代码',
      nums: '数量',
      maxBuy: '最大可买',
      maxSell: '最大可卖',
      aon1: '全额或取消',
      aon2: '全额或等待',
      type1: '增强/竞价限价盘',
      type2: '限价盘',
      type3: ' 竞价盘',
      type4: '特别限价盘',
      type5: '条件指示盘',
      price1: '跟市价',
      price2: '跟买一',
      price3: '跟卖一',
      condition1: '>=升穿',
      condition2: '<=跌穿',
      whole: '全仓',
      custormId: '券商客户编码',
      tiaojian: '条件',
      price: '股价',
      tradMoney: '交易金额',
      costMoney: '参考佣金及费用',
      duiyinzhi: '港币对应值',
      cost1: '参考佣金',
      cost2: '结算费',
      cost3: '交易征费',
      cost4: '厘印费',
      cost4: '交易费',
      cost5: '合计',
      costExplain:
        '*以上显示的佣金及交易费用只供参考。参考佣金是以交易金额乘以0.15%。请查阅你的日结单了解实际佣金及交易费用。',
      usExplain1: '*參考佣金按成交金额0.15%计算。',
      usExplain2: `*ESS收费是按每个交易每只股票的每边交易收取（适用于美股参考名单：<a class="activeTagColor" target="_blank" href="http://www.viewtrade.com/ess">http://www.viewtrade.com/ess</a>）。`,
      usExplain3:
        '*只适用于《场外柜台交易系统 OTCBB》、《美国粉红单市场 Pink Sheet》及《BATS 交易所》之交易并买入或卖出多于100,000股细价股股票（细价股票价格低于美元 1 元之股票）。',
      usExplain4: '所有费用仅供参考。 详情请参阅收费表及账户结单。',
      totalPrice: '总金额',
      noMoneyExplain: '现金余额不足，可通过账户转账或资金存入补充现金',
      accountTrans: '账户转账',
      assetInput: '资金存入',
      success: '下单成功',
      sucTip: '请记录阁下的交易编号',
      //股票结存
      stockPosition: '股票结存',
      marketVal: '持仓市值',
      profitLoss: '参考盈亏',
      profitToday: '今日盈亏',
      curPrice: '现价',
      costPrice: '成本',
      totalNum: '总数量',
      canSellNum: '可沽',
      jinriyingkui: '今日盈亏',
      cankaoyingkui: '参考盈亏',
      shizhi: '市值',
      ancanzhi: '按仓值'
    },
    // 其他市场
    otherMarket: {
      headTitle: '日本东京',
      headTitle1: '南韩首尔',
      headTitle2: '中国台北',
      service: '电话落盘服务: ',
      phone: '请致电交易部，电话: ',
      time: '交易时间（香港时间）:',
      time1: '上午交易时段',
      time2: '上午9时至下午1时30分',
      time3: '下午交易时段',
      time4: '上午11时30分至下午2时',
      time5: '上午8时至下午2时',
      time6: '上午9时至下午1时30分',
      date: '交收日:',
      commission: '佣金及收费:',
      content: '请参考',
      link: '海通国际网站',
      content1: '或联络阁下经纪了解详细情况。',
      exchange: '外币兑换:',
      info:
        '阁下只需提出外币兑换指示，我们便会为您办理手续。有关汇率将以银行最后确认是项兑换之汇率为准。',
      query: '外汇查询',
      reference: '* 兑换率只作参考 ',
      updateTime: '最后更新时间',
      conversion: '转 换'
    },
    // 新股申购
    ipoSubscriptions: {
      list: '新股列表',
      stock: '股票',
      price: '招股价',
      date7: '截止申购日期',
      state: '申购状况',
      details: '新股详情',
      accept: '接受申请',
      accept2: '不接受申请',
      suspended: '暂停',
      jiaoYiSuo: '交易所',
      currency: '货币',
      commission: '经纪佣金',
      huiFei: '证监会交易征费',
      huiFei1: '投资者赔偿征费',
      jiaoYiFei: '联交所交易费',
      zaFei: '杂费',
      date: '发行人退票日',
      date1: '股票托收日期',
      date2: '上市交易日',
      sharesNumber: '每手股数',
      way: '申购方式',
      cash: '现金申购',
      date3: '截止申请日期',
      date4: '截止付款日期',
      date5: '付款扣除日期',
      poundage: '手续费',
      subscribe: '融资申购',
      date6: '计息日期',
      interestRate: '利率',
      amount: '最低融资金额',
      proportion: '最高融资比例',
      btn: '申购',
      cash1: '现金',
      margin: '融资',
      cashMargin: '现金/融资',
      jieshou: '接受申请',
      bujieshou: '不接受申请',
      zanting: '暂停',
      popover: {
        title: '新股申购申请',
        headInfo: '申购详细资料查阅',
        headLink: '招股章程',
        headLink1: '申请股数一览表',
        sharesNumber: '申请数量',
        proportion: '融资比例',
        amount: '申购金额',
        chekTitle: '请选择下列事项作出确认',
        chekInfo1: '本人/我们陈述及保证本人/我们符合申购证券资格。',
        chekInfo2:
          '本人/我们确认本人/我们已获提供充足的机会接触有关的招股章程及当中所披露的信息。',
        chekInfo3:
          '本人/我们已阅读及明白本网站所载列有关申购证券的条件及条款及申请程序，并同意受其所约束。',
        chekInfo4:
          '本人/我们清楚及明白申请一经提交，便可能无法推翻、更改或撤回。',
        chekTitle2: '免费申购结果公布提示信息',
        details: '详情',
        detailsInfo:
          '发行人公布公开发售申请结果当日下午，海通国际证券将所获成功配发给阁下之证券数量拨归于阁下在海通国际证券维持的电子证券买卖户口内，届时海通国际证券将免费发出提示信息通知阁下申购结果已经可在电子户口查询，请选择提示信息方法以接受申购结果公布的提示信息(提示信息将会根据阁下于海通国际证券登记的电邮地址或手机号码发出)。',
        notice: '电子邮件通知',
        notice1: '手机短讯通知',
        submitInfo: '申购申请已提交',
        btn: '新股申购查询'
      },
      prospectus: {
        title: '招股章程',
        content: '如何查阅招股章程“testing3”：',
        content1: '1.可浏览于香港交易所网页内电子版招股书：',
        content2: 'a.登入香港交易所网站',
        content3: 'b.于“投资者”栏下， 按“上市公司讯息搜寻”。',
        content4:
          'c.在股份代号索引中，于“股份代号”内输入“ 6789”，再在右方选取“招股文件”后再按搜寻即可。',
        content5:
          '2.如欲亲身前往任何一间收票银行之分行，分行详情刊载于发行人发出之报章通告。',
        content6:
          '警告：任何非根据上述指示位置所浏览得的有关是次公开发售股份的资料，并非公开招股文件的内容。是次公开发售之股份只根据公开招股文件的内容发售。',
        content7:
          '注意：阁下需要安装Acrobat Reader，以作下载招股文件的PDF档案之用。',
        link: 'https://sc.hkex.com.hk/TuniS/www.hkex.com.hk/?sc_lang=zh-cn'
      },
      prospectusForm: {
        number: '数量',
        amount: '金额'
      }
    },
    // 公司行动
    corporateAction: {
      title: '公司行動',
      list: '公司行动列表',
      market: '市场',
      stock: '股票',
      type: '类型',
      date: '回复截止日期',
      date1: '预计支付日期',
      state: '回复状态',
      yihuifu: '已回复',
      weihuifu: '未回复',
      xianjinguxi: '现金股息',
      gupiaoguxi: '股票股息',
      details: '公司行动详情',
      code: '参考编号',
      dividend: '每股股息',
      newShares: '收取新股价',
      describe:
        '根据上述公司宣布，股东有权就有关股息作出以下选择。请在网上填妥并提交下列指示，或者填妥指示函件，并必须于2018年08月18日前寄回本公司交收部或传真至（852）2537 7647 或致电经纪人/分行。若届时未接获阁下回复，或指示未填写清楚，则本公司将代为收取全部现金股息。',
      describe1:
        '根据上述公司宣布，股东有权就有关股息作出以下选择。请在网上填妥并提交下列指示，或者填妥指示函件，并必须于2018年08月18日前寄回本公司交收部或传真至（852）2537 7647 或致电经纪人/分行。若届时未接获阁下回复，或指示未填写清楚，则本公司将代为全部收取股票股息。',
      info:
        '*倘阁下沿用原设之长期指示，则毋须就是次派息回复本公司。否则，请网上填妥并提交下列指示，或者填妥指示函件。',
      info1: '对于更多信息关于以上公司行动，请浏览香港交易所网页',
      info2: '之投资服务中心“上市公司讯息搜寻”。',
      info3: '本人/吾等根据上述事项通知贵公司：',
      info4: '持有可获配股息之股数：',
      info5: '全部现金',
      info6: '港元',
      info7: '人民币',
      info8: '美元',
      info9: '全部新股',
      info10: '部分现金及部分新股',
      info11: '选择收取现金股息之股数',
      info12: '选择收取新股股息之股数',
      tijiao: '提交',
      successInfo: '您的公司行动指示已经受理成功。',
      successInfo1: '您可以通过“公司行动记录查询”功能查询详情。',
      btn: '公司行动记录查询'
    },
    // 按仓比率
    marginFinancingRatios: {
      ganggu: '港股',
      hugutong: '沪股通',
      ganggutong: '港股通',
      meigu: '美股',
      ratio: '孖展比率',
      operation: '操作',
      maimai: '买卖',
      noRecord: '沒有符合查询的资料',
      stock: '股票'
    }
  },
  //资金管理菜单
  cash: {
    //货币兑换
    fxConversion: {
      zhishi: '货币兑换指示',
      explain1:
        '*本平台提供的服务只为便利客户处理交易和/或任何其他相关交易活动和/或结算，包括但不限于使用该海通账户及/或其他海通账户中产生的费用和收费。',
      explain2: '*平台中的「CNY」符号是指离岸人民币的相关报价。',
      sell: '卖出',
      accountName: '户口名称',
      accountNum: '户口',
      market: '市场',
      money: '金额',
      buy: '买入',
      duihuanDate: '兑换日期',
      query: '查询',
      mianze: '免责声明',
      mianzeContent1:
        '海通国际证券集团有限公司及其子公司及其职员，代表或代理人（“海通”）对您因访问、使用或无法访问或无法使用本平台及其提供的服务而造成的任何损失，损害或伤害不承担任何责任；除非海通通过本平台提供服务时存在欺诈或故意不当行为。',
      mianzeContent2:
        '您清楚明白亦接受使用服务时或会出现传输延迟或失败、以电子方式进行的任何传输中断或停顿；您同意海通不对此类或任何由此造成的损失，损害或伤害承担责任。',
      mianzeContent3:
        '本平台提供的信息和材料不构成出售要约或征求购买任何货币的要约，且不得被依赖作出任何投资决策。 必要时请谘询独立建议。',
      huilv: '参考汇率',
      duichu: '预计兑出',
      duiru: '预计兑入',
      duihuanlv: '兑换率（只作参考，最后更新时间',
      duihuanExplain:
        '籍递交兑换指示，阁下表明已同意受附于现金/保证金账户使用条款和细则中货币兑换服务的相关条款约束，并确保是次兑换符合兑换资格。',
      password: '密码',
      change: '更改',
      confirm: '确认',
      duihuanSuccess: '兑换指示已经接收成功',
      bianhao: '请留意并记录您的参考编号',
      duihuanjilu: '查看兑换记录',
      print: '列印',
      jiecunTotal: '货币结存汇总表',
      allMarket: '所有',
      hkAUSAsotck: '香港，中国A股，美国及场外市场',
      cnBStock: '中国B股',
      otherMarket: '其它市场',
      date: '日期',
      sellMoney: '请输入卖出金额',
      buyMoney: '请输入买入金额',
      formCheck1: '请输入卖出货币或者买入货币。',
      formCheck2: '请输入正确的卖出金额，最多输入2位小数。',
      formCheck3: '请输入正确的买入金额，最多输入2位小数。',
      formCheck4: '卖出货币和买入货币只能输入其中一个',
      formCheck5: '卖出货币与买入货币不可以相同'
    },
    //账户转账
    fundTransfer: {
      chuzhangAccout: '出账户口',
      chuzhangzhanghu: '支账账户',
      chuzhangRequire: '请选择支账账户',
      marketAndCurrency: '市场及货币',
      marketRequire: '请选择市场及货币',
      money: '转账金额',
      moneyPlaceholder: '请输入金额',
      ruzhang: '入账户口',
      zhanghuType: '账户类别',
      zhanghuTypeRequire: '请选择账户类别',
      accoutType1: '证券',
      accoutType2: '期货',
      ruzhangAccount: '入账账户',
      ruzhangRequire: '请选择入账账户',
      market: '市场',
      marketRequire: '请选择市场',
      zhengquanMarket1: '香港，中国A股，美国及场外市场',
      zhengquanMarket2: '中国B股市场',
      zhengquanMarket3: '其他市场',
      qihuoMarket1: '本地市场',
      qihuoMarket2: '海外市场',
      nextStep: '下一步',
      zhuyi: '注意事项',
      zhuyiinfo1: '1.转账服务时间为港股交易日上午9时至下午5时。',
      zhuyiinfo2: '2.转账服务适用于证券及期货账户。',
      zhuyiinfo3: '3.接受港元、美元及人民币转账指示。',
      zhuyiinfo4:
        '4.如于转账指示发出当日有任何交易，有关之交易佣金及其他收费可能尚未被扣除，请预留足够款项以免账户出现结欠，并导致利息产生。',
      heshi: '转账核实',
      heshiinfo: '请核实一下数据并按「确认」。如需更改数据，请按「更改」。',
      password: '密码',
      change: '更改',
      confirm: '确认',
      zhishi: '转账指示已接收',
      bianhao: '请记录阁下的参考编号',
      zhanghujiecun: '查看账户结存',
      print: '列印',
      formCheck1: '转账金额错误',
      formCheck2:
        '阁下指示的转账金额错误，正确的金额应为HKD 1元至1,000,000,000元之间（WC7001）REF：WEB001-1594104449990-20',
      formCheck3: '此功能不适用于此账户。'
    },
    //资金提取
    fundWithdrawal: {
      tikuanzhanghu: '提款账户',
      koukuanzhanghu: '扣款账户',
      market: '市场',
      zhengquanMarket1: '香港，中国A股，美国及场外市场',
      zhengquanMarket2: '中国B股市场',
      zhengquanMarket3: '其他市场',
      tiquMoney: '提取金额',
      tiquPlaceholder: '请输入金额',
      cunruzhanghu: '存入账户',
      bankZhanghu: '银行账户',
      nextStep: '下一步',
      zhuyi: '注意事项',
      zhuyiExplain1: '1、提取资金服务时间为港股交易日上午9时至下午5时。',
      zhuyiExplain2:
        '2、下午2时前发出的提款指示会于即日处理。下午2时后提交的提款指示会于下一个工作天处理。',
      zhuyiExplain3:
        '3、请确保所登记的银行户口号码正确及可接受存款之用。如需协助，请致电客户服务热线 (852) 3583-3388 / (86) 755 8266-3232。',
      zhuyiExplain4: '4、只接受港元提款指示。',
      zhuyiExplain5:
        '5、如于提款指示发出当日有任何交易，有关之交易佣金及其他收费可能尚未被扣除，请预留足够款项以免账户出现结欠，并导致利息产生。',
      tiquTitle: '资金提取',
      tiquTip: '请核实一下数据并按「确认」。如需更改数据，请按「更改」',
      zhishi: '指示',
      password: '密码',
      zhizhangzhanghu: '支账账户',
      ruzhangzhanghu: '入账账户',
      change: '更改',
      cofirm: '确认',
      confirmSuccess: '我们已收到你的预设指示。',
      bianhao: '请记录阁下的参考编号',
      ticunjilu: '查看提存记录',
      print: '列印',
      formCheck1: '提取金额必须填写',
      formCheck2: '提取金额不正确',
      formCheck3:
        '阁下指示的提取金额错误，正确金额应为HKD1元至1,000,000,000元之间（WC7001）REF：WEB001-1594108496248-22'
    },
    // 汇款服务
    remittanceServices: {
      nav1: '账户资料',
      nav2: '申请资讯',
      icbc: '可申请开通银行之服务：中国工商银行（亚洲）',
      methods: '申请办法',
      content2: '客户可联络经纪人索取《申请表》并填写以下资料:',
      content3: '·海通国际证券账户名称',
      content4:
        '·英文(汉语拼音)姓名 (英文姓名拼音必须正确无误, 如需协助, 请联络阁下经纪人)',
      content5: '·海通国际证券账户号码',
      content6: '·手机号码',
      content7:
        '填妥表格后, 请交还阁下经纪人进行申请。上述账户开启后, 会以短讯形式通知阁下之境外汇款账户号码。',
      remittance: '成功申请后如何进行转账汇款?',
      content8:
        '内地客户可到中国内地主要商业银行柜台向香港工商银行（亚洲）进行汇款。汇款时请正确填写收款方资料：',
      content9:
        '收款银行选择：Industrial and Commercial Bank of China (Asia) Limited (需填写英文)',
      content10: '户口号码填写：在海通国际证券开通的工商银行境外汇款账户号码',
      content11: '户口持有人姓名填写：申请服务时填写的英文姓名（拼音）',
      content12:
        '收款银行地址请填写：33/F, ICBC Tower, 3 Garden Road, Central, HK (需填写英文)',
      content13: 'SWIFT code: UBHKHKHH',
      attention: '注意事项:',
      content14: '境外汇款将收取一定费用，请参考相关银行资料：',
      content15: '汇款到账时间以银行处理进度为准。',
      content16: '内地汇款金额受外管局限额限制，请参考国家有关规定。',
      boc: '申请开通银行之服务：中国银行（香港）有限公司',
      content17:
        '内地客户完成以下申请后，便可前往任何一家国内银行办理境外汇款，简单方便。',
      methods2: '申请办法',
      content18: '客户可联络经纪人或海通国际网站索取《申请表》并填写以下资料:',
      content19: '海通国际证券账户名称',
      content20:
        '英文(汉语拼音)姓名 (英文姓名拼音必须正确无误, 如需协助, 请联络阁下经纪人)',
      content21: '海通国际证券账户号码',
      content22: '手机号码',
      content23:
        '填妥表格后, 请交还阁下经纪人进行申请。上述账户开启后, 会以短讯形式通知阁下之境外汇款账户号码。',
      remittance2: '成功申请后如何进行转账汇款?',
      content24:
        '内地客户可到中国内地主要商业银行柜台向中国银行（香港）有限公司进行汇款。汇款时请正确填写收款方资料：',
      content25: '收款银行选择：Bank of China (Hong Kong) Limited (需填写英文)',
      content26: '户口号码填写：在海通国际证券开通的中银香港境外汇款账户号码',
      content27: '户口持有人姓名填写：申请服务时填写的英文姓名（拼音）',
      content28:
        '收款银行地址请填写：Bank of China Tower, 1 Garden Road, Central Hong Kong (需填写英文)',
      content29: 'SWIFT code: BKCHHKHH',
      attention2: '注意事项:',
      content30: '境外汇款将收取一定费用，请参考相关银行资料：',
      content31: '汇款到账时间以银行处理进度为准。',
      content32: '内地汇款金额受外管局限额限制，请参考国家有关规定。',
      dahSing: '可申请开通之银行服务: 大新银行',
      content33:
        '内地客户完成以下申请后，便可前往国内银行办理滙款或经中国大新银行网银实时汇款至香港大新银行个人账户。',
      methods2: '申请办法',
      content34: `客户可在开立大新银行综合理财账户期间一併登记香港大新银行网上理财转账服务至海通国际于香港大新银行之账户。客户亦可自行于香港大新银行网页(<a  href="http://www.dahsing.com"
    target="_blank" style='color: #4191ff;
    border-bottom: 1px solid #4191ff;'>www.dahsing.com</a>)下载登记表格，填妥后并寄回香港大新银行办理申请。`,
      content35:
        '有关办理开户手续或办理汇款手续详情, 客户可致电以下之大新银行客户服务热线查询:',
      content36: '国内: +86 400 882 8893',
      content37: '香港: +852 2828 8000',
      content38: '香港中区分行: +852 2521 8134',
      attention3: '注意事项:',
      content39: '1.综合理财账户接受港币及美元汇款。',
      content40: '2.境外汇款将收取一定费用，请参考相关银行资料。',
      content41: '3.内地汇款金额受外管局限额限制，请参考国家有关规定。',
      content42: '4.申请人须已在中国大新银行内地分行开立贵宾或以上账户。'
    },
    // 资金存入
    ePayment: {
      eps: {
        content1:
          '由即日起，客户可利用「易办事」于海通国际证券上环客户服务中心及本港各间分行缴交证券及恒生指数期货买卖的款项，每日处理高达港币五万元的帐项，免除客户到银行或开发支票之繁複程序，方便快捷。',
        content2:
          '「易办事」服务在香港为一盛行已久的电子缴费系统，透过银行来实现客户贸及公司的联系。因此，客户在办理证券买卖缴费时，可直接由自己的银行户口付款至海通国际证券的银行户口，当中并无涉及任何现金提存。整个交易过程得以简化，安全程度亦因而提高，无论本公司、客户甚至银行也都一同受惠。',
        content3: '如有任何查询，请致电客户热线 (852) 3583-3388 ',
        btn: '返回',
        information1: ' 以',
        link: '易办事',
        information2: 'EPS于各海通国际各分行缴款。',
        information3: '不适用于澳门分行。'
      }, // 易辦事
      fps: {
        information1: '利用',
        link: '「快速支付系统」(「转数快」) ',
        information2:
          '转账, 交易日 9:00am – 4:00pm 预计2小时内到账，其他时段及非交日预计下一工作日11:00am前到账，费用全免。',
        information3:
          '是香港金融管理局(「金管局」)於2018年推出的支付金融基建，由香港银行同业结算有限公司负责运作，在香港以不同货币(港元及人民币)进行支付，全日24小时提供安全、有效率及便捷的支付服务。'
      }, // 转数快
      easyRevolutions: {
        link1: '「易转数」',
        information1: '服务适用于所有使用透过',
        link2: 'www.htisec.com',
        information2: '使用网上',
        link3: '「缴费灵」',
        information3:
          '作转账的海通国际证券客户。在服务时间内所作之转账，款项将',
        red: '即时',
        information4: '存至证券户口。',
        information5: '进行网上买卖而遇上金额不足时，透过',
        link4: 'www.htisec.com',
        information6: '的',
        link5: '「易转数」',
        information7: '服务以网上',
        link6: '「缴费灵」',
        information8: '户口作',
        red1: '即时',
        information9: '转账，立即可传送买卖指令。'
      }, // 易转数
      pps: {
        information1:
          '电话缴费灵用户于服务时间内致电18033，以五位数字密码登入并选择「海通国际证券」商户编号',
        red1: '9218',
        information2: '进行转账，款项将于',
        red2: '下一交易日',
        information3: '存入证券户口。',
        information4:
          '「缴费灵」用户如已设「缴费灵」八位数字网上密码，可于服务时间内透过',
        link1: 'www.ppshk.com',
        link: 'https://www.ppshk.com/index_c.html',
        information5: '进行转账，款项将于',
        red3: '下一交易日',
        information6: '更新至证券户口。'
      }, // 缴费灵
      boc: {
        information1:
          '利用中国银行(香港)服务于网上转账，必须从海通国际网上交易内「',
        link1: '中国银行(香港)智达银行服务',
        information2: '」登入，以取得足够资料完成',
        red: '即时',
        information3: '转账过程。'
      }, // 中国银行
      hsbc: {
        information1: '于',
        link1: '汇丰银行网上理财服务网页',
        link3: 'https://www.hsbc.com.hk/zh-cn/index/',
        information2: '「',
        information3: '银行服务',
        information4: '」以「',
        information5: '缴付账单',
        information6: '」缴费。',
        information8: '',
        link2: '按此',
        link4:
          'http://gb.htisec.com/gb/www.htisec.com/tc/cs/payment.jsp#select3',
        information7: '参阅缴费详情。'
      }, // 汇丰银行
      hsb: {
        information1: '于恆生银行网页内之「',
        link1: '恆生e-Banking',
        link3: 'https://www.hangseng.com/zh-cn/home/',
        information2: '」,以「',
        information3: '查阅及缴付账单',
        information4: '」缴费。',
        information6: '',
        link2: '按此',
        link4:
          'http://gb.htisec.com/gb/www.htisec.com/tc/cs/payment.jsp#select3',
        information5: '参阅缴费详情。'
      }, // 恒生银行
      scb: {
        information1: '于',
        link: 'https://www.sc.com/hk/zh/',
        link1: '渣打网上理财',
        information2: '之「',
        information3: '户口转账服务',
        information4: '」下的「',
        information5: '电子缴费',
        information6: '」内付款，款项将于下一交易日存入证券户口。'
      }, // 渣打银行
      fpsConfiguration: {
        title: '将资金转账至海通国际的FPS识别码',
        fpsCode: 'FPS 识别码:',
        digital: '167011527',
        collection: '收款银行:',
        chinaBank: '中国银行（香港）',
        payee: '收款人名称:',
        name: 'Haitong International Securities Company Limited',
        guide: 'FPS 转数快汇款指引',
        return: '返回资金存入主页',
        nextStep: '下一步',
        attention: '注意事项',
        content:
          '请使用阁下本人同名的银行账户转账，不可使用他人银行账户转账。目前海通国际不接受由香港银行柜台、ATM等渠道直接存入现金的入金，不接受联名账户入金，不接受电子钱包入金。',
        notice: '通知海通国际收款',
        AfterFour: '转出银行账户末四位：',
        account: '存入账户:',
        market: '存入市场:',
        currency: '存入货币:',
        amount: '存入金额:',
        return1: '返回',
        queren: '确认',
        instructions: '我们已收到您的快速入金申请指示。',
        record: '请记下参考编号以作纪录。',
        ReferenceCode: '参考编号：',
        digital1: '9D5909C7',
        wanCheng: '完成',
        print: '列印',
        check: '请输入您开户时指定的香港银行账户末四位',
        hkd: '港币',
        cny: '人民币',
        head: '快速入金申请结果', //弹框头部
        formCheck1: '提取金额必须填写',
        formCheck2: '提取金额不正确',
        formCheck3: '阁下指示的提取金额错误',
        formCheck4: '银行卡末四位必须填写',
        formCheck5: '您指示的银行卡末四位错误'
      }
    }
  },
  //我的查询菜单
  myInquiry: {
    // 我的资产
    accoutSummary: {
      market: '市场',
      buypower: '购买力',
      hukoujiecun: '户口结存',
      keyongjiecun: '可用结存(不包括利息)',
      xianjinjiecun: '现金结存',
      leijilixi: '累积利息',
      zhipiao1: '支票交收(D+1)',
      zhipiao2: '支票交收(D+2) ',
      duiyinghuobi: '对应货币',
      xindaie: '信贷额',
      zhengquanshizhi: '证券市值',
      dongjiejine: '冻结金额',
      daijiaoshou1: '待交收(T+1)',
      daijiaoshou2: '待交收(T+2)',
      daijiaoshou3: '待交收(T+N)',
      ancanzhi: '证券按仓值',
      zongzichan: '总资产',
      xianjin: '现金',
      ganggu: '港股',
      agu: 'A股',
      chanwaijiaoyi: '场外交易',
      meigu: '美股',
      keyongjiecun: '可用结存(不包括利息)',
      duihuanlv: '兑换率(只作参考，最后更新时间',
      chicanxiangqing: '持仓详情',
      gupiao: '股票',
      xianjia: '现价',
      chenben: '成本',
      zongshuliang: '总数量',
      kemaishuliang: '可沽数量',
      cankaoyinkui: '参考盈亏',
      jinriyinkui: '今日盈亏',
      shizhi: '市值',
      ancangzhi: '按仓值',
      caozuo: '操作',
      mairu: '买入',
      maichu: '卖出',
      xiugaichenben: '修改成本',
      jiaoyijilu: '交易记录',
      explianInfo:
        '*是次买入上限(购买力)以香港，中国A股，美国及场外市场內所有货币结余及证券按仓值(孖展戶口适用)的港币对应值计算。有关其他市场的结存资料(包括中国B股市场或其他市场)，请查阅结单或于交易时段內透过中国B股市场交易平台查阅。',
      gupiaoshuliang: '股票数量',
      pingjunmairujia: '平均买入价',
      pingjunjia: '平均价',
      beizhu: '备注',
      beizhuxiangqin1:
        '1. 『平均买入价』、『平均价』、『未实现盈亏』仅作参考用途，海通国际证券有限公司(“海通国际”)不建议客戶以此作为买卖准则。海通国际有权随时修改计算及/或资料更新时间而无须另行通知。',
      beizhuxiangqin2:
        '2. 『平均买入价』、『平均价』、『未实现盈亏』并未计算佣金及交易费用。',
      beizhuxiangqin3:
        '3. 客戶可自行修改『平均价』及『平均买入价』。及后系统会因应账户的证券买卖而自动调整『平均价』及『平均买入价』。',
      beizhuxiangqin4:
        '4. 『平均买入价』及『平均价』于指定情况下会显示为 “不适用”。',
      beizhuxiangqin5:
        '5. 有关『平均买入价』、『平均价』、『未实现盈亏』的定义参阅',
      beizhuanniu: '『平均买入价』及『平均价』说明',
      xinpingjunjia: '新平均价',
      queren: '确认',
      zhishi1: '指示已收到',
      zhishi2: '请于稍后查询更改指示处理情况'
    },
    // 交易记录(今日记录和历史记录合一起了)
    tradeHistory: {
      title1: '今日记录',
      title2: '历史记录',
      title3: '新股申购',
      title4: '公司行动',
      tradeType: '交易种类',
      all: '所有',
      buy: '买入',
      sell: '卖出',
      stockNum: '股票编号',
      specifyStock: '指定股票',
      Summary: '汇总',
      detailed: '明细',
      recordTime: '记录直至',
      tradeDate: '交易日期',
      zhi: '至',
      startDate: '开始日期',
      endDate: '结束日期',
      aWeek: '一周',
      aMonth: '一个月',
      threeMonth: '三个月',
      settlementDate: '交收日期',
      market: '市场',
      stock: '股票编号',
      tradeClasify: '交易种类',
      tradeNum: '成交数量',
      currency: '货币',
      tradePrice: '成交价格',
      avagPrice: '平均价',
      money: '金额',
      channel: '渠道',
      numId: '参考编号',
      noResult: '没有交易记录符合搜寻条件',
      remarks: '备注',
      remark1:
        '1) 金额并不包括经纪佣金、印花税、交易征费、联交所交易费、中央结算费及其他交易费用。',
      remark2: '2) 所有交易项目以结单显示记录为准',
      remark3: '3) 交易记录查询功能提供最近12个月的记录。',
      remark4: '4) 以上查询并不包括今天的交易记录。阁下可',
      remarkBtn1: '汇出至Excel',
      remarkBtn2: '打印',
      ipoSub: {
        subscriptionId: '申购编号',
        stockNum: '股票编号',
        biddingPrice: '招股价',
        subscriptionNum: '申购股数',
        subscriptionType: '申购类型',
        subscriptionMoney: '申购金额',
        serviceCharge: '手续费',
        financingRatio: '融资比例',
        rate: '参考利率',
        tradeCost: '交易金额',
        stockNum: '获配股数',
        tradeChannel: '交易渠道',
        state: '申购状况',
        action: '操作',
        cancel: '取消',
        cancelIPO: '取消新股申购申请',
        stockName: '新股名称',
        stockCode: '股票代号',
        zhaogujia: '招股价',
        shengoushuliang: '申购股数',
        shouxufei: '手续费',
        shengoujine: '申购金额',
        rongzibili: '融资比例',
        cankaolilv: '参考利率',
        jiaoyijine: '交易金额',
        tishi: '提示信息方法',
        zhishibianhao: '申购指示编号',
        zhishizhuangkuang: '申购指示状况',
        password: '密码',
        tip: '请输入密码',
        cofirm: '确认',
        submitSuccess: '取消新股申购申请已提交'
      },
      companyAction: {
        market: '市场',
        all: '所有',
        hkStock: '港股',
        hugutong: '沪股通',
        gangutong: '港股通',
        zhuangtai: '状态',
        yiqidong: '已启动',
        yijiezhi: '已截止',
        yishouquan: '已授权',
        yipaifa: '已派发',
        yiwancheng: '已完成',
        leixing: '类型',
        xianjinguxi: '现金股息',
        gupiaoguxi: '股票股息',
        gupiaobianhao: '股票编号',
        zhidinggupiao: '指定股票',
        sousuo: '搜索',
        gupiao: '股票',
        xingdong: '行动描述',
        cankao: '参考编号',
        qudao: '渠道',
        jiezhiriqi: '回复截止日期',
        zhuangtai: '状态',
        caozuo: '操作',
        editor: '修改',
        xiugai: '公司行动修改',
        cankaobianhao: '参考编号',
        guxi: '每股股息',
        xingujia: '收取新股价',
        jieshi1:
          '根据上述公司宣布，股东有权就有关股息作出以下选择。请在网上填妥并提交下列指示，或者填妥指示函件，并必须于2018年08月18日前寄回本公司交收部或传真至（852）2537 7647 或致电经纪人/分行。若届时未接获阁下回复，或指示未填写清楚，则本公司将代为全部收取股票股息。',
        jieshi2: '本人吾等根据上述事项通知贵公司',
        jieshi3: '持有可获配股息之股数',
        xianjin: '全部现金',
        xingu: '全部新股',
        bufenxianjin: '部分现金部分新股',
        ganyuan: '港元',
        renmingbi: '人民币',
        meiyuan: '美元',
        xuanze1: '选择收取现金股息之股数',
        xuanze2: '选择收取新股股息之股数',
        cofirm: '确认',
        xingdongtijiao: '您的公司行动指示已经受理成功。'
      }
    },
    // 资金记录
    fundMovement: {
      currencyExchangeRecord: {
        title: '货币兑换纪录',
        info:
          '*本平台提供的服务只为便利客户处理交易和/或任何其他相关交易活动和/或结算，包括但不限于使用该海通账户及/或其他海通账户中产生的费用和收费。',
        info1: '*平台中的「CNY」符号是指离岸人民币的相关报价。',
        state: '兑换状态',
        all: '所有',
        inProgress: '处理中',
        accept: '已接受',
        refused: '已拒绝',
        date1: '日期',
        oneWeek: '一周',
        oneMonth: '一个月',
        threeMonths: '三个月',
        record: '记录直至',
        date2: '兑换指示接收日期',
        date3: '结算日期',
        market1: '市场 (卖出)',
        currency: '卖出货币',
        amount: '卖出金额',
        market2: '市场 (买入)',
        currency1: '买入货币',
        amount1: '买入金额',
        huiLv: '兑换汇率',
        code: '参考编号',
        state1: '状态',
        disclaimer: '免责声明',
        content1:
          '海通国际证券集团有限公司及其子公司及其职员，代表或代理人（“海通”）对您因访问、使用或无法访问或无法使用本平台及其提供的服务而造成的任何损失，损害或伤害不承担任何责任；除非海通通过本平台提供服务时存在欺诈或故意不当行为。',
        content2:
          '您清楚明白亦接受使用服务时或会出现传输延迟或失败、以电子方式进行的任何传输中断或停顿；您同意海通不对此类或任何由此造成的损失，损害或伤害承担责任。',
        content3:
          '本平台提供的信息和材料不构成出售要约或徵求购买任何货币的要约，且不得被依赖作出任何投资决策。 必要时请谘询独立建议。'
      },
      escrowRecords: {
        title: '资金提存记录',
        date1: '查询日期',
        oneWeek: '一周',
        oneMonth: '一个月',
        threeMonths: '三个月',
        record: '记录直至',
        date2: '交易日期',
        date3: '入账日期',
        code1: '参考编号',
        market: '市场',
        instructions: '说明',
        number: '数量',
        currency: '货币',
        amount: '金额',
        note: '备注',
        content: '1) 所有交易项目以结单显示记录为准。',
        content1: '2) 交易记录查询功能提供最近12个月的记录。'
      }
    },
    // 证券提存
    stockMovement: {
      market: '市场',
      allMarket: '所有',
      hkAUSAsotck: '香港，中国A股，美国及场外市场',
      cnBStock: '中国B股',
      otherMarket: '其它市场',
      project: '项目',
      securities: '证券',
      futures: '期货',
      date1: '日期',
      oneWeek: '一周',
      oneMonth: '一个月',
      threeMonths: '三个月',
      code: '股票',
      stock: '指定股票',
      record: '记录直至',
      date2: '交易日期',
      date3: '入账日期',
      code1: '参考编号',
      query: '查询项目',
      instructions: '说明',
      code2: '证券代号',
      number: '数量',
      currency: '货币',
      amount: '金额',
      note: '备注',
      content: '1) 所有交易项目以结单显示记录为准。',
      content1: '2) 交易记录查询功能提供最近12个月的记录。'
    },
    // 我的结单
    myStatement: {
      type: '结单类型',
      all: '所有',
      dayStatement: '日结单',
      monthlyStatement: '月结单',
      date: '日期',
      oneWeek: '一周',
      oneMonth: '一个月',
      threeMonths: '三个月',
      time: '时间',
      file: '户口编号',
      type2: '结单类型',
      download: '下载'
    },
    // 我的报表
    myReport: {
      code: '基金代码',
      date: '日期',
      oneWeek: '一周',
      oneMonth: '一个月',
      threeMonths: '三个月',
      name: '报告名称',
      time: '时间',
      file: '报告文件',
      allDownload: '下载全部报告',
      download: '下载',
      start: '开始日期',
      to: '至 ',
      end: '结束日期'
    }
  },
  //我的设定
  mySettings: {
    //个人资料
    changeParticulars: {
      //baseStep
      gerenziliao: '个人资料',
      back: '返回',
      next: '下一步',
      confirm: '确认',
      choose: '请选择',
      shoutiPhone: '手提电话',
      guojiahaoma: '国家及地区号码',
      dianhuahaoma: '电话号码',
      youbian: '邮编',
      tianxieyoubian: '填写邮编 (如有)',
      dizhi: '地址',
      tianxiedizhi: '填写地址',
      email: '电子邮箱',
      inputEmail: '填写电子邮箱',
      shouquhukou: '收取户口结单方式(如需要更改收取户口结单方式请选择以下选项)',
      shouqufangshi: '收取方式',
      dianzijiedan: '收取电子结单',
      youjijiedan: '收取邮寄结单',
      jiedanyuyan: '结单语言',
      en: '英文',
      cn: '简体',
      hk: '繁体',
      editorMore: '修改更多资料',
      explain:
        '吾等会尽快（在任何情况下，在30天内）向贵公司提供所需的额外文件，包括但不限于更新资料变更后的自我证明。如本人／吾等未能在指定时间内提供所需的额外文件，本人／吾等明白贵公司可能根据有关的资料变更向相关司法管辖区内的合资格监管及／或政府当局（包括但不限于美国国家税务局、美国财政部和香港税务局）披露及／或提交本人/吾等之相关账户资料，以符合FATCA、《共同汇报标准条例》和其他相关法规、守则和规则的规定。',
      explian1: '· 网上更改资料只接受个人账户客户。',
      explian2: '· 本公司将于下一个工作天收到阁下的指示。',
      explian3: '· 如需修改住宅地址，请填妥及交回',
      aLink1: '更改资料及易结单服务表格',
      explian4: '· 如需修改指定银行户口，请填妥及回',
      aLink2: '更改/新增指定银行户口表格',
      explian5: '· 请输入英文或中文通讯地址。',
      explian6:
        '· 更改的资料会更新阁下存于以下公司的记录: 海通国际证券有限公司、海通国际期货有限公司、海通国际资产管理有限公司、海通国际投资经理有限公司、海通资产管理(香港)有限公司、海通国际创富理财有限公司、HTI Advisory Company Limited 及海通国际财务有限公司。',
      explian7: '重要提示',
      explain8:
        '· 客户若更改手提电话或同时更改通讯地址及电邮地址，客户服务部在收到阁下的更改资料指示后，将致电阁下进行电话确认。如未能成功联络或确认，阁下的账户服务和交易功能将被暂停。阁下如需重启交易账户，须致电客户服务部以作电话确认，本公司亦有可能要求阁下重新递交更改指示。',
      //detailStep
      zhuzhaidianhua: '住宅电话',
      bangongdianhua: '办公室电话',
      chuanzhenhaoma: '传真号码',
      jiaoyuchengdu: '教育程度及职业资料',
      jiaoyu: '教育程度',
      zhiye: '职业',
      guzhuming: '僱主名称',
      tianxieguzhu: '填写僱主名称',
      congyenianfen: '从业年数',
      qingtianxie: '请填写',
      zhiwei: '职位',
      tianxiezhiwei: '填写职位',
      caiwuziliao: '财务资料',
      zhuwu: '住屋',
      caifulaiyuan: '持续财富来源',
      laiyuanxuanze:
        '薪金及/或花红|储蓄|业务收入|退休金|遗赠或礼物|投资回报|其他',
      laiyuanqita: '请说明',
      caifuzhuanyi: '持续资金来源(a)资金来转移方式',
      zhuanyixuanze: '现金|电汇|支票/银行本票|其他',
      caifulaiyuandi: '持续资金来源(b)资金来源地',
      laiyuandixuanze: '香港|中国|美国|其他',
      zongshouru: '每年总收入',
      jingzichan: '净流动资产值',
      touzimudi: '投资经验及目的',
      touzijingyan: '投资经验',
      touzijinyanxuanze:
        '没有|证券|认股权证|期权|期货|外汇|贵金属|基金|其他衍生工具',
      touzinianfen: '投资经验年资',
      touzinianfenxuanze: '没有|一至三年|三至五年|五至十年|超过十年',
      touzimudi: '投资目的',
      touzimudixuanze: '资本增长|定期收入|对冲|投机|其他',
      cofirmInfo: '请确认以下修改的资料',
      tijiaozhishi: '您修改的资料已提交',
      zhishixinxi: '指示将于下一个工作天收到',
      educaitionLevel: '小学或以下/中学/大专或以上',
      occupation:
        '会计/法律/审计|广告|农业|艺术/媒体|银行/金融|美容/保健|生物科技/医药|公务员|企业|顾问|设计|教育|工程|家庭主妇|人力资源|工业|保险|投资|物流|市场营销|医疗|采购|印刷|物业|公共关系|零售/批发|退休|科技|电讯|贸易|运输|待业|其他',
      house: '自置物业/按揭物业/租用物业/宿舍/与家人同住',
      changeInformationLink: 'http://www.htisec.com/zh-cn/form-download/1392',
      bankFormLink: 'http://www.htisec.com/zh-cn/form-download/1392'
    },
    //更改密码
    changePassword: {
      oldPassword: '旧密码',
      oldPasswordTip: '请输入旧密码',
      newPassword1: '新密码',
      newPassword1Tip: '请输入新密码',
      newPassword2: '确认新密码',
      newPassword2Tip: '请再次输入新密码',
      attention: '注意事项',
      attentionInfo:
        '*密码必须是数字(0-9)+英文字母 ( A - Z, a - z ) 之组合，合计8-10位，新密码将即时生效于所有电子交易渠道。',
      confirm: '确认',
      changePassword: '更改密码',
      updatePassword: '密码已更新'
    },
    //密码确认
    passwordConfirm: {
      state: '「要求密码确认」状态',
      started: '已启动',
      editor: '修改「要求密码确认」设定',
      adapt: '（适用于网上证券交易平台）',
      loginName: '登入名称',
      startedInfo: '启动「要求密码确认」步骤',
      cancelInfo: '取消「要求密码确认」步骤',
      cancelTip: '请细阅取消「要求密码确认」步骤之声明',
      cancelTitle: '取消「要求密码确认」步骤之声明',
      cancelExpian1:
        '本人现授权海通国际证券有限公司于本人名下之证券户口, 取消一切在进行发出证券交易新盘、更改及删除指示、转账及提款指示时所需重新输入「要求密码确认」步骤。',
      cancelExpian2:
        '本人清楚明白及愿意承担, 取消「要求密码确认」步骤可能引起之一切额外风险, 并同意贵公司毋须就本人放弃使用上述之步骤所遭受之损失承担任何责任。此外, 本人瞭解在完成证券交易后或在离开电脑前应先行「登出」证券户口并关闭有关系统,避免他人使用本人的证券户口交易、转账或阅览账户资料。',
      tip:
        '# 证券交易新盘、更改及删除指示的取消「要求密码确认」步骤只适用于香港、中国A股、美国及场外交易。',
      password: '密码',
      inputPassword: '请输入密码',
      confirm: '确认',
      passwordConfirm: '密码确认',
      changeSuccess: '「要求密码确认」步骤修改成功'
    },
    //信贷额申请
    marginApplication: {
      customName: '客户姓名',
      accountId: '账户号码',
      existCredit: '现有信贷额',
      currentMargin: '现有证券抵押值',
      newCredit: '申请信贷额',
      currency: '港币',
      wan: '万',
      customData:
        '如您申请的额度超过800万港币, 请填写申请的金额。 根据您的信用记录以及在海通国际的持仓及账户余额, 我们为您准备了预设额度, 如您申请的额度超过预设额度或者申请的额度在800万港币以上,我们将派专人与您跟进。',
      totalIncome: '每年总收入(港币)',
      job: '职业',
      currentAsset: '淨流动资产(港币)',
      incomeFrom: '财富来源',
      profitVal: '税后利润估值(港币)',
      netAssetVal: '资产净值(港币)',
      suppleInfo: '补充信贷资料',
      action: '注意事项',
      explian1:
        '1.	该项信贷申请只适用于海通国际证劵有限公司(下称“本公司”或“海通国际”)开立之保证金证劵网上交易账户，而阁下授予本公司之《证劵常设授权》必须仍然生效，否则有关申请将被拒绝。',
      explian2:
        '2.	信贷额度乃本公司给予该保证金证劵网上交易账户的保证金贷款额度上限，账户之实际购买力的计算方法是参照当时账户内之现金馀额及证劵按仓值的总和。',
      // explian3:
      //   '3.	此信贷额度只适用于在香港联合交易所有限公司上市或交易之证劵。如欲申请提升美股交易之信贷额度，请联络阁下之客户经理。',
      // explian4:
      //   '4.	若申请额度超过账户资产淨值之4倍，客户须提供最近三个月内之收入 / 资产证明文件副本，并将相关文件传真至(852) 2526-7612 或电邮至 credit@htisec.com，否则申请将被自动拒绝。如有查询，请与信贷管理部联络 (852)2801-2657。',
      explian5:
        '5.	海通国际有绝对酌情权因应客户之财务状况或信贷记录的变更，随时对已批出的信贷额度作出检讨及调整而不作另行通知。',
      explian6:
        '6.	在审批客户之信贷额度申请，海通国际会考虑的因素包括但不限于客户的信贷纪录、股票抵押品的质素、波动性、流通性、最新市况、账户资产及证劵按仓值。本公司有绝对酌情权拒绝任何申请或批出较客户申请为低之信贷额度。',
      // explian7:
      //   '7.	本公司只于香港交易日办理信贷申请。于非交易日提交之信贷申请，将于下一交易日办理。',
      // explian8:
      //   '8.	本公司将透过手机短讯形式及/或电邮通知客户有关申请结果，若客户于本公司并无任何手机或电邮登记记录，本公司则会有专人致电通知客户有关申请结果。',
      explian9:
        '9.	阁下应明白寄存放抵押品而为交易取得融资的亏损风险可能极大，客户可能会在短时间内被要求存入额外的保证金款项。',
      explian10:
        '10.	如阁下未能在指定的时间内支付所需的保证金及/或利息，客户的部份或所有证券可能在不获通知的情况下被强制出售。',
      privateAgree:
        '本人已阅读及暸解注意事项及确认所提供的问卷资料在提供当时均属真确。',
      companyAgree: '本人已阅读及暸解注意事项。',
      marginApply: '更改信贷额',
      comfirmTip: '请检查以下资料无误，方作确认提交。',
      caiwuInfo: '根据您的信用记录以及在海通国际的持仓及账户余额，您的帐户',
      caiwuInfo1: '信贷额将更改至港币$',
      caiwuInfo2: '(即时生效)。',
      caiwuInfo3: '您是否同意提交申请？',
      cancel: '修改',
      confirm: '确认',
      submitInfor: '您为账户',
      submitInfor1: '于',
      submitInfor2: '申请了更改信贷额至港币$',
      submitInfor3: '已通过审批。',
      submitInfor4: '提交了更改信贷额的申请。现已完成审批，您现有信贷额为港币$',
      submitTip: '相关申请参考编号为：'
    },
    //投资者风险取向问卷
    investProfile: {
      info:
        '于进行任何投资交易前，请完成风险取向问卷以更新您的投资风险取向记录。',
      input: '开始填写',
      chuli: '您的风险取向问卷正在处理中。',
      orientation: '投资风险取向',
      assessment: '场外衍生工具知识评估',
      content1: '如需更新您的投资风险取向记录，请',
      content2: '按此',
      content3: '完成风险取向问卷',
      content4: '根据您最近一次的风险评估记录，您的风险取向为',
      content5: '保守',
      content6: '中度保守',
      content7: '平稳',
      content8: '中度进取',
      content9: '进取',
      content10: '投资风险评估总分:',
      content11: '投资风险取向:',
      content12: '有效日期至:',
      content13: '2020-03-11',
      content14: '是否具备金融衍生工具的知识:',
      content15: '是',
      content16: '否',
      content17: '根据您最近一次的场外衍生工具知识评估记录，您',
      content18: '不具备金融衍生工具的知识',
      content19: '具备金融衍生工具的知识',
      answer: '请回答所有问题',
      prompt: '您的投资风险取向问卷已提交',
      jiaoyuLink: 'http://www.htisec.com/zh-cn/investor-education',
      conservative:
        '根据阁下/贵公司于第三题的答桉，阁下/贵公司的主要投资目标为保本，因此阁下/贵公司的风险取向将被评定为保守',
      // 个人问卷
      personalQuestionnaire: {
        questionnaire: '投资风险取向问卷',
        title: '个人/联名投资取向问卷',
        name: '姓名 ：',
        account: '账户号码 ：',
        content:
          '本问卷旨在帮助我们确定和评估阁下的风险取向、投资经验和是否具备衍生工具知识。我们将会根据阁下所提供的资料，评估阁下是否了解个别投资产品的性质和风险。联名账户的账户持有人须个别填妥一份问卷，以风险取向较低者为准。本问卷共分为两部份，如阁下不欲投资衍生产品，阁下只须填妥第一部份风险取向，第二部份衍生工具知识评估则不用填写。',
        important: '重要事项：',
        info:
          '阁下的风险取向是根据您在此问卷所有问题的答案整合得出，而非基于阁下就任何个别问题给予的答案（第3条除外）。在回答阁下的财务或投资资料的问题时，例如可投资资产金额或事务资料，阁下的答案应基于您在本行、其他证券行、银行及金融机构所持全部资产及交易，而不单限于本行持有资产及交易。',
        oneContent: '第一部分：风险取向',
        oneInfo:
          '此部分收集阁下之财务状况，投资态度及投资经验以评估阁下对风险的承受能力。请在适当的选项内勾选并回答全部13条问题。',
        one: '1 您的教育程度是？',
        oneA: 'A. 小学以下',
        oneB: 'B. 小学',
        oneC: 'C. 中学',
        oneD: 'D. 大专或以上',
        two: '2 您现时有否供养家庭成员？如有，请问多少名家庭成员需要阁下供养？',
        twoA: 'A. 4名或以上',
        twoB: 'B. 3名',
        twoC: 'C. 2名或以下',
        three: '3 投资产品价值下跌对您有何影响？',
        threeA:
          'A. 我的主要目标是保本，不愿意接受投资于任何时候有任何亏损。（请注意：所有投资均涉及投资风险。如您不愿意接受任何投资于任何时候有任何亏损，并只希望本公司根据此问题的答案，而非本问卷的全部答案去评估您的风险取向，您属于一个保守型的投资者，您只可考虑传统保守产品。）',
        threeB:
          'B. 我愿意接受于投资期限内有轻微亏损，但对投资有中度至大幅亏损感到不安。',
        threeC:
          'C. 我愿意接受于投资期限内有中度亏损，但会对投资有大幅亏损感到不安。',
        threeD:
          'D. 我愿意接受于投资期限内有大幅波动及投资价值亏损，以获得最高长期潜在回报。',
        four: '4 您愿意投资于波幅多大的投资产品？',
        fourA: 'A. 介乎–5%至+5%之间的波幅',
        fourB: 'B. 介乎–10%至+10%之间的波幅',
        fourC: 'C. 介乎–20%至+20%之间的波幅',
        fourD: 'D. 介乎–20%以上至+20%以上之间的波幅',
        five:
          '5 平均来说，您每月可动用的资金有多少？[可动用资金的定义：可动用资金指扣除税项、退休金供款及必需开支（例如按揭供款或租金、汽车贷款、保险、食品、衣履、照顾儿童或长者和水、电、煤、差饷等开支）后剩余的金额（包括银行存款、工资、股息、花红等）]',
        fiveA: 'A. 4,000至15,000港元',
        fiveB: 'B. 15,001至60,000港元',
        fiveC: 'C. 60,001至100,000港元',
        fiveD: 'D. 超过100,000港元',
        six: '6 您是否依靠投资回报以应付您供养家庭成员的日常开支？',
        sixA: 'A. 是，超过20%',
        sixB: 'B. 是，超过10%至20%',
        sixC: 'C. 是，超过0%至10%',
        sixD: 'D. 否',
        seven: '7 您可用作投资的金额占每月收入百分比为多少？',
        sevenA: 'A. 0%至10%',
        sevenB: 'B. 超过10%至25%',
        sevenC: 'C. 超过25%至50%',
        sevenD: 'D. 超过50%',
        eight:
          '8 您的储备金额大约可应付多少个月的基本家庭开支及满足额外的抵押要求？',
        eightA: 'A. 少于3个月',
        eightB: 'B. 3个月至少于6个月',
        eightC: 'C. 6个月至少于9个月',
        eightD: 'D. 9个月或以上',
        nine: '9 买卖投资产品时，您可以接受的投资年期是多少？',
        nineA: 'A. 1年或以下',
        nineB: 'B. 1年以上至5年',
        nineC: 'C. 5年以上至10年',
        nineD: 'D. 超过10年',
        ten: '10 在过往一年，您曾执行过多少次交易？',
        tenA: 'A. 少于5次交易',
        tenB: 'B. 5至10次交易',
        tenC: 'C. 11至20次交易',
        tenD: 'D. 超过20次交易',
        eleven: '11 您对金融市场和投资的认识有多少？',
        elevenA: 'A. 没有认识：我对金融市场和投资完全没有任何认识。',
        elevenB:
          'B. 低水平：我对金融市场只有一些基本知识，例如股票和债券的分别。',
        elevenC:
          'C. 中等水平：达基本知识以上的水平，明白分散投资的重要性，并作出分散投资（即把资金配置于不同类别的投资，以分散风险）。',
        elevenD:
          'D. 高水平：我懂得阅读一家公司的财务报告（即损益表及资产负债表），并明白影响股票和债券价格的因素。',
        elevenE:
          'E. 精通：我熟识大部分金融产品（包括债券、股票、认股权证、期权及期货），并明白可能影响这些金融产品的风险和表现的各项因素。',
        twelve:
          '12 您的可投资资产的总值是（包括您所有现金及投资组合总和（不包括物业价值）再减去结欠如私人贷款及信用卡结欠（不包括物业贷款））',
        twelve1: '估计可投资资产的总值： 港币 $：',
        thirteen:
          '13 在下表中，请选出您曾经参与的投资产品（如适用，可选择多于一项）',
        thirteen1: '交易经验年数 ',
        thirteen2: '无',
        thirteen3: '有限',
        thirteen4: '良好',
        thirteen5: '丰富',
        thirteen6: '产品',
        thirteen7: '认股权证／牛熊证',
        thirteen8: '交易所买卖基金',
        thirteen9: '结构性产品（例如：保本或非保本产品）',
        thirteen10: '杠杆及反向产品',
        thirteen11: '期货／期权',
        thirteen12: '上市股票',
        thirteen13: '场外衍生工具（例如：场外期权）',
        thirteen14: '股票沽空',
        thirteen15: '证券配售',
        thirteen16: '外币',
        thirteen17: '互惠基金／单位信托基金',
        thirteen18: '对冲基金／私募股权基金',
        thirteen19: '债券',
        note: '备注：',
        note1: '1. 如您之前不具备相关知识／经验或对此不确定，请选择「无」。',
        note2:
          '2. 问题13内填报的各种投资产品之交易经验年数将被视为客户的最新投资经验年数。',
        twoContent: '第二部分：衍生工具知识评估',
        twoInfo:
          '此部分旨在协助评估您是否具备衍生工具知识。本公司将根据您所提供资料，评估您是否了解衍生产品的性质和风险。请在适当的选项内勾选并回答全部问题。',
        one1: '1 您对金融衍生工具的认知？',
        one2: '没有：我不具备金融衍生工具的知识，亦没有兴趣了解这方面的知识。',
        one3:
          '少许认知：我只具备金融衍生工具的一些基本知识，例如传统投资工具如股票等与衍生工具属于不同类型资产。',
        one4:
          '中等认知：我具备基本以上的知识及明白金融衍生工具的价值可因应相关资产的价值而波动及其升跌幅度可大于传统投资工具。我懂得如何阅读金融衍生工具合约或销售文件的条款及细则及明白影响金融衍生工具价格的一般因素。',
        one5:
          '非常认知：我熟悉大部分金融衍生工具及在过往多年经常买卖金融衍生工具。',
        two1: '2 您对以下金融衍生工具的投资经验（可选择多于一项）？',
        two2:
          '香港或海外上市的金融衍生工具（如期货合约、商品合约、期权及认股权证等）',
        two3:
          '场外结构性产品或金融衍生工具（如结构性/可换股债券、信贷挂钩票据、商品挂钩票据及股票挂钩票据等）',
        two4: '对冲基金或广泛地投资于金融衍生工具以达到投资目的的基金',
        two5: '其他 （请注明）：  ',
        two6: '沒有 （如答没有，请直接到第4题。） ',
        three1:
          '3 您有否在过去3年间就问题2所述产品（不论是否于交易所买卖）执行5项或以上交易？',
        three2: '有;请注明：',
        three3: '金融机构名称：',
        three4: '总交易金额：',
        three5: '沒有',
        four1:
          '4 您有否曾经接受及／或参加由学术机构或金融机构所提供有关上述衍生工具及／或结构性产品的在线或面授形式培训及／或课程，而阁下亦完全了解这类投资产品的性质和风险？',
        four2:
          '有，我已透过贵公司网站有关债券、埸内及场外衍生工具之培训短片了解相关产品的性质和风险 ',
        four3: '日期：',
        four4: '验证码：',
        four5: '按此观看投资者教育短片',
        four6: '有，有关培训及／或课程由以下提供机构提供',
        four7: '机构名称：',
        four8: '课程名称：',
        five1:
          '5 您有否拥有1年以上有关上述衍生工具及／或结构性产品的工作经验？',
        five2: '公司名称：',
        five3: '部门名称：',
        five4: '工作性质：',
        five5: '任职年期：',
        prompt:
          '本人明白如问卷内填写的内容不实，海通国际将不能评估所要求服务是否适合本人',
        submit: '提交'
      },
      // 公司问卷
      groupQuestionnaire: {
        title: '公司投资取向问卷',
        name: '公司名称：',
        account: '账户号码：',
        content:
          '本问卷旨在帮助我们确定和评估贵公司的风险取向、投资经验和是否具备衍生工具知识。我们将会根据贵公司所提供的资料，考虑贵公司的获授权人是否了解个别投资产品的性质和风险。本问卷共分为两部份，如贵公司不欲投资衍生产品，贵公司只须填妥第一部份风险取向，第二部份衍生工具知识评估则不用填写。',
        important: '重要事项：',
        info:
          '贵公司的风险取向是根据贵公司的获授权人在此问卷所有问题的答案整合得出，而非基于贵公司的获授权人就任何个别问题给予的答案（第3条除外）。在回答贵公司的财务或投资资料的问题时，例如可投资资产金额或事务资料，贵公司的获授权人的答案应基于贵公司在本行、其他证券行、银行及金融机构所持全部资产及交易，而不单限于本行持有资产及交易。',
        oneContent: '第一部分：风险取向',
        oneInfo:
          '此部分收集贵公司之财务状况、投资态度及获授权人的投资经验以评估贵公司对风险的承受能力。请在适当的选项内勾选并回答全部13条问题。',
        one:
          '1 贵公司属私人公司并由公司持有人负责投资决定或贵公司属具规模公司并由投资团队负责投资决定？',
        oneA: ' A. 本公司属私人公司并由公司持有人负责投资决定',
        oneB: ' B. 本公司属具规模公司并由投资团队负责投资决定',
        two: '2 有关贵公司的企业架构、实质的投资程序及监控措施：',
        twoA:
          'A. 本公司设有由具备胜任能力及适当资格的专业人士组成的专责投资委员会，负责投资策略及投资程序；及 (i) 该委员会代表本公司作出投资决定或 (ii) 本公司在作出有根据的投资决定时会考虑该委员会的意见或建议；',
        twoB:
          'B. 本公司内部设有由具备胜任能力及适当资格的专业人士组成的库务、投资或类似职能，负责投资策略及投资程序；',
        twoC:
          'C. 本公司委聘由具备胜任能力及适当资格的专业人士组成的外部投资顾问团队，负责投资策略及投资程序；及 (i) 该团队代表本公司者作出投资决定或 (ii) 本公司在作出有根据的投资决定时会考虑该团队的意见或建议；',
        twoD:
          'D. 本公司依据及遵循其有连系法团的投资策略、意见及建议，该有连系法团： (i) 设有内部库务、投资或类似职能； (ii) 设有专责投资委员会；或 (iii) 委聘符合上述的条件的外部投资顾问团队；',
        twoE: 'E. 以上四项皆没有',
        three: '3 投资产品价值下跌对贵公司有何影响？',
        threeA:
          'A. 本公司的主要目标是保本，不愿意接受投资于任何时候有任何亏损。（请注意：所有投资均涉及投资风险。如贵公司不愿意接受任何投资于任何时候有任何亏损，并只希望本公司根据此问题的答案，而非本问题的全部答案去评估贵公司的风险取向，贵公司属于保守型的投资者。）',
        threeB:
          'B. 本公司接受于投资期限内有轻微亏损，但对投资有中度至大幅亏损感到不安。',
        threeC:
          'C. 本公司愿意接受于投资期限内有中度亏损，但会对投资有大幅亏损感到不安。',
        threeD:
          'D. 本公司愿意接受于投资期限内有大幅波动及投资价值亏损，以获得最高长期潜在回报。',
        four: '4 贵公司愿意投资于波幅多大的投资产品？',
        fourA: 'A. 介乎–5%至+5%之间的波幅',
        fourB: 'B. 介乎–10%至+10%之间的波幅',
        fourC: 'C. 介乎–20%至+20%之间的波幅',
        fourD: 'D. 介乎–20%以上至+20%以上之间的波幅',
        five:
          '5 贵公司的负债与总资本比率现为多少？（负债与总资本比率定义为：（流动负债总额 + 非流动负债总额）／有形净值）',
        fiveA: 'A. 高于200%',
        fiveB: 'B. 100.1%与200%之间',
        fiveC: 'C. 50.1%与100%之间',
        fiveD: 'D. 20.1%与50%之间',
        fiveE: 'E. 低于20%',
        six: '6 买卖投资产品时，贵公司可以接受的投资年期是多少？',
        sixA: 'A. 1年或以下',
        sixB: 'B. 1年以上至5年',
        sixC: 'C. 5年以上至10年',
        sixD: 'D. 超过10年',
        seven:
          '7 贵公司在最近五年的纯利状况是？（如属非牟利机构，请以净现金流量代替纯利走势）',
        sevenA: 'A. 非常不稳定',
        sevenB: 'B. 不稳定',
        sevenC: 'C. 尚算稳定',
        sevenD: 'D. 稳定并与经济增长看齐',
        sevenE: 'E. 稳定并领先经济增长',
        eight:
          '8 贵公司现时是否持有以下任何投资产品？（如为多项，请选择最高分数的一项）',
        eightA: 'A. 现金、存款',
        eightB: 'B. 债券、债券基金',
        eightC: 'C. 股票、开放式基金、非保本投资产品',
        eightD: 'D. 认股权证（窝轮）、期权、期货',
        nine: '9 在过往一年，贵公司曾执行过多少次交易？',
        nineA: 'A. 少于5次交易',
        nineB: 'B. 5至10次交易',
        nineC: 'C. 11至20次交易',
        nineD: 'D. 超过20次交易',
        ten:
          '10 贵公司期望每年的投资回报率为多少？ 一般来说，风险与回报通常成正比。回报越高，所负担的风险越高。',
        tenA: 'A. 5%或以下',
        tenB: 'B. 6% - 15%',
        tenC: 'C. 16% - 25%',
        tenD: 'D. 25%以上',
        eleven: '11 贵公司各获授权人对金融市场和投资的整体认识有多少？',
        elevenA:
          'A. 没有认识：本公司各获授权人对金融市场和投资完全没有任何认识。',
        elevenB:
          'B. 低水平：本公司各获授权人对金融市场只有一些基本知识，例如股票和债券的分别。',
        elevenC:
          'C. 中等水平：本公司各获授权人达基本知识以上的水平，明白分散投资的重要性，并作出分散投资（即把资金配置于不同类别的投资，以分散风险）。',
        elevenD:
          'D. 高水平：本公司各获授权人懂得阅读一家公司的财务报告（即损益表及资产负债表），并明白影响股票和债券价格的因素。',
        twelve:
          '12 贵公司的可投资资产的总值是 （包括贵公司所有投资组合总和（不包括物业价值）及现金再减去公司任何贷款及债务的金额（不包括物业贷款））：',
        twelve1: '估计可投资资产的总值： 港币 $：',
        thirteen:
          '13 在下表中，请选出贵公司各获授权人曾经参与的投资产品（如适用，可选择多于一项）',
        thirteen1: '交易经验年数',
        thirteen2: '无',
        thirteen3: '有限',
        thirteen4: '良好',
        thirteen5: '丰富',
        thirteen6: '产品',
        thirteen7: '认股权证／牛熊证',
        thirteen8: '交易所买卖基金',
        thirteen9: '结构性产品（例如：保本或非保本产品）',
        thirteen10: '杠杆及反向产品',
        thirteen11: '期货／期权',
        thirteen12: '上市股票',
        thirteen13: '场外衍生工具（例如：场外期权）',
        thirteen14: '股票沽空',
        thirteen15: '证券配售',
        thirteen16: '外币',
        thirteen17: '互惠基金／单位信托基金',
        thirteen18: '对冲基金／私募股权基金',
        thirteen19: '债券',
        note: '备注:',
        note1:
          '1. 如贵公司各获授权人之前不具备相关知识／经验或对此不确定，请选择「无」。',
        note2:
          '2. 问题13内填报的各种投资产品之交易经验年数将被视为客户的最新投资经验年数。',
        twoContent: '第二部分：衍生工具知識評估',
        twoInfo:
          '此部分旨在协助评估贵公司各获授权人整体上是否具备衍生工具知识。本公司将根据贵公司所提供资料，评估贵公司各获授权人整体上是否了解衍生产品的性质和风险。 请在适当的选项内勾选并回答全部问题。',
        one1: '1 贵公司各获授权人整体上对金融衍生工具的认知？',
        one2:
          '没有，本公司各获授权人整体上不具备金融衍生工具的知识，亦没有兴趣了解这方面的知识。',
        one3:
          '少许认知，本公司各获授权人整体上只具备金融衍生工具的一些基本知识，例如传统投资工具如股票等与衍生工具属于不同类型资产。',
        one4:
          '中等认知，本公司各获授权人整体上具备基本以上的知识及明白金融衍生工具的价值可因应相关资产的价值而波动及其升跌幅度可大于传统投资工具。我们懂得如何阅读金融衍生工具合约或销售文件的条款及细则及明白影响金融衍生工具价格的一般因素。',
        one5:
          '非常认知，本公司各获授权人整体上熟悉大部分金融衍生工具及在过往多年经常买卖金融衍生工具。',
        two1:
          '2 贵公司各获授权人整体上对以下金融衍生工具的投资经验（可选择多于一项）？',
        two2:
          '香港或海外上市的金融衍生工具（如期货合约、商品合约、期权及认股权证等）',
        two3:
          '场外结构性产品或金融衍生工具（如结构性/可换股债券、信贷挂钩票据、商品挂钩票据及股票挂钩票据等）',
        two4: '对冲基金或广泛地投资于金融衍生工具以达到投资目的的基金',
        two5: '其他 （请注明 ）： ',
        two6: '沒有 （如答没有，请直接到第4题。）',
        three1:
          '3 贵公司各获授权人整体上有否在过去3年间就问题2所述产品（不论是否于交易所买卖）执行5项或以上交易？',
        three2: '有;请注明：',
        three3: '金融机构名称：',
        three4: '总交易金额：',
        three5: '沒有',
        four1:
          '4 贵公司各获授权人整体上有否曾经接受及／或参加由学术机构或金融机构所提供有关上述衍生工具及／或结构性产品的在线或面授形式培训及／或课程，而你们亦完全了解这类投资产品的性质和风险？',
        four2:
          ' 有，我/我们已透过贵公司网站有关债券、场内及场外衍生工具之培训短片了解相关产品的性质和风险。',
        four3: '日期：',
        four4: '验证码：',
        four5: '按此观看投资者教育短片',
        four6: '有，有关培训及／或课程由以下提供机构提供',
        four7: '机构名称：',
        four8: '课程名称：',
        five1:
          '5 贵公司各获授权人整体上有否拥有1年以上有关上述衍生工具及/或结构性产品的工作经验？',
        five2: '公司名称：',
        five3: '部门名称：',
        five4: '工作性质：',
        five5: '任职年期：',
        prompt:
          '本人／吾等明白如问卷内填写的内容不实，海通国际将不能评估所要求服务是否适合本人。',
        submit: '提交'
      }
    },
    //中华通北向交易同意书
    consentForConnnect: {
      title: '中华通北向交易同意书',
      title1: '有关中华通证券北向交易的个人资料收集声明',
      content1:
        '除非下文另有界定，本有关中华通证券北向交易的个人资料收集声明(「本个人资料收集声明」)所用词汇与本公司的[现金]账户条款和条件及其附件所规定的定义具有相同涵义。若本个人资料收集声明的英文本与中文本在解释或意义方面有任何歧义，以英文版本为准。',
      content2: '处理个人资料作为北向交易的一部份',
      content3:
        '阁下确认并同意本公司为阁下提供透过互联互通进行中华通证券北向交易服务将须:',
      content4:
        'i.	在阁下每个送达内地互联互通系统的订单，附加本公司为阁下或为阁下的联名户口(如适用)编派唯一的券商客户编码(「BCAN」或「券商客户编码」)。',
      content5:
        'ii.	就联交所根据交易所规则可能提出的要求，向联交所提供阁下的劵商客户编码及有关阁下的识别资料(「CID」或「客户识别信息」)。',
      content6:
        '不限于任何本公司已向阁下发出的提示或本公司已从阁下收到同意就有关阁下户口或本公司提供的服务而处理阁下的个人资料，阁下确认并同意本公司为阁下提供透过中华通进行中华通证券北向交易服务可能须要收集、储存、使用、披露及转移有关阁下的个人资料，包括:',
      content7:
        'a.	不时向联交所及相关联交所子公司披露及转移券商客户编码及客户识别信息，包括在提交内地互联互通系统的中华通订单中附加上券商客户编码，再实时转递至相关中华通市场营运者；',
      content8:
        'b.	允许联交所及每一个相关联交所子公司 (i) 收集、使用及储存阁下的券商客户编码、客户识别信息及任何由相关中国结算提供已综合、认可及配对的券商客户编码及客户识别信息（由任何一方或透过香港交易所储存），用作市场监控和监察目的及执行交易所规则；(ii) 基于以下(c)及(d)项列出之目的不时向中华通市场营运者（直接或透过中国结算）转移此等数据；及(iii) 向在香港的相关监管机构及执法机关披露此等资料，以助他们履行有关香港证券市场的监控、监察及执法职能；',
      content9:
        'c.	允许中国结算(i) 收集、使用及储存阁下的券商客户编码及客户识别信息，以便综合及认可券商客户编码与客户识别信息，并将此类信息与其本身的投资者身份数据库进行配对，以提供该已综合、认可及配对的券商客户编码及客户识别信息给中华通市场营运者、联交所和相关联交所子公司；(ii) 使用阁下的券商客户编码及客户识别信息来协助其履行证券账户管理的监管职能; 及(iii) 向管辖中国结算的内地监管机构及执法机关披露此等资料，以助他们履行有关内地证券市场的监控、监察及执法职能；',
      content10:
        'd.	允许中华通市场营运者(i) 收集、使用及储存阁下的券商客户编码及客户识别信息，以助其就互联互通下在相关中华通市场进行的证券交易进行监管与监察及执行中华通市场营运者规则；及(ii) 向内地的监管机构及执法机关披露此等资料，以助他们履行有关内地证券市场的监管、监察及执法职能；',
      content11:
        '在指示本公司进行有关中华通证券交易时，阁下确认并同意本公司可就提供透过互联互通进行中华通证券北向交易服务为遵从联交所的要求或不时生效的联交所规则使用阁下的个人资料。阁下同时确认即使阁下往后撤回同意，阁下的个人资料不论在上述撤回同意前或后仍可能会为上述目的继续被储存、使用、披露、转移及处理。',
      content12: '未能提供个人资料或同意的后果',
      content13:
        '如阁下未能提供上述个人资料或同意给本公司，可导致本公司不能或无法继续执行阁下的交易指示或提供北向交易服务。',
      content14: '确认并同意',
      content15:
        '本人确认本人已阅读及清楚本有关中华通证券北向交易的个人资料收集声明。在以下格上勾选，本人表示同意或拒绝海通国际证券集团有限公司及其附属公司(「海通国际证券集团」或「贵司」)根据本个人资料收集声明所述的条款及目的使用本人的个人资料。',
      content16:
        '本人同意海通国际证券集团根据本个人资料收集声明所述的目的使用本人的个人资料。',
      content17:
        '本人拒绝海通国际证券集团根据本个人资料收集声明所述的目的使用本人的个人资料并确认海通国际证券集团将无法继续执行本人的交易指示或提供北向交易服务。本人进一步确认:',
      content18:
        '本人沒有提供类似同意给任何其他证券商、银行或金融机构根据本个人资料收集声明所述的目的使用本人的个人资料。',
      content19:
        '本人有提供类似同意给任何其他证券商、银行或金融机构根据本个人资料收集声明所述的目的使用本人的个人资料，而本人拒绝海通国际证券集团根据本个人资料收集声明所述的目的使用本人的个人资料的原因为：',
      content20:
        '如本人未能提供任何原因/解释或本人上述之原因/解释不能令贵司合理满意，贵司有权坚持索取本人的同意，且在本人未作出该等同意之前海通国际证券集团有权不再执行本人下达的任何中华通订单。',
      confirm: '确认',
      cancel: '取消',
      content21: '阁下的中华通证券北向交易个人资料收集声明已成功提交。',
      content22:
        '阁下的中华通证券北向交易个人资料收集声明未能成功提交, 请稍后再重试或联络海通国际客户服务部。热线电话: (852) 3583 3388 (香港) / (86) 755 8266 3232 (中国内地)。',
      content23: '关闭窗口',
      ipt: '请填写',
      prompt: '下次登录时不要提醒我'
    }
  }
}
