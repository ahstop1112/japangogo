import Vue from 'vue'
import VueI18n from 'vue-i18n'
import elementEnLocale from 'element-ui/lib/locale/lang/en' // element-ui英文包
import elementZhCNLocale from 'element-ui/lib/locale/lang/zh-CN'// element-ui中文包
import elementZhTWLocale from 'element-ui/lib/locale/lang/zh-TW'// element-ui繁体包
import locale from 'element-ui/lib/locale'
import zhTWLocale from './zh-TW' // 本地繁体包
import zhCNLocale from './zh-CN' // 本地中文包
import enLocale from './en' // 本地英文包

Vue.use(VueI18n) // vue使用i18n模块
//引入本地语音包
const messages = {
    en_US: {
        ...enLocale,  
        ...elementEnLocale,          
    }, 
    zh_CN: {
        ...zhCNLocale,  
        ...elementZhCNLocale,          
    },
    zh_TW: {
        ...zhTWLocale,  
        ...elementZhTWLocale,          
    },
}
// 创建国际化实例
const i18n = new VueI18n({
    locale: localStorage.getItem('language') || 'zh_TW', // set locale，默认繁体 this.$i18n.locale = 'zhTW';
    messages // set locale messages。语言包
})
locale.i18n((key, value) => i18n.t(key, value))
export default i18n