export default {
  //返回旧版
  asideBottom: {
    old: 'Old',
    Version: 'Version'
  },
  //侧边菜单栏
  menuList: {
    home: {
      level1: 'Home',
      level1_1: 'Home'
    },
    trad: {
      level1: 'Security',
      level1_1: 'Security',
      level2_1: 'HK, China A-shares & US Markets',
      level2_2: 'Other Markets',
      level2_3: 'IPO Subscription',
      level2_4: 'Corporate Action',
      level2_5: 'Margin Financing Ratios'
    },
    control: {
      level1: 'Cash',
      level1_1: 'Cash',
      level2_1: 'FX Conversion',
      level2_2: 'Fund Transfer',
      level2_3: 'Fund Withdrawal',
      level2_4: 'e-Payment',
      level2_5: ''
    },
    query: {
      level1: 'My Inquiry',
      level1_1: 'Inquiry',
      level2_1: 'Account Summary',
      level2_2: 'Trade Transaction History',
      level2_3: 'Fund Movement',
      level2_4: 'Stock Movement',
      level2_5: 'My Statement',
      level2_6: 'My Report'
    },
    seting: {
      level1: 'My Settings',
      level1_1: 'Settings',
      level2_1: 'Change Particulars',
      level2_2: 'Change Password',
      level2_3: 'Password Confirmation Setting',
      level2_4: 'Change Credit Limit',
      level2_5: 'Client Invest. Profile Questionnaire',
      level2_6: 'Consent for Northbound Trading of China Connect'
    }
  },
  //顶部导航栏
  topBar: {
    account: 'Account',
    loginOut: 'Logout',
    userID: 'ID',
    checkSetting: 'Check My Computer Configuration',
    backOld: 'Old Version',
    middleman: 'Account Executive',
    telphone: 'Direct Line',
    blue: 'Blue',
    yellow: 'Gold',
    huBlue: 'Turquoise',
    anhei: 'dark',
    notice: 'Notice',
    contact: 'Contact US',
    help: 'Help center',
    color: 'Theme color',
    quoteColor: 'Quote Color',
    greenUpColor: 'Green Up / Red Down',
    redUpColor: 'Red Up / Green Down',
    tishi: 'You confirm whether to logout?',
    confirm: 'Confirm',
    cancel: 'Cancel'
  },
  //底部版权信息
  bottomBar: {
    company: '©2020 Haitong International Securities Group',
    mianze: ' Disclaimers',
    pernsonInfo: 'Data Privacy Policy',
    ji: 'and',
    mianzeInfo:
      'DISCLAIMER:Haitong International Securities Company Limited, Haitong International On-line Services Limited, the HKEx Information Services Limited, the Stock Exchange of Hong Kong Limited, Hong Kong Futures Exchange Limited and their content providers, Shanghai Stock Exchange and Shenzhen Stock Exchange endeavour to ensure the accuracy and reliability of the information provided but do not guarantee its accuracy or reliability and accepts no liability (whether in tort or contract or otherwise) for any loss or damage arising from inaccuracies or omissions.Contents, news and information provided in the Securities Trading platform are properties of service providers, and shall not be copied, manipulated, republished, re-circulated, redistributed, advertised, broadcasted or otherwise disseminated to any party for any usage.'
  },
  //主页
  home: {
    //我的资产
    asset: {
      title: 'Asset',
      total: 'Total',
      account: 'Ledger Balance',
      available: 'Available Balance',
      cashTotal: 'Cash Balance',
      purchPower: 'Buying Power',
      stockVal: 'Stock Market Value',
      stockHasVal: 'Discounted Value',
      explain: '*For indicative(only Last Update',
      cash: 'Cash',
      aStock: 'A Shares',
      hkStock: 'HK',
      usStock: 'US',
      outsideStock: 'OTC',
      oneMonth: '1M',
      threeMonth: '1M',
      halfOfYear: '0.5Y',
      oneYear: '1Y',
      twoYear: '2Y',
      money: 'Profit and loss',
      percent: 'Ratio'
    },
    //常用功能
    commonFunc: {
      title: 'Commonly Used',
      tradHistory: 'Trade Transaction History',
      stockPush: 'Stock Movement',
      jiedan: 'My Statement',
      baobiao: 'My Report'
    },
    //通知
    notice: {
      title: 'Notice',
      more: 'More',
      noResult: 'No Notice yet',
      time: 'Time',
      theme: 'Subject',
      operation: 'Action',
      toView: 'Detail'
    },
    //我的持仓
    volume: {
      title: 'Stock Position',
      market: 'Market',
      aStock: 'China A-Shares',
      hkStock: 'HK',
      usStock: 'US',
      outsideStock: 'OTC Market',
      volumeVal: 'Stock Market Value',
      Profit: 'Profit and Loss',
      todyProfit: 'Profit and Loss Today',
      stock: 'Stock',
      curPrice: 'Price',
      cost: 'Cost',
      totalNum: 'Total Qty.',
      sellNum: 'Sellable Qty.',
      stockTodyProfit: 'P&L Today',
      stockProfit: 'P&L',
      marketVal: 'MV',
      chicangVal: 'DV',
      operation: 'Action',
      sell: 'Sell',
      tradHistory: 'History',
      noResult: 'No Positions yet'
    },
    //新股申购
    ipo: {
      title: 'IPO Subscription',
      more: 'More',
      rengou: 'Subscribe',
      stockPrice: 'Offer Price',
      endDate: 'Application Deadline',
      noReulst: 'No IPO for Subscription yet'
    }
  },
  // 登录页
  login: {
    bounced: 'Your login ID or password is invalid', // 提示弹框
    bounced1:
      'Your account is locked. Please contact Haitong International Customer Service Hotline for password reset：(852) 3583 3388 (Hong Kong) / (86) 7558266 3232 (China). ',
    bounced2: 'Your login ID has not been activated.',
    bounced4: 'Your login account is already suspended',
    bounced5:
      'Sorry, Web Securities Trading is under maintenance. For order placing or enquiry, please call your account executive or dealing department at (852) 2213-8333. For other enquiry, please call our customer service hotline at (852) 3583-3388.',
    bounced6:
      'Online account login unsuccessful!  As required by regulatory authority, please register an e-mail address for receiving notification of account activities.  24 Hour Investment Centre: (852) 2213 8333  CS Hotline: (852) 3583 3388 (Hong Kong) / (86) 755 8266 3232 (China) / (86) 755 8266 3232',
    bounced7:
      'System is not available. Please try again later or contact our customer service department. Our Hotline: (852) 3583-3388 / (86) 755 8266-3232[CA SERVER].',
    bounced8:
      'Failed to send One-Time Password (OTP). Please try again later or contact our customer service department. Our Hotline: (852) 3583-3388 / (86) 755 8266-3232.',
    bounced9:
      'Resend One-Time Password (OTP) too frequently. Please try later.',
    bounced10:
      'System is not available temporarily. Please contact your Account Executive or customer service at (852) 3583 3388 (Hong Kong) / (86) 755 8266 3232 (China) or dealing hotline (852) 2213 8333 for any inquiries.',
    bounced11: 'The password you entered does not correspond to our record.',
    bounced12: 'You must change your password before proceeding.',
    bounced13:
      'Password must be combination of numbers (0-9) and letters (A-Z, a-z), total 8-10 digits.',
    bounced14:
      'The status of your online login account is unusual. Please contact our customer service department to request new password.Our Hotline: (852) 3583-3388 / (86) 755 8266-3232.',
    bounced15:
      'Password Reset Unsuccessful!  As required by regulatory authority, please register an e-mail address for receiving notification of account activities.  24 Hour Investment Centre: (852) 2213 8333  CS Hotline: (852) 3583 3388 / (86) 755 8266 3232.',
    bounced16:
      'Your password is reset, please re-login after receiving the password letter.',
    bounced17: 'Your new password must not be the same as previous passwords.',
    bounced18: 'Login session invalid. Please login again.',
    bounced19: 'password cannot be empty',
    bounced20: 'The two passwords do not match',

    system: 'Securities Online Trading System',
    customer: 'Client Login',
    name: 'Login ID',
    password: 'Password',
    information1: 'Login ID is required', // 错误提示信息
    information2: 'Password is required', // 错误提示信息
    ForgetPassword: 'Forget Password',
    btn: 'LOGIN',
    Register: 'Software Token Register',
    Unregister: 'Software Token Unregister',
    Activation: '"Activation Code"Login',
    Caution:
      'Caution: Please temporarily disable all installed "Pop-up Blocker" (eg. WinXP SP2 IE, Yahoo Toolbar, Google Toolbar, MSN Toolbar, etc) before login, otherwise some functions may not be able to work properly.',
    kefu:
      'For unsuccessful online trading, please call our Dealing Hotline (852) 2213 8333 for placing order.If you have any enquires when logging in to the online trading platform, please call our Customer Services Hotline (852) 3583 3388 or (86) 755 8266 3232 for assistance during office hours.',
    company:
      'Haitong International Securities Company Limited is a licensed corporation to carry on Type 1 (dealing in securities) regulated activities for the purposes of the Securities and Futures Ordinance (Cap.571) (CE No.: AAF806) and an Exchange Participant of The Stock Exchange of Hong Kong Limited.',
    prompt1:
      'To protect your account,we recommend you to change your password regularly,please change your password according to the instruction.',
    keep: 'Keep Password',
    tishi: 'prompt'
  },
  // 保安提示弹框
  prompt: {
    title:
      'Security tips for using Haitong International online trading platforms via mobile phones and tablets/desktop computer',
    content1:
      '1.Do not store your Internet/Mobile trading username and password on your mobile handsets and tablets/desktop computer.',
    content2:
      '2.Never disclose your personal security data (such as account number or personal password) to anyone, even if someone claims to be an employee of the company or a police officer.',
    content3:
      '3.Avoid using a public computer to log in to Haitong International Online Trading Platform.',
    content4:
      '4.Be alert to your surroundings before conducting any transactions. Make sure no one sees your PIN and cover the keypad when you enter your PIN on any device.',
    content5:
      '5.Install and update the latest anti-virus and anti-spyware software regularly on your mobile handsets and tablets/desktop computer, whenever they are available.',
    content6:
      '6.Avoid sharing your mobile handsets and tablets/desktop computer with others and use your own handset or tablet/desktop computer to log on.',
    content7:
      '7.Do not leave your handset or tablet /desktop computer unattended after logon to Internet/Mobile trading platforms. Always log off properly when you are finished using it.',
    content8:
      '8.Before transferring, selling, or recycling your mobile phone or tablet/desktop, delete all of the information from your old device(s).',
    content9:
      '9.If you lose your mobile phone or tablet/desktop computer, you should review your account transaction history through online trading platforms. If there are any suspicious transactions, please contact Customer Service Hotline and report to us immediately. You should also enable remote wiping and report stolen timely.',
    content10:
      '10.Set up auto-lock and enable passcode lock to prevent unauthorized access to your handsets.',
    content11:
      '11.When using Wi-Fi connection, please use trusted Wi-Fi networks or service providers and enable security protection such as Wi-Fi Protected Access (WPA), if possible',
    content12:
      '12.Disable Bluetooth if you are not using or set the smartphone or tablet/desktop computer to non-discovery mode.',
    content13:
      '13.Use default browsers originally provided by mobile handsets and tablets/desktop computer rather than newly installed browsers downloaded from other sources.',
    content14:
      '14.Do not use any jail-broken handset or tablet to avoid loopholes when logging on the online trading platforms.',
    content15:
      "15.Don't install applications on your mobile handsets or tablets from mistrusted sources. Understand the permissions of mobile application before installation. Don't use untrusted custom virtual keyboards.",
    content16:
      '16.Install updates and patches to your smartphone and tablet /desktop computer timely, covering upgrade/update of OS and other mobile applications. Enable data encryption in handset or tablet /desktop computer if feasible.',
    content17:
      '17.Always download our application from official application store only to avoid going to fraudulent websites',
    content18: '18.For security reasons, change your password regularly',
    content19:
      '19.Actively monitor the activities of your account. Check your monthly statement soon after receiving it. If you find any unusual transactions, please notify the Company immediately. You can always check the transaction records of your account through Haitong International Online Trading Platform.',
    content20:
      '20.Do not forward one-time passwords (OTP) received via short message service (SMS) from your mobile devices to other devices when using SMS OTPs for two-factor authentication login.',
    chek: "Don't alert me again",
    Close: 'Close'
  },
  // 2FA 页面
  twoFaLogin: {
    // 短讯认证
    phoneLogin: {
      check: 'Mobile phone number is required',
      check1: 'Please input valid mobile number',
      check2: 'Your one-time password (OTP) is required',
      check3: 'Please input valid One-Time Password (OTP)',
      Sms: 'SMS Verification',
      coding: 'OTP Verification',
      code:
        'Please input your registered mobile phone number in Haitong International for receiving the One Time Password(OTP).',
      phone: 'Please enter your cell phone number',
      prompt1:
        '*Country code and area code is not required. For example, if your mobile phone number is (86)13912345678, you only have to input 13912345678.',
      prompt2:
        '*If you fail to receive the One Time Password ("OTP”), you may select another SMS Service Provider. We will send a new OTP to your registered mobile phone.',
      btn1: 'Cancel', // 取消按钮
      btn2: 'Continue', // 确认按钮
      supplier1: 'SMS Service Provider 1', // 服务商
      supplier2: 'SMS Service Provider 2',
      supplier3: 'SMS Service Provider 3',
      supplier4: 'SMS Service Provider 4',
      prompt3: 'Mobile number is incorrect. Please re-login.'
    },
    // 保安编码认证
    codingLogin: {
      coding1: 'Please input the six-digit One Time Password (OTP)',
      coding2: 'Enter OTP Here',
      bounced1: 'System information invalid.'
    }
  },
  // 验证码填写页面
  codeLogin: {
    code:
      'Please input the six-digit One Time Password (OTP) received from your registered mobile phone number in Haitong International.',
    time: 'Verification code will expire at',
    shixiao: ' failure.',
    prompt: 'Enter OTP Here', // 提示
    resend: '',
    resend1: 'Resend',
    no: 'If I do not receive the OTP, what should I do?',
    content1:
      "1. The delivery of OTP may be affected by network condition. If you don't receive your OTP within a reasonable time, please click 'RESEND OTP' to obtain another OTP.2. The OTP will only be sent to the customer's registered mobile phone number. If you need to update your registered mobile phone number, please fill in and submit the ' Change of Particular & Estatement Service Form to us.",
    check1: 'Your one-time password (OTP) is required',
    check2: 'Please input valid One-Time Password (OTP)',
    bounced1:
      'Login fail due to channel expired. Please contact our customer service department. Our Hotline: (852) 3583-3388 / (86) 755 8266-3232.', // 错误提示弹框
    bounced2:
      'Your online account is suspended. Please contact our customer service department. Our Hotline: (852) 3583-3388 / (86) 755 8266-3232.',
    bounced3:
      'The selected password letter has already been voided and reset. Please contact our customer service department. Our Hotline: (852) 3583-3388 / (86) 755 8266-3232.',
    bounced6:
      'Exceeded maximum number of failed One-Time Password (OTP) login attempt, your account is locked. Please contact our customer service department. Our Hotline: (852) 3583-3388 / (86) 755 8266-3232.',
    bounced7:
      'Your One-Time Password (OTP) is expired. Please click “RESEND OTP” to obtain another One-Time Password (OTP).',
    bounced8:
      'Resend One-Time Password (OTP) too frequently. Please try later.',
    bounced9: 'Your One-Time Password (OTP) is incorrect. Please input again.',
    bounced10:
      'Number of One-Time Password (OTP) resend request exceeded limit. Please re-login.'
  },
  // 注册流动编码页面
  register: {
    // 弹框
    addDialog: {
      title: 'registered software token',
      content:
        'You have not registered software token！ Press ‘OK’ to register now or ‘Cancel’ to continue with SMS Authentication (SMS OTP).'
    },
    registerCode: {
      name: 'Login ID',
      password: 'Password',
      phone: 'Registered Mobile Phone Number',
      email: 'Registered Email Address',
      agree: 'I understand and accept',
      terms: 'the Terms of Use',
      promptName: 'Please enter Please enter the Login ID',
      promptPassword: 'Please enter Password',
      promptPhone: 'Please enter Registered Mobile Phone Number',
      promptEmail: 'Please enter Registered Email Address',
      check: 'Email address is required',
      check1: 'Please input valid e-mail address',
      terms1: 'Please check the terms',
      errorMsg1:
        'Login ID is missing. Please try again later or contact our customer service department. Our Hotline: (852) 3583-3388 / (86) 755 8266-3232.',
      errorMsg2: 'Number of registered devices exceed the limit',
      errorMsg3: 'Device is already registered.',
      errorMsg4: 'Software token enrollment resend limit exceeded.',
      errorMsg5:
        'Please input valid mobile number and e-mail address,if you have not registered them before, Please contact Haitong International Customer Service Hotline for password reset：(852) 3583 3388 (Hong Kong) / (86) 755 8266 3232 (China).',
      errorMsg6:
        'Fail to send e-mail. Please try again later or contact our customer service department. Our Hotline: (852) 3583-3388 / (86) 755 8266-3232.',
      errorMsg7: 'You have not registed software token.',
      errorMsg8: 'One time password( OTP) does not exist.'
    },
    success: {
      content1:
        'Activation Package and OTP are sent to your registered Email Address and Mobile Phone.',
      content2:
        'Please follow the instructions and open the URL in the e-mail.',
      content3:
        'You will be asked to input the Activation OTP after opening the URL.'
    },
    unregister: {
      title: 'Software Token Unregister',
      CancelRegister: 'Confirm Unregister？',
      complete: 'UnRegister is finish',
      zaici: 'Register Software Token at this device?'
    }
  },
  // 风险披露页面
  risk: {
    content1: `
    <h4 style="font-family: SourceHanSansCN-Medium;
    font-size: 18px;
    color: #333333;">Risk Disclosure Statement of Electronic Service</h4>
    1.The account holder is the only authorised user of the Electronic Services. You, as the account holder, shall be wholly and solely responsible for the confidentiality, security and use of the Access Codes issued to you by our Company. Our Company shall not be liable for any loss or damage you may suffer as a result of unauthorised using or attempting to use the Electronic Services.
    <br />
    <br />
   2.If you undertake transactions on an electronic trading system, you will be exposed to risks associated with the system including the failure of hardware and software. The result of any system failure may be that your order is either not executed according to your instruction or is not executed at all.
    <br />
    <br />
   3.Electronic trading facilities are supported by computer-based component system for the order-routing, execution, matching, registration or clearing of trades. As with all facilities and systems, they are vulnerable to temporary disruption or failure. Your ability to recover certain losses may be subject to limits on liability imposed by the system provider, the market, the clearing house and or participant firms. Such limits may vary.
    <br />
    <br />
    4.Due to unpredictable traffic congestion and other reasons, electronic transmission may not be a reliable medium of communication. Transactions conducted via electronic means are subject to delays in transmission and receipt of your instruction or other information, delays in execution or execution of your instructions at prices different from those prevailing at the time your instructions were given, transmission interruption or blackout. There are risks of misunderstanding or errors in communication.
    <br />
    <br />
    5.You are strongly advised to review every instruction before entering it as it may not be possible to cancel your instruction once given.
    <br />
    <br />
    6.Our Company does not guarantee the timeliness, sequence, accuracy or completeness of market data or any market information including any information provided to you through the electronic trading system. Our Company shall not be liable in any way for any loss arising from or caused by (1) any inaccuracy, error in or omission from any such data, information or message; (2) any delay in the transmission or delivery thereof; (3) any suspension or congestion in communication; (4) any unavailability or interruption of any such data, message or information whether due to any act of our Company; or (5) by any forces beyond the control of our Company.
    <h4 style="font-family: SourceHanSansCN-Medium;
    font-size: 18px;
    color: #333333;">Points to Note for trading China A shares:</h4>
    Customer is required to read and understand the Stock Connect Supplement of terms & conditions and Risk Disclosure and other information. For details, please refer to below documents:
    <br />
    <a style=" font-family: SourceHanSansCN-Medium;
    font-size: 1rem;
    color: #4191ff;
    letter-spacing: 0;
    line-height: 12px;
    border-bottom: 1px solid #4191ff;" href="http://www.htisec.com/sites/default/files/Amendments%20to%20Cash%20Account%20and%20Leveraged%20Foreign%20Exchange%20Trading%20Account%20Terms%20%26%20Conditions_EN.pdf"
    target="_blank">Stock Connect Supplement to Cash Account and Leveraged Foreign Exchange Trading Account Terms & Conditions and Stock Connect Risk Disclosure and other information</a>
    <br />
    <a style=" font-family: SourceHanSansCN-Medium;
    font-size: 1rem;
    color: #4191ff;
    letter-spacing: 0;
    line-height: 12px;
    border-bottom: 1px solid #4191ff;" href="http://www.htisec.com/sites/default/files/Amendments%20to%20Margin%20Account%20and%20Leveraged%20Foreign%20Exchange%20Trading%20Account%20Terms%20%26%20Conditions_EN.pdf"
    target="_blank">Stock Connect Supplement to Margin Account and Leveraged Foreign Exchange Trading Account Terms & Conditions and Stock Connect Risk Disclosure and other information</a>
    <h4 style="font-family: SourceHanSansCN-Medium;
    font-size: 18px;
    color: #333333;">Points to Note for US Stock Online Trading Service:</h4>
    I/We acknowledge and consent the following Points to Notes below:
    <br />
    1.Account Documentation and W-8 Form (Department of the Treasury Internal Revenue Service)
    <br />
    To apply for the US stock online trading service, applicants (non-US citizens/residents and non-Canadian residents) should fill in the W-8 Form during services application. The W-8 form is subject to renew for every 3 years. If W-8 Form has not been renewed as aforesaid, the US stock trading services will not be provided, and only sell orders can be placed on the US Stocks, and the capital gain tax will be withheld until W-8 Form is renewed. Please also note that you come under a different tax regime when invest overseas, and may NOT be exempted from US capital gain taxes. You should seek professional tax advice, where appropriate.
    <br />
    <br />
    2.US Tax ( e.g. withholding tax on dividends gained )
    <br />
    The US tax regime covers everyone holding US-based investments (be it marketable securities, mutual funds, or bonds, etc.) in his/her own name, regardless of whether the person is a US citizen or permanent resident. In other words, all investors holding US securities of any form are required to pay a withholding tax on dividends gained.
    Any U.S. source income received by a customer through the Company, including interests or dividends, is subject to the U.S. withholding tax. Therefore, the Company’s executing broker for U.S. stocks is required to withhold a tax of up to 30% of any payment of the said income to a foreign person. Moreover, the Company will not represent or assist a customer for any application filed with the IRS for reduction or exemption of the withholding tax.
    <br />
    You should seek professional tax advice, where appropriate. For details, please click the following SFC’s link:    
    <br />
    <a style=" font-family: SourceHanSansCN-Medium;
    font-size: 1rem;
    color: #4191ff;
    letter-spacing: 0;
    line-height: 12px;
    border-bottom: 1px solid #4191ff;" href="http://www.thechinfamily.hk/web/tc/financial-products/financial-intermediaries/broker/online-trading/trading-process.html"
    target="_blank">(http://www.thechinfamily.hk/web/tc/financial-products/financial-intermediaries/broker/online-trading/trading-process.html)</a>
    <br />
    <br />
    3.Clearing and Custodian Services
    <br />
    The execution broker would be ViewTrade Securities, Inc. and the clearing agent would be APEX Clearing Corporation.
    <br />
    Please understand that Haitong International Securities Company Ltd. will act as introducing broker and assist you to ascertain and recover the accountabilities and liabilities of ViewTrade Securities, Inc and APEX Clearing Corporation. in case of any counter-party risk arising from such arrangement.
    <br />
    <br />
    4.Provision of Services
    <br />
    (a)   If your Securities Account is in Margin Type, margin financing is provided for online US Stocks trading also. For more information like interest rate, please refer to <a style=" font-family: SourceHanSansCN-Medium;
    font-size: 1rem;
    color: #4191ff;
    letter-spacing: 0;
    line-height: 12px;
    border-bottom: 1px solid #4191ff;" href="http://www.htisec.com/zh-hk/fees-and-charges"
    target="_blank">http://www.htisec.com/zh-hk/fees-and-charges</a>。
    <br />
    (b)   The service is not available for U.S. persons and Canadian residents. Only non-US citizens/ residents, as well as non-Canadian residents, can apply for this service. For any change of personal information, please contact our customer services (852) 3583-3388 or (86) 755 8266-3232.
    <br />
    (c)   Only stocks in NASDAQ, NYSE, NYSEMKT and BATS are available for US stock online trading. And no pre/post market trading sessions are available.
    <br />
    (d)  For stocks traded at (i) OTC Bulletin Board/OTC BB and (ii) OTC Pink (i.e. outside NASDAQ, NYSE, NYSEMKT and BATS), both BUY and SELL orders cannot be placed via US Stock Online Trading Service but you can contact us for placing orders. In addition, we do not accept purchase and transfer-in of US OTC market securities with a market capitalization of less than US$50 million AND a share price of less than US$0.5 apiece. If you would like to sell the OTC stocks in your account, you may still contact your account executive or our 24-Hour Investment Centre (Tel: (852) 2213-8333) to sell the affected securities. Please be reminded that orders for US OTCmarket securities priced below US$0.5 apiece will require the manual approval from our Broker before they are routed to the market; therefore, processing time for orders placed via account executives or our 24-Hour Investment Centre would be longer. In addition, our Broker shall have absolute discretion to refuse or act upon/accept any of your instructions.
    <br />
    (e)   Online US Stocks trading provides delayed US stocks quote free of charge. If you want to subscribe real-time quote, please kindly visit eServices <a style=" font-family: SourceHanSansCN-Medium;
    font-size: 1rem;
    color: #4191ff;
    letter-spacing: 0;
    line-height: 12px;
    border-bottom: 1px solid #4191ff;" href="https://eservices.htisec.com/"
    target="_blank">https://eservices.htisec.com/</a>。 You are required to fill in the online user agreements during your first login to Online US Stocks trading for real-time US Stocks quote services. The agreements are only available in English and here is the agreement template
    <a style=" font-family: SourceHanSansCN-Medium;
    font-size: 1rem;
    color: #4191ff;
    letter-spacing: 0;
    line-height: 12px;
    border-bottom: 1px solid #4191ff;" href="http://www.htisec.com/zh-hk/ real-time-quotes/securities"
    target="_blank">http://www.htisec.com/zh-hk/ real-time-quotes/securities</a> for your reference
    <br />
    <br />
    5.Commissions and Fees
    <br />
    Upon execution of orders, commissions and fees should be paid which may vary from time to time upon notice through Haitong International’s website <a style=" font-family: SourceHanSansCN-Medium;
    font-size: 1rem;
    color: #4191ff;
    letter-spacing: 0;
    line-height: 12px;
    border-bottom: 1px solid #4191ff;" href="http://www.htisec.com"
    target="_blank">http://www.htisec.com</a> or any other means. In particular, there is special commission/ handling fee for trading the penny stock (i.e. stock value less than US$1) and American Depository Receipts (ADR) etc.
    <br />
    <br />
    6.Trading Hour
    <br />
    The trading hour of US stock online trading is 09:30am – 04:00pm Monday to Friday (US Eastern Standard Time(EST).
    All outstanding same day orders will be expired after market close at 04:00pm (EST).
Orders will be accepted from 08:00am Monday to Friday (US Eastern Standard Time (EST) (Except Holiday). Please make sure the trading account has enough buying power/stock positions for all trading instructions, and check the latest order status and account balances/portfolio after market open.

    <br />
    <br />
    7.Settlement Date
    <br />
    The purchase and sale of stocks are settled on settlement date, i.e. on the second business day after the transaction. The sales proceed of the sale transactions can be used for further stock purchase until settled.
    <br />
    <br />
    8.Fund Deposit/ Withdrawal
    <br />
    US Dollar should be deposited or exchanged from other currencies to the US stock online trading account for online trading purpose. The cut off time of fund deposit instruction for online US Stocks trading services is 4:30 pm Monday to Friday Hong Kong Time (except public holiday), and the cutoff time of fund withdrawal and foreign currency exchange instructions is 2:00 pm Monday to Friday Hong Kong Time (exceptpublic holiday), the buying power of online trading account will be updated before US Stocks Market opens.
    <br />
    <br />
    9.Position Transfer
    <br />
    Please pay special attention that the online US Stocks trading instructions, account balance and stocks positions are totally separated from offline account. If client would like to transfer the balance/position between the online and offline accounts, please submit the request by 2:00pm Monday to Friday Hong Kong Time (Except Holiday). Should you have any enquiry, please contact your Account Executive or Customer Services for details.
    <br />
    <br />
    10.Miscellaneous
    <br />
    Details could be referred to the account opening document(s) and other accompanying documents and other information (including any relevant updates from time to time) on Haitong International’s website
    <a style=" font-family: SourceHanSansCN-Medium;
    font-size: 1rem;
    color: #4191ff;
    letter-spacing: 0;
    line-height: 12px;
    border-bottom: 1px solid #4191ff;" href="http://www.htisec.com"
    target="_blank">http://www.htisec.com</a>。
    <br />
    For US Stocks Trading enquiry, please call our Dealing Department at (852) 2213-8333 from 6:00pm Monday to 6:00am Saturday (Hong Kong Time) during US Stocks trading days. Please note that online services may be suspended due to special situations like holiday arrangement or unsettled corporate actions without prior notice.
    <br />
    In the event of any difference in interpretation or meaning between the Chinese and English version of this authority, the English version shall prevail.
    <h4 style="font-family: SourceHanSansCN-Medium;
    font-size: 18px;
    color: #333333;">Disclaimer for Real Time Service</h4>
    Haitong International Securities Company Limited, Haitong International Futures Limited, Haitong International On-line Services Limited, any of their holding companies, subsidiary companies or associated companies, their content providers and HKEx Information Services Limited, its holding companies and/or any subsidiaries of such holding companies, Shanghai Stock Exchange and Shenzhen Stock Exchange endeavour to ensure the accuracy and reliability of the information provided but do not guarantee its accuracy or reliability and accept no liability (whether in tort or contract or otherwise) for any loss or damage arising from any inaccuracies or omissions.Contents, news and information provided in the Securities Trading platform are properties of service providers, and shall not be copied, manipulated, republished, re-circulated, redistributed, advertised, broadcasted or otherwise disseminated to any party for any usage.

    <h4 style="font-family: SourceHanSansCN-Medium;
    font-size: 18px;
    color: #333333;">Important points to note for Use of the Electronic Services</h4>
    The electronic services provided by Haitong involve no solicitation of the sale or recommendation of, or advice on, any product from Haitong International, all transactions that you enter into through the electronic services are conducted on an execution-only basis, for more information please refer to 
    <a style=" font-family: SourceHanSansCN-Medium;
    font-size: 1rem;
    color: #4191ff;
    letter-spacing: 0;
    line-height: 12px;
    border-bottom: 1px solid #4191ff;" href="https://www.htisec.com/sites/all/themes/hitong/files/what-is-news/security_tips_en.html#es"
    target="_blank"> Important points to note for Use of the Electronic Services </a>。

    <h4 style="font-family: SourceHanSansCN-Medium;
    font-size: 18px;
    color: #333333;">Warning statement about Complex Product</h4>
    
    If you are trading a complex product (including but not limited to derivative warrant, callable bull/bear contract, exchange traded fund, equity linked instrument/equity linked note, leveraged and inverse product, futures, stock options etc.), you must read the following <a style=" font-family: SourceHanSansCN-Medium;
    font-size: 1rem;
    color: #4191ff;
    letter-spacing: 0;
    line-height: 12px;
    border-bottom: 1px solid #4191ff;" href="https://www.htisec.com/sites/all/themes/hitong/files/what-is-news/security_tips_en.html#cp"
    target="_blank">warning statement for complex products</a> before trading.。
    <br />
    <br />
    `,
    content2: `<a style=" font-family: SourceHanSansCN-Medium;
    font-size: 1rem;
    color: #4191ff;
    letter-spacing: 0;
    line-height: 12px;
    border-bottom: 1px solid #4191ff;" href="http://www.htisec.com/trading/help_menu/help_eng/order.html#pre-mkt"
    target="_blank">Trading Sessions and Order Features</a>
    and <a style=" font-family: SourceHanSansCN-Medium;
     font-size: 1rem;
     color: #4191ff;
     letter-spacing: 0;
     line-height: 12px;
     border-bottom: 1px solid #4191ff;" href="http://www.htisec.com/trading/help_menu/help_eng/order.html#special"
     target="_blank">Definitions of Order Types</a>`
  },
  // 联络我们页面
  newContact: {
    title: 'Contact US',
    content1: 'Customer Service Hotline:',
    content2: 'China Customer Hotline:',
    content3: 'EmailEnquiry:'
  },
  // 帮助中心页面
  newHelp: {
    link1: '1.Do I have to configure my browser to accept cookies?',
    link2: '2.Why the browser could memorize my account number and password?',
    link3:
      '3.How to secure my information if I use a computer shared with others?',
    link4:
      '4.Can you provide me with any tips on how to protect my account information?',
    link5: '5.What should I know before placing amend or cancel order request?',
    content1: 'Do I have to configure my browser to accept cookies?',
    content2:
      'Yes. It is necessary to configure your browser to accept cookies. Cookies are frequently used to identify you and prepare customized web pages each time you return to the same site. For example, instead of seeing a generic welcome message at the top of the page, you will see your name at the top.',
    content3: 'Why the browser could memorize my account number and password?',
    content4:
      'It is the auto-complete function on your browser. In order to avoid the automatic completion of your account number and password when you type in the account number, you have to disable the auto-complete function on your browser. ',
    content16:
      'In the Internet Explorer browser, the AutoComplete feature saves previous entries you have made for web address, forms and passwords. Then, whenever you type information into one of these fields, AutoComplete will present a possible match. To turn off the Auto-complete function, click the ˉToolsˇ menu, and then click the ˉInternet Optionsˇ. Afterward, click the ˉContentˇ tab, click the ˉAutoCompleteˇ button and then disable the ˉUser names and passwords on formsˇ. ',
    content5:
      'How to secure my information if I use a computer shared with others?',
    content6:
      'To keep you account information secure, make sure that you clear the cache (temporary internet file) and close your internet browser after logging off.',
    content7:
      'Can you provide me with any tips on how to protect my account information?',
    content8:
      'We suggest that users of Electronic Services should take the following procedures in order to maintain high security standards:',
    content9:
      '•  Change your login password periodically, through the subscribed Electronic Service(s)',
    content10: '•  Never discuss your password with anyone else',
    content11:
      "•	Create a password that is easy to remember but hard for anyone else to guess. Don't use repetitive numbers, birth dates, telephone numbers, or I.D. card numbers.",
    content12:
      '•	Exit your Internet browser when you have finished trading online. This will prevent other people from using the Back button to view your account information.',
    content13:
      '•	Always visit Haitong International homepage by typing in our address (www.htisec.com) or by using a bookmark link you created yourself',
    content14:
      'What should I know before placing amend or cancel order request?',
    content15:
      'Any unfilled Enhanced Limit Order will be put in queue as Limit Order at the same price. Amendment to Enhanced Limit Buy / Sell Order can be made only at a price not higher than the best ask / a price not lower than the best bid prices or else the amendment will be rejected by the system.',
    content16:
      'If you do not want to change the order quantity, you would not need to amend the quantity inside the field of "Ultimate order quantity". The "Ultimate order quantity" should be equal to outstanding quantity (OS. Qty) plus filled quantity (Filled Qty) This value has already filled inside the field of "Ultimate order quantity" by the system automatically.After placing amend/cancel order, please kindly click the "Refresh" button at "Order Status" to update the trading status. Market may not accept the amend/cancel order. Please confirm the result of amendment or cancellation at "Order Status".',
    content17:
      '1.	" * " represents that the previous request of amendment/cancellation has been done successfully.',
    content18:
      '2.	" # " represents the previous order amendment/cancellation has been rejected. No change in price and quantity has been accepted.',
    content19:
      '3.	" @ " represents the last order amendment/cancellation is in progress.'
  },
  //证券交易菜单
  security: {
    // 港A美股
    mainMarket: {
      hkTrading: 'HK',
      chinaTrading: 'China A-shares',
      usTrading: 'US',
      refresh: 'Refresh',
      actionExplain:
        'Attention: Please note that if you transmit an instruction via an electronic trading system on a trade day at or before 9:29 a.m., there is a risk that the said instruction might not be able to execute prior to an instruction which is transmitted by you or any other clients after 9:30 a.m., i.e. the commencement of trading hour of The Stock Exchange of Hong Kong Limited. (Applicable to Hong Kong share trading only)',
      //自选股
      watchlists: 'Watchlists',
      stock: 'Stock',
      prc: 'Price',
      prcentChg: '$Chg',
      chg: 'Chg',
      //行情图表
      chart: 'Chart',
      date: 'Data',
      addUseStock: 'Add to Watch List',
      removeUseStock: 'Remove from Watch List',
      trading: 'Trading',
      minK: 'Mins',
      fiveDate: '5D',
      dateK: '1D',
      weekK: '1W',
      monK: '1M',
      Unopened: 'Not Opened',
      Trading: 'Trading',
      Closed: 'Closed',
      Normal: 'Normal',
      LimitUp: 'Limit Up',
      LimitDown: 'Limit Down',
      Suspend: 'Suspend',
      Delisted: 'Delisted',
      IPOPeriod: 'IPO Period',
      AuctionSession: 'Auction Session',
      LunchBreak: '"Lunch Break',
      MarkerClosed: 'Marker Closed',
      Actual: 'Actual',
      AdjFwd: 'Adj.Fwd',
      AdjBwd: 'Adj.Bwd',
      updateTime: 'Last Update',
      linkName1: 'Real-time basic market prices',
      alink1: 'http://www.htisec.com/en-us/bmp',
      aExplain1:
        'are provided by HKEX, SSE and SZSE. Previous closing price of US market is provided by Orbis. ',
      linkName2: '(Disclaimer)',
      alink2: 'http://www.htisec.com/en-us/disclaimer-bmp',
      zuigao: 'High',
      jinkai: 'Open',
      zuidi: 'Low',
      zuoshou: 'Pre.Close',
      chenjiaoe: 'Turnover',
      chenjiaoliang: 'Volume',
      shiyinglv: 'P/E',
      xinshijia: 'Strike',
      shouhuijia: 'Call Price',
      shangxianjia: 'Upper Strike',
      xiaxianjia: 'Lower Strike',
      daoqiri: 'Exp.Date',
      meishou: 'Lot Size',
      pingjunjia: 'Avg Price',
      shijinlv: 'P/B',
      shizhi: 'Market Cap',
      huanshoulv: 'Turnover Ratio',
      zhengfu: 'Amplitude',
      liangbi: 'Volume Ratio',
      waipan: 'Active Buy',
      neipan: 'Active Sell',
      weibi: 'Bid/Ask',
      fiveWeekHight: '52wk High',
      fiveWeekLower: '52wk Low',
      yijia: 'Premium',
      yishenbofu: 'Implied Volatility',
      duichongzhi: 'Delta',
      jiehuobi: 'Outstanding Ratio',
      huangubili: 'Conversion Ration',
      gangganbili: 'Leverage Ratio',
      jianeijiawai: 'Moneyness',
      dahedian: 'BE',
      zuihoujiaoyiri: 'LTD',
      leibie: 'Type',
      lengjinjia: 'VCM Ref Price',
      lengjinshanxian: 'VCM Upper Limit',
      lengjinxiaxian: 'VCM Lower Limit',
      lengjinBshijian: 'VCM Cool Off Start',
      lengjinEshijian: 'VCM Cool Off End',
      shoushijingjia: 'CAS Ref Price',
      shoushishangxian: 'CAS Upper Limit',
      shoushixiaxian: 'CAS Lower Limit',
      bupinghengliang: 'Order Imbal',
      bupinghengfangxiang: 'Order Imbal Side',
      //交易状况
      orderStatus: 'Order Status',
      export: "Export Today's Transactions to Excel",
      print: 'Print',
      status: 'Status',
      all: 'All',
      completed: 'Completed',
      queuing: 'Queuing',
      canceled: 'Canceled',
      noRecords: 'No records',
      action: 'Action',
      ordNo: 'Ord.No',
      buy: 'B',
      sell: 'S',
      num: 'Quantity',
      sellNum: 'Trd.Qty',
      amd: 'Amd',
      del: 'Del',
      buys: 'Buy',
      sells: 'Sell',
      guchu: 'Sell',
      explain:
        "* The order is amended/cancelled # The order can't be amended / cancelled @ Amended/Cancel order is in progress",
      //交易状况弹出框内容
      explain1: 'The order is amended/cancelled',
      explain2: "The order can't be amended / cancelled",
      explain3: 'Amended/Cancel order is in progress',
      tradDetail: 'Order Details',
      tradExplain:
        '*Unfilled Enhanced Limit Order will be put in queue as Limit Order at the same price',
      account: 'Accout ID.',
      tradId: 'Order No.',
      tradStatus: 'Status',
      detail: 'Detail',
      tradType: 'Order Type',
      market: 'Market',
      tradPrice: 'Order Price',
      condition: 'Stop Price /Triggering Condition',
      orignNum: 'Org.Ord.Quantity',
      changeNum: 'Changed/Cancelled Qty',
      chejiaojiage: 'Traded Price',
      sellTotalNum: 'Filled Qty',
      jiaoyiduishou: 'Counterpart Broker ID',
      noComplateNum: 'OS.Qty',
      expired: 'Validity',
      refusReson: 'Order Rejected Reason',
      aon: 'AON',
      channel: 'Channel',
      changeTip: 'Amend Request',
      confirmChange:
        '*Check Order Status to confirm the result of amendment or cancellation',
      chufaPrice: 'Triggering Price',
      targePrice: 'Target Price',
      lastTradNum: 'Ultimate Order Qty',
      password: 'Password',
      placeholder: 'Please Input',
      cancelTradTip: 'Cancel Request',
      confirm: 'Confirm',
      //交易面板
      buyAllMoneyHK: 'MOS',
      type: 'Type',
      code: 'Stock',
      nums: 'QTY',
      maxBuy: 'Max Buyable',
      maxSell: 'Max Sellable',
      aon1: 'AON',
      aon2: 'AON',
      type1: 'ELO/ALO',
      type2: 'Limit Order',
      type3: ' AO',
      type4: 'SLO',
      type5: 'Conditional Order',
      price1: 'Market Order ',
      price2: 'Best Bid',
      price3: 'Best Ask',
      condition1: '>=Up Trigger',
      condition2: '<=Down Trigger',
      whole: 'all',
      custormId: 'BCAN',
      tiaojian: 'Conditional',
      price: 'Unit Price',
      tradMoney: 'Order Amt',
      costMoney: 'Reference Charges',
      duiyinzhi: 'HKD Eqv',
      cost1: 'Commission',
      cost2: 'CCASS Charges',
      cost3: 'Levy Charges',
      cost4: 'Stamp Charges',
      cost4: 'Trading Fee',
      cost5: 'Total in HKD Equivalent',
      costExplain:
        '*Commission and Charges shown above are for reference only. The reference commission is calculated by multiplying the order amount by 0.15%. For the actual amount of commission and charges, please refer to your daily statement.',
      usExplain1: '* Reference rate is 0.15%.',
      usExplain2: `*ESS is charged per stock per trade side per trade date(applicable stock：<a class="activeTagColor" target="_blank" href="http://www.viewtrade.com/ess">http://www.viewtrade.com/ess</a>）。`,
      usExplain3:
        '*Applicable to OTCBB, pinkSheet & BATS of US trading markets with the transaction quantity more than 100,000 share of US Penny Stocks(Penny Stock means those stocks with Stock Price below USD 1).',
      usExplain4:
        'All charges are for reference only. Please refer to fee schedule and Statement of Account for details.',
      totalPrice: 'Rough Amt',
      noMoneyExplain:
        'Your buying power is not enough to place the order.  you can increase buying power by fund transfer or fund deposit.',
      accountTrans: 'Fund Transfer',
      assetInput: 'Fund Deposit',
      success: 'Success',
      sucTip: 'Please record the Order No',
      //股票结存
      stockPosition: 'Stock Position',
      marketVal: 'Stock Market Value',
      profitLoss: 'Profit and Loss',
      profitToday: 'Profit and Loss Today',
      curPrice: 'Price',
      costPrice: 'Cost',
      totalNum: 'Total Qty.',
      canSellNum: 'Sellable Qty.',
      jinriyingkui: 'P&L Today',
      cankaoyingkui: 'P&L',
      shizhi: 'MV',
      ancanzhi: 'DV'
    },
    // 其他市场
    otherMarket: {
      headTitle: 'Tokyo',
      headTitle1: 'Seoul',
      headTitle2: 'Taipei',
      service: 'Phone Order Placing：',
      phone: 'Call Dealing Department at: ',
      time: 'Trading Hours(HK time):',
      time1: 'Morning Session',
      time2: '　8:00 am - 10:30 pm',
      time3: 'Afternoon Session',
      time4: '11:30 am - 2:00 pm',
      time5: '8:00 am - 2:00 pm',
      time6: '9:00 am - 1:30 pm',
      date: 'Settlement Day:',
      commission: 'Commission&Charges:',
      content: 'Please refer to',
      link: 'www.htisec.com',
      content1: 'or call your Account Executive for details.',
      exchange: 'Foreign Exchange:',
      info:
        "Simply give us an instruction, we can arrange foreign exchange for you. Exchange rate is subject to respective bank's confirmation after execution.",
      query: 'Exchange Rate',
      reference: '* For indicative only',
      updateTime: 'Last Update',
      conversion: 'Covert'
    },
    // 新股认购
    ipoSubscriptions: {
      list: 'IPO List',
      stock: 'Stock',
      price: 'Offer Price',
      date7: 'Subscription Deadline',
      state: 'Status',
      details: 'IPO Detail',
      accept: 'Open',
      accept2: 'Suspend',
      suspended: 'Close',
      jiaoYiSuo: 'Market',
      currency: 'Currency',
      commission: 'Brokerage Rate',
      huiFei: 'SFC transaction levy',
      huiFei1: 'Investor compensation levy',
      jiaoYiFei: 'Stock Exchange trading fee',
      zaFei: 'Misc Fee',
      date: 'Issuer Refund Date',
      date1: 'Share Collection Date',
      date2: 'Listing Date',
      sharesNumber: 'Lot Size',
      way: 'Subscription Type',
      cash: 'Fully Paid',
      date3: 'Application Deadline',
      date4: 'Payment Deadline',
      date5: 'Payment Debit Date',
      poundage: 'Handling Charges',
      subscribe: 'Margin Financing',
      date6: 'Number of Interest Bearing days',
      interestRate: 'Interest Rate',
      amount: 'Minimum Loan Amount',
      proportion: 'Maximum Loan Ratio',
      btn: 'Subscribe',
      cash1: 'Fully Paid',
      margin: 'Margin Financing',
      cashMargin: 'Fully Paid/Margin Financing',
      jieshou: 'OPEN',
      bujieshou: 'CLOSE',
      zanting: 'SUSPEND',
      popover: {
        title: 'IPO Subscription',
        headInfo: 'Subscription details',
        headLink: 'Prospectus',
        headLink1: 'Table of Multiples',
        sharesNumber: 'Apply Qty',
        proportion: 'Loan Ratio',
        amount: 'Apply Amount',
        chekTitle:
          'Before proceeding further, please make the following confirmations by ticking the boxes below:',
        chekInfo1:
          'I/We represent and warrant that I am/we are eligible to apply for the securities.',
        chekInfo2:
          'I/We confirm that I/we have been provided with sufficient opportunity to access the prospectus and the information disclosed in the prospectus.',
        chekInfo3:
          'I/We have read and understood the foregoing terms and conditions and application procedures set out in the Website in relation to the application for securities and agree to be bound by them.',
        chekInfo4:
          'I/We fully understood the once any application for securities is given, it may not be revoked, amended or withdrawn.',
        chekTitle2:
          'Free Notification Service for Announcement of Result of Application',
        details: 'Details',
        detailsInfo:
          'In the afternoon of the day when issuer announces the allotment result, HTISCL shall credit the amount of securities which are successfully allotted to you in your securities electronic trading account maintained with HTISCL. HTISCL will offer free notification service to inform you when the allotment result is available at your electronic trading account. Please kindly select the channel via which you would prefer to receive the notification for delivering the notification service(Notification will be delivered to your email address or mobile registered with HTISCL.)。',
        notice: 'Email',
        notice1: 'Short Message',
        submitInfo: 'Your IPO Subscription Application is submitted.',
        btn: 'IPO Subscription Enquiry'
      },
      prospectus: {
        title: 'Prospectus',
        content: 'How to view the prospectus of "testing3":',
        content1:
          '1.	View the electronic version of the prospectus from Hong Kong. Exchange and Clearing Limited:',
        content2:
          'a.Navigate Hong Kong Exchange and Clearing Limited homepage at',
        content3: 'b.Click "Listed Company Information Search".',
        content4:
          'c.Enter stock code "6789" and then select "Prospectuses" under the session of "Search by Document Type". Click "Search" to retrieve the prospectus file.',
        content5:
          '2.To visit one of the branches of the receiving bank(s), details are set out in the issue newspaper announcement of the issuer.',
        content6:
          'WARNING:Information in relation to this IPO falling outside the areas accessible by following the above Instructions is not part of the public offer documents. Securities offered under this IPO are offered solely on the basis of information contained in the public offer documents.',
        content7:
          'Note: In order to view the electronic prospectus, you may need Acrobat Reader. ',
        link: 'https://www.hkex.com.hk/?sc_lang=en'
      },
      prospectusForm: {
        number: 'Qty',
        amount: 'Amount'
      }
    },
    // 公司行动
    corporateAction: {
      title: 'Corporate Action',
      list: 'List',
      market: 'Market',
      stock: 'Stock',
      type: 'Type',
      date: 'Reply Deadline',
      date1: 'Expected Pay Date',
      state: 'Reply',
      yihuifu: 'Replied',
      weihuifu: 'Not Replied',
      xianjinguxi: 'Cash Dividend',
      gupiaoguxi: 'Scrip Dividend',
      details: 'Details',
      code: 'Ref',
      dividend: 'Dividend Per Share',
      newShares: 'New Price',
      describe:
        'The captioned company declared that shareholders are offered the option of receiving the above-mentioned dividend.Kindly advise us of your intention by submitting the following instruction Online or by signing and returning instruction letter to our Settlement Department by mail, by fax (852) 2537 7647,or by contacting your Account Executive NO LATER THAN August 18, 2018. If we do not receive your duly completed instruction,we shall accept CASH dividend in on your behalf.',
      describe1:
        'The captioned company declared that shareholders are offered the option of receiving the above-mentioned dividend.Kindly advise us of your intention by submitting the following instruction Online or by signing and returning instruction letter to our Settlement Department by mail, by fax (852) 2537 7647,or by contacting your Account Executive NO LATER THAN August 18, 2018. If we do not receive your duly completed instruction,we shall accept SCRIP dividend in  on your behalf.',
      info:
        '*If you have standing instruction on the entitlement option, you can ignore it.',
      info1:
        'For more information on the corporate action mentioned above, please refer to the relevant announcements that have been posted in the website of HKEx  at',
      info2:
        'under Investment Service Centre "Listed Company Information Search". ',
      info3:
        'I/We refer to the captioned subject and wish to advise you that: ',
      info4: 'Number of shares held for dividend:',
      info5: 'Wholly in Cash',
      info6: 'HKD',
      info7: 'RMB',
      info8: 'USD',
      info9: 'Wholly in Scrip',
      info10: 'Partial Election',
      info11: 'shares obtain CASH dividend',
      info12: 'shares obtain SCRIP dividend',
      tijiao: 'Submit',
      successInfo:
        'Your Corporate Action Instruction has been successfully received. ',
      successInfo1:
        'You can go to “Corporate Action Entitlement History” section to check the details.',
      btn: 'Corporate Action Entitlement History'
    },
    // 按仓比率
    marginFinancingRatios: {
      ganggu: 'HK',
      hugutong: 'SH-A',
      ganggutong: 'SZ-A',
      meigu: 'US',
      ratio: 'Margin Ratio',
      operation: 'Action',
      maimai: 'Trade',
      noRecord: 'No record matched for the search',
      stock: 'Stock'
    }
  },
  //资金管理菜单
  cash: {
    //货币兑换
    fxConversion: {
      zhishi: 'FX Conversion',
      explain1:
        '*The Service provided under this Platform is solely for the Client to facilitate Transactions and/or any other related trading activities and/or settlement of such including but not limited to the fees and charges incurred in the Account and/or any account maintained with any HTI Company',
      explain2:
        '*The symbol “CNY” in the platform refers to a quotation for/against offshore Renminbi (RMB)',
      sell: 'Sell',
      accountName: 'Account Name',
      accountNum: 'Account',
      market: 'Market',
      money: 'Currency',
      buy: 'Buy',
      duihuanDate: 'Value Date',
      query: 'Enquire',
      mianze: 'Disclaimer',
      mianzeContent1:
        'Haitong International Securities Group Limited, its subsidiaries and their officers, employees, representatives or agents (“Haitong”) shall not be held liable for any losses, damages or injury resulting from your access to, use of, or inability to access, or use of this platform including the services provided via this platform unless there is fraud or willful misconduct from Haitong for the provision of services in this platform.',
      mianzeContent2:
        'You understand and acknowledge that there would be possible delays or failure in transmission, any transmission interruption or blackout conducted via electronic means and agree that Haitong shall not be held liable for such or any resulting losses, damages or injury.',
      mianzeContent3:
        'Information and material provided on this platform do not constitute an offer to sell or the solicitation of an offer to buy any currencies and must not be relied upon in connection with any investment decision. Please consult independent advices when necessary.',
      huilv: 'Exchange Rate',
      duichu: 'Sell',
      duiru: 'Buy',
      duihuanlv: 'The above information is for reference only. (Last Update',
      duihuanExplain:
        'By submitting a Conversion Instruction below, you hereby agree to the relevant terms set out in the Foreign Exchange Conversion Service supplement to Cash/Margin Account Term& Conditions and to confirm that the conversion is for Eligible Purpose.',
      password: 'Password',
      change: 'Modify',
      confirm: 'Confirm',
      duihuanSuccess:
        'Your Conversion Instruction has been successfully received.',
      bianhao: 'Please note the Reference No.',
      duihuanjilu: 'FX Conversion History',
      print: 'Print',
      jiecunTotal: 'Currency Balance Summary Table',
      allMarket: 'All',
      hkAUSAsotck: 'HK,China A-shares,US&OTC Markets',
      cnBStock: 'China B Shares Market',
      otherMarket: 'Other Markets',
      date: 'Date',
      sellMoney: 'Please input Sell Amount',
      buyMoney: 'Please input Buy Amount',
      formCheck1: 'Please input either Sell Amount or Buy Amount.',
      formCheck2:
        'Please input correct Sell Amount, with 2 decimal places at most.',
      formCheck3:
        'Please input correct Buy Amount, with 2 decimal places at most.',
      formCheck4: 'Only one of Sell Amount or Buy Amount can be inputed',
      formCheck5: 'Sell Currency can′t be same as Buy Currency'
    },
    //账户转账
    fundTransfer: {
      chuzhangAccout: 'Transfer from',
      chuzhangzhanghu: 'From Account',
      chuzhangRequire: 'Please Select From Account',
      marketAndCurrency: 'Market and Currency',
      marketRequire: 'Please Select Market and Currency',
      money: 'Transfer Amount',
      moneyPlaceholder: 'Please input Amount',
      ruzhang: 'Transfer To',
      zhanghuType: 'Account Type',
      zhanghuTypeRequire: 'Please Select Type of Trading Account',
      accoutType1: 'Securities',
      accoutType2: 'Futures',
      ruzhangAccount: 'To Account',
      ruzhangRequire: 'Please Select To Account',
      market: 'Market',
      marketRequire: 'Please Select Market',
      zhengquanMarket1: 'HK, China A – shares,US & OTC Markets',
      zhengquanMarket2: 'China B Shares Market',
      zhengquanMarket3: 'Other Markets',
      qihuoMarket1: 'Local Market',
      qihuoMarket2: 'Overseas Market',
      nextStep: 'Next',
      zhuyi: 'Notice',
      zhuyiinfo1:
        '1.Fund Transfer is available from 9 am to 5 pm in trading days of Hong Kong stock market.',
      zhuyiinfo2:
        '2.Fund Transfer is applicable between Securities Accounts and Futures Accounts.',
      zhuyiinfo3:
        '3.Fund Transfer is applicable for Hong Kong Dollar,US Dollar and Renminbi.',
      zhuyiinfo4:
        '4.If there is any transaction done on the date of fund transfer, the related commission and other fees applicable may not yet be deducted. Please reserve sufficient amount in the Account to avoid negative balance and debit interest.',
      heshi: 'Instruction',
      heshiinfo:
        'Please verify the following details. Click the CONFIRM button to proceed. Or, click the MODIFY button to edit.',
      password: 'Password',
      change: 'Modify',
      confirm: 'Confirm',
      zhishi: 'Your instruction has been successfully processed.',
      bianhao: 'Please note the Reference No. for your records',
      zhanghujiecun: 'Account Summary',
      print: 'Print',
      formCheck1: 'The transfer amount of your instruction is invalid.',
      formCheck2:
        'Your deposit amount of your instruction is invalid.The amount should be between HKD 1 and HKD1,000,000,000 （WC7001）REF：WEB001-1594105187912-21 ',
      formCheck3: 'The function is not applicable to your account.'
    },
    //资金提取
    fundWithdrawal: {
      tikuanzhanghu: 'Withdrawal From',
      koukuanzhanghu: 'Debit Account',
      market: 'Market',
      zhengquanMarket1: 'HK, China A – shares,US & OTC Markets',
      zhengquanMarket2: 'China B Shares Market',
      zhengquanMarket3: 'Other Markets',
      tiquMoney: 'Debit Amount',
      tiquPlaceholder: 'Please input Amount',
      cunruzhanghu: 'Withdrawal To',
      bankZhanghu: 'Bank Account',
      nextStep: 'Next',
      zhuyi: 'Notice',
      zhuyiExplain1:
        '1、Fund Withdrawal is available from 9 am to 5 pm in trading days of Hong Kong stock market.',
      zhuyiExplain2:
        '2、Instruction submitted before 2 pm will be processed in the same day and instruction submitted after 2 pm will be processed in the next business day.',
      zhuyiExplain3:
        '3、Please make sure the designated bank account is correct and valid for fund deposit. For assistance, please call our Customer Service Hotline at (852) 3583-3388 / (86) 755 8266-3232.',
      zhuyiExplain4:
        '4、Fund Withdrawal is applicable for Hong Kong Dollar only.',
      zhuyiExplain5:
        '5、If there is any transaction done on the date of fund withdrawal, the related commission and other fees applicable may not yet be deducted. Please reserve sufficient amount in the Account to avoid negative balance and debit interest.',
      tiquTitle: 'Fund Withdrawal',
      tiquTip:
        'Please verify the following details. Click the CONFIRM button to proceed. Or, click the MODIFY button to edit.',
      zhishi: 'Instruction',
      password: 'Password',
      zhizhangzhanghu: 'Debit From',
      ruzhangzhanghu: 'Credit To',
      change: 'Modify',
      cofirm: 'Confirm',
      confirmSuccess: 'Your Instruction has been successfully processed.',
      bianhao: 'Please note the Reference for your record',
      ticunjilu: 'Fund &Stock Movement History',
      print: 'Print',
      formCheck1: 'Bank Amount is required',
      formCheck2: 'Debit Account is not correct',
      formCheck3:
        'Your deposit amount of your instruction is invalid.The amount should be between HKD 1 and HKD1,000,000,000 （WC7001）REF：WEB001-1594109581200-24'
    },
    // 资金存入
    ePayment: {
      eps: {
        content1:
          'securities and futures transactions (daily limit of HK$50,000), at Haitong International Customer Service Centre situated in Sheung Wan, as well as all the branches located throughout Hong Kong, without the need to visit the banks or utilize cheques.',
        content2:
          "EPS is an electronic payment method linking up customers and merchants via the bank system. It simplifies transactions between customers and merchants by enabling direct fund transfers from customers' bank accounts to that of merchants. Users of this cashless payment system can be assured of convenience and security.",
        content3:
          'Should you have enquiry, please free feel to contact our online services hotline at (852) 3583-3388 . ',
        btn: 'BACK',
        information1: '',
        link: 'EPS',
        information2:
          ' Services available at our branches except Macau branch.',
        information3: ''
      }, // 易辦事
      fps: {
        information1: 'Using',
        link: ' The Faster Payment System (FPS) ',
        information2:
          'transfer, trading days 9:00am – 4:00pm is expected to process within 2 hours, other time periods and non-trading days are expected to process before 11:00am on the next business day, free of charge.',
        information3:
          'is a payment financial infrastructure introduced in 2018 by the Hong Kong Monetary Authority (HKMA) and operated by Hong Kong Interbank Clearing Limited (HKICL) to enable a safe, efficient and widely accessible payment service on a 24/7 basis in Hong Kong in multiple currencies – Hong Kong dollar (HKD) and Renminbi (CNY).'
      }, // 转数快
      easyRevolutions: {
        link1: ' eTransfer Service ',
        information1:
          'is applicable to all securities customers with PPS on Internet accounts to make instant online payment transfer via',
        link2: 'www.htisec.com ',
        information2:
          'to have the account balance updated on real time basis within service hours.',
        link3: '',
        information3: '',
        red: '',
        information4: '',
        information5: 'Make instant payment transfer from PPS via ',
        link4: 'www.htisec.com ',
        information6: '',
        link5: '',
        information7: '',
        link6: '',
        information8:
          'upon insufficient funds in online securities account, the dealing instruction will be transmitted all at your fingertips.',
        red1: '',
        information9: ''
      }, // 易转数
      pps: {
        information1:
          'Phone PPS customers can dial 18031 within service hours, login with 5-digit password and key in',
        red1: ' 9218',
        information2:
          ' as "Haitong International Securities" Merchant Code to make payment transfer. The funds will be ready in securities account on the next trade day.',
        red2: '',
        information3: '',
        information4:
          ' Customers with PPS Account and PPS 8-digit Internet password can settle securities payment online within service hours at',
        link1: 'www.ppshk.com',
        link: 'https://www.ppshk.com/index_e.html',
        information5: 'with balance updated to securities account',
        red3: 'on the next trade day.',
        information6: ''
      }, // 缴费灵
      boc: {
        information1:
          "In order to collect all required references to complete a fund transfer directly into your Haitong International Securities account from your iT's Banking account, it is compulsory for you to login to ",
        link1: "iT's Banking ",
        information2: '',
        red: '',
        information3: 'through www.htisec.com.'
      }, // 中国银行
      hsbc: {
        information1: 'PayBills" through',
        link1: "HSBC's Banking",
        link3: 'https://www.hsbc.com.hk/zh-hk/index/',
        information2: 'Services.',
        information3: '',
        information4: '',
        information5: '',
        information6: '',
        information8: 'Please click ',
        link2: 'here ',
        link4: 'http://www.htisec.com/en/cs/payment.jsp#select3',
        information7: 'for detail.'
      }, // 汇丰银行
      hsb: {
        information1: 'View & Pay Bill" through  ',
        link1: 'Hang Seng e-Banking ',
        link3: 'https://www.hangseng.com/en-hk/home/',
        information2: 'services.',
        information3: '',
        information4: '',
        information6: 'Please click ',
        link2: ' here ',
        link4: 'http://www.htisec.com/en/cs/payment.jsp#select3',
        information5: 'for detail.'
      }, // 恒生银行
      scb: {
        information1:
          'By using the "Online Payment" service under "Fund Transfer" section of',
        link: 'https://www.sc.com/hk/',
        link1: ' Standard Chartered Bank Online ',
        information2: '',
        information3: '',
        information4: '',
        information5: '',
        information6:
          'your payment will be updated to your account on the next trading day.'
      }, // 渣打银行
      fpsConfiguration: {
        title: 'Cash Deposit to FPS ID of Haitong International',
        fpsCode: 'FPS ID:',
        digital: '167011527',
        collection: 'Receiving Bank:',
        chinaBank: 'Bank of China (Hong Kong)',
        payee: 'Recipient Name:',
        name: 'Haitong International Securities Company Limited',
        guide: 'FPS remittance guidelines',
        return: 'Back',
        nextStep: 'Next',
        attention: 'Notice',
        content:
          'Please use your own bank account under your name to do fund transfer. Fund transferring from third party, Joint account and E-Wallet is not accepted. In additions, cash deposit through bank counters, ATMs, and other channels is not accepted.',
        notice: 'Submit FPS Deposit Request',
        AfterFour: 'Last 4 Digits of Bank AC Deposit From：',
        account: 'Deposit Account:',
        market: 'Deposit Market: ',
        currency: 'Deposit Currency:',
        amount: 'Deposit Amount:',
        return1: 'Back',
        queren: 'Submit',
        instructions:
          'Your FPS deposit request has been successfully processed. ',
        record: 'Please note the Reference No. for your records.',
        ReferenceCode: 'Reference No.：',
        digital1: '9D5909C7',
        wanCheng: 'Finish',
        print: 'Print',
        check:
          'Please enter your Last four digits of the designated Hong Kong bank account specified during account opening.',
        hkd: 'HKD',
        cny: 'CNY',
        head: 'FPS Deposit Request Processed', //弹框头部
        formCheck1: 'Bank Amount is required',
        formCheck2: 'Debit Account is not correct',
        formCheck3: 'Your deposit amount of your instruction is invalid.',
        formCheck4: '银行卡末四位必须填写',
        formCheck5:
          'The last 4 digits bank account of  your instruction is invalid'
      }
    }
  },
  //我的查询菜单
  myInquiry: {
    // 我的资产
    accoutSummary: {
      market: 'Market',
      buypower: 'Buying Power',
      hukoujiecun: 'Ledger Balance',
      keyongjiecun: 'Available Bala-nce(Excl.Interest)',
      xianjinjiecun: 'Cash Balance',
      leijilixi: 'Accrual Interest',
      zhipiao1: 'Clearing Cheque(D+1)',
      zhipiao2: 'Clearing Cheque(D+2)',
      duiyinghuobi: 'Equivalent to',
      xindaie: 'Margin Limit',
      zhengquanshizhi: 'Stock Market Value',
      dongjiejine: 'Hold Balance',
      daijiaoshou1: 'Pending Settlement(T+1)',
      daijiaoshou2: 'Pending Settlement(T+2)',
      daijiaoshou3: 'Pending Settlement(T+N)',
      ancanzhi: 'Discounted Value',
      zongzichan: 'Total assets',
      xianjin: 'Cash',
      ganggu: 'HK',
      agu: 'A shares',
      chanwaijiaoyi: 'OTC',
      meigu: 'US',
      keyongjiecun: 'Available Balance(Excl. Interest)',
      duihuanlv: '* For indicative(only Last Update',
      chicanxiangqing: 'Stock Position',
      gupiao: 'Stock',
      xianjia: 'Prv. Close',
      chenben: 'Cost',
      zongshuliang: 'Total Qty',
      kemaishuliang: 'Sellable Qty',
      cankaoyinkui: 'P&L',
      jinriyinkui: 'P&L Today',
      shizhi: 'MV',
      ancangzhi: 'DV',
      caozuo: 'Action',
      mairu: 'Buy',
      maichu: 'Sell',
      xiugaichenben: 'Modify',
      jiaoyijilu: 'Trd.Rec.',
      explianInfo:
        '*MOS (Buying Power) is calculated from the available balances of all currencies in HK, China A-shares, US & OTC Market and HKEX stock discount value (Margin Account only) in HKD Equivalent. For account summary in other markets (e.g. China B Shares Market or other oversea markets), please refer to your latest statement or enquire via China B Shares Market trading platform.',
      gupiaoshuliang: 'Quantity',
      pingjunmairujia: 'Average Buying Unit Price',
      pingjunjia: 'Average Unit Price',
      beizhu: 'Remarks',
      beizhuxiangqin1: `1. "Average Buying Unit Price", "Average Unit Price", "Unrealized Profit & Loss" are for reference only, Haitong International Securities Company Limited ("HTI") does not recommend clients considering these data for trading decision making. HTI reserves the right to change the calculation formula and/or time of data update without prior notice.`,
      beizhuxiangqin2: `2. "Average Buying Unit Price", "Average Unit Price" and "Unrealized Profit & Loss" do not include commission and trading fees.`,
      beizhuxiangqin3: `3. You can edit "Average Buying Unit Price" and "Average Unit Price". System will keep adjusting them automatically upon stock buying and/or selling.`,
      beizhuxiangqin4: `4. "Average Buying Unit Price" and "Average Unit Price" will display as "N/A" in some cases.`,
      beizhuxiangqin5: `5. Please refer to Definition of`,
      beizhuanniu: `" Average Buying Unit Price" and "Average Unit Price" for details.`,
      xinpingjunjia: 'New Average Price',
      queren: 'Confirm',
      zhishi1: 'Instruction received',
      zhishi2: 'Please inquire the updated data later'
    },
    // 交易记录(今日记录和历史记录合一起了)
    tradeHistory: {
      title1: "Today's record",
      title2: 'Trade Transaction History',
      title3: 'IPO Subscription Enquiry',
      title4: 'Corporate Action Entitlement History',
      tradeType: 'Transaction Type',
      all: 'All',
      buy: 'Buy',
      sell: 'Sell',
      stockNum: 'Securities Code',
      specifyStock: 'Particular Stock',
      Summary: 'Summary',
      detailed: 'Detailed',
      recordTime: 'Record as at',
      tradeDate: 'Trade Date',
      zhi: 'to',
      startDate: 'State Date',
      endDate: 'End Date',
      aWeek: '1Week',
      aMonth: '1 Month',
      threeMonth: '3Month',
      settlementDate: 'Settlement Date',
      market: 'Market',
      stock: 'Stock',
      tradeClasify: 'Tx Type',
      tradeNum: 'Executed Qty',
      currency: 'CCY',
      tradePrice: 'Executed Price',
      avagPrice: 'Average Price',
      money: 'Amount',
      channel: 'Channel',
      numId: 'Reference No.',
      noResult: 'There is no transaction history for the selection criteria.',
      remarks: 'Notice',
      remark1:
        '1) Amount does not include brokerage, stamp, transaction levy, trading fee, CCASS fee or other trading fees.',
      remark2:
        '2) All transactions are subject to the records printed in statements.',
      remark3:
        '3) Transaction records within 12 months are available. Each enquiry can retrieve up to one month records.',
      remark4:
        "4) The above enquiry does not include today's transactions and you can",
      remarkBtn1: 'Export to Excel',
      remarkBtn2: 'Printing',
      ipoSub: {
        subscriptionId: 'Order Ref',
        stockNum: 'Stock',
        biddingPrice: 'Offer Price',
        subscriptionNum: 'Apply Quantity',
        subscriptionType: 'Subscription Type',
        subscriptionMoney: 'Apply Amout',
        serviceCharge: 'Handing Charges',
        financingRatio: 'Loan Ratio',
        rate: 'Interest Rate',
        tradeCost: 'Order Amount',
        stockNum: 'Allotted Quantity',
        tradeChannel: 'Channel',
        state: 'Status',
        action: 'Action',
        cancel: 'Cancel',
        cancelIPO: 'Cancel Subscribe',
        stockName: 'IPO Name',
        stockCode: 'Stock',
        zhaogujia: 'Offer Price',
        shengoushuliang: 'Apply Quantity',
        shouxufei: 'Handing Charges',
        shengoujine: 'Apply Amout',
        rongzibili: 'Loan Ratio',
        cankaolilv: 'Interest Rate',
        jiaoyijine: 'Order Amount',
        tishi: 'Channels for Notificaiton Services',
        zhishibianhao: 'Application Number',
        zhishizhuangkuang: 'Application Request Status',
        password: 'Password',
        tip: 'Please input password',
        cofirm: 'Confirm',
        submitSuccess:
          'Cancel Subscription instruction is successfully received. '
      },
      companyAction: {
        market: 'Market',
        all: 'All',
        hkStock: 'HK',
        hugutong: 'SH-A',
        gangutong: 'SZ-A',
        zhuangtai: 'Statues',
        yiqidong: 'Activated',
        yijiezhi: 'Cutoff',
        yishouquan: 'Authorized',
        yipaifa: 'Paid',
        yiwancheng: 'Completed',
        leixing: 'Type',
        xianjinguxi: 'Cash-Dividend',
        gupiaoguxi: 'Scrip-Dividend',
        gupiaobianhao: 'Securities Code',
        zhidinggupiao: 'Particular Stock',
        sousuo: 'Search',
        gupiao: 'Stock',
        xingdong: 'Event Name',
        cankao: 'Ref.No',
        qudao: 'Channel',
        jiezhiriqi: 'Reply Deadline',
        zhuangtai: 'Status',
        caozuo: 'Action',
        editor: 'Edit',
        xiugai: 'Corporate Action',
        cankaobianhao: 'Ref',
        guxi: 'Dividend Rate',
        xingujia: 'Reinvestment Price',
        jieshi1:
          'The captioned company declared that shareholders are offered the option of receiving the above-mentioned dividend. Kindly advise us of your intention by submitting the following instruction Online or by signing and returning instruction letter to our Settlement Department by mail, by fax (852) 2537 7647,or by contacting your Account Executive NO LATER THAN 15 Oct, 2019. If we do not receive your duly completed instruction, we shall accept CASH dividend in HKD on your behalf.',
        jieshi2:
          'I/We refer to the captioned subject and wish to advise you that',
        jieshi3: 'Number of shares held for dividend',
        xianjin: 'Wholly in Cash',
        xingu: 'Wholly in Scrip',
        bufenxianjin: 'Partial Election',
        ganyuan: 'HKD',
        renmingbi: 'RMB',
        meiyuan: 'USD',
        xuanze1: 'shares obtain CASH dividend',
        xuanze2: 'shares obtain SCRIP dividend',
        cofirm: 'Confirm',
        xingdongtijiao:
          'Your Corporate Action Instruction has been successfully received.'
      }
    },
    // 资金记录
    fundMovement: {
      currencyExchangeRecord: {
        title: 'FX Conversion History',
        info:
          '*The Service provided under this Platform is solely for the Client to facilitate Transactions and/or any other related trading activities and/or settlement of such including but not limited to the fees and charges incurred in the Account and/or any account maintained with any HTI Company',
        info1:
          '*The symbol “CNY” in the platform refers to a quotation for/against offshore Renminbi (RMB)',
        state: 'Status',
        all: 'All',
        inProgress: 'In Progress',
        accept: 'Accepted',
        refused: 'Rejected',
        date1: 'Date',
        oneWeek: '1Week',
        oneMonth: '1Month',
        threeMonths: '3Month',
        record: 'Record as at',
        date2: 'Instruction Date',
        date3: 'Value Date',
        market1: 'Market (Sell)',
        currency: 'Sell CCY',
        amount: 'Sell AMT',
        market2: 'Market (Buy)',
        currency1: 'Buy CCY',
        amount1: 'Buy AMT',
        huiLv: 'Ex. Rate',
        code: 'Ref. No.',
        state1: 'Status',
        disclaimer: 'Disclaimer',
        content1:
          'Haitong International Securities Group Limited, its subsidiaries and their officers, employees,representatives or agents (“Haitong”) shall not be held liable for any losses, damages or injury resulting from your access to, use of, or inability to access, or use of this platform including the services provided via this platform unless there is fraud or willful misconduct from Haitong for the provision of services in this platform.',
        content2:
          'You understand and acknowledge that there would be possible delays or failure in transmission, any transmission interruption or blackout conducted via electronic means and agree that Haitong shall not be held liable for such or any resulting losses, damages or injury.',
        content3:
          'Information and material provided on this platform do not constitute an offer to sell or the solicitation of an offer to buy any currencies and must not be relied upon in connection with any investment decision. Please consult independent advices when necessary. '
      },
      escrowRecords: {
        title: 'Fund Movement History',
        date1: 'Date',
        oneWeek: '1Week',
        oneMonth: '1Month',
        threeMonths: '3Month',
        record: 'Record as at',
        date2: 'Transection Date',
        date3: 'Value Date',
        code1: 'Reference No.',
        market: 'Market',
        instructions: 'Description',
        number: 'Quantity',
        currency: 'CCY',
        amount: 'Amount',
        note: 'Remarks',
        content:
          '1)  All transactions are subject to the records printed in statements.',
        content1: '2) Transaction records within 12 months are available. '
      }
    },
    // 证券提存
    stockMovement: {
      market: 'Market',
      allMarket: 'All',
      hkAUSAsotck: 'HK，China A-share&US Market',
      cnBStock: 'China B Shares Market',
      otherMarket: 'Other Markets',
      project: 'Type',
      securities: 'Securities',
      futures: 'Futures',
      date1: 'Date',
      oneWeek: '1Week',
      oneMonth: '1Month',
      threeMonths: '3Month',
      code: 'Stock Code',
      stock: 'Particular Stock',
      record: 'Record as at',
      date2: 'Transection Date',
      date3: 'Value Date',
      code1: 'Reference No.',
      query: 'Type',
      instructions: 'Description',
      code2: 'Securities',
      number: 'Quantity',
      currency: 'CCY',
      amount: 'Amount',
      note: 'Remarks',
      content:
        '1)  All transactions are subject to the records printed in statements.',
      content1: '2) Transaction records within 12 months are available. '
    },
    // 我的结单
    myStatement: {
      type: 'Type',
      all: 'All',
      dayStatement: 'Daily Statement',
      monthlyStatement: 'Monthly Statement',
      date: 'Date',
      oneWeek: '1Week',
      oneMonth: '1Month',
      threeMonths: '3Month',
      time: 'Time',
      file: 'Account No.',
      type2: 'Type',
      download: 'Download'
    },
    // 我的报表
    myReport: {
      code: 'Fund Code',
      date: 'Date',
      oneWeek: '1Week',
      oneMonth: '1Month',
      threeMonths: '3Month',
      name: 'Report Filter',
      time: 'Time',
      file: 'Report Name',
      allDownload: 'Download All Reports',
      download: 'Download',
      start: 'Start Date',
      to: 'To ',
      end: 'End Date'
    }
  },
  //我的设定
  mySettings: {
    //个人资料
    changeParticulars: {
      //baseStep
      gerenziliao: 'Change of Particular',
      back: 'Back',
      next: 'Next',
      confirm: 'Confirm',
      choose: 'Please select',
      shoutiPhone: 'Mobile Phone',
      guojiahaoma: 'IDD Codes',
      dianhuahaoma: 'Phone No',
      youbian: 'Postal Code',
      tianxieyoubian: 'Postal Code (if any)',
      dizhi: 'Address',
      tianxiedizhi: 'Please Input',
      email: 'Email address',
      inputEmail: 'Please Input',
      shouquhukou:
        'Method of Account Statement Collection (If you need to change the method of account statement colletion, please choose the following options)',
      shouqufangshi: 'Channels for Notificaiton Services',
      dianzijiedan: 'Email',
      youjijiedan: 'Short Message',
      jiedanyuyan: 'Statement Language',
      en: 'English',
      cn: 'Simplified Chinese',
      hk: 'Traditional Chinese',
      editorMore: 'Revise More information',
      explain:
        'I / We represent that the information on this Change of Particular & Estatement Service Form is true, complete and correct. Upon request from your Companies, I / We shall promptly (in any event, within 30 days) provide the Companies any additional documentation, including without limitation to the self-certification, in relation to the changes to such information. If the additional documentation is not provided timely, I / we understand that the Companies may disclose and / or submit certain of my / our account information in relation to the changes to the competent regulatory or Government Authority in the relevant jurisdiction(s) (including without limitation to U.S. Internal Revenue Service, U.S. Department of the Treasury and the Hong Kong Inland Revenue Department) for the purpose of complying with FATCA, Common Reporting Standard and other related laws, regulations, codes and rules.',
      explian1:
        '·  Online change particular is only applicable for individual account.',
      explian2:
        '·  We will receive your instruction of change on the next working day.',
      explian3:
        '·  To change your residential address, please complete and return ',
      aLink1: ' Change of Personal Particular & eStatement Service Form',
      explian4:
        '·  To change your designated bank account, please complete and return',
      aLink2: 'Change / Addition of Designated Bank Account Form',
      explian5:
        '·  Please input English or Chinese for Correspondence Address.',
      explian6:
        'The changed information will be updated your records in Haitong International Securities Company Limited, Haitong International Futures Limited, Haitong International Asset Management Limited, Haitong International Investment Managers Limited, Hai Tong Asset Management (HK) Limited, Haitong International Wealth Management Limited,  Haitong International Advisory Company Limited  and Haitong International Finance Company Limited.',
      explian7: 'Important Note',
      explain8:
        '· If you change your mobile phone number or correspondence address and email address simultaneously, Customer Service Department will conduct phone confirmation with you after receiving your instruction of change of particular. In case you are unreachable or unsuccessfully confirmed, your trading account(s) will be suspended. You are required to contact our Customer Service for phone confirmation if you want to reactivate your account(s) and we may request you to provide new instruction of change of particular.',
      //detailStep
      zhuzhaidianhua: 'Home Phone',
      bangongdianhua: 'Office Phone',
      chuanzhenhaoma: 'Fax No',
      jiaoyuchengdu: 'Education and occupation Information',
      jiaoyu: 'Education Level',
      zhiye: 'Occupation',
      guzhuming: 'Name of Employer',
      tianxieguzhu: 'Please Input',
      congyenianfen: 'Years in Occupation',
      qingtianxie: 'Please Input',
      zhiwei: 'Position',
      tianxiezhiwei: 'Please Input',
      caiwuziliao: 'Financial Summary',
      zhuwu: 'Residence',
      caifulaiyuan: 'Ongoing Source(s) of Wealth',
      laiyuanxuanze:
        'Salary and/or bonus|Saving|Business Income|Retirement funds|Inheritance or gift|Return on investment|Others',
      laiyuanqita: 'Please Explain',
      caifuzhuanyi: 'Ongoing Source(s) of Funds (a)Means of fund transfer(s)',
      zhuanyixuanze: 'Cash|Telegraphic Transfer|Cheque/Bank Draft|Others',
      caifulaiyuandi: 'Ongoing Source(s) of Funds (b)Country(ies) of Origin(s)',
      laiyuandixuanze: 'Hong Kong|Mainland China|United States|Others',
      zongshouru: 'Annual Income',
      jingzichan: 'Estimated Liquid Net Worth',
      touzimudi: 'Investment Experiences and Objectives',
      touzijingyan: 'Investment Experiences',
      touzijinyanxuanze:
        'Nil|Stocks|Warrants|Options|Futures|Foreign Currency|Bullion|Fund|Other Derivatives',
      touzinianfen: 'Years of Experiences',
      touzinianfenxuanze: 'Nil|1-3 years|3-5 years|5-10 years|Over 10 years',
      touzimudi: 'Investment Objectives',
      touzimudixuanze:
        'Capital Appreciation|Dividend Yield|Hedging|Speculation|Others',
      cofirmInfo: 'Please confirm the updated information below',
      tijiaozhishi: 'Your revised information has been submitted',
      zhishixinxi: 'We will update your records in the next working day',
      educaitionLevel: 'Primary or below/ Secondary/ Post-Secondary',
      occupation:
        'Accounting/Lawyer/Audit |Advertising|Agriculture| Arts/Media |Banking/Finance|Beauty/Health|Biotechnology/Pharmacy|Civil Servant|Conglomerate|Consultancy|Designer|Education|Engineering|Housewife|Human Resources|Industrial|Insurance|Investment Holding|Logistics|Marketing Sales|Medical|Merchant|Printing|Properties|Public relation|Retail/Wholesale|Retired|Technology|Telecom|Trading|Transportation|Unemployed|Others',
      house: 'Self-Owned/Mortgage/Rented/Quarters/Living with family',
      changeInformationLink: 'http://www.htisec.com/en-us/form-download/675',
      bankFormLink: 'http://www.htisec.com/en-us/form-download/675'
    },
    //更改密码
    changePassword: {
      oldPassword: 'Original Password',
      oldPasswordTip: 'Please enter a Original password',
      newPassword1: 'New Password',
      newPassword1Tip: 'Please enter a new password',
      newPassword2: 'Confirm New Password',
      newPassword2Tip: 'Please enter the new password again',
      attention: 'Points to Note',
      attentionInfo:
        'Password must be combination of numbers (0-9) and letters (A-Z, a-z), total 8-10 digits. Your new password will take effect immediately to all Internet trading channels.',
      confirm: 'Confirm',
      changePassword: 'Change Password',
      updatePassword: 'Your password has been changed successfully'
    },
    //密码确认
    passwordConfirm: {
      state: `Status of "Password Confirmation Requirement`,
      started: 'Enable',
      editor: `Change "Password Confirmation Requirement" Setting`,
      adapt: ' (Applicable in Web Securities Trading Platform)',
      loginName: 'Login ID',
      startedInfo: `Enable "Password Confirmation Requirement"`,
      cancelInfo: `Disable "Password Confirmation Requirement"`,
      cancelTip: `Please read through the Declaration for Disable "Password Confirmation Requirement".`,
      cancelTitle: `Declaration for Disable "Password Confirmation Requirement"`,
      cancelExpian1:
        'I hereby authorize Haitong International Securities Company Limited to remove all password confirmation requirement for placing new order, order amendment request, order cancellation, fund transfer and fund withdrawal request from my securities accounts.',
      cancelExpian2: `I fully understand and agree to undertake all additional risks arising from the removal of "Password Confirmation Requirement", and agree that the Company will not be liable for any loss I may suffer as a result of giving up to use the aforesaid password confirmation procedures.In addition, I understand that I shall "Logout" from the trading platform and exit the system while I am away from the computer or upon completion of securities trading in avoidance of unauthorized use of securities account in trading, fund withdrawal or information enquiry. `,
      tip: `# For new order, order amendment and cancellation requests, disable "Password Confirmation Requirement" setting is applied to HK, China A Shares, US and OTC only.`,
      password: 'Password',
      inputPassword: 'Please Input Password',
      confirm: 'Confirm',
      passwordConfirm: 'Password Confirmation Setting',
      changeSuccess:
        '"Password Confirmation Requirement" Setting Change Success.'
    },
    //信贷额申请
    marginApplication: {
      customName: 'Client Name',
      accountId: 'Account No',
      existCredit: 'Existing Credit limit',
      currentMargin: 'Current Discount Value',
      newCredit: 'Requested Credit limit',
      currency: 'HKD',
      wan: 'K',
      customData:
        'If you wish to have a credit limit over HKD8M, please specify the amount in the box. A credit limit is preset for you according to your credit record and your positions and balance in your account. If you request to have a credit limit more than the preset credit limit and/or over HKD8M, we will follow up your application.',
      totalIncome: 'Annual Income(HK$)',
      job: 'Occupation*',
      currentAsset: 'Estimated Net Worth(HK$)',
      incomeFrom: 'Source(s) of Wealth',
      profitVal: 'Estimated Profit after Tax (HK$)',
      netAssetVal: 'Net Asset Value(HK$)',
      suppleInfo: 'Additional Credit Information',
      action: 'Points to Note',
      explian1:
        '1.	This credit facility application is only applicable to Margin Securities Online Trading Account opened with Haitong International Securities Company Limited (“the Company” or “HTI”), while the Securities Standing Authority given to the Company by the Client shall remain valid. Otherwise the relevant application will be rejected.',
      explian2:
        '2.	The credit facility is the maximum margin loan amount granted to the margin securities online trading account by the Company. The actual purchasing power of the account is calculated by reference to the aggregate of prevailing cash balance and stocks discount value in that account.',
      explian3:
        '3.	This credit facility is only applicable to the securities listed or traded in the Stock Exchange of Hong Kong Limited. If you would like to apply for margin limit on US stocks trading, please contact your account manager.',
      explian4:
        '4.	Clients are required to provide us with a copy of the last three months of income/ asset proof either by facsimile at (852) 2526-7612 or by email to credit@htisec.com if the margin limit application is 4 times exceeding the net asset value of the account, otherwise the application will be automatically rejected. If you have any query, please contact our Credit Control Department at (852)2801-2657.',
      explian5:
        '5.	HTI reserves the right to review and adjust the approved margin limit at any time in response to the changes of the client’s financial condition or credit record without any prior notice.',
      explian6:
        '6.	To examine the credit facility application, HTI will take into account of the factors including but not limited to the client’s credit history, the quality, volatility and liquidity of stock collateral and prevailing market conditions, net assets value and discount value of the account stock holding. The Company has an absolute discretion to refuse any application or to approve a lower margin limit to the client.',
      explian7:
        '7.	Credit facility application will only be processed by the Company on HK market trading day. Application submitted on non-trading day will be processed on the next trading day.',
      explian8:
        '8.	The Company will notify the application result to the client via SMS and/ or email. For clients who do not register any mobile number or email address with us, we will notify the application result by phone.',
      explian9:
        '9.	You are required to understand that the risk of loss in financing a transaction by deposit of collateral is significant. Client may be called upon at short notice to deposit additional margin funds.',
      explian10:
        '10.	Should you do not pay the required margin and/or interest within the specified period of time, the client’s securities may be wholly or partly forced liquidation without any prior notice.',
      privateAgree:
        'I hereby acknowledge I read and understood the points to note.I hereby affirm that the information provided in this application is accurate as of the moment of provision',
      companyAgree:
        'I hereby acknowledge I read and understood the points to note.',
      marginApply: 'Change Credit Limit',
      comfirmTip: 'Please verify before confirming the application.',
      caiwuInfo:
        'According to your credit record and your positions and balance in your account, the credit limit of your account numbered',
      caiwuInfo1: 'will be changed to HKD',
      caiwuInfo2: 'with immediate effect.',
      caiwuInfo3: 'Do you agree to submit this request?',
      cancel: 'Amend',
      confirm: 'Confirm',
      submitInfor: 'For your account numbered',
      submitInfor1: 'on',
      submitInfor2: 'You have sent a request to change the credit limit to HKD',
      submitInfor3: 'The request has been approved.',
      submitInfor4: 'has been approved. Your existing Credit limit is HKD',
      submitTip: 'Reference No: '
    },
    //投资者风险取向问卷
    investProfile: {
      info:
        'Please update your risk aptitude by filling in the Risk Profiling Questionnaire before you perform any investment transactions.',
      input: 'Filling',
      chuli: 'Your Risk Profiling Questionnaire is processing.',
      orientation: 'Risk Apptitude',
      assessment:
        'Assessment on Knwledge of Over-the-Counter (OTC) Derivatives',
      content1: 'You can click',
      content2: 'here',
      content3:
        'to update your risk aptitude by filling in the Risk Profile Questionaire.',
      content4:
        'According to your latest risk level assessment, your risk aptitude is',
      content5: 'Conservative',
      content6: 'Moderately Conservative',
      content7: 'Moderate',
      content8: 'Moderately Aggressive',
      content9: 'Aggressive',
      content10: 'Risk Aptitude Score:',
      content11: 'Risk Aptitude Classification:',
      content12: 'Expiry Date:',
      content13: '2020-03-11',
      content14: 'With knowledge on financial derivatives:',
      content15: 'Yes',
      content16: 'No',
      content17:
        'According to your latest assessment on knowledge of Over-the-Counter (OTC) Derivatives, you',
      content18: 'do not have knowledge on OTC derivatives',
      content19: 'have knowledge on OTC derivatives',
      answer: 'Please answer All the question',
      prompt: 'Thanks for completed the questionnaire',
      jiaoyuLink: 'http://www.htisec.com/en-us/investor-education',
      conservative:
        'According to your answer in Question 3,your investment objective is capital preservation,therefore your risk aptitude will be classified as “Conservative”',
      digital: 'Please input in 8 digits',
      prompt1:
        'Your investment experience(s) of financial derivatives is not match with what you indicated in the investment products, please select again.',
      // 个人问卷
      personalQuestionnaire: {
        questionnaire: 'Client Invest. Profile Questionnaire',
        title: 'Client Investment Profile Questionnaire (Individual/Joint)',
        name: 'Name:',
        account: 'Account No: ',
        content:
          'This Questionnaire aims to help us establish and assess your risk profile, investment experience and knowledge of the derivatives. Based on the information provided, we can assess whether you are knowledgeable about the characteristics and risk of relevant investment products. Joint account holders are required to complete the questionnaire separately and the person with lower risk appetite would be concluded for the account. This questionnaire is divided into two parts. If you do not trade derivatives, please fill in part 1 Risk Profile only.',
        important: 'Important notes:',
        info:
          'your risk profile is based on your overall responses to all questions respectively of this questionnaire (except for question 3), rather than your answer to any individual question. When answering questions about your financial or investment information such as the amount of investable assets, or transaction information, please refer to all of your holdings and transactions in our company, as well as, those in other securities firms and financial institutions, and not solely those in our company.',
        oneContent: 'Part 1: Risk Profile',
        oneInfo:
          'This part collects information about you including your financial situation, investment attitude and investment experience in order to help you assess your risk tolerance level. Please select the appropriate one and fill in all 13 questions.',
        one: '1 What is your education level?',
        oneA: 'A. Below primary',
        oneB: 'B. Primary',
        oneC: 'C. Secondary',
        oneD: 'D. Tertiary or above',
        two:
          '2 Do you have any dependable household members? If yes, how many?',
        twoA: 'A. Four or more',
        twoB: 'B. Three',
        twoC: 'C. Two or below',
        three: '3 What is your investment objective?',
        threeA:
          'A. My primary objective is capital preservation and I am not willing to accept any declines at any point in time. (Please note all investments involve risks. If you are not willing to take any risks and only wish us to assess your risk profile based on your answer to this specific question rather than your answers to all questions, you are a conservative investor, you more suitable for conservative products.)(If A, please go to Question 5.)',
        threeB:
          'B. My primary objective is to achieve low level of return and I am willing to accept some low level of declines over the course of my investment horizon. I am not comfortable with moderate to extreme drops in the value of my investments. (Please note if you are only willing to take low level of risks and wish us to assess your risk profile based on your answer to this specific question, you will not be classified as a moderately aggressive nor aggressive investor.)',
        threeC:
          'C. My primary objective is to achieve moderate level of return and I am willing to accept moderate declines over the course of my investment horizon. I am not comfortable with extreme drops in the value of my investments.',
        threeD:
          'D. My primary objective is to achieve a high level of return and I am willing to accept large fluctuations over the course of my investment horizon and take loss in the value of my investments in order to maximize my long term potential returns.',
        four:
          '4 Which of the following potential fluctuations would you generally be most comfortable with?',
        fourA: 'A. Fluctuates between –5% and +5%',
        fourB: 'B. Fluctuates between –10% and +10%',
        fourC: 'C. Fluctuates between –20% and +20%',
        fourD: 'D. Fluctuates between > –20% and > +20%',
        five:
          '5 On average, what is your monthly available capital? [Definition of available capital: Available capital is the amount of capital (including bank deposit, wages, dividends, bonus, etc.) after taxes, pension contributions, and essential expenditures such as mortgage payment or rental, car loans, insurance, food, clothes, child or elderly care, utilities, etc.]',
        fiveA: 'A. HK$4,000 to 15,000',
        fiveB: 'B. HK$15,001 to 60,000',
        fiveC: 'C. HK$60,001 to 100,000',
        fiveD: 'D. Over HK$100,000',
        six:
          '6 Do you rely on the investment return to support your Dependent’s daily expenses?',
        sixA: 'A. Yes, Over 20%',
        sixB: 'B. Yes, Between > 10% and 20%',
        sixC: 'C. Yes, Between > 0% and 10%',
        sixD: 'D. No.',
        seven:
          '7 What is the percentage of monthly income available for investment?',
        sevenA: 'A. Between 0% and 10%',
        sevenB: 'B. Between > 10% and 25%',
        sevenC: 'C. Between > 25% and 50%',
        sevenD: 'D. Over 50%',
        eight:
          '8 How many months could your savings meet your basic family expenses and extra collateral requirements?',
        eightA: 'A. Less than 3 months',
        eightB: 'B. Between 3 months and < 6 months',
        eightC: 'C. Between 6 months and < 9 months',
        eightD: 'D. 9 months or above',
        nine:
          '9 When trading in investment products, how long will your acceptable investment horizon be?',
        nineA: 'A. Less than or equal to 1 year',
        nineB: 'B. More than 1 year to 5 years',
        nineC: 'C. More than 5 years to 10 years',
        nineD: 'D. Over 10 years',
        ten: '10 In the past year, how many transactions did you execute?',
        tenA: 'A. Less than 5 transactions',
        tenB: 'B. Between 5 and 10 transactions',
        tenC: 'C. Between 11 and 20 transactions',
        tenD: 'D. Over 20 transactions',
        eleven:
          '11 What is your knowledge of financial markets and investments?',
        elevenA:
          'A. None: I have no knowledge of financial markets and Investments.',
        elevenB:
          'B. Low: I have only some basic knowledge of financial markets such as differences between stocks and bonds.',
        elevenC:
          'C. Medium: I have above basic knowledge and understand the importance of diversification (i.e., I have my money in different types of investment to spread the risks).',
        elevenD:
          "D. High: I know how to read a company's financial reports (i.e., profit and loss statements and balance sheet) and understand the factors affecting the prices of stocks and bonds.",
        elevenE:
          'E. Advanced: I am familiar with most financial products (including bonds, stocks, warrants, options, and futures) and understand various factors that may affect the risk and performance of these financial products.',
        twelve:
          '12 The value of your Liquid Net Worth is (It equals to the sum of your cash and investment portfolio(excluding property value) net of personal loans and credit card balance repayment (excluding mortgage loan)):',
        twelve1: 'Estimated total value of your liquid net worth: HK $: ',
        thirteen:
          '13 Please indicate your investment experience in the following investment product (Check more than one box if appropriate)',
        thirteen1: 'Total number of years of dealing experience',
        thirteen2: 'None',
        thirteen3: 'Limited',
        thirteen4: 'Good',
        thirteen5: 'Extensive',
        thirteen6: 'Products',
        thirteen7: 'Warrants / Callable bull/bear contracts',
        thirteen8: 'Exchange traded funds',
        thirteen9:
          'Structured products (e.g. capital and non-capital preserved investment)',
        thirteen10: 'Leveraged and Inverse Products',
        thirteen11: 'Futures / Listed Option',
        thirteen12: 'Equities',
        thirteen13: 'OTC derivatives (e.g. OTC Options)',
        thirteen14: 'Securities short selling',
        thirteen15: 'Securities placing',
        thirteen16: 'Foreign Exchange',
        thirteen17: 'Mutual funds/ Unit trusts',
        thirteen18: 'Hedge funds/ Private equity funds',
        thirteen19: 'Bonds',
        note: 'Note:',
        note1:
          '1. Choose “None” if you have no relevant previous knowledge/experience or if you are unsure about it.',
        note2:
          '2. The investment experience as indicated in Question 13 will be considered as the most recent investment experience in a particular product.',
        twoContent: 'Part 2: Assessment on Knowledge of Derivatives',
        twoInfo:
          'This part assesses whether you have knowledge of derivatives. Based on the information provided below, we will assess whether you understand the nature and risks of derivative products. Please complete the each question and check the box that best describes you.',
        one1: '1 What is your knowledge of financial derivatives?',
        one2:
          'None: I have no knowledge of financial derivatives and have no interest in understanding them.',
        one3:
          'Low: I have only some basic knowledge of financial derivatives such as differences between traditional investment products like stocks and derivatives as different asset classes.',
        one4:
          'Medium: I have above basic knowledge and understand that the value of financial derivatives can fluctuate following that of the underlying assets and hence its performance can vary to a larger extent than traditional investment products in both directions. I know how to read terms and conditions for a financial derivative contract or offering documents and understand the factors affecting the prices of financial derivatives in general.',
        one5:
          'Advanced: I am familiar with most financial derivatives and have been a frequent trader in financial derivatives for many years.',
        two1:
          '2 What is the investment experience(s) that you have for the following types of financial derivatives (You can check more than one box)?',
        two2:
          'Listed financial derivatives in Hong Kong or overseas exchanges (e.g. futures contracts, commodity contracts, options and warrants, etc.)',
        two3:
          'OTC structured products or financial derivatives (e.g. structured/convertible bonds, credit-linked, commodity-linked and equity-linked notes, etc.)',
        two4:
          'Hedge funds or funds employing financial derivatives extensively for investment purpose',
        two5: 'Others (please specify): ',
        two6: 'None (If None, please go to Question 4.)',
        three1:
          '3 Have you executed five or more transactions in relation to those products (whether traded on exchange or not) as stated in Question 2 within the past three years?',
        three2: 'Yes; please specify:',
        three3: 'Name of financial institution:',
        three4: 'total transaction amount:',
        three5: 'No',
        four1:
          '4 Have you undergone training and/or attended courses either in form of online or classroom offered by academic institutions or financial institutions on the aforesaid derivatives and/or structured products and that you are fully aware of the nature and risks of this kind of investment products?',
        four2:
          'Yes, I have learned about the nature and risks of related products through training videos on bonds, exchange traded derivatives and OTC derivatives on your company website.',
        four3: 'Date:',
        four4: 'Security Code：',
        four5: 'Click here to watch the investor education video',
        four6:
          'Yes, the training / course is offered by the following institution:',
        four7: 'Institution name :',
        four8: 'Course name:',
        five1:
          '5 Do you possess more than 1 year work experience related to the aforesaid derivatives and/or structured products?',
        five2: 'Company name:',
        five3: 'Department name:',
        five4: 'Job nature:',
        five5: ' Period of employment:',
        prompt:
          'I understand that HTISG will be unable to assess the suitability of the requested service to my interest if the information provided in the questionnaire by me is incorrect.',
        submit: 'Submit'
      },
      // 公司问卷
      groupQuestionnaire: {
        title: 'Client Investment Profile Questionnaire (Corporate)',
        name: 'Name of Company : ',
        account: 'Account No :',
        content:
          'This Questionnaire aims to help us establish and assess your company’s risk profile, investment experience and knowledge of derivatives. Based on the information provided, we can assess whether the authorized person(s) of your company is knowledgeable about the characteristics and risk of relevant investment products. This questionnaire is divided into two parts. If your company does not trade derivatives, please fill in Part 1 Risk Profile only.',
        important: 'Important notes: ',
        info:
          'Your company’s risk profile is based on overall responses of your company’s authorized person’s answers to all questions in this questionnaire, rather than the answers given by your company’s authorized person to any individual question (except for question 3). When answering questions about your company’s financial or investment information such as the amount of investable assets, or transactions, please refer to all of your company’s holdings and transactions in our company, as well as, those in other securities firms and financial institutions.',
        oneContent: 'Part 1: Risk Profile',
        oneInfo:
          'This part collects information about your company including your company’s financial situation, investment attitude and investment experience of your company’s authorized person in order to assess your company’s risk tolerance level. Please select the appropriate one and fill in all 13 questions.',
        one:
          '1 Is your firm a private company where the investment decision rests with the owner or a substantial company with a dedicated investment function?',
        oneA:
          'A. My company is a private company where the investment decision rests with the owner',
        oneB:
          'B. My company is a substantial company where the investment decision rests with the a dedicated investment function',
        two:
          '2 The corporate structure ,investment process and control of your company:',
        twoA:
          'A. We have a designated investment committee comprising of competent and suitably qualified professionals responsible for our investment strategies and investment process; and (i) such a committee makes investment decisions on behalf of our company or (ii) we make informed investment decisions taking into account the advice or recommendation of such committee;',
        twoB:
          'B. We have an in-house treasury, investment or similar function comprising of competent and suitably qualified professionals responsible for our investment strategies and investment process;',
        twoC:
          'C. We engage an external investment advisory team comprising of competent and suitably qualified professionals responsible for our investment strategies and investment process; and (i) such a team makes investment decisions on behalf of our company or (ii) we make informed investment decisions taking into account the advice or recommendation of such team;',
        twoD:
          'D. We rely on and follows the investment strategies, advice and recommendations of our related corporation provided that such related corporation: (i) have an in-house treasury, investment or similar function; (ii) have a designated investment committee; or (iii) engage an external investment advisory team that meets the conditions set out above;',
        twoE: 'E. We have none of the above',
        three:
          '3 How would a decline in the value of investments affect your company?',
        threeA:
          'A. Our company is not willing to accept any declines at any point in time as capital preservation is our primary objective. (Please note all investments involve risks. If your company is not willing to take any risk and only wish us to assess your company’s risk profile based on the answer to this specific question rather than the answers to all questions, your company belongs to a conservative investor.)(If A, please go to Question 5.)',
        threeB:
          'B. Our company is willing to accept some declines over the course of our investment horizon but we are not comfortable with moderate to extreme drops in the value of my investments.',
        threeC:
          'C. Our company is willing to accept moderate declines over the course of our investment horizon but we are not comfortable with extreme drops in the value of my investments.',
        threeD:
          'D. Our company is willing to accept large fluctuations over the course of our investment horizon and take loss in the value of our investments in order to maximize our long term potential returns.',
        four:
          '4 Which of the following potential fluctuations would your company generally be most comfortable with?',
        fourA: 'A. Fluctuates between –5% and +5%',
        fourB: 'B. Fluctuates between –10% and +10%',
        fourC: 'C. Fluctuates between –20% and +20%',
        fourD: 'D. Fluctuates between > –20% and > +20%',
        five:
          '5 What is your company’s total gearing ratio? (Total gearing ratio is defined as: (Total Current Liabilities + Total Non-Current Liabilities)/Tangible Net Worth)',
        fiveA: 'A. Over 200%',
        fiveB: 'B. Between 100.1% and 200%',
        fiveC: 'C. Between 50.1% and 100%',
        fiveD: 'D. Between 20.1% and 50%',
        fiveE: 'E. Less than 20%',
        six:
          '6 When trading investment products, how long will your company’s acceptable investment horizon be?',
        sixA: 'A. Less than or equal to 1 year',
        sixB: 'B. More than 1 year to 5 years',
        sixC: 'C. More than 5 years to 10 years',
        sixD: 'D. Over 10 years',
        seven:
          '7 What was your company’s profit status in the last five years? (For non-profit-making organizations, please use net cash flow instead)',
        sevenA: 'A. Very unstable',
        sevenB: 'B. Unstable',
        sevenC: 'C. Somewhat stable',
        sevenD: 'D. Stable and in line with economic growth',
        sevenE: 'E. Stable and outpacing economic growth',
        eight:
          '8 Is your company currently holding any of the following investment products? (If more than 1 option is applicable, please choose the one with the highest score)',
        eightA: 'A. Cash, deposits',
        eightB: 'B. Bonds, bond funds',
        eightC:
          'C. Stocks, open-end funds, non-capital-protected investment products',
        eightD: 'D. Warrants, options, futures',
        nine:
          '9 In the past year, how many transactions did your company execute?',
        nineA: 'A. Less than 5 transactions',
        nineB: 'B. Between 5 and 10 transactions',
        nineC: 'C. Between 11 and 20 transactions',
        nineD: 'D. Over 20 transactions',
        ten:
          '10 What is your company’s target annualized investment rate of return? Generally speaking, there is a positive correlation between the amount of risk and the potential for return. A higher risk investment has a higher potential for profit but also a potential for a greater loss.',
        tenA: 'A. 5% or below',
        tenB: 'B. 6% - 15%',
        tenC: 'C. 16% - 25%',
        tenD: 'D. Over 25%',
        eleven:
          '11 What is the overall knowledge of your company’s authorized person(s) on financial markets and investments?',
        elevenA:
          'A. None: The authorized person(s) of our company has/ no knowledge of financial markets and Investment.',
        elevenB:
          'B. Low: The authorized person(s) of our company has only some basic knowledge of financial markets such as differences between stocks and bonds.',
        elevenC:
          'C. Medium: The authorized person(s) of our company has above basic knowledge and understand the importance of diversification and practice it (i.e., Our company has invested money in different types of investment to spread the risks).',
        elevenD:
          "D. High: The authorized person(s) of our company knows how to read a company's financial reports (i.e., profit and loss statements and balance sheet) and understands the factors affecting the prices of stocks and bonds.",
        twelve:
          '12 The total amount of investable assets of the company is (It equals to the sum of the Company’s investment portfolio and cash (excluding property value) net of any loan or repayment obligations (excluding mortgage loan)) :',
        twelve1: 'Estimated total value of your investable assets: HK $:',
        thirteen:
          '13 Please indicate the investment experience of your company’s authorized person(s) in the following investment product (Check more than one box if appropriate)',
        thirteen1: 'Total number of years of dealing experience',
        thirteen2: 'None',
        thirteen3: 'Limited',
        thirteen4: 'Good',
        thirteen5: 'Extensive',
        thirteen6: 'Products',
        thirteen7: 'Warrants / Callable bull/bear contracts',
        thirteen8: 'Exchange traded funds',
        thirteen9:
          'Structured products (e.g. capital and non-capital preserved investment)',
        thirteen10: 'Leveraged and Inverse Products',
        thirteen11: 'Futures / Listed Option',
        thirteen12: 'Equities',
        thirteen13: 'OTC derivatives (e.g. OTC Options)',
        thirteen14: 'Securities short selling',
        thirteen15: 'Securities placing',
        thirteen16: 'Foreign Exchange',
        thirteen17: 'Mutual funds/ Unit trusts',
        thirteen18: 'Hedge funds/ Private equity funds',
        thirteen19: 'Bonds',
        note: 'Note:',
        note1:
          '1. Choose “None” if the authorized person(s) of your company has no relevant previous knowledge/experience or if they are not sure about it.',
        note2:
          '2. The investment experience in Question 13 will be considered as the most recent investment experience in a particular product.',
        twoContent: 'Part 2: Assessment on Knowledge of Derivatives',
        twoInfo:
          'This part assesses whether the authorized person(s) of your company has knowledge of derivatives. Based on the information provided below, we will assess whether the authorized person(s) of your company understand the nature and risks of derivative products. Please select the appropriate one and fill in all questions.',
        one1:
          '1 What is the authorized person(s) of your company’s knowledge of financial derivatives?',
        one2:
          'None, the authorized person(s) of our company has no knowledge of financial derivatives at all and has no interest in understanding them.',
        one3:
          'Low, the authorized person(s) of our company have only some basic knowledge of financial derivatives such as differences between traditional investment products like stocks and derivatives as different asset classes.',
        one4:
          'Medium, the authorized person(s) of our company has above basic knowledge and understands that the value of financial derivatives can fluctuate following that of the underlying assets and hence its performance can vary to a larger extent than traditional investment products in both directions. We know how to read terms and conditions for a financial derivative contract or offering documents and understand the factors affecting the prices of financial derivatives in general.',
        one5:
          'Advanced, the authorized person(s) of our company are familiar with most financial derivatives and have been a frequent trader in financial derivatives for many years.',
        two1:
          '2 What is the investment experience(s) that the authorized person(s) of your company has for the following types of financial derivatives (You can check more than one box)?',
        two2:
          'Listed financial derivatives in Hong Kong or overseas exchanges (e.g. futures contracts, commodity contracts, options and warrants, etc.)',
        two3:
          'OTC structured products or financial derivatives (e.g. structured/convertible bonds, credit-linked, commodity-linked and equity-linked notes, etc.)',
        two4:
          'Hedge funds or funds employing financial derivatives extensively for investment purpose',
        two5: 'Others (please specify ): ',
        two6: 'None (If None, please go to Question 4.)',
        three1:
          '3 Has the authorized person(s) of your company executed five or more transactions in relation to those products (whether traded on exchange or not) as stated in Question 2 within the past three years?',
        three2: 'Yes; please specify:',
        three3: 'Name of financial institution:',
        three4: 'total transaction amount:',
        three5: 'No',
        four1:
          '4 Has the authorized person(s) of your company undergone training and/or attended courses either in form of online or classroom offered by academic institutions or financial institutions on the aforesaid derivatives and/or structured products and that you are fully aware of the nature and risks of this kind of investment products?',
        four2:
          'Yes, I/We have learned about the nature and risks of related products through training videos on bonds, exchange traded derivatives and OTC derivatives on your company website. ',
        four3: ' Date:',
        four4: 'Security Code：',
        four5: '按此觀看投資者教育短片',
        four6:
          'Yes, the training / course is offered by the following institution: ',
        four7: 'Institution name:',
        four8: 'Course name:',
        five1:
          '5 Does the authorized person(s) of your company possess more than 1 year work experience related to the aforesaid derivatives and/or structured products?',
        five2: 'Company name:',
        five3: 'Department name:',
        five4: 'Job nature:',
        five5: 'Period of employment:',
        prompt:
          'I/ We understand that HTISG will be unable to assess the suitability of the requested service to my/ our interest if the information provided in the questionnaire by me/ us is incorrect.',
        submit: 'Submit'
      }
    },
    //中华通北向交易同意书
    consentForConnnect: {
      title: 'Consent for Northbound Trading of China Connect',
      title1:
        'Personal Information Collection Statement concerning Northbound Trading of China Connect Securities',
      content1:
        'Unless otherwise defined below, terms defined in the [Cash] Account Terms and Conditions and the Stock Connect Supplement to Cash Account Terms & Conditions shall have the same meaning in this Personal Information Collection Statement concerning Northbound Trading orders (“Personal Information Collection Statement”). In the event of any difference in interpretation or meaning between the English version and Chinese version of this Personal Information Collection Statement, the English version shall prevail.',
      content2: 'Processing of Personal Data as part of the Northbound Trading',
      content3:
        'You acknowledge and agree that in providing our service of Northbound Trading of China Connect Securities through Stock Connect to you, we will be required to:',
      content4:
        'i.	tag each of your orders submitted to the CSC with a Broker-to-Client Assigned Number ("BCAN") that is unique to you or the BCAN that is assigned to your joint account with us, as appropriate; and',
      content5:
        'ii.	provide to the Exchange your assigned BCAN and such identification information (“Client Identification Data” or “CID”) relating to you as the Exchange may request from time to time under the Rules of the Exchange.',
      content6:
        'Without limitation to any notification we have given you or consent we have obtained from you in respect of the processing of your personal data in connection with your account and our services to you, you acknowledge and agree that we may collect, store, use, disclose and transfer personal data relating to you as required as part of our service of Northbound Trading of China Connect Securities through Stock Connect, including as follows:',
      content7:
        'a.	to disclose and transfer your BCAN and CID to the Exchange and the relevant SEHK Subsidiaries from time to time, including by indicating your BCAN when inputting a China Connect Order into the CSC, which will be further routed to the relevant China Connect Market Operator on a real-time basis;',
      content8:
        'b.	to allow each of the Exchange and the relevant SEHK Subsidiaries to: (i) collect, use and store your BCAN, CID and any consolidated, validated and mapped BCANs and CID information provided by the relevant China Connect Clearing House (in the case of storage, by any of them or via HKEX) for market surveillance and monitoring purposes and enforcement of the Rules of the Exchange; (ii) transfer such information to the relevant China Connect Market Operator (directly or through the relevant China Connect Clearing House) from time to time for the purposes set out in (c) and (d) below; and (iii) disclose such information to the relevant regulators and law enforcement agencies in Hong Kong so as to facilitate the performance of their statutory functions with respect to the Hong Kong financial markets;',
      content9:
        'c.	to allow the relevant China Connect Clearing House to: (i) collect, use and store your BCAN and CID to facilitate the consolidation and validation of BCANs and CID and the mapping of BCANs and CID with its investor identification database, and provide such consolidated, validated and mapped BCANs and CID information to the relevant China Connect Market Operator, the Exchange and the relevant SEHK Subsidiary; (ii) use your BCAN and CID for the performance of its regulatory functions of securities account management; and (iii) disclose such information to the Mainland regulatory authorities and law enforcement agencies having jurisdiction over it so as to facilitate the performance of their regulatory, surveillance and enforcement functions with respect to the Mainland financial markets; and',
      content10:
        'd.	to allow the relevant China Connect Market Operator to: (i) collect, use and store your BCAN and CID to facilitate their surveillance and monitoring of securities trading on the relevant China Connect Market through the use of the China Connect Service and enforcement of the rules of the relevant China Connect Market Operator; and (ii) disclose such information to the Mainland regulatory authorities and law enforcement agencies so as to facilitate the performance of their regulatory, surveillance and enforcement functions with respect to the Mainland financial markets.',
      content11:
        'By instructing us in respect of any transaction relating to China Connect Securities, you acknowledge and agree that we may use your personal data for the purposes of complying with the requirements of the Exchange and its rules as in force from time to time in connection with the service of Northbound Trading of China Connect Securities through Stock Connect. You also acknowledge that despite any subsequent purported withdrawal of consent by you, your personal data may continue to be stored, used, disclosed, transferred and otherwise processed for the above purposes, whether before or after such purported withdrawal of consent.',
      content12: 'Consequences of failing to provide Personal Data or Consent',
      content13:
        'Failure to provide us with your personal data or consent as described above may mean that we will not, or no longer be able, as the case may be, to carry out your trading instructions or provide you with our service of Northbound Trading.',
      content14: 'Acknowledgement and Consent',
      content15:
        'I acknowledge I have read and understand the content of this Personal Information Collection Statement concerning Northbound Trading of China Connect Securities. By ticking the box below, I signify my consent or objection for Haitong International Securities Group Limited and its subsidiaries (together, "HTISG" or “you”) to use my personal data on the terms of and for the purposes set out in this Personal Information Collection Statement.',
      content16:
        'I agree to HTISG’s use of my personal data for the purposes set out in the Personal Information Collection Statement.',
      content17:
        'I object to HTISG’s use of my personal data for the purposes set out in the Personal Information Collection Statement and acknowledge that HTISG will not or no longer be able to carry out my trading instructions or provide me with your service of Northbound Trading of China Connect Securities through Stock Connect. Furthermore, I confirm that:',
      content18:
        'I have not given any similar consent to any other broker or bank or financial institution for their use of my personal data for the purposes set out in the Personal Information Collection Statement.',
      content19:
        'I have given consent to other broker or bank or financial institutions for their use of my personal data for the purposes set out in the Personal Information Collection Statement and the reason/explanation of objecting HTISG’s use of my personal data for the purposes set out in the Personal Information Collection Statement is/being',
      content20:
        'Should I fail to provide any reason/explanation or if the abovementioned reason/explanation is not deemed reasonably satisfactory by you, HTISG shall have the right to insist for my consent before placing any further China Connect orders for me.',
      confirm: 'Confirm',
      cancel: 'Cancel',
      content21:
        'Your personal information collection statement concerning northbound trading of China connect securities is successfully submitted.',
      content22:
        'Your personal information collection statement concerning northbound trading of China connect securities is failed to submitted, Please try again later or contact our customer service department. Our Hotline: (852) 3583 3388 (Hong Kong) / (86) 755 8266 3232 (China).',
      content23: 'Close',
      ipt: 'Please Input',
      prompt: 'Do not remind me at next time login'
    }
  }
}
