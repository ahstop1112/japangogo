// import { localSet } from '@/utils/mylocal.js'

const mutations = {
  updateCurrentTitle (state, val) {
    state.currentTitle = val;
  },
  updateBgColor (state, val) {
    state.bgColor = val;
  },
  changeSideBar (state, val) {
    state.toggleSideBar = val;
  },
  changeDeviceBar (state, val) {
    state.deviceSidebar = !state.deviceSidebar;
  },
  changeDevice (state, val) {
    state.device = val;
  },
  changeLang (state, val) {
    state.lang = val;
  },
  changeFixedSide (state, val) {
    state.fixedSide = !state.fixedSide;
  },
  changeIsJumpRouter (state, val) {
    state.isJumpRouter = val;
  },
  changeCurStock (state, val) {
    state.curStock = val;
  },
  changeUpdateSelfStock (state, val) {
    state.updateSelfStock = val;
  },
  // saveUserInfo: (state, user_data) => {
  //   state.user_data = user_data
  //   localSet('user_data', user_data)
  // },
  changeQuterType (state, val) {
    state.quterType = val;
  },
  updateActiveAccountId(state, val) {
    state.activeAccountId = val;
  }
}

export default mutations
