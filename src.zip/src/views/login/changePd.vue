<template>
  <!-- 强制更改面页面 -->
  <div class="cancelRegister">
    <div class="top">
      <div class="top-box">
        <img src="@/assets/img/1@3x.png" alt="" />
        <span>{{ $t('mySettings.changePassword.changePassword') }}</span>
      </div>
    </div>
    <div class="box" v-if="firstStep">
      <el-form :model="form1" :rules="rules1" ref="form1" class="form" :inline="false">
        <h4>{{ $t('mySettings.changePassword.oldPassword') }}</h4>
        <el-form-item prop="password">
          <el-input :type="show?'text':'password'" :placeholder="$t('mySettings.changePassword.oldPasswordTip')" v-model="form1.password" clearable auto-complete="off">
            <i v-if="form1.password!==''" slot="suffix" @click="show=!show" style="cursor:pointer; font-size: 40px;" :class="show?'iconfont icon-header_eye_show':'iconfont icon-header_eye_hide'"></i>
          </el-input>
        </el-form-item>
        <h4>{{ $t('mySettings.changePassword.newPassword1')}}</h4>
        <el-form-item prop="newPassword">
          <el-input :type="show1?'text':'password'" :placeholder="$t('mySettings.changePassword.newPassword1Tip')" v-model="form1.newPassword" clearable auto-complete="off">
            <i v-if="form1.newPassword!==''" slot="suffix" @click="show1=!show1" style="cursor:pointer; font-size: 40px;" :class="show1?'iconfont icon-header_eye_show':'iconfont icon-header_eye_hide'"></i>
          </el-input>
        </el-form-item>
        <h4>{{$t('mySettings.changePassword.newPassword2')}}</h4>
        <el-form-item prop="newPassword2">
          <el-input :type="show2?'text':'password'" :placeholder="$t('mySettings.changePassword.newPassword2Tip')" v-model="form1.newPassword2" clearable auto-complete="off">
            <i v-if="form1.newPassword2!==''" slot="suffix" @click="show2=!show2" style="cursor:pointer; font-size: 40px;" :class="show2?'iconfont icon-header_eye_show':'iconfont icon-header_eye_hide'"></i>
          </el-input>
        </el-form-item>
        <div class="explain-wrap">
          <div class="explain-title">{{$t('mySettings.changePassword.attention')}}</div>
          <div class="explain-content">{{$t('mySettings.changePassword.attentionInfo')}}</div>
        </div>
        <div class="btn-wrap">
          <el-button type="primary" @click="goNextStep('form1')" :loading="loading">{{$t('mySettings.changePassword.confirm')}}</el-button>
        </div>
      </el-form>
    </div>
    <div class="success" v-else>
      <div class="info-wrap">
        <div class="imgs"><img src="@/assets/img/icon_pass@2x.png" alt="" /></div>
        <div class="info">
          <p>{{$t('mySettings.changePassword.updatePassword')}}</p>
        </div>
      </div>
      <el-button class="btn" type="primary" @click="toHome">{{
        $t('twoFaLogin.phoneLogin.btn2')
      }}</el-button>
    </div>
    <!-- 底部组件 -->
    <bottombar></bottombar>
  </div>
</template>

<script>
import bottombar from '@/views/_layout/bottombar'
import { changePasswordApi } from '@/api/layout'
import errTables from '@/utils/errTables'
export default {
  components: {
    bottombar
  },
  data() {
    return {
      loading: false,
      show: false,
      show1: false,
      show2: false,
      firstStep: true, //是否显示第一步
      form1: {
        password: "",
        newPassword: "",
        newPassword2: "",
      },
      //  校验规则
      rules1: {
        password: [
          {
            validator: (rule, value, callback) => {
              if (value === '') {
                callback(new Error(this.$t('login.bounced19')));
              } else {
                callback();
              }
            },
            trigger: 'blur'
          }
        ],
        newPassword: [
          {
            validator: (rule, value, callback) => {
              if (value === '') {
                callback(new Error(this.$t('login.bounced19')));
              } else {
                if (this.form1.newPassword2 !== '') {
                  this.$refs.form1.validateField('newPassword2');
                }
                callback();
              }
            },
            trigger: "blur"
          },
        ],
        newPassword2: [
          {
            validator: (rule, value, callback) => {
              if (value === '') {
                callback(new Error(this.$t('mySettings.changePassword.newPassword2Tip')));
              } else if (value !== this.form1.newPassword) {
                callback(new Error(this.$t('login.bounced20')));
              } else {
                callback();
              }
            },
            trigger: "blur"
          },
        ],
      }
    }
  },
  mounted() {
    // 阻止浏览器后退行为
    history.pushState(null, null, document.URL);
    window.addEventListener('popstate', function () {
      history.pushState(null, null, document.URL);
    });
  },
  methods: {
    // 密码确认点击事件
    goNextStep(form1) {
      // 全局效验
      this.$refs.form1.validate(val => {
        if (val) {
          // 将加载状态设置为 true
          this.loading = true
          changePasswordApi(this.form1).then(res => {
            // 将加载状态设置为 false
            this.loading = false
            if (res.data.returnStatus == "NORMAL") {
              this.firstStep = false
            } else {
              this.$notify({
                message: this.$t(errTables[res.data.errorCode]),
                duration: 3000
              });
            }
          })
          if (this.firstStep == false) {
            this.$refs.form1.resetFields();
          }
        } else {
          // 将加载状态设置为 false
          this.loading = false
        }
      })
    },
    toHome() {
      this.$router.push('/risk')
    }
  }
}
</script>

<style lang="scss" scoped>
.cancelRegister {
  overflow: auto;
  width: 100%;
  .top {
    display: flex;
    align-items: center;
    height: 64px;
    background: #003da5;
    box-shadow: 6px 0 6px 0 rgba(162, 140, 133, 0.3);
    .top-box {
      display: flex;
      margin: 0 auto;
      align-items: center;
      width: 30%;
      @media screen and (max-width: 1000px) {
        margin-left: 180px;
        width: auto;
      }
      @media screen and (max-width: 768px) {
        margin-left: 70px;
        width: auto;
      }
      @media screen and (max-width: 375px) {
        margin: 0 12px;
        width: auto;
      }
      img {
        margin-right: 25px;
        width: 95px;
        height: 32px;
      }
      span {
        padding-left: 25px;
        font-family: SourceHanSansCN-Medium;
        font-size: 18px;
        color: #ffffff;
        line-height: 25px;
        border-left: 1px #fff solid;
      }
    }
  }
  .box {
    margin: 60px auto 0;
    width: 30%;
    min-height: calc(100vh - 238px);
    @media screen and(min-width:768px) and (max-width: 1000px) {
      padding: 0px 180px;
      width: auto;
      min-height: calc(100vh - 238px);
    }
    @media screen and(min-width:375px) and (max-width: 768px) {
      overflow: auto;
      padding: 0px 70px;
      width: auto;
      min-height: calc(100vh - 238px);
    }
    @media screen and(max-width: 375px) {
      overflow: auto;
      padding: 0px 12px;
      width: auto;
      min-height: calc(100vh - 238px);
    }
    .form {
      h4 {
        margin: 0px 0px 10px 0px;
      }
      .el-input {
        font-family: SourceHanSansCN-Regular;
        font-size: 1rem;
        color: rgba(51, 51, 51, 0.5);
        letter-spacing: 0;
        line-height: 16px;
        >>> .el-input__inner {
          // padding-left: 48px;
          height: 40px;
        }
        >>> .el-input__clear {
          font-size: 20px;
        }
        >>> .el-input__prefix {
          top: -4px;
        }
        >>> .el-input__suffix {
          padding: 0px 60px 0 0;
          border-left: none;
        }
        .icon-header_eye_hide,
        .icon-header_eye_show {
          position: absolute;
          top: 1.3px;
          right: -2px;
        }
        .icon-login_username,
        .icon-login_password {
          margin-left: 8px;
          font-size: 24px;
          color: #003da5;
          line-height: 48px;
        }
      }
      .btn-wrap {
        text-align: right;
        height: 120px;
        .el-button {
          margin: 40px 0;
          width: 120px;
          height: 40px;
          background-color: #003da5;
          border: #003da5;
          font-family: SourceHanSansCN-Bold;
          font-size: 1rem;
          color: #ffffff;
          letter-spacing: 0;
          text-align: center;
          line-height: 16px;
          @media screen and(max-width: 320px) {
            margin-bottom: 40px;
          }
        }
      }

      .explain-wrap {
        font-family: SourceHanSansCN-Regular;
        font-size: 1rem;
        color: rgba(51, 51, 51, 0.75);
        line-height: 20px;
        .explain-title {
          font-family: SourceHanSansCN-Medium;
          font-size: 1rem;
          color: #333333;
          padding: 12px 0;
        }
      }
    }
  }
  .success {
    margin: 125px auto 0;
    width: 826px;
    min-height: calc(100vh - 303px);
    @media screen and (max-width: 850px) {
      padding: 0 24px;
      width: 100%;
      min-height: calc(100vh - 238px);
    }
    @media screen and (max-width: 375px) {
      padding: 0 12px;
      width: 100%;
      min-height: calc(100vh - 238px);
    }
    .info-wrap {
      display: flex;
      margin-bottom: 50px;
      width: 100%;
      justify-content: center;
      .imgs {
        width: 58px;
        height: 58px;
        img {
          width: 58px;
          height: 58px;
        }
      }
      .info {
        padding-left: 20px;
        font-family: SourceHanSansCN-Medium;
        font-size: 24px;
        color: #003da5;
        line-height: 30px;
        font-weight: 550;
      }
    }
    .btn {
      display: block;
      margin: 85px auto;
      width: 120px;
      height: 40px;
      font-family: SourceHanSansCN-Bold;
      font-size: 1rem;
      color: #ffffff;
      text-align: center;
      line-height: 16px;
    }
    .link {
      display: block;
      text-align: center;
      a {
        font-family: SourceHanSansCN-Regular;
        font-size: 1rem;
        color: #4d88ff;
        border-bottom: 1px solid #4191ff;
        line-height: 20px;
      }
    }
  }

  .bottom-wrap {
    width: 100%;
  }
}
</style>
