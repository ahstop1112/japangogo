<template>
  <!-- 流动保安编码注册页面 -->
  <div class="register">
    <div class="top">
      <div class="top-box">
        <img src="@/assets/img/1@3x.png" alt="" />
        <span>{{ $t('register.addDialog.title') }}</span>
      </div>
    </div>
    <!-- 表单 -->
    <div class="box" v-if="isSuccess == true">
      <el-form :model="form" :rules="rules" ref="form" class="form" :inline="false">
        <h4>{{ $t('register.registerCode.name') }}</h4>
        <el-form-item prop="loginId">
          <el-input :placeholder="$t('register.registerCode.promptName')" v-model="form.loginId" clearable>
            <i slot="prefix" class="iconfont icon-login_username"></i>
          </el-input>
        </el-form-item>
        <h4>{{ $t('register.registerCode.password') }}</h4>
        <el-form-item prop="password">
          <el-input :type="show?'text':'password'" :placeholder="$t('register.registerCode.promptPassword')" v-model="form.password" clearable>
            <i slot="prefix" class="iconfont icon-login_password"></i>
            <i v-if="form.password!==''" slot="suffix" @click="show=!show" style="cursor:pointer; font-size: 40px;" :class="show?'iconfont icon-header_eye_show':'iconfont icon-header_eye_hide'"></i>
          </el-input>
        </el-form-item>
        <h4>{{ $t('register.registerCode.phone') }}</h4>
        <el-form-item prop="mobileNumber">
          <el-input :placeholder="$t('register.registerCode.promptPhone')" v-model="form.mobileNumber" clearable>
            <i slot="prefix" class="iconfont icon-login_phone"></i>
          </el-input>
        </el-form-item>
        <h4>{{ $t('register.registerCode.email') }}</h4>
        <el-form-item prop="emailAddress">
          <el-input :placeholder="$t('register.registerCode.promptEmail')" v-model="form.emailAddress" clearable>
            <i slot="prefix" class="iconfont icon-login_email"></i>
          </el-input>
        </el-form-item>
        <!-- 协议条款 -->
        <el-form-item prop="isPass">
          <el-checkbox v-model="form.isPass">
            {{ $t('register.registerCode.agree') }}
            <a href="http://www.htisec.com/zh-hk/software_token_tips" target="_blank">{{ $t('register.registerCode.terms') }}</a>
          </el-checkbox>
        </el-form-item>
        <div class="btn">
          <el-button :class="{ btnBg: btnState }" class="fr" type="primary" @click="toSuccess(form)" :disabled="btnState == false" :loading="loading">{{ $t('twoFaLogin.phoneLogin.btn2') }}</el-button>
        </div>
      </el-form>
    </div>

    <!-- 注册成功 -->
    <div class="success" v-else>
      <div class="imgs"><img src="@/assets/img/icon_pass@2x.png" alt="" /></div>
      <div class="info">
        <p>{{ $t('register.success.content1') }}</p>
        <p>{{ $t('register.success.content2') }}</p>
        <p>{{ $t('register.success.content3') }}</p>
      </div>
      <el-button class="btn" type="primary" @click="$router.push('/login')">{{
        $t('twoFaLogin.phoneLogin.btn2')
      }}</el-button>
    </div>
    <!-- 底部组件 -->
    <bottombar></bottombar>
  </div>
</template>

<script>
import bottombar from '@/views/_layout/bottombar'
import { mobileOtpEnrollmentApi } from '@/api/register'
import { login1FaApi } from '@/api/login'
import errTables from '@/utils/errTables'
import register from './register.scss'

export default {
  components: {
    bottombar
  },
  computed: {
    btnState() {
      return (
        this.form.loginId !== '' &&
        this.form.password !== '' &&
        this.form.mobileNumber !== '' &&
        this.form.emailAddress !== '' &&
        this.form.isPass == true
      )
    }
  },
  data() {
    return {
      loading: false,
      show: false,
      isSuccess: true,
      form: {
        loginId: '',
        password: '',
        mobileNumber: '',
        emailAddress: '',
        isPass: true
      },
      //  校验规则
      rules: {
        loginId: [
          {
            required: true,
            message: this.$t('login.information1'),
            trigger: 'blur'
          }
        ],
        password: [
          {
            required: true,
            message: this.$t('login.information2'),
            trigger: 'blur'
          }
        ],
        mobileNumber: [
          {
            required: true,
            message: this.$t('twoFaLogin.phoneLogin.check'),
            trigger: 'blur'
          },
          {
            validator: (rule, value, callback) => {
              // let reg = /^(0|86|17951)?(13[0-9]|15[012356789]|166|17[3678]|18[0-9]|14[57])[0-9]{8}$/
              let reg = /^\d{8,11}$/
              if (reg.test(value)) {
                callback()
              } else {
                callback(new Error(this.$t('twoFaLogin.phoneLogin.check1')))
              }
            },
            trigger: 'change'
          }
        ],
        emailAddress: [
          {
            required: true,
            message: this.$t('register.registerCode.check'),
            trigger: 'blur'
          },
          {
            validator: (rule, value, callback) => {
              let reg = /\w+([-+.]\w+)*@\w+([-.]\w+)*\.\w+([-.]\w+)*/
              if (reg.test(value)) {
                callback()
              } else {
                callback(new Error(this.$t('register.registerCode.check1')))
              }
            },
            trigger: 'change'
          }
        ],
        isPass: [
          { required: true, message: this.$t('register.registerCode.terms1'), trigger: 'blur' },
          {
            validator: (rule, value, callback) => {
              if (value) {
                callback()
              } else {
                callback(new Error(this.$t('register.registerCode.terms1')))
              }
            },
            trigger: 'change'
          }
        ]
      }
    }
  },
  created() {
    let _self = this;
    window.document.onkeydown = function (e) {
      let key = window.event.keyCode;
      if (key == 13 || key == 100) {
        _self.toSuccess();
      }
    }
  },
  mounted() { },
  methods: {
    toSuccess(form) {
      // 全局效验
      this.$refs.form.validate(val => {
        if (val) {
          // 将加载状态设置为 true
          this.loading = true
          login1FaApi({
            loginId: this.form.loginId,
            password: this.form.password,
          }).then(res => {
            // 将加载状态设置为 false
            this.loading = false
            if (res.data.errorCode) {
              this.$notify({
                message: this.$t(errTables[res.data.errorCode]),
                duration: 3000
              });
            } else {
              sessionStorage.setItem('entitySequence', res.data.entitySequence)
              mobileOtpEnrollmentApi({
                loginId: this.form.loginId,
                mobileNumber: this.form.mobileNumber,
                emailAddress: this.form.emailAddress,
                entitySequence: sessionStorage.getItem("entitySequence")
              }).then(res => {
                if (res.data.errorCode) {
                  this.$notify({
                    message: this.$t(errTables[res.data.errorCode]),
                    duration: 3000
                  });
                } else {
                  // 跳转页面
                  this.isSuccess = false
                }
              }).catch(error => {
                console.log(error);
              })
            }
          }).catch(error => {
            console.log(error);
          })
        } else {
          // 将加载状态设置为 false
          this.loading = false
        }
      })
    }
  }
}
</script>