<!--其它市场(证券交易)-->
<template>
  <div class="otherMarket-wrap">
    <pageNav :routerArr="routerArr" />
    <div class="content-wrap">
      <keep-alive>
        <router-view />
      </keep-alive>
    </div>
  </div>
</template>

<script>
import pageNav from "@/components/pageNav"
import { mapGetters } from 'vuex'
export default {
  data() {
    return {
      routerArr: []
    };
  },
  computed: {
    ...mapGetters(['getLang'])
  },
  components: {
    pageNav
  },
  watch: {
    getLang: {
      handler: function (o, n) {
        this.routerArr = [
          {
            name: this.$t('security.otherMarket.headTitle'),
            path: "japan"
          },
          {
            name: this.$t('security.otherMarket.headTitle1'),
            path: "southKorea"
          },
          {
            name: this.$t('security.otherMarket.headTitle2'),
            path: "china"
          }
        ]
      },
      immediate: true
    }
  },
  methods: {},
  mounted() { },

}

</script>
<style lang='scss' scoped>
.otherMarket-wrap {
  width: 100%;
  .content-wrap {
    margin-top: 24px;
  }
}
@media screen and (max-width: 768px) {
  .otherMarket-wrap .router-wrap .router-item {
    padding-left: 12px;
  }
  .otherMarket-wrap .content-wrap {
    margin-top: 12px;
  }
}
</style>