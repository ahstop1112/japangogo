<!--新股认购(证券交易)-->
<template>
  <div class="ipoSubscriptions">
    <!-- 彈框 -->
    <popover ref="renGou" :title="$t('security.ipoSubscriptions.popover.title')" :showPopover="showPopover" @close="closePopover" :isFirst="firstStep">
      <div class="first-wrap" v-if="firstStep">
        <div class="title messageBgColor">
          <span>{{$t('security.ipoSubscriptions.popover.headInfo')}} <a href="javascript:;" @click="toProspectus">{{$t('security.ipoSubscriptions.popover.headLink')}}</a>、<a href="javascript:;" @click="toProspectusForm">{{$t('security.ipoSubscriptions.popover.headLink1')}}</a> 。</span>
        </div>
        <div class="content-details">
          <ul class="content-wrap contentBorder">
            <li class="info-item">
              <span class="txt mediumColor">{{$t('myInquiry.tradeHistory.ipoSub.stockName')}}</span>
              <span class="val heavyColor">{{eipoDetail.ipoName}}</span>
            </li>
            <li class="info-item">
              <span class="txt mediumColor">{{$t('myInquiry.tradeHistory.ipoSub.zhaogujia')}}</span>
              <span class="val heavyColor">{{eipoDetail.offerPrice}}</span>
            </li>
            <li class="info-item">
              <span class="txt mediumColor">{{$t('security.ipoSubscriptions.way')}}</span>
              <span class="val">
                <el-radio @change="changeHeight" style="margin-right:0px" v-if="eipoDetail.isEnable=='true'" v-model="radio" label="1">{{$t('security.ipoSubscriptions.cash')}}</el-radio>
                <el-radio @change="changeHeight" v-model="radio" label="2" v-if="eipoDetail.isEnableMF=='true'">{{$t('security.ipoSubscriptions.subscribe')}}</el-radio>
              </span>
            </li>
            <li class="info-item">
              <span class="txt mediumColor">{{$t('security.ipoSubscriptions.popover.sharesNumber')}}</span>
              <span class="val">
                <el-select v-model="value" placeholder="请选择">
                  <el-option v-for="(item,index) in eipoDetail.ipoDenominationDtoList" :key="index" :value="index" :label="item.appliedShare">
                    {{item.appliedShare | num}}{{'股'}}{{'('}}{{item.amountPayable | num}}{{')'}}
                  </el-option>
                </el-select>
              </span>
            </li>
            <li class="info-item" v-if="radio==2">
              <span class="txt mediumColor">{{$t('security.ipoSubscriptions.popover.proportion')}}</span>
              <span class="val">
                <el-select v-model="value1" placeholder="90%(融资金额：$131,9">
                  <el-option v-for="item in options1" :key="item" :label="item" :value="item">
                  </el-option>
                </el-select>
              </span>
            </li>
            <li class="info-item" v-if="radio==1">
              <span class="txt mediumColor" style="flex: 0 0 145px;">{{$t('security.ipoSubscriptions.poundage')}}</span>
              <span class="val heavyColor" v-if="eipoDetail.handlingCharge">{{eipoDetail.handlingCharge|num}}</span>
            </li>
            <li class="info-item" v-if="radio==1">
              <span class="txt mediumColor" style="flex: 0 0 145px;">{{$t('security.ipoSubscriptions.popover.amount')}}</span>
              <span class="val heavyColor">90%</span>
            </li>
            <li class="info-item" v-if="radio==1">
              <span class="txt mediumColor" style="flex: 0 0 145px;">{{$t('myInquiry.tradeHistory.ipoSub.jiaoyijine')}}</span>
              <span class="val heavyColor">$463.63</span>
            </li>

            <li class="info-item" v-if="radio==2">
              <span class="txt mediumColor" style="flex: 0 0 145px;">{{$t('security.ipoSubscriptions.poundage')}}</span>
              <span class="val heavyColor" v-if="eipoDetail.handlingChargeMF">{{eipoDetail.handlingChargeMF|num}}</span>
            </li>
            <li class="info-item" v-if="radio==2">
              <span class="txt mediumColor" style="flex: 0 0 145px;">{{$t('security.ipoSubscriptions.popover.amount')}}</span>
              <span class="val heavyColor">90%</span>
            </li>
            <li class="info-item" v-if="radio==2">
              <span class="txt mediumColor" style="flex: 0 0 145px;">{{$t('myInquiry.tradeHistory.ipoSub.cankaolilv')}}</span>
              <span class="val heavyColor">{{interestRateMF}}</span>
            </li>
            <li class="info-item" v-if="radio==2">
              <span class="txt mediumColor" style="flex: 0 0 145px;">{{$t('myInquiry.tradeHistory.ipoSub.jiaoyijine')}}</span>
              <span class="val heavyColor">$463.63</span>
            </li>
          </ul>
          <div class="options-wrap contentBorder">
            <span class="options-title mediumColor">{{$t('security.ipoSubscriptions.popover.chekTitle')}}</span>
            <el-checkbox-group v-model="checkListOne">
              <el-checkbox :label="item" v-for="item in ConfirmInformation" :key="item"></el-checkbox>
            </el-checkbox-group>
          </div>
          <div class="info-wrap">
            <div class="info-title mediumColor">{{$t('security.ipoSubscriptions.popover.chekTitle2')}}
              <el-popover placement="right" width="180" trigger="click">
                <div class="explain lightColor">
                  {{$t('security.ipoSubscriptions.popover.detailsInfo')}}
                </div>
                <div class="info-text" slot="reference">
                  <i class="iconfont icon-detail"></i>
                  <span class="lightColor contentBorder">{{$t('security.ipoSubscriptions.popover.details')}}</span>
                </div>
              </el-popover>
            </div>
            <el-checkbox-group v-model="checkListTwo">
              <el-checkbox :label="item" v-for="item in PromptInformation" :key="item"></el-checkbox>
            </el-checkbox-group>
          </div>
        </div>
        <div class="avg-wrap contentTopBorder" v-if="userData.transactionProtection == true">
          <span class="txt mediumColor">{{$t('myInquiry.tradeHistory.ipoSub.password')}}</span>
          <span class="val">
            <el-input v-model="password" :placeholder="$t('myInquiry.tradeHistory.ipoSub.tip')"></el-input>
          </span>
        </div>
        <div class="confirm-btn">
          <el-button type="primary" @click="goToSuccess">{{$t('myInquiry.tradeHistory.ipoSub.cofirm')}}</el-button>
        </div>
      </div>
      <div class="second-wrap" v-else>
        <div class="layout-wrap">
          <div class="success-wrap">
            <span class="icons"><i class="iconfont icon-status_success activeFontColor"></i></span>
            <span class="text activeFontColor">{{$t('security.ipoSubscriptions.popover.submitInfo')}}</span>
            <div class="success-btn">
              <el-button plain @click="goToRoute('/myInquiry/tradeHistory/ipoSubscription')">{{$t('security.ipoSubscriptions.popover.btn')}}</el-button>
            </div>
          </div>
        </div>
      </div>
    </popover>
    <div class="img">
      <img src="@/assets/img/banner_IPO@2x.png" alt="">
    </div>
    <el-row :gutter="24">
      <el-col :xs="24" :sm="24" :md="md" :lg="lg" :xl="xl">
        <div class="newStock-list contentBg">
          <main-title :title="$t('security.ipoSubscriptions.list')" />
          <div class="newStock-wrap">
            <el-table :data="tableData" highlight-current-row @row-click="getEipoDetail" :row-class-name="tableRowClass" :header-cell-style="headeRowClass" style="width: 100%">
              <el-table-column align="left" min-width="180" :label="$t('security.ipoSubscriptions.stock')">
                <template v-slot="scope">
                  <span>{{ scope.row.instrDsplyCode }} {{ scope.row.ipoName }}</span>
                </template>
              </el-table-column>
              <el-table-column align="right" min-width="60" :label="$t('security.ipoSubscriptions.price')">
                <template v-slot="scope">
                  <span>{{ scope.row.ccyCode }}{{ scope.row.offerPrice }}</span>
                </template>
              </el-table-column>
              <el-table-column align="right" min-width="80" :label="$t('security.ipoSubscriptions.way')" prop="isEnable" :formatter="SubscribeWay">
                <!-- <template v-slot="scope">
                  <span>{{ scope.row.isEnable=='true'&&scope.row.isEnableMF=='true'?'现金/融资':''||scope.row.isEnable=='true'?'现金':''||scope.row.isEnableMF=='true'?'融资':''}}</span>
                </template> -->
              </el-table-column>
              <el-table-column align="center" min-width="110" :label="$t('security.ipoSubscriptions.date7')">
                <template v-slot="scope">
                  <span v-if="scope.row.cutOffDateTime">{{ scope.row.cutOffDateTime.substring(0,10) }}</span>
                </template>
              </el-table-column>
              <el-table-column prop="ipoSubStatus" :formatter="SubscribeStatus" align="left" width="90" :label="$t('security.ipoSubscriptions.state')">
              </el-table-column>
            </el-table>
          </div>

        </div>
      </el-col>
      <el-col :xs="24" :sm="24" :md="12" :lg="12" :xl="12" v-if="isShow" >
        <div class="newStock-details contentBg">
          <newStockDetails :cashShow.sync="cashShow" :marginShow.sync="marginShow" :eipoDetail="eipoDetail" v-if="eipoDetail"></newStockDetails>
          <div class="btn">
            <el-button :disabled="userData.allowTrade === false" type="primary" @click="openPopover">{{$t('security.ipoSubscriptions.btn')}}</el-button>
          </div>
        </div>
      </el-col>
    </el-row>
  </div>
</template>

<script>
import mainTitle from '@/components/mainTitle';
import newStockDetails from './ipoSubscriptions/newStockDetails';
import popover from '@/components/popover';
import { mapGetters } from 'vuex';
import { enquiryAllIposByLangApi, enquiryIpoMasterDetailApi } from "@/api/security"
import errTables from '@/utils/errTables'
export default {
  components: {
    mainTitle,
    newStockDetails,
    popover,
  },
  data() {
    return {
      marginShow: false,
      cashShow: false,
      md: 24,
      lg: 24,
      xl: 24,
      isShow: false,
      password: '',
      checkListOne: [],
      checkListTwo: [],
      value: '',
      value1: '',
      radio: '1',
      firstStep: true, //是否显示第一步
      showPopover: false,
      currentRow: '',
      tableData: [],
      userData: {},
      eipoDetail: {},
    };
  },

  computed: {
    ...mapGetters(['getBgColor', 'getLang', 'getActiveAccountId']),
    ConfirmInformation() {
      return [this.$t('security.ipoSubscriptions.popover.chekInfo1'),
      this.$t('security.ipoSubscriptions.popover.chekInfo2'), this.$t('security.ipoSubscriptions.popover.chekInfo3'), this.$t('security.ipoSubscriptions.popover.chekInfo4')]
    },
    PromptInformation() {
      return [this.$t('security.ipoSubscriptions.popover.notice'), this.$t('security.ipoSubscriptions.popover.notice1')]
    },
    // options() {
    //   return [
    //     '40,000股($ 146,663.18)', '10,000股($ 146,663.18)']
    // },
    options1() {
      return ['90%(融资金额：$131,9', '80%(融资金额：$131,9']
    },
    interestRateMF: {
      get: function () {
        let a4 = this.eipoDetail.interestRateMF
        if (a4 == 0) {
          return 0;
        }
        let str = Number(a4 * 100).toFixed();
        str += "%";
        return str
      }
    },
  },
  watch: {
    tableData(val) {
      this.tableData = val;
    },
    getLang() {
      this.getEipoList()
    },
    getActiveAccountId: {
      handler: function (val) {
        if (val) {
          this.getEipoList();
        }
      },
      immediate: true
    }
  },
  methods: {
    changeHeight() {
      this.$refs.renGou.calcContentHeight();
    },
    SubscribeWay(row, column) {
      if (row.isEnable == 'true' && row.isEnableMF == 'true') {
        return this.$t('security.ipoSubscriptions.cashMargin');
      } else if (row.isEnable == 'true') {
        return this.$t('security.ipoSubscriptions.cash1');
      } else if (row.isEnableMF == 'true') {
        return this.$t('security.ipoSubscriptions.margin');
      }
    },
    SubscribeStatus(row, column) {
      if (row.ipoSubStatus == "CLOSE") {
        return this.$t('security.ipoSubscriptions.bujieshou');
      } else if (row.ipoSubStatus == 'OPEN') {
        return this.$t('security.ipoSubscriptions.jieshou');
      } else if (row.ipoSubStatus == 'SUSPEND') {
        return this.$t('security.ipoSubscriptions.zanting');
      }
    },
    tableRowClass({ row, rowIndex }) {
      row.index = rowIndex;
      return 'tableRowClass'
    },
    headeRowClass({ row, column, rowIndex, columnIndex }) {
      //表头的背景颜色
      if (rowIndex == 0) {
        if (this.getBgColor == 'bg-anhei') {
          return 'background:rgb(51,51,51)';
        } else {
          return 'background:rgb(255,255,255)';
        }
      }
    },
    toProspectus() {
      let routeProspectus = this.$router.resolve({
        path: '/prospectus'
      })
      window.open(routeProspectus.href, '_blank');
    },
    toProspectusForm() {
      let routeProspectusForm = this.$router.resolve({
        path: '/prospectusForm'
      })
      window.open(routeProspectusForm.href, '_blank');
    },
    goToRoute(path) {
      this.$router.push(path);
      this.$store.commit('changeIsJumpRouter', true);
    },
    goToSuccess() {
      this.firstStep = false;
    },
    openPopover() {
      this.firstStep = true;
      this.showPopover = true;
    },
    // 隐藏弹窗
    closePopover() {
      this.showPopover = false
      this.radio = '1'
      this.value = ''
      this.value1 = ''
      this.checkListOne = []
      this.checkListTwo = []
      this.password = ''
    },
    //EIPO详情点击事件
    getEipoDetail(row, event, column) {
      let index = row.index;
      console.log(index);
      if (this.tableData[index].isEnable == 'true' && this.tableData[index].isEnableMF == 'true') {
        enquiryIpoMasterDetailApi({
          accountId: this.getActiveAccountId,
          lang: this.$store.state.lang,
          ipoId: this.tableData[index].ipoId
        }).then(res => {
          if (res.data.errorCode) {
            this.$notify({
              message: this.$t(errTables[res.data.errorCode]),
              duration: 3000
            });
            this.md = 24
            this.lg = 24
            this.xl = 24
            this.isShow = false
            console.log(res.data);
          } else {
            this.eipoDetail = res.data;
            console.log(this.eipoDetail);
            if (JSON.stringify(this.eipoDetail) !== "{}") {
              this.md = 12
              this.lg = 12
              this.xl = 12
              this.isShow = true
              this.cashShow = true
              this.marginShow = true
            }
          }
        }).catch(error => {
          console.log(error);
        });
      } else if (this.tableData[index].isEnable == 'true') {
        enquiryIpoMasterDetailApi({
          accountId: this.getActiveAccountId,
          lang: this.$store.state.lang,
          ipoId: this.tableData[index].ipoId
        }).then(res => {
          if (res.data.errorCode) {
            this.$notify({
              message: this.$t(errTables[res.data.errorCode]),
              duration: 3000
            });
            this.md = 24
            this.lg = 24
            this.xl = 24
            this.isShow = false
            console.log(res.data);
          } else {
            this.eipoDetail = res.data;
            console.log(this.eipoDetail);
            if (JSON.stringify(this.eipoDetail) !== "{}") {
              this.md = 12
              this.lg = 12
              this.xl = 12
              this.isShow = true
              this.marginShow = false
              this.cashShow = true
            }
          }
        }).catch(error => {
          console.log(error);
        });
      } else if (this.tableData[index].isEnableMF == 'true') {
        enquiryIpoMasterDetailApi({
          accountId: this.getActiveAccountId,
          lang: this.$store.state.lang,
          ipoId: this.tableData[index].ipoId
        }).then(res => {
          if (res.data.errorCode) {
            this.$notify({
              message: this.$t(errTables[res.data.errorCode]),
              duration: 3000
            });
            this.md = 24
            this.lg = 24
            this.xl = 24
            this.isShow = false
            console.log(res.data);
          } else {
            this.eipoDetail = res.data;
            console.log(this.eipoDetail);
            if (JSON.stringify(this.eipoDetail) !== "{}") {
              this.md = 12
              this.lg = 12
              this.xl = 12
              this.isShow = true
              this.marginShow = true
              this.cashShow = false
            }
          }
        }).catch(error => {
          console.log(error);
        });
      } else {
        this.md = 24
        this.lg = 24
        this.xl = 24
        this.isShow = false
      }
    },
    // 获取EIPO列表
    getEipoList() {
      enquiryAllIposByLangApi({
        accountId: this.getActiveAccountId,
        lang: this.$store.state.lang
      }).then(res => {
        if (res.data.errorCode) {
          this.$notify({
            message: this.$t(errTables[res.data.errorCode]),
            duration: 3000
          });
        } else {
          this.tableData = res.data.ipoMasters
          console.log(this.tableData);
        }
      }).catch(error => {

      });
    }
  },
  created() {
    this.userData = JSON.parse(sessionStorage.getItem("userData"));
  },
  mounted() {
    this.$nextTick(() => {
    })
  },
}

</script>
<style lang='scss' scoped>
.ipoSubscriptions {
  width: 100%;
  height: 100%;
  .img {
    padding-bottom: 24px;
    img {
      width: 100%;
      height: 100%;
      vertical-align: middle;
    }
  }
  .newStock-list {
    margin-bottom: 24px;
    padding-bottom: 24px;
    width: 100%;
    .newStock-wrap {
      padding: 0 24px;
      >>> .el-table th > .cell {
        color: rgba(51, 51, 51, 0.5);
      }
      >>> .el-table .cell {
        font-family: SourceHanSansCN-Regular;
        color: #333333;
      }
    }
  }
  .newStock-details {
    width: 100%;
    .btn {
      padding: 0 24px 24px 24px;
      text-align: right;
    }
  }
  .first-wrap {
    width: 100%;
    height: 100%;
    .title {
      padding-left: 24px;
      font-family: SourceHanSansCN-Regular;
      font-size: 12px;
      color: #333333;
      line-height: 25px;
      a {
        font-family: SourceHanSansCN-Medium;
        color: #4191ff;
        border-bottom: 1px solid #4191ff;
      }
    }
    .content-details {
      padding: 12px 24px;
      width: 100%;
      height: 100%;
      .content-wrap {
        padding-bottom: 12px;
        .info-item {
          display: flex;
          flex-wrap: wrap;
          align-content: flex-start;
          align-items: baseline;
          padding: 4px 0;
          .txt {
            flex: 0 0 100px;
            font-family: SourceHanSansCN-Regular;
            font-size: 1rem;
            line-height: 20px;
          }
          .val {
            flex: 1;
            font-family: SourceHanSansCN-Regular;
            font-size: 1rem;
            text-align: right;
            line-height: 20px;
          }
        }
      }
      .options-wrap {
        padding-top: 12px;
        .el-checkbox {
          display: block;
          margin-right: 12px;
          >>> .el-checkbox__label {
            overflow: hidden;
            display: inline-flex;
            white-space: pre-line;
            font-family: SourceHanSansCN-Regular;
            font-size: 1rem;
            color: rgba(0, 0, 0, 0.75);
            line-height: 23px;
          }
        }
      }
      .info-wrap {
        padding-top: 12px;
        >>> .el-checkbox__label {
          font-family: SourceHanSansCN-Regular;
          font-size: 1rem;
          color: rgba(51, 51, 51, 0.75);
        }
        .info-text {
          display: inline-block;
          cursor: pointer;
          .icon-detail {
            color: #9b9b9b;
          }
          span {
            display: inline-block;
            font-family: SourceHanSansCN-Medium;
            font-size: 12px;
            transform: translateY(-2px);
          }
        }
        .explain {
          font-family: SourceHanSansCN-Normal;
          font-size: 12px;
        }
      }
      .options-title,
      .info-title {
        display: inline-block;
        padding-bottom: 12px;
        font-family: SourceHanSansCN-Regular;
      }
    }
    .avg-wrap {
      display: flex;
      align-items: center;
      padding: 24px;
      width: 100%;
      .txt {
        flex: 0 0 80px;
        font-family: SourceHanSansCN-Regular;
        font-size: 1rem;
      }
      .val {
        flex: 1;
      }
    }
    .confirm-btn {
      padding: 0 24px 24px 24px;
      text-align: right;
    }
  }
  .second-wrap {
    .layout-wrap {
      padding: 24px;
      width: 100%;
      height: 100%;
      .success-wrap {
        text-align: center;
        span {
          display: block;
        }
        .icons {
          padding: 24px 0;
          i {
            font-size: 58px;
          }
        }
        .text {
          font-family: SourceHanSansCN-Medium;
          font-size: 18px;
        }
        .success-btn {
          margin-top: 30px;
        }
      }
    }
  }
}
@media screen and (max-width: 768px) {
  .ipoSubscriptions .img {
    padding-bottom: 12px;
  }
  .ipoSubscriptions .newStock-list {
    margin-bottom: 12px;
  }
  .ipoSubscriptions .newStock-list .newStock-wrap {
    padding: 0 12px;
  }
  .ipoSubscriptions .newStock-details .btn {
    padding: 12px;
  }
}
</style>