<template>
  <div class="prospectus">
    <div class="top">
      <div class="top-box">
        <img src="@/assets/img/1@3x.png" alt="" />
        <span>{{$t('security.ipoSubscriptions.prospectus.title')}}</span>
      </div>
    </div>
    <span class="title">{{$t('security.ipoSubscriptions.prospectus.title')}}</span>
    <div class="box">
      <div class="content">
        <el-scrollbar wrap-class="scrollbar-wrapper" style="height: 100%;">
          <p>
            {{$t('security.ipoSubscriptions.prospectus.content')}}
          </p>
          <p>{{$t('security.ipoSubscriptions.prospectus.content1')}}</p>
          <p style="text-indent:1em;">
            {{$t('security.ipoSubscriptions.prospectus.content2')}} <a :href="$t('security.ipoSubscriptions.prospectus.link')" target="_blank">{{$t('security.ipoSubscriptions.prospectus.link')}}</a>
          </p>
          <p style="text-indent:1em;">
            {{$t('security.ipoSubscriptions.prospectus.content3')}}
          </p>
          <p style="text-indent:1em;">
            {{$t('security.ipoSubscriptions.prospectus.content4')}}
          </p>
          <p>{{$t('security.ipoSubscriptions.prospectus.content5')}}</p>
          <p>{{$t('security.ipoSubscriptions.prospectus.content6')}}</p>
          <p class="text">{{$t('security.ipoSubscriptions.prospectus.content7')}}</p>
        </el-scrollbar>
      </div>
    </div>

    <div class="btn">
      <el-button type="primary" @click="close">{{
        $t('prompt.Close')
      }}</el-button>
    </div>
  </div>
</template>

<script>
export default {

  data() {
    return {
    };
  },
  created() {

  },
  methods: {
    // 关闭当前页
    close() {
      window.close()
    }
  },

};
</script>

<style lang="scss" scoped>
.prospectus {
  .top {
    display: flex;
    align-items: center;
    margin-bottom: 24px;
    height: 64px;
    background: #003da5;
    box-shadow: 6px 0 6px 0 rgba(162, 140, 133, 0.3);
    @media screen and(max-width: 1080px) {
      padding: 0 24px;
    }
    @media screen and(max-width:768px) {
      padding: 0 12px;
    }
    .top-box {
      display: flex;
      align-items: center;
      margin: 0 auto;
      width: 1000px;
      img {
        margin-right: 25px;
        width: 95px;
        height: 32px;
      }
      span {
        padding-left: 25px;
        font-family: SourceHanSansCN-Medium;
        font-size: 18px;
        color: #ffffff;
        letter-spacing: 0;
        line-height: 25px;
        border-left: 1px #fff solid;
      }
    }
  }
  .title {
    display: block;
    font-family: SourceHanSansCN-Medium;
    font-size: 18px;
    color: #003da5;
    line-height: 18px;
    text-align: center;
  }
  .box {
    margin: 53px auto 80px;
    width: 1000px;
    @media screen and(max-width: 1000px) {
      padding: 0 24px;
      width: 100%;
    }
    @media screen and(max-width:768px) {
      padding: 0 12px;
    }
    .content {
      font-family: SourceHanSansCN-Regular;
      font-size: 1rem;
      color: rgba(51, 51, 51, 0.75);
      line-height: 20px;
      p {
        padding: 5px 0;
      }

      .text {
        margin-top: 40px;
      }
      a {
        font-family: SourceHanSansCN-Regular;
        font-size: 1rem;
        color: #4191ff;
        border-bottom: 1px solid #4191ff;
      }
    }
  }
  .btn {
    padding-bottom: 24px;
    text-align: center;
    .el-button {
      width: 120px;
      height: 40px;
      font-family: SourceHanSansCN-Bold;
      font-size: 1rem;
    }
  }
}
</style>