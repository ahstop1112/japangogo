<!--港A美股(证券交易)-->
<template>
  <div class="mainMarket">
    <div class="top-wraps">
      <div class="pagNav-wrap">
        <pageNav :routerArr="routerArr"/>
      </div>
      <div class="refresh">
        <el-button type="primary" @click="reloadPage">
          <i class="iconfont icon-refresh"></i>
          <span class="txt">{{$t("security.mainMarket.refresh")}}</span>
        </el-button>
      </div>
      </div>
    <div class="content-wrap">
      <router-view v-if="isRouterAlive"/>
    </div>
  </div>
</template>

<script>
import pageNav from "@/components/pageNav"
export default {
  provide () {
      return {
        reload: this.reload
      }
  },
  data () {
    return {
      isRouterAlive: true,
    };
  },
  computed: {
    routerArr() {
      return [
        {
          img: require("@/assets/img/flag_HK@2x.png"),
          name: this.$t("security.mainMarket.hkTrading"),
          path:"hkTrading"
        },
        {
          img: require("@/assets/img/flag_CN@2x.png"),
          name:this.$t("security.mainMarket.chinaTrading"),
          path:"A-shareTrading"
        },
        {
          img: require("@/assets/img/flag_US@2x.png"),
          name:this.$t("security.mainMarket.usTrading"),
          path:"usTrading"
        }
      ]
    }
  },
  components: {
    pageNav
  },
  methods: {
    reloadPage() {
      this.reload();
    },
     // 刷新当前页
    reload() {
        this.isRouterAlive = false;
        this.$nextTick(function(){
            this.isRouterAlive = true;
        })
    },
  },
  mounted(){},

}

</script>
<style lang='scss' scoped>
  .mainMarket{
     width: 100%;
     .top-wraps{
      width: 100%;
      display: flex;
     }
     .pagNav-wrap{
       width: 100%;
     }
     .refresh{
       flex: 0 0 114px;
       text-align: right;
       line-height: 48px;
       i{
         font-size: 12px;
       }
     }
    .content-wrap{
      margin-top: 24px;
    }
  }
  @media screen and (max-width: 768px){
     .mainMarket .router-wrap .router-item{
       padding-left: 12px;
     }
     .mainMarket .content-wrap{
       margin-top: 12px;
     }
     .mainMarket .refresh{
       position: fixed;
       bottom: 100px;
       right: -10px;
       z-index: 1000;
     }
   }
</style>