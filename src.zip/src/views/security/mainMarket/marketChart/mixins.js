// 行情数据的数据内容信息
import { getQuot, getWarrantQuot } from "@/api/security"
import { mapGetters } from 'vuex'
import {initMOption} from "./kline.js";
import { _calTradyTime } from '@/utils/security'
export const MarketData = {
    watch: {
        getCurStock(val){
            this.sotckCode = val.assetId;
            let type = val.secType;
            //判断当前选择的股票是否在自选股中
            if(this.getUpdateSelfStock.indexOf(this.sotckCode) != -1) {
                this.isCollect = true
            }else{
                this.isCollect = false
            }
            let obj = {
                "0":"base",
                "1":"base",
                "2":"base",
                "3":"base",
                "4":"wolun",
                "5":"base",
                "6":"niuxiong",
                "7":"jienei",
            }
            let orgType ="";
            for(let keys in obj) {
                if(keys == type) {
                    orgType = obj[keys];
                    break;
                }
            }
            this.curType = orgType;
            //基础数据
            this._getChartData();
            //加载echart
            this.echartReload();
            //涡轮数据
            if(this.curMarket == 'hkTrading') {
                this._getWarrantQuot();
            }
        }
    
    },
    data() {
        return {
            curType:"base",//当前市场是什么，港股的话是否是涡轮，牛熊证等 (base wolun niuxiong jienei)
            states: "c",//当前的股票类型  v股票参与冷静期 c收市竞价盘 p股票参与港交所盘前时段控制
            detailData: [],//基础详情数据
            updateTime: "-",
            WarrantData:{},//涡轮数据
        }
    },
    computed: {
        ...mapGetters(['getCurStock','getUpdateSelfStock','getQuterType']),
          //行情数据的基础信息
        baseItem1() {
             return [
                {
                    name: this.$t('security.mainMarket.zuigao'), //显示行情数据的名称
                    val: this.detailData[5] || "-", //显示行情数据的值    
                },   
                {
                    name: this.$t('security.mainMarket.jinkai'),
                    val: this.detailData[6] || "-", 
                }, 
                {
                    name: this.$t('security.mainMarket.zuidi'),
                    val: this.detailData[7] || "-", 
                }, 
                {
                    name: this.$t('security.mainMarket.zuoshou'),
                    val: this.detailData[8] || "-", 
                }, 
            ]  
        },
        baseItem2() {
            let obj = [
                {
                    name: this.$t('security.mainMarket.chenjiaoe'),
                    val: this.forMatNum(this.detailData[9]), 
                    type:"base,wolun,niuxiong",
                },
                {
                    name: this.$t('security.mainMarket.xinshijia'),
                    val: this.WarrantData.exercisePrice || "-", 
                    type:"wolun",
                },
                {
                    name: this.$t('security.mainMarket.shangxianjia'),
                    val: this.WarrantData.exercisePriceCeiling || "-", 
                    type:"jienei",
                },
                {
                    name: this.$t('security.mainMarket.xiaxianjia'),
                    val: this.WarrantData.exercisePriceFloor || "-",
                    type:"jienei",
                },
                {
                    name: this.$t('security.mainMarket.daoqiri'),
                    val: this.WarrantData.lastTradingDay || "-",
                    type:"jienei",
                },
                {
                    name: this.$t('security.mainMarket.shouhuijia'),
                    val: this.WarrantData.pStrPrice?(this.WarrantData.pStrPrice*100/100).toFixed(3) : "-",
                    type:"niuxiong",
                },
                {
                    name: this.$t('security.mainMarket.meishou'),
                    val: this.detailData[12]?this.detailData[12]+"股" : "-", 
                    type:"base，wolun,niuxiong,jienei",
                },
                {
                    name: this.$t('security.mainMarket.shiyinglv'),
                    val: this.detailData[11] || "-", 
                    type:"base",
                },
            ]
            return this.getCurTypeData(obj, this.curType);
        },
        //行情数据的基础信息(不包含)
        detailItem1() {
            let obj = [
                {
                    name: this.$t('security.mainMarket.chenjiaoliang'),
                    val: this.forMatNum(this.detailData[10])+'手', 
                    type:"base,wolun,niuxiong",
                },
                {
                    name: this.$t('security.mainMarket.pingjunjia'),
                    val: this.detailData[13] || "-", 
                    type:"base",
                },
                {
                    name: this.$t('security.mainMarket.shijinlv'),
                    val: this.detailData[14] || "-",
                    type:"base",
                },
                {
                    name: this.$t('security.mainMarket.shizhi'),
                    val: this.forMatNum(this.detailData[15]), 
                    type:"base",
                },
                {
                    name: this.$t('security.mainMarket.huanshoulv'),
                    val:  this.forMatPrcent(this.detailData[16]),
                    type:"base",
                },
                {
                    name: this.$t('security.mainMarket.zhengfu'),
                    val: this.forMatPrcent(this.detailData[17]), 
                    type:"base",
                },
                {
                    name: this.$t('security.mainMarket.waipan'),
                    val: this.forMatNum(this.detailData[19])+'手', 
                    type:"base",
                },
                {
                    name: this.$t('security.mainMarket.weibi'),
                    val: this.forMatPrcent(this.detailData[21]),
                    type:"base",
                },
                {
                    name: this.$t('security.mainMarket.fiveWeekHight'),
                    val: this.detailData[22] || "-",
                    type:"base",
                },
                {
                    name: this.$t('security.mainMarket.neipan'),
                    val: this.forMatNum(this.detailData[20])+'手', 
                    type:"base",
                },
                {
                    name: this.$t('security.mainMarket.liangbi'),
                    val: this.detailData[18] || "-", 
                    type:"base",
                },
                {
                    name: this.$t('security.mainMarket.fiveWeekLower'),
                    val: this.detailData[23] || "-",
                    type:"base",
                },
                {
                    name: this.$t('security.mainMarket.yijia'),
                    val: (this.WarrantData.premium*100/100).toFixed(3) || "-",
                    type:"wolun,niuxiong,jienei",
                },
                {
                    name: this.$t('security.mainMarket.yishenbofu'),
                    val: this.WarrantData.impliedVolatility || "-", 
                    type:"wolun,niuxiong,jienei",
                },
                {
                    name: this.$t('security.mainMarket.duichongzhi'),
                    val: this.WarrantData.delta || "-", 
                    type:"wolun,niuxiong,jienei",
                },
                {
                    name: this.$t('security.mainMarket.jiehuobi'),
                    val: (this.WarrantData.percOfStillOut || this.WarrantData.percOfStillOut == 0)?(this.WarrantData.percOfStillOut*100).toFixed(3)+"%" : "-",
                    type:"wolun,niuxiong,jienei",
                },
                {
                    name: this.$t('security.mainMarket.huangubili'),
                    val: (this.WarrantData.entRatio || this.WarrantData.entRatio== 0)?(this.WarrantData.entRatio*100).toFixed(3)+"%" : "-", 
                    type:"wolun,niuxiong",
                },
                {
                    name: this.$t('security.mainMarket.gangganbili'),
                    val:  (this.WarrantData.leverageRatio || this.WarrantData.leverageRatio == 0) ?(this.WarrantData.leverageRatio*100).toFixed(3)+"%" : "-",
                    type:"wolun,niuxiong,jienei",
                },
                {
                    name: this.$t('security.mainMarket.jianeijiawai'),
                    val: this.WarrantData.moneyness || "-", 
                    type:"wolun,niuxiong",
                },
                {
                    name: this.$t('security.mainMarket.dahedian'),
                    val: this.WarrantData.breakEvenPrice || "-", 
                    type:"wolun,niuxiong",
                },
                {
                    name: this.$t('security.mainMarket.daoqiri'),
                    val: this.forMatDate(this.WarrantData.maturityDate), 
                    type:"wolun,niuxiong",
                },
                {
                    name: this.$t('security.mainMarket.zuihoujiaoyiri'),
                    val: this.WarrantData.lastTradingDay || "-",
                    type:"wolun,niuxiong,jienei",
                },
                {
                    name: this.$t('security.mainMarket.leibie'),
                    val: this.forMatCharacter(this.WarrantData.warrantCharacter), // wolun 认购证 认沽证 
                    type:"wolun,niuxiong,jienei",//niuxiong  牛证  熊证  jienei  界内证
                },
            ] 
            return this.getCurTypeData(obj, this.curType);  
        },
        detailItem2() {
            let obj =   [
                {
                    name: this.$t('security.mainMarket.lengjinjia'),
                    val: '3.65', // v 冷静期  c收市竞价盘
                    type:"v",
                },
                {
                    name: this.$t('security.mainMarket.lengjinshanxian'),
                    val: '4.25',
                    type:"v",
                },
                {
                    name: this.$t('security.mainMarket.lengjinxiaxian'),
                    val: '4.25',
                    type:"v",
                },
                {
                    name: this.$t('security.mainMarket.lengjinBshijian'),
                    val: '2020-09-23', 
                    type:"v",
                },
                {
                    name: this.$t('security.mainMarket.lengjinEshijian'),
                    val: '2020-11-23', 
                    type:"v",
                },
                {
                    name: this.$t('security.mainMarket.shoushijingjia'),
                    val: '3.96', 
                    type:"c",
                },
                {
                    name: this.$t('security.mainMarket.shoushishangxian'),
                    val: '3.86', 
                    type:"c",
                },
                {
                    name: this.$t('security.mainMarket.shoushixiaxian'),
                    val: '3.23', 
                    type:"c",
                },
                {
                    name: this.$t('security.mainMarket.bupinghengliang'),
                    val: '3000', 
                    type:"c",
                },
                {
                    name: this.$t('security.mainMarket.bupinghengfangxiang'),
                    val: '1205', 
                    type:"c",
                },
            ]
            return this.getCurTypeData(obj, this.states);
        },
    },
    methods: {
        //根据类型获取它的类别
        forMatCharacter(type) {
            if(!type) {
                return "-"
            }
            let obj = {
                "1":"认购",
                "2":"认沽",
                "3":"牛证",
                "4":"熊证",
                "5":"其他",
                "6":"界内证",
            }
            let val ="";
            for(let keys in obj) {
                if(keys == type) {
                    val = obj[keys];
                    break;
                }
            }
            return val;
        },
        forMatPrcent(num) {
            if(!num) {
                return "-" 
            }
            let val = (num*100).toFixed(2)+"%";
            return val;
        },
        //格式化金额
        forMatNum(num) {
            if(!num) {
               return "-" 
            }
            num = Number(num).toFixed(2);
            let val = ""
            let sizes = ['','万','亿','万亿']
            let k = 10000;
            if(num < k) {
                val = num;
            }else{
               let i = Math.floor(Math.log(num) / Math.log(k)); 
               val = ((num / Math.pow(k, i))).toFixed(2)+ sizes[i];
            } 
            return val;
        },
        //格式化时间
        forMatDate(time, year) {
            if(!time) {
                return "-";
            }
            var time = new Date(time);
            var y = time.getFullYear();  //年
            var m = time.getMonth() + 1;  //月
            if(m < 10){ m = '0' + m }
            var d = time.getDate();  //日
            if(d < 10){ d = '0' + d }
            var h = time.getHours();  //时
            if(h < 10){ h = '0' + h }
            var mm = time.getMinutes();  //分
            if(mm < 10){ mm = '0' + mm }
            var s = time.getSeconds();  //秒
            if(s < 10){ s = '0' + s }
            if(year) {
                return y+"-"+m+"-"+d
            }
            return  y+"-"+m+"-"+d+" "+h+":"+mm+":"+s;
        },
        //根据类型得到当前的
        getCurTypeData(data,type) {
            let dataArr = [];
            for(let i=0;i<data.length;i++) {
                if(data[i].type.indexOf(type) != -1) {
                    dataArr.push(data[i]);
                }
            }
            return dataArr
        },
        //基本信息查询
        _getChartData() {
            //如果时间段不是在 9点半到11点 30 或者13点到 15点就不发送请求
            let sotckCode = this.sotckCode
            if(!sotckCode || sotckCode == '') {
                return;
            }
            let params =  {
                "params": {
                    "fields": "0|1|2|9|10|3|5|4|6|7|8|39|105|116|40|38|37|108|12|120|119|11|71|72|118|42",
                    "assetIds": [sotckCode],//300059.SZ
                },
                "tester": "ibester"
            }
            getQuot(
               params
            ).then(res => {
              this.detailData = res.result.data[0];
              this.updateTime = this.forMatDate(res.curtime);
              //只有菜单是分时的时候去拼接
              if(this.kTypeIndex == 0) {
                var time = new Date(res.curtime);
                var h = time.getHours().toString();  //时
                if(h < 10){ h = '0' + h }
                var mm = time.getMinutes().toString();  //分
                if(mm < 10){ mm = '0' + mm }
                let curTime = h+mm;
                //新数据同时增长到分时图上面去
                let obj = [
                  curTime,
                  Number(this.detailData[2]).toFixed(2),
                  this.detailData[13],
                  //this.detailData[10],
                  this.minDataArr[this.minDataArr.length-1][3],//1分钟成交量,现在还只取得是上一分钟的量,得跟后台对接一下
                  Number(this.detailData[6]).toFixed(2)
                ]
                if(this.minDataArr[this.minDataArr.length-1][0] != curTime) {
                  this.minDataArr.push(obj);
                }else{
                  this.minDataArr.splice(this.minDataArr.length-1,1,obj);
                }
                _calTradyTime(this.curMarket, this._startTimeSharData);
              }  
            }).catch(error => {

            })
        },
        _startTimeSharData() {
            let types = ''
            this.curMarket == 'hkTrading'? types = 'hk':this.curMarket == 'A-shareTrading'?types = 'hs':types = 'us';
            this.kChart.setOption(initMOption(types,  this.minDataArr, this.minPreClose, this.getQuterType, this.getBgColor));
        },
        //涡轮数据的查询
        _getWarrantQuot() {
            if(!this.sotckCode || this.sotckCode == '') {
                return;
            }
            let params =  {
                "params": {
                    "assetIds": this.sotckCode
                },
                "tester": "ibester"
            }
            getWarrantQuot(
               params
            ).then(res => {
                if(!res.result.data[0].length) {
                    return;
                }
                this.WarrantData =  res.result.data[0];
            }).catch(error => {
                //console.log(error)
            })
        },
    }
};