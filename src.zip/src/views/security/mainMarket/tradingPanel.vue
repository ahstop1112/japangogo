<!--交易面板-->
<template>
  <div class="trading-pannel contentBg">
    <popover :title="curPopoverTitle" @close="closeBuyWrap" :showPopover="showBuy" titleColor="#003da5">
      <div class="buy-wrap" v-if="!isBuySuccess">
        <div class="no-balance messageBgColor" v-if="!isBalance">
          <i class="iconfont icon-detail"></i>{{$t('security.mainMarket.noMoneyExplain')}}
        </div>
        <ul class="buy-info">
          <li class="info-item">
            <span class="tx mediumColor">{{$t('security.mainMarket.market')}}</span>
            <span class="val heavyColor">港股 </span>
          </li>
          <li class="info-item">
            <span class="txt mediumColor">{{$t('security.mainMarket.stock')}}</span>
            <span class="val heavyColor">00665 海通國際 </span>
          </li>
          <li class="info-item">
            <span class="txt mediumColor">{{$t('security.mainMarket.num')}}</span>
            <span class="val heavyColor">3,000</span>
          </li>
          <li class="info-item">
            <span class="txt mediumColor">{{$t('security.mainMarket.price')}}</span>
            <span class="val heavyColor">HKD 2.600</span>
          </li>
          <li class="info-item">
            <span class="txt mediumColor">{{$t('security.mainMarket.tiaojian')}}</span>
            <span class="val heavyColor">不適用</span>
          </li>
          <li class="info-item">
            <span class="txt mediumColor">{{$t('security.mainMarket.expired')}}</span>
            <span class="val heavyColor">即日 </span>
          </li>
          <li class="info-item">
            <span class="txt mediumColor">{{$t('security.mainMarket.aon1')}}</span>
            <span class="val heavyColor">否 </span>
          </li>
          <li class="info-item">
            <span class="txt mediumColor">{{$t('security.mainMarket.tradMoney')}}</span>
            <span class="val heavyColor">HKD 7,800.00</span>
          </li>
          <li class="info-item">
            <span class="txt mediumColor" style="flex: 0 0 210px;">
              {{$t('security.mainMarket.costMoney')}}
              <span class="tip">
                <i class="iconfont icon-detail"></i>
                <el-popover placement="right" :width="curMarket == 'usTrading'?360:220" trigger="click">
                  <!--key -value得从后台取数据-->
                  <div class="list">
                    <span class="icon mediumColor">參考佣金</span>
                    <span class="text heavyColor">HKD 100.00</span>
                  </div>
                  <div class="list">
                    <span class="icon mediumColor">結算費</span>
                    <span class="text heavyColor">HKD 2.00</span>
                  </div>
                  <div class="list">
                    <span class="icon mediumColor">交易徵費</span>
                    <span class="text heavyColor">HKD 0.21</span>
                  </div>
                  <div class="list">
                    <span class="icon mediumColor">厘印費</span>
                    <span class="text heavyColor">HKD 8.00</span>
                  </div>
                  <div class="list">
                    <span class="icon mediumColor">交易費</span>
                    <span class="text heavyColor">HKD 0.39</span>
                  </div>
                  <div class="list">
                    <span class="icon mediumColor">合计</span>
                    <span class="text heavyColor">HKD 110.60</span>
                  </div>
                  <div class="explain lightColor" v-if="curMarket != 'usTrading'">
                    <p class="explain-item">{{$t('security.mainMarket.costExplain')}}</p>
                  </div>
                  <div class="explain lightColor" v-if="curMarket == 'usTrading'">
                    <p class="explain-item">{{$t('security.mainMarket.usExplain1')}}</p>
                    <p class="explain-item" v-html="$t('security.mainMarket.usExplain2')"></p>
                    <p class="explain-item">{{$t('security.mainMarket.usExplain3')}}</p>
                    <p class="explain-item">{{$t('security.mainMarket.usExplain4')}}</p>
                  </div>
                  <span slot="reference" class="txt lightColor">{{$t('security.mainMarket.detail')}}</span>
                </el-popover>
              </span>
            </span>
            <span class="val heavyColor">HKD 110.60</span>
          </li>
          <li class="info-item">
            <span class="txt mediumColor">{{$t('security.mainMarket.totalPrice')}}</span>
            <span class="val heavyColor">USD 7,910.60</span>
          </li>
          <li class="info-item" v-if="curMarket != 'hkTrading'">
            <span class="txt mediumColor">{{$t('security.mainMarket.duiyinzhi')}}</span>
            <span class="val heavyColor">HKD 72,169.23</span>
          </li>
        </ul>
        <div v-if="!isBalance" class="no-balance-btn contentTopBorder">
          <el-button @click="goToRoute('/cash/fundTransfer')">{{$t('security.mainMarket.accountTrans')}}</el-button>
          <el-button @click="goToRoute('/cash/ePayment')" type="primary">{{$t('security.mainMarket.assetInput')}}</el-button>
        </div>
        <div class="password-wrap contentTopBorder" v-if="isBalance">
          <div class="password-content">
            <span class="txt mediumColor">{{$t('security.mainMarket.password')}}</span>
            <span class="val">
              <el-input v-model="password" type="password" :placeholder="$t('security.mainMarket.placeholder')"></el-input>
            </span>
          </div>
          <div class="confirm-btn">
            <el-button type="primary" @click="confirmBuy">{{$t('security.mainMarket.confirm')}}</el-button>
          </div>
        </div>
      </div>
      <div class="succes-wrap" v-if="isBuySuccess">
        <div class="layout-wrap">
          <div class="success-wrap">
            <span class="ico"><i class="iconfont icon-status_success activeFontColor"></i></span>
            <span class="text activeFontColor">{{$t('security.mainMarket.success')}}</span>
          </div>
          <div class="success-info activeFontColor">{{$t('security.mainMarket.sucTip')}}： 80044</div>
        </div>
        <ul class="base-wrap contentTopBorder">
          <li class="info-item">
            <span class="txt mediumColor">{{$t('security.mainMarket.market')}}</span>
            <span class="val heavyColor">港股</span>
          </li>
          <li class="info-item">
            <span class="txt mediumColor">{{$t('security.mainMarket.stock')}}</span>
            <span class="val heavyColor">00665 海通國際</span>
          </li>
          <li class="info-item">
            <span class="txt mediumColor">{{$t('security.mainMarket.num')}}</span>
            <span class="val heavyColor">3,000</span>
          </li>
          <li class="info-item">
            <span class="txt mediumColor">{{$t('security.mainMarket.price')}}</span>
            <span class="val heavyColor">HKD 2.600</span>
          </li>
          <li class="info-item">
            <span class="txt mediumColor">{{$t('security.mainMarket.tradMoney')}}</span>
            <span class="val heavyColor">HKD 7,800.00</span>
          </li>
          <li class="info-item">
            <span class="txt mediumColor">{{$t('security.mainMarket.totalPrice')}}</span>
            <span class="val heavyColor">HKD 7,910.60</span>
          </li>
          <li class="info-item" v-if="curMarket != 'hkTrading'">
            <span class="txt mediumColor">{{$t('security.mainMarket.duiyinzhi')}}</span>
            <span class="val heavyColor">HKD 72,169.23</span>
          </li>
        </ul>
      </div>
    </popover>
    <popover :title="curPopoverTitle" @close="closeSellWrap" :showPopover="showSell" titleColor="#ED8B00">
      <div class="sell-wrap" v-if="!isSellSuccess">
        <ul class="buy-info">
          <li class="info-item">
            <span class="txt mediumColor">{{$t('security.mainMarket.market')}}</span>
            <span class="val heavyColor">港股 </span>
          </li>
          <li class="info-item">
            <span class="txt mediumColor">{{$t('security.mainMarket.stock')}}</span>
            <span class="val heavyColor">00665 海通國際 </span>
          </li>
          <li class="info-item">
            <span class="txt mediumColor">{{$t('security.mainMarket.num')}}</span>
            <span class="val heavyColor">3,000</span>
          </li>
          <li class="info-item">
            <span class="txt mediumColor">{{$t('security.mainMarket.price')}}</span>
            <span class="val heavyColor">HKD 2.600</span>
          </li>
          <li class="info-item">
            <span class="txt mediumColor">{{$t('security.mainMarket.tiaojian')}}</span>
            <span class="val heavyColor">不適用</span>
          </li>
          <li class="info-item">
            <span class="txt mediumColor">{{$t('security.mainMarket.expired')}}</span>
            <span class="val heavyColor">即日 </span>
          </li>
          <li class="info-item">
            <span class="txt mediumColor">{{$t('security.mainMarket.aon1')}}</span>
            <span class="val heavyColor">否 </span>
          </li>
          <li class="info-item">
            <span class="txt mediumColor">{{$t('security.mainMarket.tradMoney')}}</span>
            <span class="val heavyColor">HKD 7,800.00</span>
          </li>
          <li class="info-item">
            <span class="txt mediumColor" style="flex: 0 0 210px;">
              {{$t('security.mainMarket.costMoney')}}
              <span class="tip">
                <i class="iconfont icon-detail"></i>
                <el-popover placement="right" :width="curMarket == 'usTrading'?360:220" trigger="click">
                  <div class="list">
                    <span class="icon mediumColor">參考佣金</span>
                    <span class="text heavyColor">HKD 100.00</span>
                  </div>
                  <div class="list">
                    <span class="icon mediumColor">結算費</span>
                    <span class="text heavyColor">HKD 2.00</span>
                  </div>
                  <div class="list">
                    <span class="icon mediumColor">交易徵費</span>
                    <span class="text heavyColor">HKD 0.21</span>
                  </div>
                  <div class="list">
                    <span class="icon mediumColor">厘印費</span>
                    <span class="text heavyColor">HKD 8.00</span>
                  </div>
                  <div class="list">
                    <span class="icon mediumColor">交易費</span>
                    <span class="text heavyColor">HKD 0.39</span>
                  </div>
                  <div class="list">
                    <span class="icon mediumColor">合计</span>
                    <span class="text heavyColor">HKD 110.60</span>
                  </div>
                  <div class="explain lightColor" v-if="curMarket != 'usTrading'">
                    <p class="explain-item">{{$t('security.mainMarket.costExplain')}}</p>
                  </div>
                  <div class="explain lightColor" v-if="curMarket == 'usTrading'">
                    <p class="explain-item">{{$t('security.mainMarket.usExplain1')}}</p>
                    <p class="explain-item" v-html="$t('security.mainMarket.usExplain2')"></p>
                    <p class="explain-item">{{$t('security.mainMarket.usExplain3')}}</p>
                    <p class="explain-item">{{$t('security.mainMarket.usExplain4')}}</p>
                  </div>
                  <span slot="reference" class="txt lightColor">{{$t('security.mainMarket.detail')}}</span>
                </el-popover>
              </span>
            </span>
            <span class="val heavyColor">HKD 110.60</span>
          </li>
          <li class="info-item">
            <span class="txt mediumColor">{{$t('security.mainMarket.totalPrice')}}</span>
            <span class="val heavyColor">HKD 7,910.60</span>
          </li>
          <li class="info-item" v-if="curMarket != 'hkTrading'">
            <span class="txt mediumColor">{{$t('security.mainMarket.duiyinzhi')}}</span>
            <span class="val heavyColor">HKD 72,169.23</span>
          </li>
        </ul>
        <div class="password-wrap contentTopBorder">
          <div class="password-content">
            <span class="txt mediumColor">{{$t('security.mainMarket.password')}}</span>
            <span class="val">
              <el-input v-model="password" type="password" :placeholder="$t('security.mainMarket.placeholder')"></el-input>
            </span>
          </div>
          <div class="confirm-btn">
            <el-button type="warning" @click="confirmSell">{{$t('security.mainMarket.confirm')}}</el-button>
          </div>
        </div>
      </div>
      <div class="succes-wrap" v-if="isSellSuccess">
        <div class="layout-wrap">
          <div class="success-wrap">
            <span class="ico"><i class="iconfont icon-status_success sellColor"></i></span>
            <span class="text sellColor">{{$t('security.mainMarket.success')}}</span>
          </div>
          <div class="success-info sellColor">{{$t('security.mainMarket.sucTip')}}： 80044</div>
        </div>
        <ul class="base-wrap contentTopBorder">
          <li class="info-item">
            <span class="txt mediumColor">{{$t('security.mainMarket.market')}}</span>
            <span class="val heavyColor">港股</span>
          </li>
          <li class="info-item">
            <span class="txt mediumColor">{{$t('security.mainMarket.stock')}}</span>
            <span class="val heavyColor">00665 海通國際</span>
          </li>
          <li class="info-item">
            <span class="txt mediumColor">{{$t('security.mainMarket.num')}}</span>
            <span class="val heavyColor">3,000</span>
          </li>
          <li class="info-item">
            <span class="txt mediumColor">{{$t('security.mainMarket.price')}}</span>
            <span class="val heavyColor">HKD 2.600</span>
          </li>
          <li class="info-item">
            <span class="txt mediumColor">{{$t('security.mainMarket.tradMoney')}}</span>
            <span class="val heavyColor">HKD 7,800.00</span>
          </li>
          <li class="info-item">
            <span class="txt mediumColor">{{$t('security.mainMarket.totalPrice')}}</span>
            <span class="val heavyColor">HKD 7,910.60</span>
          </li>
          <li class="info-item" v-if="curMarket != 'hkTrading'">
            <span class="txt mediumColor">{{$t('security.mainMarket.duiyinzhi')}}</span>
            <span class="val heavyColor">HKD 72,169.23</span>
          </li>
        </ul>
      </div>
    </popover>
    <div class="trading-content">
      <ul class="trading-wrap">
        <li class="trading-item">
          <span class="text mediumColor">
            <span class="type">{{$t('security.mainMarket.type')}}</span>
            <span class="tip"><i class="iconfont icon-detail"></i></span>
          </span>
          <span class="val">
            <el-select class="trading-type" v-model="type">
              <el-option v-for="item in tradingType" :key="item.value" :label="item.label" :value="item.value">
              </el-option>
            </el-select>
          </span>
        </li>
        <li class="trading-item">
          <span class="text mediumColor">{{$t('security.mainMarket.code')}}</span>
          <span class="val">
            <searchBox :inInput='inInput' :curMarket="curMarket" @handleSelect="handleSelect" isShowInput="true" placeholderVal="00665 海通国际" />
          </span>
        </li>
        <li class="trading-item mediumColor" v-if="type != 2">
          <span class="text">{{$t('security.mainMarket.prc')}}</span>
          <span class="val">
            <el-input-number v-model="price" @change="handleChange1" :step="0.01" :min="0"></el-input-number>
            <el-dropdown class="el-dropdown-anhei" size="medium" trigger="click">
              <span class="el-dropdown-link">
                <i class="el-icon-arrow-down el-icon--right"></i>
              </span>
              <el-dropdown-menu slot="dropdown">
                <el-dropdown-item>{{$t('security.mainMarket.price1')}}</el-dropdown-item>
                <el-dropdown-item v-if="curMarket == 'A-shareTrading'">{{$t('security.mainMarket.price2')}}</el-dropdown-item>
                <el-dropdown-item v-if="curMarket == 'A-shareTrading'">{{$t('security.mainMarket.price3')}}</el-dropdown-item>
              </el-dropdown-menu>
            </el-dropdown>
          </span>
        </li>
        <li class="trading-item mediumColor" v-if="type == 4">
          <span class="text">{{$t('security.mainMarket.condition')}}</span>
          <span class="val">
            <el-select class="trading-type" v-model="condition">
              <el-option :label="$t('security.mainMarket.condition1')" value="up"></el-option>
              <el-option :label="$t('security.mainMarket.condition2')" value="down"></el-option>
            </el-select>
          </span>
        </li>
        <li class="trading-item mediumColor" v-if="type == 4">
          <span class="text">{{$t('security.mainMarket.chufaPrice')}}</span>
          <span class="val">
            <el-input-number v-model="chufaPrice" @change="handleChange1" :step="0.01" :min="0" :disabled="userData.allowTrade === false"></el-input-number>
          </span>
        </li>
        <li class="trading-item mediumColor">
          <span class="text">{{$t('security.mainMarket.nums')}}</span>
          <span class="val">
            <el-input-number v-model="num" @change="handleChange1" :step="100" :min="0"></el-input-number>
            <el-dropdown class="el-dropdown-anhei" size="medium" trigger="click" @command="handleCommand">
              <span class="el-dropdown-link">
                <i class="el-icon-arrow-down el-icon--right"></i>
              </span>
              <el-dropdown-menu slot="dropdown">
                <el-dropdown-item command="a">1/4</el-dropdown-item>
                <el-dropdown-item command="b">1/3</el-dropdown-item>
                <el-dropdown-item command="c">1/2</el-dropdown-item>
                <el-dropdown-item command="d">{{$t('security.mainMarket.whole')}}</el-dropdown-item>
              </el-dropdown-menu>
            </el-dropdown>
          </span>
        </li>
        <li class="trading-item mediumColor" v-if="curMarket == 'A-shareTrading'">
          <span class="text">{{$t('security.mainMarket.custormId')}}</span>
          <span class="val">
            <el-input v-model="custormId"></el-input>
          </span>
        </li>
        <li class="expain">
          <div class="max-buy">
            <span class="txt lightColor">{{$t('security.mainMarket.maxBuy')}}</span>
            <span class="num activeFontColor">3000</span>
          </div>
          <div class="max-sell">
            <span class="txt lightColor">{{$t('security.mainMarket.maxSell')}}</span>
            <span class="num">0</span>
          </div>
        </li>
      </ul>
      <div class="btn-wrap">
        <div class="allOrCancel">
          <el-checkbox v-model="isCancel">{{curMarket == 'usTrading'?$t('security.mainMarket.aon1'):$t('security.mainMarket.aon2')}}</el-checkbox>
        </div>
        <div class="buyOrSell">
          <el-button class="buy" type="primary" @click="openBuyWrap" :class="calcNotClick" :disabled="calcNotClick?true:false">{{$t('security.mainMarket.buys')}}</el-button>
          <el-button class="sell" type="warning" @click="openSellWrap" :class="calcNotClick" :disabled="calcNotClick?true:false">{{$t('security.mainMarket.guchu')}}</el-button>
        </div>
      </div>
      <div class="other-info lightColor">
        <P class="maxMoneyBuy">
          <span class="txt mediumColor">{{$t('security.mainMarket.buyAllMoneyHK')}}(HKD)</span>
          <span class="val heavyColor">505,919,823.77</span>
        </P>
        <P class="maxMoneyBuy">
          <span class="txt mediumColor">{{$t('security.mainMarket.buyAllMoneyHK')}}(CNY)</span>
          <span class="val heavyColor">432,919,823.77</span>
        </P>
      </div>
    </div>
  </div>
</template>

<script>
import popover from "@/components/popover"
import searchBox from '@/components/searchBox'
import { mapGetters } from 'vuex'
export default {
  components: {
    popover,
    searchBox
  },
  watch: {
    getCurStock(val) {
      this.inInput = val.value;
    }
  },
  computed: {
    ...mapGetters(['getCurStock']),
    //根据不同的市场加载不同类型的
    tradingType() {
      let curMarket = this.$route.name;
      let orgArr = [
        {
          label: this.$t('security.mainMarket.type1'),
          value: "1",
          type: "hkTrading,A-shareTrading",//哪些市场可用
        },
        {
          label: this.$t('security.mainMarket.type3'),
          value: "2",
          type: "hkTrading",
        },
        {
          label: this.$t('security.mainMarket.type4'),
          value: "3",
          type: "hkTrading",
        },
        {
          label: this.$t('security.mainMarket.type5'),
          value: "4",
          type: "hkTrading",
        },
        {
          label: this.$t('security.mainMarket.type2'),
          value: "5",
          type: "usTrading",
        }
      ];
      for (let i = orgArr.length - 1; i >= 0; i--) {
        if (orgArr[i].type.indexOf(curMarket) == -1) {
          orgArr.splice(i, 1);
        }
      }
      //默认赋值第一个数
      this.type = orgArr[0].value;
      return orgArr
    },
    calcNotClick() {
      if( this.userData.allowTrade == false){
        return 'notClick'
      }
      if(this.curMarket == 'usTrading' && !this.userData.usTradable) {
        return 'notClick'
      }
    }
  },
  data() {
    return {
      curMarket: "hkTrading",//当前的市场 hkTrading usTrading A-shareTrading
      type: "1",
      code: "00665 海通国际",
      price: '2.600',
      condition: "up",
      chufaPrice: "2.600",
      num: "100",
      custormId: "",
      isCancel: false,
      showBuy: false,
      showSell: false,
      password: "",
      isBalance: true,//true 足够的余额 false不足够
      isBuySuccess: true,//是否买入成功
      isSellSuccess: false,//是否卖出成功
      curPopoverTitle: "",//当前弹出框标题
      inInput: '',//用户选择的信息
      userData: '',
    };

  },
  methods: {
    handleSelect(item) {
      console.log(item);
    },
    goToRoute(path) {
      this.$router.push(path);
      this.$store.commit('changeIsJumpRouter', true);
    },
    confirmBuy() {
      this.isBuySuccess = true;
    },
    confirmSell() {
      this.isSellSuccess = true;
    },
    openBuyWrap() {
      this.getPopoverTitle(this.$t('security.mainMarket.buys'));
      this.showBuy = true;
      this.isBuySuccess = false;
    },
    openSellWrap() {
      this.getPopoverTitle(this.$t('security.mainMarket.guchu'));
      this.showSell = true;
      this.isSellSuccess = false;
    },
    getPopoverTitle(typeName) { //得到当前的弹出框标题
      let dataArr = this.tradingType;
      let type = this.type;
      var curTypeObj = dataArr.filter(function (item) {
        return item.value == type;
      })
      this.curPopoverTitle = typeName + "（" + curTypeObj[0].label + "）";
    },
    closeBuyWrap() {
      this.showBuy = false;
    },
    closeSellWrap() {
      this.showSell = false;
    },
    handleCommand(command) {
      console.log(command)
    },
    handleChange1(val) {
      console.log(val)
    },
    handleChange2(val) {
      console.log(val)
    },
  },
  created() {
    this.userData = JSON.parse(sessionStorage.getItem("userData"));
  },
  mounted() {
    this.curMarket = this.$route.name;
  },
}

</script>
<style lang='scss' scoped>
.trading-pannel {
  width: 100%;
  min-height: 400px;
  .info-item {
    padding: 2px 0;
    display: flex;
    flex-wrap: wrap;
    .txt {
      font-family: SourceHanSansCN-Regular;
      font-size: 1rem;
      flex: 0 0 120px;
    }
    .tip {
      i {
        font-size: 14px;
        color: #9b9b9b;
      }
      .txt {
        font-family: SourceHanSansCN-Medium;
        font-size: 12px;
        text-decoration: underline;
        cursor: pointer;
      }
    }
    .val {
      font-family: SourceHanSansCN-Regular;
      font-size: 1rem;
      flex: 1;
      text-align: right;
      padding-left: 10px;
    }
  }
  .buy-wrap,
  .sell-wrap {
    .no-balance {
      padding: 4px 24px;
      font-family: SourceHanSansCN-Regular;
      font-size: 12px;
      color: #333333;
      line-height: 14px;
      i {
        color: #626262;
        font-size: 12px;
        margin-right: 4px;
      }
    }
    .buy-info {
      padding: 12px 24px;
    }
    .no-balance-btn {
      padding: 48px 24px 24px 24px;
      text-align: right;
    }
    .password-wrap {
      padding: 24px;
      .password-content {
        display: flex;
        align-items: center;
        .txt {
          flex: 0 0 80px;
          padding-right: 10px;
          font-family: SourceHanSansCN-Regular;
          font-size: 1rem;
        }
        .val {
          flex: 1;
        }
      }
      .confirm-btn {
        padding-top: 24px;
        text-align: right;
      }
    }
  }
  .succes-wrap {
    padding: 24px;
    .layout-wrap {
      width: 100%;
      height: 100%;
      padding-bottom: 12px;
      .success-wrap {
        text-align: center;
        span {
          display: block;
        }
        .ico {
          padding: 24px 0;
          i {
            font-size: 58px;
            &.sellColor {
              color: #ed8b00;
            }
          }
        }
        .text {
          font-family: SourceHanSansCN-Medium;
          font-size: 18px;
          &.sellColor {
            color: #ed8b00;
          }
        }
      }
      .success-info {
        padding: 6px 0;
        font-family: SourceHanSansCN-Regular;
        font-size: 14px;
        color: #333333;
        line-height: 16px;
        text-align: center;
        &.sellColor {
          color: #ed8b00;
        }
      }
    }
    .base-wrap {
      padding-top: 12px;
      padding-bottom: 46px;
    }
  }
  .trading-content {
    padding: 24px;
    .trading-wrap {
      .trading-item {
        display: flex;
        flex-wrap: wrap;
        align-items: center;
        padding: 6px 0;
        .text {
          font-family: SourceHanSansCN-Regular;
          font-size: 1rem;
          flex: 0 0 90px;
          .tip {
            cursor: pointer;
            i {
              font-size: 14px;
              color: #9b9b9b;
            }
          }
        }
        .val {
          flex: 1;
          display: flex;
          .trading-type {
            width: 100%;
          }
          .el-input-number {
            width: 100%;
            line-height: 34px;
            flex: 1;
            >>> .el-input .el-input__inner {
              border-radius: 4px 0 0 4px;
            }
          }
          .el-dropdown {
            width: 36px;
            height: 36px;
            border-radius: 0 4px 4px 0;
            border: 1px solid rgba(51, 51, 51, 0.25);
            border-left: none;
            cursor: pointer;
            .el-dropdown-link {
              width: 100%;
              height: 100%;
              line-height: 34px;
              text-align: center;
              .el-icon-arrow-down {
                margin: 0;
              }
            }
          }
        }
      }
      .expain {
        padding: 6px 0;
        font-family: SourceHanSansCN-Normal;
        font-size: 14px;
        display: flex;
        padding-left: 90px;
        .max-buy {
          flex: 1;
        }
        .max-sell {
          flex: 1;
          .num {
            color: #fb6130;
          }
        }
      }
    }
  }
  .btn-wrap {
    padding: 12px 0;
    .buyOrSell {
      display: flex;
      .buy {
        flex: 1;
        margin-right: 12px;
      }
      .notClick {
        background: grey;
        cursor: not-allowed;
        border: none;
      }
      .sell {
        flex: 1;
      }
    }
  }
  .other-info {
    font-family: SourceHanSansCN-Medium;
    font-size: 14px;
    line-height: 16px;
    padding-top: 12px;
    .maxMoneyBuy{
      font-size: 14px;
      padding-bottom: 6px;
      .txt{
        margin-right: 6px;
      }
    }
  }
}
.list {
  width: 100%;
  display: flex;
  flex-wrap: wrap;
  font-family: SourceHanSansCN-Regular;
  font-size: 14px;
  padding-bottom: 4px;
  .icon {
    width: auto;
  }
  .text {
    flex: 1;
    text-align: right;
  }
}
.explain {
  padding-top: 6px;
  font-family: SourceHanSansCN-Normal;
  font-size: 12px;
  line-height: 18px;
}
@media screen and (max-width: 768px) {
  .trading-pannel .trading-content {
    padding: 12px;
  }
  .trading-pannel .trading-content .trading-wrap .expain {
    text-indent: 0;
  }
}
</style>