 <!--股票结存-->
<template>
  <div class="stock-balance contentBg">
    <main-title :title="$t('security.mainMarket.stockPosition')"></main-title>
    <transactionComponent :curMarket="curMarket" :tradType="tradType" :showTradingWrap="showTradingWrap" @closeTradingWrap='closeTradingWrap' />
    <div class="balance-wrap">
      <div class="total-val">
        <div class="market-val">
          <span class="txt mediumColor">{{$t('security.mainMarket.marketVal')}}:</span>
          <span class="val heavyColor">12,144,897.00</span>
        </div>
        <div class="market-val">
          <div class="val-item">
            <span class="txt mediumColor">{{$t('security.mainMarket.profitLoss')}}:</span>
            <span class="val heavyColor">19,692.00</span>
          </div>
          <div class="val-item">
            <span class="txt mediumColor">{{$t('security.mainMarket.profitToday')}}:</span>
            <span class="val heavyColor">-1,185</span>
          </div>
        </div>
      </div>
      <div class="table-wrap">
        <el-table ref="multipleTable" :row-class-name="tableRowClass" :header-cell-style="headeRowClass" :data="tableData">
          <el-table-column fixed width="60" :label="$t('security.mainMarket.action')" v-if="hasAccoutAthu">
            <template slot-scope="scope">
              <span class="num">
                <span class="small-btn small-btn-blue"  @click="openTradingWrap($t('security.mainMarket.buys'),'buy')">{{$t('security.mainMarket.buys')}}</span>
              </span>
              <span class="num">
                <span class="small-btn small-btn-yellow" @click="openTradingWrap($t('security.mainMarket.guchu'),'sell')">{{$t('security.mainMarket.guchu')}}</span>
              </span>
            </template>
          </el-table-column>
          <el-table-column prop="stock" :label="$t('security.mainMarket.stock')">
          </el-table-column>
          <el-table-column prop="price" width="116" align="right">
            <template slot="header">
              <span class="block">{{$t('security.mainMarket.curPrice')}}/</span>
              <span class="block">{{$t('security.mainMarket.costPrice')}}</span>
            </template>
            <template slot-scope="scope">
              <span class="num heavyColor">{{scope.row.price.curPrice}}</span>
              <span class="num heavyColor">{{scope.row.price.costPrice}}</span>
            </template>
          </el-table-column>
          <el-table-column prop="num" width="116" align="right">
            <template slot="header">
              <span class="block">{{$t('security.mainMarket.totalNum')}}/</span>
              <span class="block">{{$t('security.mainMarket.canSellNum')}}</span>
            </template>
            <template slot-scope="scope">
              <span class="num heavyColor">{{scope.row.num.totalNum}}</span>
              <span class="num heavyColor">{{scope.row.num.canSellNum}}</span>
            </template>
          </el-table-column>
          <el-table-column prop="yingkui" align="right" width="116">
            <template slot="header">
              <span class="block">{{$t('security.mainMarket.jinriyingkui')}}/</span>
              <span class="block">{{$t('security.mainMarket.cankaoyingkui')}}</span>
            </template>
            <template slot-scope="scope">
              <span class="num" :class="calcUpDownColor(scope.row.yingkui.jinriyingkui)">{{scope.row.yingkui.jinriyingkui}}</span>
              <span class="num" :class="calcUpDownColor(scope.row.yingkui.cankaoyingkui)">{{scope.row.yingkui.cankaoyingkui}}</span>
            </template>
          </el-table-column>
          <el-table-column prop="val" align="right" width="116">
            <template slot="header">
              <span class="block">{{$t('security.mainMarket.shizhi')}}/</span>
              <span class="block">{{$t('security.mainMarket.ancanzhi')}}</span>
            </template>
            <template slot-scope="scope">
              <span class="num heavyColor">{{scope.row.val.shizhi}}</span>
              <span class="num heavyColor">{{scope.row.val.ancanzhi}}</span>
            </template>
          </el-table-column>
        </el-table>
        <div class="pagination-wrap">
          <el-pagination 
            @current-change="handleCurrentChange" 
            :current-page.sync="curPage" 
            :page-size="1" 
            :hide-on-single-page=true 
            layout="prev, pager, next, jumper" 
            :total="stockArr.length">
          </el-pagination>
        </div>
        <noContent content="无数据" v-show="false" height="360px" width="120" />
      </div>
    </div>
  </div>
</template>

<script>
import mainTitle from '@/components/mainTitle';
import noContent from '@/components/noContent';
import transactionComponent from '@/components/TransactionComponent'
import { setQuterColor } from "@/utils/mixinsQuterColor"
import { mapGetters } from 'vuex'
export default {
  data() {
    return {
      curPage: 1, //当前页
      stockArr: [1, 1],
      showTradingWrap: false,
      tradType: {
        txt: '',//交易名
        code: '',//交易类型
      },
      curMarket: "hkTrading",
      tableData: [
        {
          stock: "211 STYLAND HOLD",
          price: {
            curPrice: "HKD 7.846",
            costPrice: "HKD 6.400"
          },
          num: {
            totalNum: "5000",
            canSellNum: "5000"
          },
          yingkui: {
            jinriyingkui: "-225.00",
            cankaoyingkui: "7230.00"
          },
          val: {
            shizhi: "39,230.00",
            ancanzhi: "0"
          },
        }
      ],
      hasAccoutAthu:true,
      userData: ''
    };
  },
  mixins: [setQuterColor],
  components: {
    mainTitle,
    noContent,
    transactionComponent
  },
  computed: {
    ...mapGetters(['getBgColor']),
    
  },
  methods: {
    calcNotClick() {
      if( this.userData.allowTrade == false){
        this.hasAccoutAthu = false;
      }
      if(this.curMarket == 'usTrading' && !this.userData.usTradable) {
       this.hasAccoutAthu = false;
      }
    },
    tableRowClass() {
      return 'tableRowClass'
    },
    headeRowClass({ row, column, rowIndex, columnIndex }) {
      //表头的背景颜色
      if (rowIndex == 0) {
        if (this.getBgColor == 'bg-anhei') {
          return 'background:rgb(51,51,51)';
        } else {
          return 'background:rgb(255,255,255)';
        }
      }
    },
    openTradingWrap(txt, code) {
      this.tradType.txt = txt;
      this.tradType.code = code;
      this.showTradingWrap = true;
    },
    closeTradingWrap() {
      this.showTradingWrap = false;
    },
    handleCurrentChange(val) {
      console.log(val)
    },
  },
  created() {
    this.userData = JSON.parse(sessionStorage.getItem("userData"));
  },
  mounted() {
    this.$nextTick(() => {
      //更新表格数据的时候执行一下，不然固定列的时候会出现高度不同
      this.$refs.multipleTable.doLayout();
      this.curMarket = this.$route.name;
      this.calcNotClick();
    })
  }
}

</script>
<style lang='scss' scoped>
.stock-balance {
  width: 100%;
  min-height: 580px;
  .balance-wrap {
    width: 100%;
    padding: 12px 24px;
    .total-val {
      padding: 12px 0;
      .market-val {
        padding: 2px 0;
        .val-item {
          display: inline-block;
          margin-right: 12px;
        }
        .txt {
          font-family: SourceHanSansCN-Regular;
          font-size: 1rem;
        }
        .val {
          padding: 0 10px;
          font-family: Avenir-Book;
          font-size: 1rem;
        }
      }
    }
  }
  .table-wrap {
    padding: 12px 0;
    .num {
      display: block;
      padding: 2px 0;
      font-family: Avenir-Book;
      font-size: 1rem;
      .notClick {
        background: grey;
        cursor: not-allowed;
      }
    }
    .pagination-wrap {
      text-align: right;
      padding-bottom: 12px;
      .el-pagination {
        padding: 6px 5px 12px 5px;
      }
    }
  }
}
.block {
  text-align: right;
  height: 16px;
  line-height: 16px;
}
@media screen and (max-width: 768px) {
  .stock-balance .balance-wrap {
    padding: 12px;
  }
  .stock-balance {
    min-height: 350px;
  }
}
</style>