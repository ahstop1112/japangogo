<template>
  <div class="app-wrapper" >
    <div class="draw-bg"  @touchmove.prevent v-if="device == 'mobile' && getDeviceBar" @click="closeDrawBg"></div>
    <div class="app-left" @touchmove.prevent  :class="appLeftClass" @mouseenter="openSideBar" @mouseleave="closeSideBar">   
      <sidebar />
    </div>    
    <div id="appRight" class="app-right"  :class="[getFixedSide?'close-right':'',device=='mobile'?'mobile-right':'']">
      <div class="right-wrap">
        <topbar/>
        <middlebar/>
        <bottombar/>
      </div>
    </div>         
  </div>
</template>

<script>
import { mapGetters } from 'vuex'
import  topbar  from '@/views/_layout/topbar'
import  sidebar  from '@/views/_layout/sidebar/index'
import  middlebar  from '@/views/_layout/middlebar'
import  bottombar  from '@/views/_layout/bottombar'
import { loadThemColor } from '@/utils/loadTheme'
import index from './index.scss'

export default {
  components: {
    topbar, 
    sidebar, 
    middlebar, 
    bottombar
  },
  computed: {
    ...mapGetters(['getSideBar','getDeviceBar','getFixedSide']),
    appLeftClass() { //计算侧边栏的class类
      let className = "";
      if(this.device=='desktop') {
        this.getSideBar?className = '':className = 'open-left';  
      }else{
        this.getDeviceBar?className ='mobile-left-show':className ='mobile-right-show'
      }
      return className;
    }
  },
  data () {
    return {
      device:"",
      timer: null
    };
  },
  methods: {
    //打开侧边栏
    openSideBar() {
      //防止用户在边界多次触发事件
      if(this.timer !== null) {
        clearTimeout(this.timer)
      }
      this.timer = setTimeout( () => {
        this.$store.commit("changeSideBar",false);
      }, 50)
    },
    //隐藏侧边栏
    closeSideBar() {
      //是固定侧边栏
      if(this.getFixedSide || this.device == 'mobile') {
        return;
      }
      this.$store.commit("changeSideBar",true);
    },
    closeDrawBg() {
      this.$store.commit("changeDeviceBar");     
    },
    $_resizeHandler() {
      const rect = document.body.getBoundingClientRect().width;
      rect < 768 ? this.device = 'mobile':this.device = 'desktop';
      //初始化顯示狀態
      if(this.device == 'mobile') {
        this.$store.state.toggleSideBar = false;
      }else{
        //如果用户宽侧边栏下没有设定固定侧边栏，就让侧边栏显示小宽度
        if(!this.getFixedSide) {
          this.$store.state.toggleSideBar = true;
        }
      }
      this.$store.commit("changeDevice", this.device);
    }
  },
  created() {
    let configColor = localStorage.getItem('bgColor') || 'bg-Blue';
    loadThemColor(configColor);
    this.$_resizeHandler();
  },
  beforeMount() {
    window.addEventListener('resize', this.$_resizeHandler)
  },
  beforeDestroy() {
    window.removeEventListener('resize', this.$_resizeHandler);
    //登录页面的加载蓝色背景即可
    let configColor = 'bg-Blue';
    loadThemColor(configColor);
  },
  mounted(){

  }
}

</script>