<template>
  <div class="bottom-wrap ">
    <div class="bottom-content">
      <p class="center">{{ $t('bottomBar.company') }}</p>
      <p class="center">
        <a class="link-info" :href="mianzeUrl" target="_Blank">{{
          $t('bottomBar.mianze')
        }}</a>{{ $t('bottomBar.ji')
        }}<a class="link-info" :href="personUrl" target="_Blank">{{
          $t('bottomBar.pernsonInfo')
        }}</a>
      </p>
      <div class="main-txt" v-if="isShow">
        {{ $t('bottomBar.mianzeInfo') }}
      </div>
    </div>
  </div>
</template>


<script>
import { mapGetters } from 'vuex'
import bottombar from './bottombar.scss'

export default {
  props: {
    isShow: {
      type: Boolean,
      default: true
    }
  },
  computed: {
    ...mapGetters(['getLang'])
  },
  //监听切换语言的动作
  watch: {
    getLang: {
      handler: function (val, n) {
        if (val == 'en_US') {
          this.mianzeUrl = 'http://www.htisec.com/en-us/disclaimers'
          this.personUrl =
            'http://www.htisec.com/sites/all/themes/hitong/files/Data_Privacy_Policy_Sec_EN.pdf'
        } else if (val == 'zh_CN') {
          this.mianzeUrl = 'http://www.htisec.com/en-cn/disclaimers'
          this.personUrl =
            'http://www.htisec.com/sites/all/themes/hitong/files/Data_Privacy_Policy_Sec_SC.pdf'
        } else {
          this.mianzeUrl = 'http://www.htisec.com/zh-hk/disclaimers'
          this.personUrl =
            'http://www.htisec.com/sites/all/themes/hitong/files/Data_Privacy_Policy_Sec_TC.pdf'
        }
      },
      immediate: true
    }
  },
  data() {
    return {
      mianzeUrl: '',
      personUrl: ''
    }
  },
  methods: {},
  mounted() { }
}
</script>