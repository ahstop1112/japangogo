<template>
  <div class="middle-wrap">
    <div class="middle-content" :class="isOtherRouter?'otherPadding':''">
      <router-view :key="key" />
    </div>
    <messageTip :content="$t('security.mainMarket.actionExplain')" v-if="path =='/security/mainMarket/hkTrading'" />
  </div>
</template>

<script>
import messageTip from "@/components/messageTip"
import middlebar from './middlebar.scss'

export default {
  components: {
    messageTip
  },
  watch: {
    $route: {
      handler: function (to, from) {
        this.path = to.path;
        let title = to.name;
        if (title == 'fundTransfer' || title == 'fundWithdrawal') {
          this.isOtherRouter = true;
        } else {
          this.isOtherRouter = false;
        }
      },
      immediate: true
    }
  },
  computed: {
    key() {
      return this.$route.path;
    }
  },
  data() {
    return {
      path: "",
      gutter: 24,
      isOtherRouter: "false",//是否是特殊路由
    };
  },
  methods: {},
  mounted() { }

}

</script>