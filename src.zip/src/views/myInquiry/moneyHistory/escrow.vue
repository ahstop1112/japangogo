<template>
  <!-- 资金提存記錄 -->
  <div class="escrow">
    <div class="escrow-wrap contentBg">
      <div class="conditions">
        <conditionChoose :conditionArr="conditionArr" @btnChoose="btnChoose" />
      </div>
      <div class="escrow-choose">
        <span class="escrow-text mediumColor">{{$t('myInquiry.fundMovement.escrowRecords.date1')}}</span>
        <div class="date-wrap">
          <div class="date-picker">
            <timeSelector :range-separator="$t('myInquiry.myReport.to')" :start-placeholder="$t('myInquiry.myReport.start')" :end-placeholder="$t('myInquiry.myReport.end')" @change="time"></timeSelector>
          </div>
        </div>
      </div>
      <div class="text heavyColor">{{$t('myInquiry.fundMovement.escrowRecords.record')}}</div>
      <div class="escrow-detail">
        <el-table 
          :data="tableData" 
          :row-class-name="tableRowClass"  
          :header-cell-style="headeRowClass"
        style="width: 100%">
          <el-table-column prop="date" width="110" :label="$t('myInquiry.fundMovement.escrowRecords.date2')">
          </el-table-column>
          <el-table-column prop="booked" align="left" width="110" :label="$t('myInquiry.fundMovement.escrowRecords.date3')">
          </el-table-column>
          <el-table-column prop="coding" align="left" width="125" :label="$t('myInquiry.fundMovement.escrowRecords.code1')">
          </el-table-column>
          <el-table-column prop="market" align="left" min-width="130" :label="$t('myInquiry.fundMovement.escrowRecords.market')">
          </el-table-column>
          <el-table-column prop="instructions" align="left" min-width="220" :label="$t('myInquiry.fundMovement.escrowRecords.instructions')">
          </el-table-column>
          <el-table-column prop="number" align="right" min-width="80" :label="$t('myInquiry.fundMovement.escrowRecords.number')">
          </el-table-column>
          <el-table-column prop="currency" align="right" min-width="50" :label="$t('myInquiry.fundMovement.escrowRecords.currency')">
          </el-table-column>
          <el-table-column prop="amount" align="right" :label="$t('myInquiry.fundMovement.escrowRecords.amount')">
          </el-table-column>
        </el-table>
      </div>
    </div>
    <div class="content">
      <div class="title heavyColor">{{$t('myInquiry.fundMovement.escrowRecords.note')}}</div>
      <p class="mediumColor">{{$t('myInquiry.fundMovement.escrowRecords.content')}}</p>
      <p class="mediumColor">{{$t('myInquiry.fundMovement.escrowRecords.content1')}}</p>
    </div>
  </div>
</template>

<script>
import conditionChoose from '@/components/conditionChoose'
import { mapGetters } from 'vuex'
import timeSelector from '@/components/timeSelector'
export default {
  components: {
    conditionChoose,
    timeSelector
  },
  data() {
    return {
      input: '',
      conditionArr: [],
      tableData: [
        {
          date: "2018-06-23",
          booked: "2018-06-23",
          coding: "OS800062455",
          market: "香港，中國A股、美國及場外市場",
          instructions: "Interest Due (2018/11/01-2018/11/30)",
          number: "100",
          currency: "USD",
          amount: "-261.54",
        },
        {
          date: "2018-06-23",
          booked: "2018-06-23",
          coding: "OS800062455",
          market: "香港，中國A股、美國及場外市場",
          instructions: "Interest Due (2018/11/01-2018/11/30)",
          number: "100",
          currency: "USD",
          amount: "-261.54",
        }
      ]
    };
  },
  computed: {
    ...mapGetters(['getLang', 'getBgColor'])
  }, watch: {
    getLang: {
      handler: function (o, n) {
        this.conditionArr = [
          {
            title: this.$t('cash.fxConversion.market'),
            dataArr: [
              {
                name: this.$t('cash.fxConversion.allMarket'),
                code: "allMarket"
              },
              {
                name: this.$t('cash.fxConversion.hkAUSAsotck'),
                code: ""
              },
              {
                name: this.$t('cash.fxConversion.cnBStock'),
                code: ""
              },
              {
                name: this.$t('cash.fxConversion.otherMarket'),
                code: ""
              }
            ]
          }
        ]
      },
      immediate: true
    }
  },
  methods: {
     tableRowClass() {
      return 'tableRowClass'
    },  
    headeRowClass({row, column, rowIndex, columnIndex}) {
       //表头的背景颜色
      if(rowIndex==0){
          if(this.getBgColor == 'bg-anhei') {
            return 'background:rgb(51,51,51)';
          }else{
            return 'background:rgb(255,255,255)';
          }
      }
    },
    btnChoose(resultArr) {
      console.log(resultArr)
    },
    time(t) {
      console.log(t);
      // this.isShowtime = NaN // 当手动修改时间选择器的时候，清除快捷选择的样式
    }
  },
  mounted() { },

}
</script>

<style lang='scss' scoped>
.escrow {
  .escrow-wrap {
    padding: 24px;
    width: 100%;
    >>> .condition-wrap .conditons-item .conditons-content {
      padding-left: 0;
    }
    .escrow-choose {
      display: flex;
      padding: 12px 0;
      flex-wrap: wrap;
      width: 100%;
      .escrow-text {
        flex: 0 0 80px;
        font-family: SourceHanSansCN-Regular;
        font-size: 1rem;
        line-height: 36px;
      }
      .date-wrap {
        display: flex;
        flex: 1;
        flex-wrap: wrap;
      }
    }

    .text {
      font-family: SourceHanSansCN-Regular;
      font-size: 12px;
    }

    .escrow-detail {
      overflow: auto;
      margin: 12px 0;
    }
  }
  .content {
    .title {
      margin: 15px 0;
      font-family: SourceHanSansCN-Medium;
      font-size: 1rem;
    }
    p {
      padding: 3px 0;
      font-family: SourceHanSansCN-Regular;
      font-size: 1rem;
      line-height: 20px;
    }
  }
}
@media screen and (max-width: 768px) {
  .escrow .escrow-wrap {
    padding: 12px;
  }
}
</style>