<!--个人资料(我的设定)-->
<template>
  <div class="changeParticulars">
    <el-row  class="topRow" :gutter=24>
        <el-col class="elCol" :lg="12" :md="12" :sm="24" :xs="24">
          <baseStep  v-if="curState=='baseStep'" @emitEvent = "editorMore"/>
          <detailStep v-if="curState=='detailStep'"  @emitEvent = "backOrNext"/>
        </el-col>  
        <el-col v-if="curState != 'confirmStep'" class="elCol" :lg="12" :md="12" :sm="24" :xs="24">
          <ul class="explain-wrap">
            <li class="explain-item">
              <span class="text mediumColor">{{$t('mySettings.changeParticulars.explian1')}}</span>
            </li>
            <li class="explain-item">
              <span class="text mediumColor">{{$t('mySettings.changeParticulars.explian2')}}</span>
            </li>
            <li class="explain-item">
              <span class="text mediumColor">{{$t('mySettings.changeParticulars.explian3')}}
                <a class="activeFontColor" :href="$t('mySettings.changeParticulars.changeInformationLink')" target="_blank">" {{$t('mySettings.changeParticulars.aLink1')}} "</a>。
              </span>
            </li>
            <li class="explain-item">
              <span class="text mediumColor">{{$t('mySettings.changeParticulars.explian4')}} 
                <a class="activeFontColor" :href="$t('mySettings.changeParticulars.bankFormLink')" target="_blank">" {{$t('mySettings.changeParticulars.aLink2')}} "</a>。
              </span>
            </li>
            <li class="explain-item">
              <span class="text mediumColor">{{$t('mySettings.changeParticulars.explian5')}}</span>
            </li>
            <li class="explain-item ">
              <span class="text red-text">{{$t('mySettings.changeParticulars.explian6')}}</span>
            </li>
            <li class="explain-item ">
              <span class="title heavyColor">{{$t('mySettings.changeParticulars.explian7')}}</span>
            </li>
             <li class="explain-item ">
              <span class="text mediumColor">{{$t('mySettings.changeParticulars.explain8')}}</span>
            </li>
          </ul>
        </el-col>   
    </el-row>
     <confirmStep :backState="backState" @backPrevStep="backPrevStep" v-if="curState=='confirmStep'"/> 
  </div>
</template>

<script>
import baseStep from "./changeParticulars/baseStep"
import detailStep from "./changeParticulars/detailStep"
import confirmStep from "./changeParticulars/confirmStep"
export default {
  data () {
    return {
        curState: "baseStep",//当前进行的修改步骤
        backState:"",
        source:"",
    };
  },
  components: {
    baseStep,
    detailStep,
    confirmStep 
  },
  methods: {
    //确认表单返回上一步
    backPrevStep(state) {  
      this.curState = state;
    },
    //详细表单页面返回或者下一步
    backOrNext(type) {
      if(type == 'back') {
        this.curState = 'baseStep';
      }else{
        this.backState = 'detailStep'
        this.curState = 'confirmStep';
      }
    },
    //基础表单修改更多或者下一步
    editorMore(type) {
      if(type == 'detail') {
        this.curState = 'detailStep';
      }else{
        this.backState = 'baseStep';
        this.curState = 'confirmStep';
      }
    }
  },
  mounted(){
    let params = this.$route.query.source;
    if(params == 'twoFaLogin') {
      this.source = 'twoFaLogin';
      this.curState = 'confirmStep';
      this.backState = "baseStep";
    }
  },
}

</script>
<style lang='scss' scoped>
  .explain-wrap{
    padding: 0 24px;
    .explain-item{
      padding: 4px 0;
      .text{
        font-family: SourceHanSansCN-Regular;
        font-size: 1rem;
        line-height: 20px;
        &.red-text{
          color: #EC3A3A;
          line-height: 27px;
        }
        a{
          font-family: SourceHanSansCN-Medium;
          font-size: 1rem;
          text-decoration: underline;
        }
      }
      .title{
        font-family: SourceHanSansCN-Medium;
        font-size: 18px;
        line-height: 36px;
      }
    }
  }
   @media screen and (max-width: 768px){
      .explain-wrap{
        padding: 24px 12px;
     }
   }
</style>