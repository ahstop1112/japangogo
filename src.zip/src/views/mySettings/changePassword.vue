<!--更改密码(我的设定)-->
<template>
  <div class="changePassword">
    <popover :title="$t('mySettings.changePassword.changePassword')" @close="closePopover" :showPopover = "showPopover">
      <div class="second-wrap"> 
          <div class="success-wrap">
            <span class="icons"><i class="iconfont icon-status_success activeFontColor"></i></span>
            <span class="text activeFontColor">{{$t('mySettings.changePassword.updatePassword')}}</span>
        </div>
      </div>
    </popover>  
    <el-row  class="topRow" :gutter=24>
      <el-col class="elCol" :lg="12" :md="12" :sm="24" :xs="24">
        <div class="left-wrap contentBg">
          <ul class="password-form">
            <li class="form-item">
              <span class="txt mediumColor">{{$t('mySettings.changePassword.oldPassword')}}</span>
              <span class="val">   
                <el-input type="password" v-model="oldPassword" :placeholder="$t('mySettings.changePassword.oldPasswordTip')"></el-input>
              </span>  
            </li>
            <li class="form-item">
              <span class="txt mediumColor">{{$t('mySettings.changePassword.newPassword1')}}</span>
              <span class="val">   
                <el-input type="password" v-model="newPassword1" :placeholder="$t('mySettings.changePassword.newPassword1Tip')"></el-input>
              </span>  
            </li>
            <li class="form-item">
              <span class="txt mediumColor">{{$t('mySettings.changePassword.newPassword2')}}</span>
              <span class="val">   
                <el-input type="password" v-model="newPassword2" :placeholder="$t('mySettings.changePassword.newPassword2Tip')"></el-input>
              </span>  
            </li>
          </ul>
          <div class="btn-wrap">
              <el-button type="primary" @click="openPopover">{{$t('mySettings.changePassword.confirm')}}</el-button>
          </div>
        </div>
      </el-col>
      <el-col  :lg="12" :md="12" :sm="24" :xs="24">
         <div class="explain-wrap">
           <div class="explain-title heavyColor">{{$t('mySettings.changePassword.attention')}}</div>
           <div class="explain-content mediumColor">{{$t('mySettings.changePassword.attentionInfo')}}</div>
          </div>
      </el-col>
    </el-row>  
  </div>
</template>

<script>
import popover from "@/components/popover"
export default {
  data () {
    return {
      oldPassword:"",
      newPassword1: "",
      newPassword2: "",
      showPopover: false,
    };
  },
  components: {
    popover
  },
  methods: {
    openPopover() {
       this.showPopover = true;
    },
       //隐藏弹窗
    closePopover() {
       this.showPopover = false;
    }
  },
  mounted(){},

}

</script>
<style lang='scss' scoped>
  .changePassword{
    width: 100%;
    .left-wrap{
      padding: 24px;
      .password-form{
        .form-item{
          display: flex;
          align-items: center;
          padding: 10px 0;
          .txt{
            flex: 0 0 90px;
            padding-right: 10px;
            font-family: SourceHanSansCN-Regular;
            font-size: 1rem;
            line-height: 20px;
          }
          .val{
            flex: 1;
          }
        }
      }
      .btn-wrap{
        padding: 36px 0;
        text-align: right;
      }
    }
    .explain-wrap{
      font-family: SourceHanSansCN-Regular;
      font-size: 1rem;
      line-height: 20px;
      padding: 24px;
      .explain-title{
        font-family: SourceHanSansCN-Medium;
        font-size: 1rem;
        padding: 12px 0;
      }
    }
    .second-wrap{
      width: 100%;
      height: 100%;    
      padding: 24px;
      .success-wrap{
        text-align: center;
        span{
            display: block;
        }
        .icons{
            padding: 24px 0;
            i{
                font-size: 58px;
            }
        }
        .text{
            font-family: SourceHanSansCN-Medium;
            font-size: 18px;
        }
      }
    }
  }
  @media screen and (max-width: 768px){
     .changePassword .left-wrap{
       padding: 12px;
     }
     .changePassword .explain-wrap{
       padding: 12px;
     }
   }
</style>