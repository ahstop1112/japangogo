<!--投资风险取向问卷书(我的设定)-->
<template>
  <div class="investProfile mediumColor">
    <!-- 没有记录 -->
    <div class="investProfile-wrap" v-if="isShowExisting==0">
      <span class="text heavyColor">{{$t('mySettings.investProfile.info')}}</span>
      <div class="btn">
        <el-button type="primary" @click="toQuestionnaire">{{$t('mySettings.investProfile.input')}}</el-button>
      </div>
    </div>
    <!-- 有记录 -->
    <div class="investProfiles-wrap" v-else-if="isShowExisting==1">
      <span class="text heavyColor">{{$t('mySettings.investProfile.content1')}} <a class="activeTagColor" href="#">{{$t('mySettings.investProfile.content2')}}</a> {{$t('mySettings.investProfile.content3')}}</span>
      <div class="content contentBg">
        <p class="title heavyColor">{{$t('mySettings.investProfile.orientation')}}</p>
        <p>{{$t('mySettings.investProfile.content4')}} <span class="activeFontColor">{{
          userData.riskProfileRecommendedInvestmentStrategyType=='CONSERVATIVE'?'保守':
          userData.riskProfileRecommendedInvestmentStrategyType=='MODRLY_CONSERVATIVE'?$t('mySettings.investProfile.content6'): userData.riskProfileRecommendedInvestmentStrategyType=='MODERAT'?'平稳':userData.riskProfileRecommendedInvestmentStrategyType=='MODRLY_AGGRESSIVE'?'中度进去':userData.riskProfileRecommendedInvestmentStrategyType=='AGGRESSIVE'?'进取':'null'
          }}</span> 。</p>
        <div class="box contentBorder">
          <div class="left">
            <p>{{$t('mySettings.investProfile.content10')}}</p>
            <p>{{$t('mySettings.investProfile.content11')}}</p>
            <p>{{$t('mySettings.investProfile.content12')}}</p>
            <p>{{$t('mySettings.investProfile.content14')}}</p>
          </div>
          <div class="right heavyColor">
            <p>{{userData.riskProfileRating}}</p>
            <p>{{$t('mySettings.investProfile.content6')}}</p>
            <p>{{userData.riskProfileExpiryDate}}</p>
            <p>{{$t('mySettings.investProfile.content16')}}</p>
          </div>
        </div>
        <p class="title heavyColor" v-if="userData.withKnowledgeOnOtcDerivatives=='N'">{{$t('mySettings.investProfile.assessment')}}</p>
        <p v-if="userData.withKnowledgeOnOtcDerivatives=='N'">{{$t('mySettings.investProfile.content17')}} <span class="activeFontColor">{{$t('mySettings.investProfile.content18')}}</span> 。</p>
      </div>
    </div>
    <!-- 处理中 -->
    <div class="processing" v-else-if="isShowExisting==2">
      <span class="text heavyColor">{{$t('mySettings.investProfile.chuli')}}</span>
      <div class="content">
        <p class="title heavyColor">{{$t('mySettings.investProfile.orientation')}}</p>
        <p></p>
        <div class="box contentBorder">
          <span>N/A</span>
        </div>
        <p class="title heavyColor">{{$t('mySettings.investProfile.assessment')}}</p>
        <span>N/A</span>
      </div>
    </div>
  </div>

</template>

<script>
export default {
  data() {
    return {
      isShowExisting: 0,
      userData: '',
    };
  },
  methods: {
    toQuestionnaire() {
      let accountProfiles = this.userData.accountProfiles
      for (let i = 0; i < accountProfiles.length; i++) {
        if (accountProfiles[i].subAccountType == "INDIVIDUAL") {
          // 新窗口打开个人问卷
          let questionnaire = this.$router.resolve({ path: '/mySettings/personalQuestionnaire' })
          window.open(questionnaire.href, '_blank')
        } else if (accountProfiles[i].subAccountType == "CORPORATE") {
          // 新窗口打开个人问卷
          let questionnaire = this.$router.resolve({ path: '/mySettings/companyQuestionnaire' })
          window.open(questionnaire.href, '_blank')
        }
        return
      }

    }
  },
  created() {
    this.userData = JSON.parse(sessionStorage.getItem("userData"));
  },
  mounted() {
    let accountProfiles = this.userData.accountProfiles
    for (let i = 0; i < accountProfiles.length; i++) {
      if (accountProfiles[i].subAccountType == "JOINT" || accountProfiles[i].entityRole == "TPA" || accountProfiles[i].entityRole == "AP") {
        this.isShowExisting = 1
      } else {
        this.isShowExisting = 0
      }
      return
    }
  },
}

</script>
<style lang='scss' scoped>
.investProfile {
  font-family: SourceHanSansCN-Regular;
  font-size: 1rem;
  .content {
    padding: 0px 12px 24px 12px;
    margin-top: 12px;
    .title {
      font-family: SourceHanSansCN-Medium;
      font-size: 18px;
      line-height: 60px;
    }
  }
  .investProfile-wrap {
    padding-top: 150px;
    text-align: center;
    .text {
      font-family: SourceHanSansCN-Regular;
      font-size: 1rem;
    }
    .btn {
      margin-top: 40px;
    }
  }
  .investProfiles-wrap {
    .text {
      a {
        font-family: SourceHanSansCN-Medium;
        line-height: 12px;
      }
    }
    .box {
      display: flex;
      padding: 30px 0 15px 0;
      .left {
        margin-right: 15px;
      }
    }
  }
  .processing {
    .box {
      display: flex;
      padding-bottom: 15px;
    }
  }
}
</style>