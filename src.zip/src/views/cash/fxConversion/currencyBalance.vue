<template>
   <div class="balance-wrap contentBg">
      <div class="market-choose">
         <conditionChoose :conditionArr="conditionArr" @btnChoose ="btnChoose"/>
      </div>
      <div class="market-detail">
        <el-table
          :data="tableData"
          :row-class-name="tableRowClass"  
          :header-cell-style="headeRowClass"
          style="width: 100%">
          <el-table-column
            fixed
            prop="date"
            width="110"
           >
          </el-table-column>
          <el-table-column
            prop="HKD"
            align="right"
            label="HKD">
          </el-table-column>
          <el-table-column
            prop="CNY"
            align="right"
            label="CNY">
          </el-table-column>
          <el-table-column
            prop="USD"
            align="right"
            label="USD">
          </el-table-column>
          <el-table-column
            prop="AUD"
            align="right"
            label="AUD">
          </el-table-column>
          <el-table-column
            prop="JPY"
            align="right"
            label="JPY">
          </el-table-column>
           <el-table-column
            prop="NZD"
            align="right"
            label="NZD">
          </el-table-column>
           <el-table-column
            prop="CAD"
            align="right"
            label="CAD">
          </el-table-column>
           <el-table-column
            prop="CHF"
            align="right"
            label="CHF">
          </el-table-column>
           <el-table-column
            prop="GBP"
            align="right"
            label="GBP">
          </el-table-column>
           <el-table-column
            prop="EUG"
            align="right"
            label="EUG">
          </el-table-column>
           <el-table-column
            prop="SGD"
            align="right"
            label="SGD">
          </el-table-column>
        </el-table>    
      </div>
    </div>
</template>

<script>
import conditionChoose from '@/components/conditionChoose'
import {mapGetters} from 'vuex'
export default {
  components: {
    conditionChoose
  },
  computed: {
    ...mapGetters(['getLang', 'getBgColor'])
  },
  watch: {
    getLang: {
      handler:function(o,n){
        this.conditionArr = [
          {
            title: this.$t('cash.fxConversion.market'),
            dataArr: [
                {
                    name: this.$t('cash.fxConversion.allMarket'),
                    code: "allMarket"      
                },
                {
                    name: this.$t('cash.fxConversion.hkAUSAsotck'),
                    code: ""      
                },
                {
                    name: this.$t('cash.fxConversion.cnBStock'),
                    code: ""      
                },
                {
                    name: this.$t('cash.fxConversion.otherMarket'),
                    code: ""      
                }
            ]
          }
        ]
      },
      immediate: true
    }
  },
  data () {
    return {
        conditionArr: [],
        tableData: [
            {
            date: "2018-06-23",
            HKD: "1,083,585.32",
            CNY: "61,747.90",
            USD: "-500",
            AUD:"-",
            JPY:"-",
            NZD:"-",
            CAD:"-",
            CHF:"-",
            GBP:"-",
            EUR:"-",
            SGD:"-"
            },
            {
            date: "2018-06-23",
            HKD: "1,083,585.32",
            CNY: "61,747.90",
            USD: "-500",
            AUD:"-",
            JPY:"-",
            NZD:"-",
            CAD:"-",
            CHF:"-",
            GBP:"-",
            EUR:"-",
            SGD:"-"
            }
        ]
    };
  },
  methods: {
    btnChoose(resultArr) {
      console.log(resultArr)  
    },  
    tableRowClass() {
      return 'tableRowClass'
    },  
    headeRowClass({row, column, rowIndex, columnIndex}) {
       //表头的背景颜色
      if(rowIndex==0){
          if(this.getBgColor == 'bg-anhei') {
            return 'background:rgb(51,51,51)';
          }else{
            return 'background:rgb(255,255,255)';
          }
      }
    },
  },
  mounted(){},

}

</script>
<style lang='scss' scoped>
    .balance-wrap{
        width: 100%;
        padding: 24px;
        .market-detail{
            margin-top: 24px;
        }
    }
     @media screen and (max-width: 768px){
         .balance-wrap .market-choose .market-info .market-item{
             margin-right: 12px;
         }
         .balance-wrap{
             padding: 12px;
         }
     }
</style>