<template>
  <!-- 申请资讯 -->
  <div class="information contentBg heavyColor">
    <h3>{{ $t('cash.remittanceServices.icbc') }}</h3>
    <h4>{{ $t('cash.remittanceServices.methods') }}</h4>
    <p>{{ $t('cash.remittanceServices.content2') }}</p>
    <p>{{ $t('cash.remittanceServices.content3') }}</p>
    <p>
      {{ $t('cash.remittanceServices.content4') }}
    </p>
    <p>{{ $t('cash.remittanceServices.content5') }}</p>
    <p>{{ $t('cash.remittanceServices.content6') }}</p>
    <p>
      {{ $t('cash.remittanceServices.content7') }}
    </p>
    <h4>{{ $t('cash.remittanceServices.remittance') }}</h4>
    <p>
      {{ $t('cash.remittanceServices.content8') }}
    </p>
    <p>
      {{ $t('cash.remittanceServices.content9') }}
    </p>
    <p>{{ $t('cash.remittanceServices.content10') }}</p>
    <p>{{ $t('cash.remittanceServices.content11') }}</p>
    <p>
      {{ $t('cash.remittanceServices.content12') }}
    </p>
    <p>{{ $t('cash.remittanceServices.content13') }}</p>
    <h4>{{ $t('cash.remittanceServices.attention') }}</h4>
    <p>{{ $t('cash.remittanceServices.content14') }}</p>
    <p>{{ $t('cash.remittanceServices.content15') }}</p>
    <p>{{ $t('cash.remittanceServices.content16') }}</p>
    <hr />
    <h3>{{ $t('cash.remittanceServices.boc') }}</h3>
    <p>
      {{ $t('cash.remittanceServices.content17') }}
    </p>
    <h4>{{ $t('cash.remittanceServices.methods2') }}</h4>
    <p>{{ $t('cash.remittanceServices.content18') }}</p>
    <p>{{ $t('cash.remittanceServices.content19') }}</p>
    <p>
      {{ $t('cash.remittanceServices.content20') }}
    </p>
    <p>{{ $t('cash.remittanceServices.content21') }}</p>
    <p>{{ $t('cash.remittanceServices.content22') }}</p>
    <p>
      {{ $t('cash.remittanceServices.content23') }}
    </p>
    <h4>{{ $t('cash.remittanceServices.remittance2') }}</h4>
    <p>
      {{ $t('cash.remittanceServices.content24') }}
    </p>
    <p>
      {{ $t('cash.remittanceServices.content25') }}
    </p>
    <p>{{ $t('cash.remittanceServices.content26') }}</p>
    <p>{{ $t('cash.remittanceServices.content27') }}</p>
    <p>
      {{ $t('cash.remittanceServices.content28') }}
    </p>
    <p>{{ $t('cash.remittanceServices.content29') }}</p>
    <h4>{{ $t('cash.remittanceServices.attention2') }}</h4>
    <p>{{ $t('cash.remittanceServices.content30') }}</p>
    <p>{{ $t('cash.remittanceServices.content31') }}</p>
    <p>{{ $t('cash.remittanceServices.content32') }}</p>
    <hr />
    <h3>{{ $t('cash.remittanceServices.dahSing') }}</h3>
    <p>
      {{ $t('cash.remittanceServices.content33') }}
    </p>
    <h4>{{ $t('cash.remittanceServices.methods2') }}</h4>
    <p v-html="$t('cash.remittanceServices.content34')"></p>
    <p>
      {{ $t('cash.remittanceServices.content35') }}
    </p>
    <p>
      {{ $t('cash.remittanceServices.content36') }}
    </p>
    <p>{{ $t('cash.remittanceServices.content37') }}</p>
    <p>{{ $t('cash.remittanceServices.content38') }}</p>

    <h4>{{ $t('cash.remittanceServices.attention3') }}</h4>
    <p>{{ $t('cash.remittanceServices.content39') }}</p>
    <p>{{ $t('cash.remittanceServices.content40') }}</p>
    <p>{{ $t('cash.remittanceServices.content41') }}</p>
    <p>{{ $t('cash.remittanceServices.content42') }}</p>
  </div>
</template>

<script>
export default {

}
</script>

<style lang="scss" scoped>
.information {
  padding: 24px;
  padding-top: 1px;
  width: 100%;
  height: 100%;
  h3 {
    font-family: SourceHanSansCN-Medium;
    font-size: 20px;
    letter-spacing: 0;
    line-height: 20px;
    font-weight: 550;
  }
  h4 {
    font-family: SourceHanSansCN-Medium;
    height: 5px;
    font-size: 1rem;
    letter-spacing: 0;
    line-height: 20px;
  }
  p {
    font-family: SourceHanSansCN-Regular;
    font-size: 1rem;
    letter-spacing: 0;
    line-height: 23px;
  }
}
@media screen and (max-width: 768px) {
  .information {
    padding: 1px 12px 12px 12px;
  }
}
</style>