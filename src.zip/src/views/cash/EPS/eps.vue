<!--
 * @Author: your name
 * @Date: 2020-11-05 15:18:25
 * @LastEditTime: 2021-01-27 11:50:36
 * @LastEditors: your name
 * @Description: In User Settings Edit
 * @FilePath: \new-web-trading\src\views\cash\EPS\eps.vue
-->
<template>
  <!-- 易办事页面 -->
  <div class="eps">
    <img v-if="command == 'en_US'" src="@/assets/img/banner_EPS_EN.png" alt="" />
    <img v-else-if="command == 'zhTW'" src="@/assets/img/banner_EPS_TC.png" alt="" />
    <img v-else src="@/assets/img/banner_EPS_SC.png" alt="" />
    <div class="content contentBg">
      <p class="mediumColor">
        {{$t('cash.ePayment.eps.content1')}}
      </p>
      <p class="mediumColor">
        {{$t('cash.ePayment.eps.content2')}}
      </p>
      <p class="mediumColor">{{$t('cash.ePayment.eps.content3')}}</p>
      <el-button type="primary" @click="$router.go(-1)">{{$t('cash.ePayment.eps.btn')}}</el-button>
    </div>
  </div>

</template>

<script>
import * as event from "@/utils/EventEmitter.js"
import { localGet } from '@/utils/mylocal.js'
export default {
  data() {
    return {
      // 切换语言的值
      command: '',
    }
  },
  mounted() {
    event.addListener('langChange', this.onCommand)
    this.command = localGet('lang') || 'zhTW'
  },
  methods: {
    onCommand(command) {
      this.command = command
    }
  }
}
</script>

<style lang="scss" scoped>
.eps {
  img {
    display: block;
    width: 100%;
    height: 100%;
  }
  .content {
    margin-top: 24px;
    padding: 27px 24px 140px;
    @media screen and (max-width: 1140px) {
      padding-bottom: 140px;
    }
    p {
      margin-top: 10px;
      font-family: SourceHanSansCN-Regular;
      font-size: 1rem;
      letter-spacing: 0;
      line-height: 20px;
    }
    .el-button {
      display: block;
      margin: 75px auto 0px;
      text-align: center;
      width: 80px;
      height: 40px;
      background-color: #003da5;
      border: #003da5;
      font-family: SourceHanSansCN-Bold;
      font-size: 1rem;
      color: #ffffff;
      letter-spacing: 0;
      line-height: 16px;
    }
  }
}
</style>