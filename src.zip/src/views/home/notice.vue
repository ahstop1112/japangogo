<!--主页(通知)-->
<template>
  <div class="notice-wrap contentBg">
    <mainTitle :title="$t('home.notice.title')">
      <span class="more lightColor hoverFontColor" @click="toMoreNotice">{{
        $t('home.notice.more')
      }}</span>
    </mainTitle>
    <ul class="notice-content">
      <li class="notice-item contentBorder hoverBgColor">
        <div class="notice-title">
          <span class="title heavyColor">有關部分海外郵寄結單服務延遲通知</span>
          <span class="time lightColor">2019-06-27</span>
        </div>
        <div class="notice-text mediumColor">
          根據相關郵政局2020年3月27日通告，部分地區的海外郵政服務已經暫停使用啥的經暫停使用啥的經暫停使用啥的
        </div>
      </li>
      <li class="notice-item contentBorder hoverBgColor">
        <div class="notice-title">
          <span class="title heavyColor ">美股交易孖展利率低至P+2.5%*</span>
          <span class="time lightColor">2019-06-27</span>
        </div>
        <div class="notice-text mediumColor">
          由2019年03月22日起，經海通國際交易美股，可享孖展利率低至P+2.5
        </div>
      </li>
      <li class="notice-item contentBorder hoverBgColor">
        <div class="notice-title">
          <span class="title heavyColor">美股交易孖展利率低至P+2.5%*</span>
          <span class="time lightColor">2019-06-27</span>
        </div>
        <div class="notice-text mediumColor">
          由2019年03月22日起，經海通國際交易美股，可享孖展利率低至P+2.5
        </div>
      </li>
    </ul>
    <noContent v-if="false" height="320px" :content="$t('home.notice.noResult')" />
  </div>
</template>

<script>
import mainTitle from '@/components/mainTitle'
import noContent from '@/components/noContent'
import notice from './notice.scss'

export default {
  data() {
    return {}
  },
  components: {
    mainTitle,
    noContent
  },
  methods: {
    toMoreNotice() {
      let routeMoreNotice = this.$router.resolve({
        path: '/moreNotice'
      })
      window.open(routeMoreNotice.href, '_blank');
    },
  },
  mounted() { }
}
</script>