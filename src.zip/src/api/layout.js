import { myhttp } from '@/utils/request'

// 用户退出登录api
export function exitLoginApi (data) {
  return myhttp({
    url: '/api/user/log/logout',
    data,
    needToken: false
  })
}

// 修改密码api
export function changePasswordApi (data) {
  return myhttp({
    url: '/api/user/changePassword',
    method: 'post',
    data,
    needToken: true
  })
}

// 保留现有密码api
export function keepPasswordApi (data) {
  return myhttp({
    url: '/api/user/keepPassword',
    method: 'post',
    data,
    needToken: true
  })
}
