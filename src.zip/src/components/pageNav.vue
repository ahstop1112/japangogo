<!--页面顶部导航组件-->
<template>
    <div class="router-wrap contentBg">
      <el-scrollbar style="height:100%;padding-bottom:6px">
        <span class="router-item" v-for="(item,index) in routerArr" :key="index" >
            <router-link active-class="activeColor" class="lightColor" tag="a" :to="{name: item.path}" exac>
                <img :src="item.img"  v-if="item.img"/>
                <span class="txt">{{item.name}}</span>
            </router-link>
        </span>       
      </el-scrollbar>   
    </div>
</template>

<script>
export default {
  props: {
    routerArr: {},    //对象数组 @params 如 img require("@/assets/img/flag_HK@2x.png"), name:"港股交易",path:"hkTrading"
  },  
  data () {
    return {
        
    };
  },
  methods: {},
  mounted(){},

}

</script>
<style lang='scss' scoped>
    .router-wrap{
        width: 100%;
        height: 48px;
        white-space:nowrap;  
        padding-right: 24px;
         >>> .el-scrollbar__wrap{
            overflow-x:auto;
        }
        .router-item{
            display: inline-block;
            padding-left: 24px;
            a{
                display: inline-block;
                font-family: SourceHanSansCN-Medium;
                font-size: 20px;
                height: 42px;
                line-height: 42px;
                img{
                    width: 18px;
                }
            }
        }
    }
    @media screen and (max-width: 768px){
     .router-wrap{
        padding-right: 12px;
     }
     .router-wrap .router-item{
        padding-left: 12px;
     }
   }
</style>