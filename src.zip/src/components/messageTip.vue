<template>
    <div class="message-content messageBgColor">
      {{content}}
    </div>
</template>

<script>
export default {
  props: {
    content: ""
  },  
  data () {
    return {
    };
  },
  methods: {},
  mounted(){},

}

</script>
<style lang='scss' scoped>
    .message-content{
       width: 100%; 
       font-family: SourceHanSansCN-Regular;
       font-size: 12px;
       padding: 10px 20px;
       letter-spacing: 0;
       line-height: 14px; 
       color: #333;
    }
    @media screen and (max-width: 768px){
    .message-content{
      padding: 10px;
    }
  }
</style>