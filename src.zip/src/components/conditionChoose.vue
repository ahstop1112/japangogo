<!--条件选择组件-->
<template>
  <div class="condition-wrap">
      <ul class="selection-conditons">
          <li class="conditons-item" :key="index" v-for="(item,index) in conditionArr">
              <div class="conditons-title">
                  <span class="text mediumColor">{{item.title}}</span>
              </div>
              <div class="conditons-content">
                  <span class="text heavyColor"
                        :key="btnIndex" 
                        :class="btnIndex == 0?'active': ''"
                        v-for="(btnInfo,btnIndex) in item.dataArr" 
                        @click="chooseBtnItem($event,index,btnInfo)">
                        {{btnInfo.name}}
                  </span>
              </div>
          </li>
      </ul>
  </div>
</template>

<script>
export default {
  props: {
      conditionArr: {}//传入一个对象数组
  },  
  data () {
    return {
        resultArr: [],//传出一个选中的数组        
    };
  },
  methods: {
      chooseBtnItem(evt,index,btnInfo) {
          let obj = evt.currentTarget;
          let siblingsObj = obj.parentNode.children;
          for(let i=0; i<siblingsObj.length; i++ ){
             siblingsObj[i].className ='text heavyColor';
          }  
          obj.className='text heavyColor active';
          this.resultArr.splice(index,1,btnInfo);
          //返回每一个选择行的选中结果
          this.$emit('btnChoose',this.resultArr);
      }
  },
  mounted(){
    if(!this.conditionArr.length)  {
        return;
    }
    for(let i=0;i<this.conditionArr.length;i++) {
        //默认每项的第一列为选中的结果
        this.resultArr.push(this.conditionArr[i].dataArr[0])
    }
  },
}

</script>
<style lang='scss' scoped>
    .condition-wrap{
        width: 100%;

        .conditons-item{
            width: 100%;
            display: flex;
            padding: 6px 0;
            .conditons-title{
                flex: 0 0 80px;
                .text{
                    font-family: SourceHanSansCN-Regular;
                    font-size: 1rem;
                    line-height: 20px;
                }
            }

            .conditons-content{
                flex: 1;
                padding-left: 12px;
                display: flex;

                .text{
                    flex: 0 0 auto;
                    font-size: 1rem;
                    line-height: 24px;
                    cursor: pointer;
                    padding: 0 6px;
                    margin-right: 4px;
                    margin-bottom: 6px;

                    &.active{
                        color: #fff;
                        background: #003DA5;
                        border-radius: 4px;
                    }
                }
            }
        }
    }
</style>