<!--交易组件-->
<template>
    <popover :title="titleName" @close="closeTradingWrap" :showPopover = "showTradingWrap" :titleColor="titleColor">
        <orderPannel 
            v-show="curStep =='order'" 
            :curMarket ="curMarket"
            :orderType = "tradType.code" 
            @goToNextStep ="goToNextStep"
        />
        <confirmPannel 
            v-show="curStep == 'confirm'" 
            :orderType = "stepType" 
            :curMarket ="curMarket"
            @backNextStep = "backNextStep" 
            @goToLastStep = "goToLastStep"
        />
        <successPannel 
            v-show="curStep == 'success'"  
            :orderType = "stepType"
        />
    </popover>    
</template>

<script>
import popover from "@/components/popover"
import orderPannel from './orderPannel'
import confirmPannel from './confirmPannel'
import successPannel from './successPannel'
export default {
  props: {
      showTradingWrap: false,//是否显示或者隐藏
      tradType: {},//买入 沽出  买/卖 {code:'',txt:''} 控制下单页面的显示
      curMarket:"",//当前市场  hkTrading usTrading A-shareTrading
  }, 
  data () {
    return {
        curStep:"order", //order,confirm,success
        stepType:'',//下一步的类型(买 或者 卖),只有在第一步的时候会去显示用户传入的买卖值
    };
  },
  watch: {
    showTradingWrap() {
        //根据弹窗显示隐藏去设置它的初始化显示类型
        this.stepType = this.tradType.code;
    }
  },
  computed: {  
    titleName() {
        if(this.stepType == 'sell') {
            return this.$t('security.mainMarket.guchu'); 
        }else if(this.stepType == 'buy'){
            return this.$t('security.mainMarket.buys');    
        }else{
            return this.tradType.txt;
        }   
    }, 
    titleColor() {
        if(this.stepType == 'sell') {
            return '#ED8B00';     
        }else{
            return '#003da5';
        }    
    }
  },
  components: {
    popover,
    orderPannel,
    confirmPannel,
    successPannel
  },
  methods: {  
    goToNextStep(type) { //当前的买卖类型
        this.stepType = type;
        this.curStep = 'confirm';
    },  
    backNextStep(type) {
        this.stepType = this.tradType.code;
        this.curStep = 'order';
    },
    goToLastStep(type) {
        this.curStep = 'success';
    },
    closeTradingWrap() {
        setTimeout( () => {
            this.curStep = 'order';  
        }, 500)
        this.$emit('closeTradingWrap');
    }
  }
}

</script>
<style lang='scss' scoped>

</style>