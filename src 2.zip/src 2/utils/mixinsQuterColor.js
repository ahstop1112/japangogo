//设置股票红涨绿跌还是绿涨红跌
import { mapGetters } from 'vuex'

export const setQuterColor = {
    computed: {
        ...mapGetters(['getQuterType']),
    },
    methods: {
        //type 代表是否设置的是背景还是文字颜色
        calcUpDownColor(val, type) { 
          //设置红涨绿跌
          if(type == 'bg') {
             if(val > 0 ) {
              return this.getQuterType == 1?'greenUpBg':'redUpBg'
            }
            else if(val < 0) {
              return this.getQuterType == 1?'greenDownBg':'redDownBg'
            }
            else{
              return 'grayBg'
            }
          }else{
            if(val > 0 ) {
              return this.getQuterType == 1?'greenUpColor':'redUpColor'
            }
            else if(val < 0) {
              return this.getQuterType == 1?'greenDownColor':'redDownColor'
            }
            else{
              return 'grayColor'
            }
          }
        }
    }    
}