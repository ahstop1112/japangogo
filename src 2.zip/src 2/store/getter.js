const getters = {
  getCurrentTitle: state => state.currentTitle,
  getBgColor: state => state.bgColor,
  getSideBar: state => state.toggleSideBar,
  getDeviceBar: state => state.deviceSidebar,
  getDevice: state => state.device,
  getLang: state => state.lang,
  getFixedSide: state => state.fixedSide,
  getIsJumpRouter: state => state.isJumpRouter,
  getCurStock: state => state.curStock,
  getUpdateSelfStock: state => state.updateSelfStock,
  // userData: state => state.user_data,
  getQuterType: state => state.quterType,
  getActiveAccountId: state => state.activeAccountId,
}
export default getters
