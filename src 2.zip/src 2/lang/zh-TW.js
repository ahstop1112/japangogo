export default {
  //返回旧版
  asideBottom: {
    old: '返回',
    Version: '舊版'
  },
  //侧边菜单栏
  menuList: {
    home: {
      level1: '主頁',
      level1_1: '主頁'
    },
    trad: {
      level1: '證券交易',
      level1_1: '證券',
      level2_1: '港A美股',
      level2_2: '其它市場',
      level2_3: '新股認購',
      level2_4: '公司行動',
      level2_5: '按倉比率'
    },
    control: {
      level1: '資金管理',
      level1_1: '資金',
      level2_1: '貨幣兌換',
      level2_2: '賬戶轉賬',
      level2_3: '資金提取',
      level2_4: '資金存入',
      level2_5: '匯款服務'
    },
    query: {
      level1: '我的查詢',
      level1_1: '查詢',
      level2_1: '我的資產',
      level2_2: '交易記錄',
      level2_3: '資金記錄',
      level2_4: '證券提存',
      level2_5: '我的結單',
      level2_6: '我的報表'
    },
    seting: {
      level1: '我的設定',
      level1_1: '設定',
      level2_1: '個人資料',
      level2_2: '更改密碼',
      level2_3: '密碼確認',
      level2_4: '更改信貸額',
      level2_5: '投資風險取向問卷',
      level2_6: '中華通北向交易同意書'
    }
  },
  //顶部导航栏
  topBar: {
    account: '戶名',
    loginOut: '登出',
    userID: '账号',
    checkSetting: '检查我的电脑设定',
    backOld: '返回舊版系統',
    middleman: '經紀人',
    telphone: '直線電話',
    blue: '海通藍',
    yellow: '貴金色',
    huBlue: '寶石色',
    anhei: '暗黑色',
    notice: '通知',
    contact: '聯絡我們',
    help: '幫助中心',
    color: '主題色',
    quoteColor: '行情漲跌顏色',
    greenUpColor: '綠漲紅跌',
    redUpColor: '紅漲綠跌',
    tishi: '您確定是否退出登錄?',
    confirm: '確定',
    cancel: '取消'
  },
  //底部版权信息
  bottomBar: {
    company: '©2020海通國際證券集團',
    mianze: '免責聲明',
    pernsonInfo: '個人資料私隱政策',
    ji: '及',
    mianzeInfo:
      '免責聲明：海通國際證券有限公司、海通國際電子網上服務有限公司、香港交易所資訊服務有限公司、香港聯合交易所有限公司及香港期貨交易所有限公司及其資料供應商、上海證券交易所及深圳證券交易所盡力確保所提供之資料準確及可靠，但不保證該等資料之準確性或可靠性，亦不對任何因資料不確或遺漏所引致之損失或損害承擔任何責任(不論是民事侵權行為責任或合約責任或其他責任)。證券交易平台之內容、新聞及資訊版權均屬服務供應商所有，不得向任何人作任何用途之複製、篡改、發佈、發行、散播、宣傳、廣播或以其它形式傳播。'
  },
  //主页
  home: {
    //我的资产
    asset: {
      title: '我的資產',
      total: '合計',
      account: '戶口結存',
      available: '可用結存',
      cashTotal: '現金結存',
      purchPower: '購買力',
      stockVal: '證券市值',
      stockHasVal: '證券按倉值',
      explain: '*兌換率(只作參考，最後更新時間',
      cash: '現金',
      aStock: 'A股',
      hkStock: '港股',
      usStock: '美股',
      outsideStock: '場外交易',
      oneMonth: '近一月',
      threeMonth: '近三月',
      halfOfYear: '近半年',
      oneYear: '近一年',
      twoYear: '近兩年',
      money: '參考盈虧',
      percent: '盈虧比例'
    },
    //常用功能
    commonFunc: {
      title: '常用功能',
      tradHistory: '交易記錄',
      stockPush: '證券提存',
      jiedan: '我的結單',
      baobiao: '我的報表'
    },
    //通知
    notice: {
      title: '通知',
      more: '更多',
      noResult: '暫無通知',
      time: '時間',
      theme: '主題',
      operation: '操作',
      toView: '查看'
    },
    //我的持仓
    volume: {
      title: '我的持倉',
      market: '市場',
      aStock: 'A股',
      hkStock: '港股',
      usStock: '美股',
      outsideStock: '場外市場',
      volumeVal: '持倉市值',
      Profit: '參考盈虧',
      todyProfit: '今日盈虧',
      stock: '股票',
      curPrice: '現價',
      cost: '成本',
      totalNum: '總數量',
      sellNum: '可沽數量',
      stockTodyProfit: '今日盈虧',
      stockProfit: '參考盈虧',
      marketVal: '市值',
      chicangVal: '按倉值',
      operation: '操作',
      sell: '賣出',
      tradHistory: '交易記錄',
      noResult: '暫無持倉'
    },
    //新股申购
    ipo: {
      title: '新股認購',
      more: '更多新股',
      rengou: '認購',
      stockPrice: '招股價',
      endDate: '截止認購日期',
      noReulst: '暫無可認購的新股'
    }
  },
  // 登录页
  login: {
    bounced: '閣下的登入密碼或登入名稱錯誤', // 错误提示弹框
    bounced1:
      '您的賬戶已被鎖定，請聯絡海通國際客戶服務部，熱線電話（852）3583-3388/（86）755 8266 3232',
    bounced2: '您的登入名稱未激活。',
    bounced4: '閣下的登入戶口暫被停用',
    bounced5:
      '抱歉，「證券網上交易系統」正在進行系統提升。如需下單或查詢交易狀況，請致電你的經紀人或交易部熱線 (852) 2213-8333。如有其他查詢，請致電客戶服務熱線 (852) 3583-3388。',
    bounced6:
      '無法登入網上交易賬戶﹗為配合監管機構要求，請即登記電郵信箱以接收賬戶活動通知。 24小時交易熱線：(852) 2213 8333 客戶服務熱線：(852) 3583 3388 (香港) / (86) 755 8266 3232 (中國內地) / (86) 755 8266 3232',
    bounced7:
      '系統未能提供服務，請稍後再重試或聯絡海通國際客戶服務部。 熱線電話: (852) 3583-3388 / (86) 755 8266-3232[CA SERVER]。',
    bounced8:
      '傳送驗證碼失敗。請稍後再重試或聯絡海通國際客戶服務部。熱線電話: (852) 3583-3388 / (86) 755 8266-3232。',
    bounced9: '發送驗證碼太頻繁。請稍後再試。',
    bounced10:
      '系統未能提供服務。請聯絡您的經紀或客戶服務部(852) 3583 3388 (香港) / (86) 755 8266 3232 (中國內地)或交易熱線(852) 2213 8333。',
    bounced11: '輸入舊密碼錯誤',
    bounced12: '您必須更改密碼才可以繼續',
    bounced13: '密碼必須是數字(0-9)+英文字母(A-Z,a-z)之組合，合計8-10位。',
    bounced14:
      '您的網上登入賬戶狀態特殊，請聯絡客戶服務部以索取網上登入密碼。熱線電話: (852) 3583-3388 / (86) 755 8266-3232。',
    bounced15:
      '無法重設登入密碼！為配合監管機構要求，請即登記電郵信箱以接收賬戶活動通知。24小時交易熱線: (852) 2213 8333 客戶服務熱線：(852) 3583 3388 / (86) 755 8266 3232',
    bounced16: '您的密碼已重置，請在收到密碼信後再登入。',
    bounced17: '閣下的新密碼不能與以往所使用的相同',
    bounced18: '登入記錄已失效﹐請重新登入。',
    bounced19: '密碼不能為空',
    bounced20: '兩次輸入密碼不一致',
    system: '證券網上交易系統',
    customer: '客戶登入',
    name: '名稱',
    password: '密碼',
    information1: '登錄名稱必須填寫', // 错误提示信息
    information2: '密碼必須填寫', // 错误提示信息
    ForgetPassword: '忘記密碼',
    btn: '登 入',
    Register: '啟動流動保安編碼註冊',
    Unregister: '取消流動保安編碼註冊',
    Activation: '激活碼登入',
    Caution:
      '注意：為免無法使用部分功能，登入前請先暫時關閉電腦內已裝置彈出型視窗攔截功能(如：WinXPSP2IE內快顯封鎖程式、Yahoo工具列、Google工具列、MSN工具列等)。',
    kefu:
      '如客戶未能進行網上交易，請致電交易熱線 (852) 2213 8333下單。若客戶在登入網上交易平台時有任何疑問，可於辦公時間致電客戶服務熱線 (852) 3583 3388或 (86) 755 8266 3232查詢。',
    company:
      '海通國際證券有限公司，為一間核准從事證券及期貨條例（香港法例第五七一章）中第一類（證券交易）受規管活動之持牌法團（中央編號：AAF806）及香港聯合交易所有限公司的交易所參與者。',
    prompt1: '為保障賬戶安全，本公司建議您定期更改密碼，請按指示更改密碼。',
    keep: '保留现有密码',
    tishi: '提示'
  },
  // 保安提示弹框
  prompt: {
    title: '手機及平板電腦/桌上電腦交易平臺的保安提示',
    content: `
      <ol>
        <li>不要在流動電話或平板電腦/桌上電腦內儲存您的海通國際網上交易平台的名稱和密碼。</li>
        <li>切勿向任何人透露您的個人保安資料（例如戶口號碼或私人密碼），即使有人聲稱自己是本公司職員或警方人員。</li>
        <li>避免使用公用的電腦登入海通國際網上交易平台。</li>
        <li>進行網上交易時，需先留意四周環境，切勿讓他人得知您所輸入的密碼；當在任何裝置輸入密碼時，請遮掩按鍵。</li>
        <li>流動電話或平板電腦/桌上電腦須安裝和定期更新防毒軟件和防間諜軟件。</li>
        <li>避免與他人分享使用流動電話，或使用他人的流動電話或平板電腦/桌上電腦登入海通國際網上交易平台。</li>
        <li>登入網上交易平台後，請不要離開或閒置您的流動電話或平板電腦/桌上電腦。當您使用完網上交易平台後，請謹記登出網上交易平台。</li>
        <li>在轉讓、出售或循環再用您的流動電話或平板電腦/桌上電腦前，請刪除您的舊流動電話或平板電腦/桌上電腦內的所有資料。</li>
        <li>如您遺失流動電話或平板電腦/桌上電腦，請透過網上交易平台查閱賬戶交易。如發現任何可疑交易，請即致電客戶服務熱線舉報。您亦應立即啟動遙控裝置刪除有關資料及報失流動電話或平板電腦/桌上電腦。</li>
        <li>設立自動上鎖和啟用密碼鎖功能，以防止他人在未經許可的情況下使用您的流動電話。</li>
        <li>當使用Wi-Fi無線上網時，請使用可信賴的Wi-Fi無線網絡或服務提供者，並啟用保安措施，例如盡可能使用Wi-FiProtectedAccess（WPA,一種保護無線電腦網絡安全的系統）。</li>
        <li>在毋須使用流動電話或平板電腦/桌上電腦時，請解除藍芽裝置或把藍芽裝置設定為隱藏模式。</li>
        <li>使用流動電話及平板電腦/桌上電腦原廠提供的瀏覽器，避免安裝由其他來源下載的瀏覽器。</li>
        <li>不應使用已被破解（「破解版」）的手機或平板電腦，以免在登入網上交易平台時出現保安漏洞。</li>
        <li>不要安裝來源不明的軟件，並在安裝軟件前清楚有關須知。請不要使用來源不明的虛擬鍵盤。</li>
        <li>請定時更新您的流動電話或平板電腦/桌上電腦，以及有關的操作系統，並把流動電話或平板電腦/桌上電腦內的資料進行加密。</li>
        <li>請只在官方應用程式網站下載海通國際流動交易平台。</li>
        <li>為保安理由，請定期更改密碼。</li>
        <li>積極監察您戶口的活動，收到月結單後請盡快查閱，若發現有任何不尋常的交易，請立即通知本公司,您可透過海通國際網上交易平台，經常查閱您戶口的交易記錄。</li>
        <li>當您使用手機短訊收取一次性驗證碼作爲雙重認證登入，切勿設定手機短訊轉發。</li>
      </ol>
    `,
    chek: '不再提醒我',
    Close: '關閉'
  },
  // 2FA 页面
  twoFaLogin: {
    // 短讯认证
    phoneLogin: {
      check: '必須填寫手機號碼',
      check1: '請輸入正確的手機號碼',
      check2: '必須填寫保安編碼',
      check3: '請輸入正確的保安編碼',
      Sms: '短訊認證',
      coding: '流動保安編碼認證',
      code: '請輸入你於海通國際登記的手機號碼收取一次性驗證碼。',
      phone: '請輸入手機號碼',
      prompt1:
        '*手機號碼毋需提供國家及地區代碼。例如，您的手機號碼是(86)13912345678，您只需輸入13912345678。',
      prompt2:
        '*如閣下未能收到「一次性密碼」可轉換「一次性密碼」的短訊服務供應商，再嘗試發送「一次性密碼」到閣下登記的手提電話。',
      btn1: '取 消',
      btn2: '確 認',
      supplier1: '短訊服務供應商 1',
      supplier2: '短訊服務供應商 2',
      supplier3: '短訊服務供應商 3',
      supplier4: '短訊服務供應商 4',
      prompt3: '手機號碼不正確,請重新登錄。'
    },
    // 保安编码认证
    codingLogin: {
      coding1: '請輸入6位數字的流動保安編碼',
      coding2: '請輸入6位數字的流動保安編碼',
      bounced1: '系統所需資料錯誤。'
    }
  },
  // 验证码填写页面
  codeLogin: {
    code: '請輸入你於海通國際登記的手機號碼所收到的6位數字一次性驗證碼。',
    time: '驗證碼將於',
    shixiao: '失效。',
    prompt: '請輸入一次性驗證碼', // 提示
    resend: '后重發',
    resend1: '重發',
    no: '沒有收到驗證碼，怎麽辦?',
    content1: `1. 一次性驗證碼的傳送速度可能會受網絡影響而出現延誤，如你在合理時間內仍未能收到一次性驗證碼，請按「重新發送」。
    2. 如您須更改登記手機號碼, 請填妥及簽署「更改資料及易結單服務表格」後發予客戶經紀或客戶服務部跟進。`,
    check1: '必須填寫驗證碼',
    check2: '請輸入正確的驗證碼',
    bounced1:
      '登入渠道失效，請聯絡海通國際客戶服務部。熱線電話:(852) 3583-3388 / (86) 755 8266-3232。', // 错误提示弹框
    bounced2:
      '您的網上帳戶已被停用，請聯絡海通國際客戶服務部。熱線電話:(852) 3583-3388 / (86) 755 8266-3232。',
    bounced3:
      '您的密碼信已經作廢和重置。請聯絡海通國際客戶服務部。熱線電話:(852) 3583-3388 / (86) 755 8266-3232。',
    bounced6:
      '您的驗證碼嘗試次數已經超出限制，您的帳戶已被鎖定,詳情請聯絡海通國際客戶服務部。熱線電話:(852) 3583-3388 / (86) 755 8266-3232。',
    bounced7: '您的驗證碼已失效。請按「重新發送」以收取新的驗證碼。',
    bounced8: '發送驗證碼太頻繁。請稍後再試。',
    bounced9: '您輸入的驗證碼不正確，請重新輸入。',
    bounced10: '驗證碼發送次數超過限制，請重新登入。'
  },
  // 注册页面
  register: {
    // 弹框
    addDialog: {
      title: '流動保安編碼註冊',
      content:
        '您尚未註冊流動保安編碼！請按確定進行註冊或按取消收取短訊一次性密碼 （SMSOTP）。'
    },
    registerCode: {
      name: '登入名稱',
      password: '密碼',
      phone: '已登記的手機號碼',
      email: '已登記的電子郵箱',
      agree: '本人理解並同意接受',
      terms: '使用條款',
      promptName: '請輸入登入名稱',
      promptPassword: '請輸入密码',
      promptPhone: '請輸入已登記的手機號碼',
      promptEmail: '請輸入已登記的電子郵箱',
      check: '必須填寫電子郵箱',
      check1: '請輸入正確的電郵地址',
      terms1: '請勾選條款',
      errorMsg1:
        '無法獲取登錄名稱。請稍後再重試或聯絡海通國際客戶服務部。熱線電話: (852) 3583-3388 / (86) 755 8266-3232。',
      errorMsg2: '註冊流動裝置數量超出限制。',
      errorMsg3: '設備已註冊。',
      errorMsg4: '首次註冊驗證碼超出發送次數上限。',
      errorMsg5:
        '請輸入正確的手機號及電郵地址，如您尚未登記，請聯絡海通國際客戶服務部，熱線電話（852）3583-3388/（86）755 8266 3232',
      errorMsg6:
        '暫時未能發送郵件，請稍後再重試或聯絡海通國際客戶服務部。熱線電話: (852) 3583-3388 / (86) 755 8266-3232。',
      errorMsg7: '您尚未註冊移動認證。',
      errorMsg8: '一次性驗證碼不正確。'
    },
    success: {
      content1:
        '首次啟動程式和啟動驗證碼已發送到您已登記的電子郵箱和流動電話。',
      content2: '請遵循電子郵件中的指示打開鏈接。',
      content3: '鏈接打開後，您將被要求輸入啟動驗證碼。'
    },
    unregister: {
      title: '取消流動保安編碼註冊',
      CancelRegister: ' 確認取消流動保安編碼註冊？',
      complete: '取消流動保安編碼註冊完成',
      zaici: '在此設備上註冊流動保安編碼？'
    }
  },
  // 风险披露页面
  risk: {
    content1: `
    <h4>電子服務風險披露聲明</h4>
        <ol>
          <li>閣下作為賬戶持有人為電子服務之唯一授權使用者，將會對本公司發給的交易密碼之保密、安全和使用自行承擔全部責任。本公司不會就閣下因其他人仕未經授權使用或嘗試使用電子服務可能遭受的任何損失或損害承擔責任。</li>
          <li>倘若閣下透過電子交易系統進行交易，閣下將會承受系統相關的風險，包括硬件和軟件發生故障的風險。任何系統發生故障的後果可能使閣下的指示不能按其指令執行或者根本沒有被執行。</li>
          <li>電子交易的設施是以電腦組成系統來進行交易指示傳遞、執行、配對、登記或交易結算。然而，所有設施及系統均有可能會暫時中斷或失靈，而閣下就此所能獲得的賠償或會受制於系統供應商、市場、結算公司及╱或參與者商號就其所承擔的責任所施加的限制。這些責任限制可以各有不同。</li>
          <li>由於無法預計的通訊阻塞或其他原因，電子傳送不一定是一種可靠的通訊方法。通過電子工具進行的交易，在傳送和接收閣下指示或其他資料時會出現延遲，在執行閣下指示時會出現延遲或以不同於閣下發出指示時的價格執行閣下的指示，通訊設施亦會出現故障或中斷。電子傳送存在通訊中之誤解或錯誤的風險。</li>
          <li>本公司慎重建議閣下在輸入每個指示之前會加以覆核，因為指示一經作出，便可能無法取消。</li>
          <li>本公司不會保證市場數據或任何市場資料(包括透過電子服務提供給閣下的任何資料)的及時性、次序、準確性或完整性。本公司對下述事項所引起或造成之任何損失概不承擔任何責任：(1)任何上述數據、資料或信息的不準確性、錯誤或遺漏；(2)上述數據、資料或信息之傳送或交付延誤；(3)通訊中斷或阻塞；(4)不論是否由於本公司的行為所致之該等數據、資料或信息的無法提供或中斷；或(5)本公司無法控制的外力。</li>
        </ol>
    <h4>中國A股交易注意事項：</h4>
        <p>客戶在交易中國A股前，必須確保已閱讀及明白相關賬戶條款和條件的互聯互通補充文件及風險披露及其他資料，詳情可參閱以下內容：</p>
          <a style="" href="http://www.htisec.com/sites/default/files/Amendments%20to%20Cash%20Account%20and%20Leveraged%20Foreign%20Exchange%20Trading%20Account%20Terms%20%26%20Conditions_TC.pdf"
          target="_blank">現金賬戶及槓桿外匯交易賬戶條款和條件的互聯互通補充文件及互聯互通風險披露及其他資料</a>
          <a href="http://www.htisec.com/sites/default/files/Amendments%20to%20Margin%20Account%20and%20Leveraged%20Foreign%20Exchange%20Trading%20Account%20Terms%20%26%20Conditions_TC.pdf"
          target="_blank">保證金賬戶及槓桿外匯交易賬戶條款和條件的互聯互通補充文件及互聯互通風險披露及其他資料</a>
    <h4>網上美股交易注意事項:</h4>
        本人/吾等明白及同意本「注意事項」的內容：
        <ol>
          <li><h5>開戶及W-8 表格(美國國稅局)</h5>
              如欲使用網上美股交易服務，申請人(非美國公民/居民及非加拿大居民) 於開戶時必須填寫美國國稅局提供的 W-8 表格並須每3年續期一次。拒絕續期將被自動中止服務之使用權，屆時客戶只可以賣出美股，而賬戶的出售所得及其它收入必須預扣資本利得稅，直至重新遞交 W-8 表格。請注意，當投資海外產品時，閣下須遵守當地的稅制，並可能會不獲豁免美國資本利得稅項。閣下亦應視乎情況尋求專業稅務意見。查詢請聯絡海通國際客戶服務部 (852) 3583-3388 或(86) 755 8266-3232。
          <li><h5>美國稅項 (如就所得紅利的預扣稅)</h5>
              <p>美國的稅制涵蓋源於美國的投資產品(不管是可交易證券、互惠基金或債券等)，而投資者無論是否美國公民或永久居民，只要以個人名義持有這些投資產品，均須繳付美國稅項。換句話說，所有持有任何形式美國證券的人士，也須就所得紅利支付預扣稅。
              客戶透過本公司收取任何源自美國的收入，如利息或股息，均須為其此等收入繳納美國稅款，因此本公司的美股執行經紀須從付給外國人的收入中預扣最高30%的稅款。此外，本公司並不會代表或協助客戶向美國稅務局申請減免或豁免預扣稅。
              閣下應視乎情況尋求專業稅務意見。詳情請點擊證監會以下連結：</p>
              <a href="http://www.thechinfamily.hk/web/tc/financial-products/financial-intermediaries/broker/online-trading/trading-process.html"
              target="_blank">(http://www.thechinfamily.hk/web/tc/financial-products/financial-intermediaries/broker/online-trading/trading-process.html)</a>
          </li>    
          <li><h5>結算及託管服務</h5>
              <p>網上美股交易由 ViewTrade Securities, Inc. 為執行經紀及 APEX Clearing Corporation . 為結算代理人。</p>
              <p>閣下需明白海通國際證券有限公司為介紹經紀人及於此安排而引起任何對手風險時會協助客戶確定及追討ViewTrade Securities， Inc. 及APEX Clearing Corporation. 的所有責任及義務。</p>
          </li>
          <li><h5>服務的提供</h5>
            <ol type="a">
              <li>如 閣下之證券賬戶為保證金賬戶，網上美股交易服務亦會為閣下提供保證金按倉買賣。詳情及利息等信息請參閱海通國際網頁<a href="http://www.htisec.com/zh-hk/fees-and-charges"
                  target="_blank">http://www.htisec.com/zh-hk/fees-and-charges</a>。
              </li>
              <li>服務只適用於非美國公民/居民及非加拿大居民。如 閣下之個人資料有任何更改，請聯絡海通國際客戶服務部 (852) 3583-3388 或(86) 755 8266-3232。</li>
              <li>網上美股交易服務只提供於 NASDAQ、NYSE、NYSEMKT 及 BATS 上市之美股買賣交易，服務暫不支持開市前/後交易。於(i) OTC Bulletin Board/OTC BB 及 (ii) OTC Pink (即 NASDAQ、NYSE、NYSEMKT 及 BATS 以外) 交易的美股不支持網上交易服務, 只可致電本公司買入與賣出。</li>
              <li>於(i) OTC Bulletin Board/OTC BB 及 (ii) OTC Pink (即 NASDAQ、NYSE、NYSEMKT 及 BATS 以外) 交易的美股不支持網上交易服務，只可致電本公司買入與賣出。本公司亦不接受交收買入市值低於 5 千萬美元及每股股價低於$0.5 美元的美國場外(OTC)股票，如客戶仍持有該等美國場外股票並希望賣出，須致電經紀或 24 小時投資服務中心交易熱線(電話: (852) 2213-8333)。另外，由於股票價格低於$0.5 美元的美國場外(OTC)股票的交易訂單，需通過交易商人工批核才可進入市場，故此通過經紀或交易部落盤所需時間會有所增加。此外，交易商對於批核客戶的交易訂單有絕對的決定權，所以 閣下的交易訂單有可能被拒絕。</li>
              <li>網上美股交易服務免費提供延時美股報價。如需申請實時美國股票報價, 請登入海通國際綜合網上服務<a href="https://eservices.htisec.com/"
                  target="_blank">https://eservices.htisec.com/</a>。 客戶第一次登入網上美股交易服務使用實時美股報價時需填寫及遞交有關使用者協議。使用者協議只有英文版本，請按此
                  <a href="http://www.htisec.com/zh-hk/ real-time-quotes/securities" target="_blank">http://www.htisec.com/zh-hk/ real-time-quotes/securities</a>參考填寫範例。</li>
            </ol>
            <li><h5>佣金及收費</h5>
                <p>當指令執行後，客戶必須繳付相關佣金及收費，此佣金及收費的更新通知會不時透過海通國際網頁<a href="http://www.htisec.com" target="_blank">http://www.htisec.com</a>或其他途徑發佈。此外，細價股(即股價少於美金1元之股票)及美國預托證券(ADR)等交易會有特別佣金/手續費安排。</p>
            </li>
            <li><h5>交易時間</h5>
                <p>美股交易時間為美國東部時間星期一至星期五上午09:30至下午04:00。所有當天未成交之「當日有效單」會在美國東部時間下午04:00收市後無效。閣下可於美國東部時間星期一至星期五上午08:00開始輸入下單指示 (假期除外)。 下單時請確保 閣下賬戶持有足夠的購買力及持倉， 並於開市後查閱最新之下單狀況及賬戶信息。</p>
            </li>
            <li><h5>結算日</h5>
                <p>網上美股交易買賣之交收時間為T+2。未結算之交易所得資金可實時作開新倉之用。</p>
            </li>
            <li><h5>資金存入/提取</h5>
                <p>閣下必須於網上戶口存入美金或從其它貨幣兌換成美金，作網上美股交易之用。網上美股交易服務資金(美金)之存入截數時間為香港時間星期一至星期五下午4:30 (公眾假期除外)，而貨幣兌換及資金提出截數時間為香港時間星期一至星期五下午2:00 (公眾假期除外)，款項會於當晚美股交易時間前反映。</p>
            </li>
            <li><h5>戶口持倉轉撥</h5>
                <p>請注意，網上美股交易服務之買賣指示、戶口結存、持倉證券等完全獨立運作，跟經紀戶口分開處理。客戶如需將資金/證券持倉等在網上戶口及經紀戶口之間轉撥請於香港時間星期一至星期五下午2:00前發出指示。詳情請向閣下經紀或客戶服務部查詢。</p>
            </li>
            <li><h5>其他</h5>
                <p>有關開戶及交易詳情可參閱開戶文件及其它附帶文件及其它發佈於海通國際網頁<a href="http://www.htisec.com" target="_blank">http://www.htisec.com</a>上相關(包括不時更新)的資料。</p>
                <p>如欲查詢網上美股交易狀況， 請於美股交易日香港時間星期一下午6:00至星期六上午6:00致電交易部 (852) 2213-8333。網上服務可能會因應特別節日或個別股票企業活動等暫停服務而不作另行通知。</p>
                <p>倘若本注意事項的中文本與英文本在解釋或意義方面有任何歧義， 請以英文本為準。</p>
            </li>
        </ol>
    <h4>即時報價服務之免責聲明</h4>
        <p>海通國際證券有限公司、海通國際期貨有限公司、海通國際電子網上服務限公司、或其任何控股公司、附屬公司或聯營公司、其資料供應商、及香港交易所資訊服務有限公司、其控股公司及/或該等控股公司的任何附屬公司、上海證券交易所及深圳證券交易所均竭力確保所提供資訊的準確和可靠度，但不能保證其絕對準確和可靠，且亦不會承擔因任何不準確或遺漏而引起的任何損失或損害的責任(不管是否侵權法下的責任或合約責任又或其他責任)。證券交易平台之內容、新聞及資訊版權均屬服務供應商所有，不得向任何人作任何用途之複製、篡改、發佈、發行、散播宣傳廣播或以其它形式傳播。</p>
    <h4>使用電子服務須知</h4>
        <p>本公司提供的電子服務並不涉及本公司就任何產品作出招攬銷售或建議或提供意見，閣下透過電子服務進行的所有交易均以只限執行基準，詳情請參閱<a href="https://www.htisec.com/sites/all/themes/hitong/files/what-is-news/security_tips_tc.html#es" target="_blank"><使用電子服務須知></a> 。</p>
    <h4>關於複雜產品的警告聲明</h4>
        <p>如閣下進行複雜產品交易 (包括但不限於衍生認股權證、牛熊證、交易所買賣基金、股票掛鈎票據、槓桿及反向產品、期貨、股票期權等)，須閱讀以下<a href="https://www.htisec.com/sites/all/themes/hitong/files/what-is-news/security_tips_tc.html#cp" target="_blank">關於複雜產品的警告聲明</a>才可進行交易。</p>
    `,
    content2: `<a href="http://www.htisec.com/trading/help_menu/help_b5/order.html#pre-mkt"
    target="_blank">交易時段及買賣盤指示功能</a>
     及 <a href="http://www.htisec.com/trading/help_menu/help_b5/order.html#special"
     target="_blank">發盤種類及定義</a>`
  },
  // 联络我们页面
  newContact: {
    title: '聯絡我們',
    content1: '客戶服務熱線:',
    content2: '中國客戶熱線:',
    content3: '電郵查詢:'
  },
  // 帮助中心页面
  newHelp: {
    link1: '1.是否必須設定瀏覽器接受cookies?',
    link2: '2.為何瀏覽器會自動記憶我的個人戶口號碼及密碼?',
    link3: '3.若需要與別人共用電腦，請問應如何保障個人資料?',
    link4: '4.保護賬戶資料有何秘訣？',
    link5: '5.更改/取消交易要注意些什麼？',
    content1: '是否必須設定瀏覽器接受cookies?',
    content2: '是，閣下必須將瀏覽器設定至接受cookies。',
    content3: '為何瀏覽器會自動記憶我的個人戶口號碼及密碼?',
    content4:
      '這是瀏覽器內「自動完成」的功能。為避免當您鍵入用戶名稱時，電腦會自動完成您的密碼輸入，您應取消瀏覽器的「自動完成」功能。',
    content16:
      '在InternetExplorer瀏覽器中，這個「自動完成」功能會儲存您過去曾經就網址、表格和密碼所輸入的資料，然後當您再一次鍵入這些資料時，「自動完成」功能就會提議可能的配對資料。因此為確保您的戶口資料獲得適當保護，您應取消瀏覽器的「自動完成」功能，以避免當您鍵入用戶名稱時，電腦會自動完成您的密碼輸入。要取消「自動完成」功能，請在瀏覽器內按一下「工具」，按一下「Internet選項」，按一下「內容」，然後按一下「自動完成」按鈕，最後取消「表單上的使用者名稱和密碼」功能。',
    content5: '若需要與別人共用電腦，請問應如何保障個人資料?',
    content6:
      '為了保障您個人戶口的資料，請緊記當您登出網上服務後必須刪除瀏覽器內的臨時檔案並關閉瀏覽器。',
    content7: '保護賬戶資料有何秘訣？',
    content8:
      '我們建議各電子交易服務用戶應該採取以下程序，以維持高度安全標準：',
    content9: '•  定期透過網頁更改用戶密碼。',
    content10: '•  切勿向任何人透露密碼。',
    content11:
      '•  設定一個容易記得但別人難於以猜測的密碼，請勿用重覆數字、出生日期、電話號碼或身份證號碼來做密碼。',
    content12:
      '•  完成網上交易後便退出互聯網瀏覽器，有助避免其他人使用回到前一頁」的功能來閱覽閣下的賬戶資料。',
    content13:
      '•  經常鍵入網址(www.htisec.com)或使用閣下建立之位址連接來瀏覽海通國際網頁。',
    content14: '更改/取消交易要注意些什麼？',
    content15:
      '未能即時成交的增強限價盤將成為相同價格的限價盤，更改增強限價買／賣盤時只可輸入不高於賣出／不低於買入盤的最佳價格，否則系統將拒絕有關更改．',
    content16:
      '若客戶不需要減少交易數量，則毋須更改『最終交易數量』內的數值。最終交易數量應是未完成數量+已成交數量，即系統已自動填入的數量。更改/取消後, 請在「交易狀況」按<<重新整理>> 以檢視最新交易狀況。 更改/取消指令未必被市場接受, 故請閣下留意更新後的交易價及交易狀態, 以確定更改是否已成功:',
    content17:
      '1.	「交易狀況」中 「狀態」出現" * "符號, 表示曾經成功更改交易/取消交易。',
    content18:
      '2.	「交易狀況」中 「狀態」出現" # "符號, 表示最新更改/取消已被拒絕，未能修改交易股價或數量。',
    content19:
      '3.	「交易狀況」中 「狀態」出現" @ "符號, 表示最新更改/取消指令正在進行中。'
  },
  //证券交易菜单
  security: {
    // 港A美股
    mainMarket: {
      hkTrading: '港股交易',
      chinaTrading: 'A股交易',
      usTrading: '美股交易',
      refresh: '刷新',
      actionExplain:
        '注意事項：閣下於交易日上午九時二十九分或以前透過電子交易系統傳送交易指示，該交易指示可能存在相比閣下或其他客戶於上午九時三十分後(香港聯合交易所有限公司開市時間)所傳送的交易指示較遲被執行之風險，敬請留意。(只適用於港股交易)。',
      //自选股
      watchlists: '自選股',
      stock: '股票',
      prc: '價格',
      prcentChg: '漲跌幅',
      chg: '漲跌額',
      //行情图表
      chart: '行情圖表',
      date: '行情數據',
      addUseStock: '加入到自選股',
      removeUseStock: '移出自選股',
      trading: '交易中',
      minK: '分時',
      fiveDate: '五日',
      dateK: '日K',
      weekK: '周K',
      monK: '月K',
      Unopened: '未開盤',
      Trading: '交易中',
      Closed: '已收盤',
      Normal: '正常',
      LimitUp: '漲停',
      LimitDown: '跌停',
      Suspend: '停牌',
      Delisted: '退市',
      IPOPeriod: 'IPO期間',
      AuctionSession: '集合競價',
      LunchBreak: '午間休市',
      MarkerClosed: '休市中',
      Actual: '不復權',
      AdjFwd: '前復權',
      AdjBwd: '後復權',
      updateTime: '更新時間',
      linkName1: '滬深A股及港股實时基本市場行情',
      alink1: 'http://www.htisec.com/zh-hk/bmp',
      aExplain1:
        '由香港交易所、上海證券交易所及深圳證券交易所提供。美股上日收市價由Orbis提供。',
      linkName2: '（免責聲明）',
      alink2: 'http://www.htisec.com/zh-hk/disclaimer-bmp',
      zuigao: '最高',
      jinkai: '今開',
      zuidi: '最低',
      zuoshou: '昨收',
      chenjiaoe: '成交額',
      chenjiaoliang: '成交量',
      shiyinglv: '市盈率',
      xinshijia: '行使價',
      shouhuijia: '收回價',
      shangxianjia: '上限價',
      xiaxianjia: '下限價',
      daoqiri: '到期日',
      meishou: '每手',
      pingjunjia: '平均價',
      shijinlv: '市凈率',
      shizhi: '市值',
      huanshoulv: '換手率',
      zhengfu: '振幅',
      liangbi: '量比',
      waipan: '外盤',
      neipan: '內盤',
      weibi: '委比',
      fiveWeekHight: '52周最高',
      fiveWeekLower: '52周最低',
      yijia: '溢價',
      yishenbofu: '引申波幅',
      duichongzhi: '對沖值',
      jiehuobi: '街貨比',
      huangubili: '換股比率',
      gangganbili: '杠桿比率',
      jianeijiawai: '價內/價外',
      dahedian: '打和點',
      zuihoujiaoyiri: '最後交易日',
      leibie: '類別',
      lengjinjia: '冷靜期參考價',
      lengjinshanxian: '冷靜期價格上限',
      lengjinxiaxian: '冷靜期價格下限',
      lengjinBshijian: '冷靜期開始時間',
      lengjinEshijian: '冷靜期結束時間',
      shoushijingjia: '收市競價參考價',
      shoushishangxian: '收市競價價格上限',
      shoushixiaxian: '收市競價價格下限',
      bupinghengliang: '不平衡数量',
      bupinghengfangxiang: '不平衡方向',
      //交易状况
      orderStatus: '交易狀況',
      export: '匯出今天成交記錄至Excel',
      print: '列印',
      status: '狀態',
      all: '全部',
      completed: '已成交',
      queuing: '掛盤中',
      canceled: '已取消',
      noRecords: '無記錄',
      action: '操作',
      ordNo: '交易編號',
      buy: '買',
      sell: '賣',
      num: '數量',
      sellNum: '成交量',
      amd: '更改',
      del: '取消',
      buys: '買入',
      sells: '賣出',
      guchu: '賣出',
      explain:
        '* 曾成功更改交易/取消交易 # 曾失敗更改/取消交易 @ 更改/取消指令正在進行中',
      //交易状况弹出框内容
      explain1: '曾成功更改交易/取消交易',
      explain2: '曾失敗更改/取消交易',
      explain3: '更改/取消指令正在進行中',
      tradDetail: '交易詳情',
      tradExplain: '*未能即時成交的增强限價盤已被轉成為相同價格的限價盤',
      account: '戶口編號',
      tradId: '交易編號',
      tradStatus: '交易狀態',
      detail: '詳情',
      tradType: '交易類型',
      market: '市場',
      tradPrice: '交易價',
      condition: '停損/觸發條件',
      orignNum: '原交易數量',
      changeNum: '改變/取消數量',
      chejiaojiage: '成交價格',
      sellTotalNum: '成交數量',
      jiaoyiduishou: '交易對手',
      noComplateNum: '未完成數量',
      expired: '到期日',
      refusReson: '拒絕原因',
      aon: '全額或等待',
      channel: '媒介',
      changeTip: '更改交易訓示',
      confirmChange: '*確認更改/取消訓示前注意',
      chufaPrice: '觸發價',
      targePrice: '目標交易股價',
      lastTradNum: '最終交易數量',
      password: '密碼',
      placeholder: '請輸入密碼',
      cancelTradTip: '取消交易提示',
      confirm: '確認',
      //交易面板
      buyAllMoneyHK: '是次買入上限',
      type: '類型',
      code: '代碼',
      nums: '數量',
      maxBuy: '最大可買',
      maxSell: '最大可賣',
      aon1: '全額或取消',
      aon2: '全額或等待',
      type1: '增强/競價限價盤',
      type2: '限價盤',
      type3: '競價盤',
      type4: '特別限價盤',
      type5: '條件指示盤',
      price1: '跟市價',
      price2: '跟買一',
      price3: '跟賣一',
      condition1: '>=升穿',
      condition2: '<=跌穿',
      whole: '全倉',
      custormId: '券商客戶編碼',
      tiaojian: '條件',
      price: '股價',
      tradMoney: '交易金額',
      costMoney: '参考佣金及費用',
      duiyinzhi: '港幣對應值',
      cost1: '参考佣金',
      cost2: '結算費',
      cost3: '交易徵費',
      cost4: '厘印費',
      cost4: '交易費',
      cost5: '合計',
      costExplain:
        '*以上顯示的傭金及交易費用只供參考。參攷傭金是以交易金額乘以0.15%。請查閱你的日結單瞭解實際傭金及交易費用。',
      usExplain1: '*參考傭金按成交金額0.15%計算。',
      usExplain2: `*ESS收費是按每個交易每只股票的每邊交易收取（適用於美股參考名單：<a class="activeTagColor" target="_blank" href="http://www.viewtrade.com/ess">http://www.viewtrade.com/ess</a>）。`,
      usExplain3:
        '*只適用於《場外櫃臺交易系統OTCBB》、《美國粉紅單市場Pink Sheet》及《BATS交易所》之交易並買入或賣出多於100000股細價股股票（細價股票價格低於美元1元之股票）。',
      usExplain4: '所有費用僅供參考。詳情請參閱收費錶及帳戶結單。',
      totalPrice: '總金額',
      noMoneyExplain: '現金餘額不足，可通過帳戶轉帳或資金存入補充現金',
      accountTrans: '帳戶轉帳',
      assetInput: '資金存入',
      success: '下單成功',
      sucTip: '請記錄閣下的交易編號',
      //股票结存
      stockPosition: '股票結存',
      marketVal: '持倉市值',
      profitLoss: '參考賺蝕',
      profitToday: '今日賺蝕',
      curPrice: '現價',
      costPrice: '成本',
      totalNum: '總數量',
      canSellNum: '可沽',
      jinriyingkui: '今日賺蝕',
      cankaoyingkui: '參考賺蝕',
      shizhi: '市值',
      ancanzhi: '按倉值'
    },
    // 其他市场
    otherMarket: {
      headTitle: '日本東京',
      headTitle1: '南韓首爾',
      headTitle2: '中國臺北',
      service: '電話落盤服務:',
      phone: '請致電交易部，電話: ',
      time: '交易時間（香港時間）:',
      time1: '上午交易時段',
      time2: '上午9時至下午1時30分',
      time3: '下午交易時段',
      time4: '上午11時30分至下午2時',
      time5: '上午8時至下午2時',
      time6: '上午9時至下午1時30分',
      date: '交收日:',
      commission: '佣金及收費:',
      content: '請參考',
      link: '海通國際網站',
      content1: '或聯絡閣下經紀了解詳細情況。',
      exchange: '外幣兌換:',
      info:
        '閣下只需提出外幣兌換指示，我們便會為您辦理手續。有關匯率將以銀行最後確認是項兌換之匯率為準。',
      query: '外匯查詢',
      reference: '* 兌換率只作參考',
      updateTime: '最後更新時間',
      conversion: '轉 換'
    },
    // 新股认购
    ipoSubscriptions: {
      list: '新股列表',
      stock: '股票',
      price: '招股價',
      date7: '截止認購日期',
      state: '認購狀況',
      details: '新股詳情',
      accept: '接受申請',
      accept2: '不接受申請',
      suspended: '暫停',
      jiaoYiSuo: '交易所',
      currency: '貨幣',
      commission: '經紀佣金',
      huiFei: '證監會交易徵費',
      huiFei1: '投資者賠償徵費',
      jiaoYiFei: '聯交所交易費',
      zaFei: '雜費',
      date: '發行人退票日',
      date1: '股票托收日期',
      date2: '上市交易日',
      sharesNumber: '每手股數',
      way: '認購方式',
      cash: '現金認購',
      date3: '截止申請日期',
      date4: '截止付款日期',
      date5: '付款扣除日期',
      poundage: '手續費',
      subscribe: '融資認購',
      date6: '計息日期',
      interestRate: '利率',
      amount: '最低融資金額',
      proportion: '最高融資比例',
      btn: '認購',
      cash1: '現金',
      margin: '融資',
      cashMargin: '現金/融資',
      jieshou: '接受申請',
      bujieshou: '不接受申請',
      zanting: '暫停',
      popover: {
        title: '新股認購申請',
        headInfo: '認購詳細資料查閱',
        headLink: '招股章程',
        headLink1: '申請股數一覽表',
        sharesNumber: '申請數量',
        proportion: '融資比例',
        amount: '認購金額',
        chekTitle: '請選擇下列事項作出確認：',
        chekInfo1: '本人/我們陳述及保證本人/我們符合認購證券資格。',
        chekInfo2:
          '本人/我們確認本人/我們已獲提供充足的機會接觸有關的招股章程及當中所披露的信息。',
        chekInfo3:
          '本人/我們已閱讀及明白本網站所載列有關認購證券的條件及條款及申請程序，並同意受其所約束。',
        chekInfo4:
          '本人/我們清楚及明白申請一經提交，便可能無法推翻、更改或撤回。',
        chekTitle2: '免費認購結果公布提示信息',
        details: '詳情',
        detailsInfo:
          '發行人公布公開發售申請結果當日下午，海通國際證券將所獲成功配發給閣下之證券數量撥歸於閣下在海通國際證券維持的電子證券買賣戶口內，屆時海通國際證券將免費發出提示信息通知閣下認購結果已經可在電子戶口查詢，請選擇提示信息方法以接受認購結果公布的提示信息(提示信息將會根據閣下於海通國際證券登記的電郵地址或手機號碼發出)。',
        notice: '電子郵件通知',
        notice1: '手機短訊通知',
        submitInfo: '認購申请已提交',
        btn: '新股認購查詢'
      },
      prospectus: {
        title: '招股章程',
        content: '如何查閲招股章程“testing3”：',
        content1: '1.可瀏覽於香港交易所網頁內電子版招股書：',
        content2: 'a.登入香港交易所網站',
        content3: 'b.於“投資者”欄下，按“上市公司訊息搜尋”。',
        content4:
          'c.在股份代號索引中，於“股份代號”內輸入“ 9876”，再在右方選取“招股文件”後再按搜尋即可。',
        content5:
          '2.如欲親身前往任何一間收票銀行之分行，分行詳情刊載於發行人發出之報章通告。',
        content6:
          '警告：任何非根據上述指示位置所瀏覽得的有關是次公開發售股份的資料，並非公開招股文件的內容。是次公開發售之股份只根據公開招股文件的內容發售。',
        content7:
          '注意：閣下需要安裝Acrobat Reader，以作下載招股文件的PDF檔案之用。',
        link: 'https://www.hkex.com.hk/?sc_lang=zh-HK'
      },
      prospectusForm: {
        number: '數量',
        amount: '金額'
      }
    },
    // 公司行动
    corporateAction: {
      title: '公司行動',
      list: '公司行動列表',
      market: '市場',
      stock: '股票',
      type: '類型',
      date: '回復截止日期',
      date1: '預計支付日期',
      state: '回復狀態',
      yihuifu: '已回復',
      weihuifu: '未回復',
      xianjinguxi: '現金股息',
      gupiaoguxi: '股票股息',
      details: '公司行動詳情',
      code: '參考編號',
      dividend: '每股股息',
      newShares: '收取新股價',
      describe:
        '根據上述公司宣布，股東有權就有關股息作出以下選擇。請在網上填妥並提交下列指示，或者填妥指示函件，並必須於2018年08月18日前寄回本公司交收部或傳真至（852）2537 7647 或致電經紀人/分行。若屆時未接獲閣下回復，或指示未填寫清楚，則本公司將代為收取全部現金股息。',
      describe1:
        '根據上述公司宣布，股東有權就有關股息作出以下選擇。請在網上填妥並提交下列指示，或者填妥指示函件，並必須於2018年08月18日前寄回本公司交收部或傳真至（852）2537 7647 或致電經紀人/分行。若屆時未接獲閣下回復，或指示未填寫清楚，則本公司將代為全部收取股票股息。',
      info:
        '*倘閣下沿用原設之長期指示，則毋須就是次派息回復本公司。否則，請網上填妥並提交下列指示，或者填妥指示函件。',
      info1: '對於更多信息關於以上公司行動，請瀏覽香港交易所網頁',
      info2: '之投資服務中心“上市公司訊息搜尋”。',
      info3: '本人/吾等根據上述事項通知貴公司：',
      info4: '持有可獲配股息之股數：',
      info5: '全部現金',
      info6: '港元',
      info7: '人民幣',
      info8: '美元',
      info9: '全部新股',
      info10: '部分現金及部分新股',
      info11: '選擇收取現金股息之股數',
      info12: '選擇收取新股股息之股數',
      tijiao: '提交',
      successInfo: '您的公司行動指示已經受理成功。',
      successInfo1: '您可以通過“公司行動記錄查詢”功能查詢詳情。',
      btn: '公司行動記錄查詢'
    },
    // 按仓比率
    marginFinancingRatios: {
      ganggu: '港股',
      hugutong: '滬股通',
      ganggutong: '港股通',
      meigu: '美股',
      ratio: '孖展比率',
      operation: '操作',
      maimai: '買賣',
      noRecord: '沒有符合查詢的資料',
      stock: '股票'
    }
  },
  //资金管理菜单
  cash: {
    //货币兑换
    fxConversion: {
      zhishi: '貨幣兌換指示',
      explain1:
        '*本平台提供的服務只為便利客戶處理交易和/或任何其他相關交易活動和/或結算，包括但不限於使用該海通賬戶及/或其他海通賬戶中產生的費用和收費。',
      explain2: '*平台中的「CNY」符號是指離岸人民幣的相關報價。',
      sell: '賣出',
      accountName: '戶口名稱',
      accountNum: '户口',
      market: '市場',
      money: '金額',
      buy: '買入',
      duihuanDate: '兌換日期',
      query: '查詢',
      mianze: '免責聲明',
      mianzeContent1:
        '海通國際證券集團有限公司及其子公司及其職員，代表或代理人（“海通”）對您因訪問、使用或無法訪問或無法使用本平台及其提供的服務而造成的任何損失，損害或傷害不承擔任何責任；除非海通通過本平台提供服務時存在欺詐或故意不當行為。',
      mianzeContent2:
        '您清楚明白亦接受使用服務時或會出現傳輸延遲或失敗、以電子方式進行的任何傳輸中斷或停頓；您同意海通不對此類或任何由此造成的損失，損害或傷害承擔責任。',
      mianzeContent3:
        '本平台提供的信息和材料不構成出售要約或徵求購買任何貨幣的要約，且不得被依賴作出任何投資決策。 必要時請諮詢獨立建議。',
      huilv: '參考匯率',
      duichu: '預計兌出',
      duiru: '預計兌入',
      duihuanlv: '兌換率（只作參考，最後更新時間',
      duihuanExplain:
        '籍遞交兌換指示，閣下表明已同意受附於現金/保證金賬戶使用條款和細則中貨幣兌換服務的相關條款約束，並確保是次兌換符合兌換資格',
      password: '密碼',
      change: '更改',
      confirm: '確認',
      duihuanSuccess: '兌換指示已經接收成功',
      bianhao: '請留意並記錄您的參考編號',
      duihuanjilu: '查看貨幣兌換記錄',
      print: '列印',
      jiecunTotal: '貨幣結存匯總表',
      allMarket: '所有',
      hkAUSAsotck: '香港，中國A股，美國及場外市場',
      cnBStock: '中國B股',
      otherMarket: '其它市場',
      date: '日期',
      sellMoney: '請輸入賣出金額',
      buyMoney: '請輸入買入金額',
      formCheck1: '請輸入賣出貨幣或者買入貨幣。',
      formCheck2: '請輸入正確的賣出金額，最多輸入2位小數。',
      formCheck3: '請輸入正確的買入金額，最多輸入2位小數。',
      formCheck4: '賣出貨幣和買入貨幣只能輸入其中一個',
      formCheck5: '賣出貨幣與買入貨幣不可以相同'
    },
    //账户转账
    fundTransfer: {
      chuzhangAccout: '出賬戶口',
      chuzhangzhanghu: '支賬賬戶',
      chuzhangRequire: '請選擇支賬賬戶',
      marketAndCurrency: '市場及貨幣',
      marketRequire: '請選擇市場及貨幣',
      money: '轉賬金額',
      moneyPlaceholder: '請輸入金額',
      ruzhang: '入賬戶口',
      zhanghuType: '賬戶類別',
      zhanghuTypeRequire: '請選擇賬戶類別',
      accoutType1: '證券',
      accoutType2: '期貨',
      ruzhangAccount: '入賬賬戶',
      ruzhangRequire: '請選擇入賬賬戶',
      market: '市場',
      marketRequire: '請選擇市場',
      zhengquanMarket1: '香港，中國A股，美國及場外市場',
      zhengquanMarket2: '中國B股市場',
      zhengquanMarket3: '其他市場',
      qihuoMarket1: '本地市場',
      qihuoMarket2: '海外市場',
      nextStep: '下一步',
      zhuyi: '注意事項',
      zhuyiinfo1: '1.轉賬服務時間為港股交易日上午9時至下午5時。',
      zhuyiinfo2: '2.轉賬服務適用於證券及期貨賬戶。',
      zhuyiinfo3: '3.接受港元、美元及人民幣轉賬指示。',
      zhuyiinfo4:
        '4.如於轉賬指示發出當日有任何交易，有關之交易佣金及其他收費可能尚未被扣除，請預留足夠款項以免賬戶出現結欠，並導致利息產生。',
      heshi: '轉賬核實',
      heshiinfo: '請核實一下數據並按「確認」。如需更改數據，請按「更改」。',
      password: '密碼',
      change: '更改',
      confirm: '確認',
      zhishi: '轉賬指示已接收',
      bianhao: '請記錄閣下的參考編號',
      zhanghujiecun: '查看賬戶結存',
      print: '列印',
      formCheck1: '轉賬金額錯誤。',
      formCheck2:
        '閣下指示的轉賬金額錯誤，正確金額應為HKD1元至1,000,000,000元之間（WC7001）REF：WEB001-1594104449990-20',
      formCheck3: '此功能不適用於此賬戶。'
    },
    //资金提取
    fundWithdrawal: {
      tikuanzhanghu: '提款賬戶',
      koukuanzhanghu: '扣款賬戶',
      market: '市場',
      zhengquanMarket1: '香港，中國A股，美國及場外市場',
      zhengquanMarket2: '中國B股市場',
      zhengquanMarket3: '其他市場',
      tiquMoney: '提取金額',
      tiquPlaceholder: '請輸入金額',
      cunruzhanghu: '存入賬戶',
      bankZhanghu: '銀行賬戶',
      nextStep: '下一步',
      zhuyi: '註意事項',
      zhuyiExplain1: '1、提取資金服務時間為港股交易日上午9時至下午5時。',
      zhuyiExplain2:
        '2、下午2時前發出的提款指示會於即日處理。下午2時後提交的提款指示會於下一個工作天處理。',
      zhuyiExplain3:
        '3、請確保所登記的銀行戶口號碼正確及可接受存款之用。如需協助，請致電客戶服務熱線 (852) 3583-3388 / (86) 755 8266-3232。',
      zhuyiExplain4: '4、只接受港元提款指示。',
      zhuyiExplain5:
        '5、如於提款指示發出當日有任何交易，有關之交易佣金及其他收費可能尚未被扣除，請預留足夠款項以免賬戶出現結欠，並導致利息產生。',
      tiquTitle: '資金提取',
      tiquTip: '請核實一下數據並按「確認」。如需更改數據，請按「更改」',
      zhishi: '指示',
      password: '密碼',
      zhizhangzhanghu: '支賬賬戶',
      ruzhangzhanghu: '入賬賬戶',
      change: '更改',
      cofirm: '確認',
      confirmSuccess: '我們已收到你的預設指示。',
      bianhao: '請記錄閣下的參考編號',
      ticunjilu: '查看提存記錄',
      print: '列印',
      formCheck1: '提取金額必須填寫',
      formCheck2: '提取金額不正確',
      formCheck3:
        '閣下指示的提取金額錯誤，正確金額應為HKD1元至1,000,000,000元之間（WC7001）REF：WEB001-1594108496248-22'
    },
    // 汇款服务
    remittanceServices: {
      nav1: '賬戶資料',
      nav2: '申請資訊',
      icbc: '可申請開通銀行之服務：中國工商銀行（亞洲）',
      methods: '申請辦法',
      content2: '客戶可聯絡經紀人索取《申請表》並填寫以下資料:',
      content3: '·海通國際證券賬戶名稱',
      content4:
        '·英文(漢語拼音)姓名 (英文姓名拼音必須正確無誤, 如需協助, 請聯絡閣下經紀人)',
      content5: '·海通國際證券賬戶號碼',
      content6: '·手機號碼',
      content7:
        '填妥表格後, 請交還閣下經紀人進行申請。上述賬戶開啟後, 會以短訊形式通知閣下之境外匯款賬戶號碼。',
      remittance: '成功申請後如何進行轉賬匯款?',
      content8:
        '內地客戶可到中國内地主要商業銀行櫃台向香港工商銀行（亞洲）進行匯款。匯款時請正確填寫收款方資料：',
      content9:
        '收款銀行選擇：Industrial and Commercial Bank of China (Asia) Limited (需填寫英文)',
      content10: '戶口號碼填寫：在海通國際證券開通的工商銀行境外匯款賬戶號碼',
      content11: '戶口持有人姓名填寫：申請服務時填寫的英文姓名（拼音）',
      content12:
        '收款銀行地址請填寫：33/F, ICBC Tower, 3 Garden Road, Central, HK (需填寫英文)',
      content13: 'SWIFT code: UBHKHKHH',
      attention: '注意事項:',
      content14: '境外匯款將收取一定費用，請參考相關銀行資料：',
      content15: '匯款到賬時間以銀行處理進度為準。',
      content16: '内地匯款金額受外管局限額限制，請參考國家有關規定。',
      boc: '可申請開通銀行之服務：中國銀行（香港）有限公司',
      content17:
        '内地客戶完成以下申請後，便可前往任何一家國內銀行辦理境外滙款，簡單方便。',
      methods2: '申請辦法',
      content18: '戶可聯絡經紀人或海通國際網站索取《申請表》並填寫以下資料:',
      content19: '海通國際證券賬戶名稱',
      content20:
        '英文(漢語拼音)姓名 (英文姓名拼音必須正確無誤, 如需協助, 請聯絡閣下經紀人)',
      content21: '海通國際證券賬戶號碼',
      content22: '手機號碼',
      content23:
        '填妥表格後, 請交還閣下經紀人進行申請。上述賬戶開啟後, 會以短訊形式通知閣下之境外匯款賬戶號碼。',
      remittance2: '成功申請後如何進行轉賬匯款?',
      content24:
        '內地客戶可到中國内地主要商業銀行櫃台向中國銀行（香港）有限公司進行匯款。匯款時請正確填寫收款方資料：',
      content25: '收款銀行選擇：Bank of China (Hong Kong) Limited (需填寫英文)',
      content26: '戶口號碼填寫：在海通國際證券開通的中銀香港境外匯款賬戶號碼',
      content27: '戶口持有人姓名填寫：申請服務時填寫的英文姓名（拼音）',
      content28:
        '收款銀行地址請填寫：Bank of China Tower, 1 Garden Road, Central Hong Kong (需填寫英文)',
      content29: 'SWIFT code: BKCHHKHH',
      attention2: '注意事項:',
      content30: '境外匯款將收取一定費用，請參考相關銀行資料：',
      content31: '匯款到賬時間以銀行處理進度為準。',
      content32: '内地匯款金額受外管局限額限制，請參考國家有關規定。',
      dahSing: '可申請開通之銀行服務: 大新銀行',
      content33:
        '内地客戶完成以下申請後，便可前往國內銀行辦理滙款或經中國大新銀行網銀實時滙款至香港大新銀行個人賬戶。',
      methods2: '申請辦法',
      content34: `客戶可在開立大新銀行綜合理財賬戶期間一併登記香港大新銀行網上理財轉賬服務至海通國際於香港大新銀行之賬戶。客戶亦可自行於香港大新銀行網頁(<a  href="http://www.dahsing.com"
      target="_blank" style='color: #4191ff;
      border-bottom: 1px solid #4191ff;'>www.dahsing.com</a>)下載登記表格，填妥後並寄回香港大新銀行辦理申請。`,
      content35:
        '有關辦理開戶手續或辦理匯款手續詳情, 客戶可致電以下之大新銀行客戶服務熱線查詢:',
      content36: '國内: +86 400 882 8893',
      content37: '香港: +852 2828 8000',
      content38: '香港中區分行: +852 2521 8134',
      attention3: '注意事項:',
      content39: '1.綜合理財賬戶接受港幣及美元匯款。',
      content40: '2.境外匯款將收取一定費用，請參考相關銀行資料。',
      content41: '3.内地匯款金額受外管局限額限制，請參考國家有關規定。',
      content42: '4.申請人須已在中國大新銀行內地分行開立貴賓或以上賬戶。'
    },
    // 资金存入
    ePayment: {
      eps: {
        content1:
          '由即日起，客戶可利用「易辦事」於海通國際證券上環客戶服務中心及本港各間分行繳交證券及恒生指數期貨買賣的款項，每日處理高達港幣五萬元的帳項，免除客戶到銀行或開發支票之繁複程序，方便快捷。',
        content2:
          '「易辦事」服務在香港為一盛行已久的電子繳費系統，透過銀行來實現客戶貿及公司的聯繫。因此，客戶在辦理證券買賣繳費時，可直接由自己的銀行戶口付款至海通國際證券的銀行戶口，當中並無涉及任何現金提存。整個交易過程得以簡化，安全程度亦因而提高，無論本公司、客戶甚至銀行也都一同受惠。',
        content3: '如有任何查詢，請致電客戶熱線 (852) 3583-3388 。',
        btn: '返回',
        information1: ' 以',
        link: '易辦事',
        information2: 'EPS於各海通國際各分行繳款。',
        information3: '不適用於澳門分行。'
      }, // 易辦事
      fps: {
        information1: '利用',
        link: '「快速支付系統」(「轉數快」) ',
        information2:
          '轉賬, 交易日 9:00am – 4:00pm 預計2小時內到賬，其他時段及非交日預計下一工作日11:00am前到賬，費用全免。',
        information3:
          ' 是香港金融管理局(「金管局」)於2018年推出的支付金融基建，由香港銀行同業結算有限公司負責運作，在香港以不同貨幣(港元及人民幣)進行支付，全日24小時提供安全、有效率及便捷的支付服務。'
      }, // 转数快
      easyRevolutions: {
        link1: '「易轉數」',
        information1: '服務適用於所有使用透過',
        link2: 'www.htisec.com',
        information2: '使用網上',
        link3: '「繳費灵」',
        information3:
          '作轉賬的海通國際證券客戶。在服務時間內所作之轉賬，款項將',
        red: '即時',
        information4: '存至證券戶口。',
        information5: '進行網上買賣而遇上金額不足時，透過',
        link4: 'www.htisec.com',
        information6: '的',
        link5: '「易轉數」',
        information7: '服務以網上',
        link6: '「繳費灵」',
        information8: '戶口作',
        red1: '即时',
        information9: '轉賬，立即可傳送買賣指令。'
      }, // 易转数
      pps: {
        information1:
          '電話繳費靈用戶於服務時間內致電18033，以五位數字密碼登入並選擇「海通國際證券」商戶編號',
        red1: '9218',
        information2: '進行轉賬，款項將於',
        red2: '下一交易日',
        information3: '存入證券戶口。',
        information4:
          '「繳費灵」用戶如已設「繳費灵」八位數字網上密碼，可於服務時間內透過',
        link1: 'www.ppshk.com',
        link: 'https://www.ppshk.com/index_c.html',
        information5: '進行轉賬，款項將於',
        red3: '下一交易日',
        information6: '更新至證券戶口'
      }, // 缴费灵
      boc: {
        information1:
          '利用中國銀行(香港)服務於網上轉賬，必須從海通國際網上交易內「',
        link1: '中國銀行(香港)智達銀行服務',
        information2: '」登入，以取得足夠資料完成',
        red: '即時',
        information3: '轉賬過程。'
      }, // 中国银行
      hsbc: {
        information1: '於',
        link1: '匯豐銀行網上理財服務網頁',
        link3: 'https://www.hsbc.com.hk/zh-hk/index/',
        information2: '「',
        information3: '銀行服務',
        information4: '」以「',
        information5: '繳付賬單',
        information6: '」繳費。',
        information8: '',
        link2: '按此',
        link4: 'http://www.htisec.com/zh-hk/fund-deposite-withdrawal#select3',
        information7: '參閱繳費詳情。'
      }, // 汇丰银行
      hsb: {
        information1: '於恆生銀行網頁內之「',
        link1: '恆生e-Banking',
        link3: 'https://www.hangseng.com/zh-hk/home/',
        information2: '」,以「',
        information3: '查閱及繳付賬單',
        information4: '」繳費。',
        information6: '',
        link2: '按此',
        link4: 'http://www.htisec.com/zh-hk/fund-deposite-withdrawal#select3',
        information5: '參閱繳費詳情。'
      }, // 恒生银行
      scb: {
        information1: '於',
        link: 'https://www.sc.com/hk/zh/',
        link1: '渣打網上理財',
        information2: '之「',
        information3: '戶口轉賬服務',
        information4: '」下的「',
        information5: '電子繳費',
        information6: '」內付款，款項將於下一交易日存入證券戶口。'
      }, // 渣打银行
      fpsConfiguration: {
        title: '將資金轉賬至海通國際的FPS識別碼',
        fpsCode: 'FPS 識別碼:',
        digital: '167011527',
        collection: '收款銀行:',
        chinaBank: '中國銀行（香港）',
        payee: '收款人名稱:',
        name: 'Haitong International Securities Company Limited',
        guide: 'FPS 轉數快匯款指引',
        return: '返回資金存入主頁',
        nextStep: '下一步',
        attention: '注意事項',
        content:
          '請使用閣下本人同名的銀行賬戶轉賬，不可使用他人銀行賬戶轉賬。目前海通國際不接受由香港銀行櫃台、ATM等渠道直接存入現金的入金，不接受聯名賬戶入金，不接受電子錢包入金。',
        notice: '通知海通國際收款',
        AfterFour: '轉出銀行賬戶末四位：',
        account: '存入賬戶:',
        market: '存入市場:',
        currency: '存入貨幣:',
        amount: '存入金額:',
        return1: '返回',
        queren: '確認',
        instructions: '我們已收到您的快速入金申請指示。',
        record: '請記下參考編號以作紀錄。',
        ReferenceCode: '參考編號：',
        digital1: '9D5909C7',
        wanCheng: '完成',
        print: '列印',
        check: '請輸入您開戶時指定的香港銀行賬戶末四位',
        hkd: '港幣',
        cny: '人民幣',
        head: '快速入金申請結果', //弹框头部
        formCheck1: '存入金額必須填寫',
        formCheck2: '存入金額不正確',
        formCheck3: '閣下指示的存入金額錯誤',
        formCheck4: '銀行卡末四位必須填寫',
        formCheck5: '閣下指示的銀行卡末四位錯誤'
      }
    }
  },
  //我的查询菜单
  myInquiry: {
    // 我的资产
    accoutSummary: {
      market: '市場',
      buypower: '購買力',
      hukoujiecun: '戶口結存',
      keyongjiecun: '可用結存(不包括利息)',
      xianjinjiecun: '現金結存',
      leijilixi: '累積利息',
      zhipiao1: '支票交收(D+1)',
      zhipiao2: '支票交收(D+2) ',
      duiyinghuobi: '對應貨幣',
      xindaie: '信貸額',
      zhengquanshizhi: '證券市值',
      dongjiejine: '凍結金額',
      daijiaoshou1: '待交收(T+1)',
      daijiaoshou2: '待交收(T+2)',
      daijiaoshou3: '待交收(T+N)',
      ancanzhi: '證券按倉值',
      zongzichan: '總資產',
      xianjin: '现金',
      ganggu: '港股',
      agu: 'A股',
      chanwaijiaoyi: '場外交易',
      meigu: '美股',
      keyongjiecun: '可用結存(不包括利息)',
      duihuanlv: '兌換率（只作參考，最後更新時間',
      chicanxiangqing: '持倉詳情',
      gupiao: '股票',
      xianjia: '現價',
      chenben: '成本',
      zongshuliang: '總數量',
      kemaishuliang: '可沽數量',
      cankaoyinkui: '參考盈虧',
      jinriyinkui: '今日盈虧',
      shizhi: '市值',
      ancangzhi: '按倉值',
      caozuo: '操作',
      mairu: '買入',
      maichu: '賣出',
      xiugaichenben: '修改成本',
      jiaoyijilu: ' 交易記錄',
      explianInfo:
        '*是次買入上限(購買力)以香港，中國A股，美國及場外市場內所有貨幣結餘及證券按倉值(孖展戶口適用)的港幣對應值計算。有關其他市場的結存資料(包括中國B股市場或其他市場)，請查閱結單或於交易時段內透過中國B股市場交易平台查閱。',
      gupiaoshuliang: '股票數量',
      pingjunmairujia: '平均買入價',
      pingjunjia: '平均價',
      beizhu: '備註',
      beizhuxiangqin1:
        '1.『平均買入價』、『平均價』、『未實現盈虧』僅作參考用途，海通國際證券有限公司(“海通國際”)不建議客戶以此作為買賣準則。海通國際有權隨時修改計算及/或資料更新時間而無須另行通知。',
      beizhuxiangqin2:
        '2.『平均買入價』、『平均價』、『未實現盈虧』並未計算佣金及交易費用。',
      beizhuxiangqin3:
        '3. 客戶可自行修改『平均價』及『平均買入價』。及後系統會因應賬戶的證券買賣而自動調整『平均價』及『平均買入價』。',
      beizhuxiangqin4:
        '4.『平均買入價』及『平均價』於指定情況下會顯示為“不適用”。',
      beizhuxiangqin5:
        '5.有關『平均買入價』、『平均價』、『未實現盈虧』的定義參閱',
      beizhuanniu: '『平均買入價』及『平均價』說明',
      xinpingjunjia: '新平均價',
      queren: '確認',
      zhishi1: '指示已收到',
      zhishi2: '請於稍後查詢更改指示處理情況'
    },
    // 交易记录(今日记录和历史记录合一起了)
    tradeHistory: {
      title1: '今日記錄',
      title2: '歷史記錄',
      title3: '新股認購',
      title4: '公司行動',
      tradeType: '交易種類',
      all: '所有',
      buy: '買入',
      sell: '賣出',
      stockNum: '股票編號',
      specifyStock: '指定股票',
      Summary: '匯總',
      detailed: '明細',
      recordTime: '記錄直至',
      tradeDate: '交易日期',
      zhi: '至',
      startDate: '開始日期',
      endDate: '結束日期',
      aWeek: '一周',
      aMonth: '一個月',
      threeMonth: '三個月',
      settlementDate: '交收日期',
      market: '市場',
      stock: '股票編號',
      tradeClasify: '交易種類',
      tradeNum: '成交數量',
      currency: '貨幣',
      tradePrice: '成交價格',
      avagPrice: '平均價',
      money: '金額',
      channel: '渠道',
      numId: '參考編號',
      noResult: '沒有交易記錄符合搜尋條件',
      remarks: '備註',
      remark1:
        '1) 金額並不包括經紀傭金、印花稅、交易徵費、聯交所交易費、中央結算費及其他交易費用。',
      remark2: '2) 所有交易項目以結單顯示記錄為準。',
      remark3: '3) 交易記錄查詢功能提供最近12個月的記錄。',
      remark4: '4) 以上查詢並不包括今天的交易記錄。閣下可',
      remarkBtn1: '匯出至Excel',
      remarkBtn2: '打印',
      ipoSub: {
        subscriptionId: '認購編號',
        stockNum: '股票編號',
        biddingPrice: '招股價',
        subscriptionNum: '認購股數',
        subscriptionType: '認購類型',
        subscriptionMoney: '認購金額',
        serviceCharge: '手續費',
        financingRatio: '融资比例',
        rate: '参考利率',
        tradeCost: '交易金额',
        stockNum: '獲配股數',
        tradeChannel: '交易渠道',
        state: '認購狀況',
        action: '操作',
        cancel: '取消',
        cancelIPO: '取消新股認購申請',
        stockName: '新股名稱',
        stockCode: '股票代號',
        zhaogujia: '招股價',
        shengoushuliang: '申購股數',
        shouxufei: '手續費',
        shengoujine: '申購金額',
        rongzibili: '融資比例',
        cankaolilv: '参考利率',
        jiaoyijine: '交易金額',
        tishi: '提示信息方法',
        zhishibianhao: '申購指示編號',
        zhishizhuangkuang: '申購指示狀況',
        password: '密碼',
        tip: '請輸入密碼',
        cofirm: '確認',
        submitSuccess: '取消新股認購申請已提交'
      },
      companyAction: {
        market: '市場',
        all: '所有',
        hkStock: '港股',
        hugutong: '滬股通',
        gangutong: '港股通',
        zhuangtai: '狀態',
        yiqidong: '已啟動',
        yijiezhi: '已截止',
        yishouquan: '已授權',
        yipaifa: '已派發',
        yiwancheng: '已完成',
        leixing: '類型',
        xianjinguxi: '現金股息',
        gupiaoguxi: '股票股息',
        gupiaobianhao: '股票編號',
        zhidinggupiao: '指定股票',
        sousuo: '搜索',
        gupiao: '股票',
        xingdong: '行動描述',
        cankao: '參考編號',
        qudao: '渠道',
        jiezhiriqi: '回復截止日期',
        zhuangtai: '狀態',
        caozuo: '操作',
        editor: '修改',
        xiugai: '公司行動修改',
        cankaobianhao: '參考編號',
        guxi: '每股股息',
        xingujia: '收取新股價',
        jieshi1:
          '根據上述公司宣布，股東有權就有關股息作出以下選擇。請在網上填妥並提交下列指示，或者填妥指示函件，並必須於2018年08月18日前寄回本公司交收部或傳真至（852）2537 7647 或致電經紀人/分行。若屆時未接獲閣下回復，或指示未填寫清楚，則本公司將代為全部收取股票股息。',
        jieshi2: '本人吾等根據上述事項通知貴公司',
        jieshi3: '持有可獲配股息之股數',
        xianjin: '全部現金',
        xingu: '全部新股',
        bufenxianjin: '部分現金部分新股',
        ganyuan: '港元',
        renmingbi: '人民幣',
        meiyuan: '美元',
        xuanze1: '選擇收取現金股息之股數',
        xuanze2: '選擇收取新股股息之股數',
        cofirm: '確認',
        xingdongtijiao: '您的公司行動指示已經受理成功。'
      }
    },
    // 资金记录
    fundMovement: {
      currencyExchangeRecord: {
        title: '貨幣兌換紀錄',
        info:
          '*本平台提供的服務只為便利客戶處理交易和/或任何其他相關交易活動和/或結算，包括但不限於使用該海通賬戶及/或其他海通賬戶中產生的費用和收費。',
        info1: '*平台中的「CNY」符號是指離岸人民幣的相關報價。',
        state: '兌換狀態',
        all: '所有',
        inProgress: '處理中',
        accept: '已接受',
        refused: '已拒絕',
        date1: '日期',
        oneWeek: '一周',
        oneMonth: '一個月',
        threeMonths: '三個月',
        record: '記錄直至',
        date2: '兌換指示接收日期',
        date3: '結算日期',
        market1: '市場 (賣出)',
        currency: '賣出貨幣',
        amount: '賣出金額',
        market2: '市場 (買入)',
        currency1: '買入貨幣',
        amount1: '買入金額',
        huiLv: '兌換匯率',
        code: '參考編號',
        state1: '狀態',
        disclaimer: '免責聲明',
        content1:
          '海通國際證券集團有限公司及其子公司及其職員，代表或代理人（“海通”）對您因訪問、使用或無法訪問或無法使用本平台及其提供的服務而造成的任何損失，損害或傷害不承擔任何責任；除非海通通過本平台提供服務時存在欺詐或故意不當行為。',
        content2:
          '您清楚明白亦接受使用服務時或會出現傳輸延遲或失敗、以電子方式進行的任何傳輸中斷或停頓；您同意海通不對此類或任何由此造成的損失，損害或傷害承擔責任。',
        content3:
          '本平台提供的信息和材料不構成出售要約或徵求購買任何貨幣的要約，且不得被依賴作出任何投資決策。 必要時請諮詢獨立建議。'
      },
      escrowRecords: {
        title: '資金提存記錄',
        date1: '日期',
        oneWeek: '一周',
        oneMonth: '一個月',
        threeMonths: '三個月',
        record: '記錄直至',
        date2: '交易日期',
        date3: '入賬日期',
        code1: '參考編號',
        market: '市場',
        instructions: '說明',
        number: '數量',
        currency: '貨幣',
        amount: '金額',
        note: '備註',
        content: '1) 所有交易項目以結單顯示記錄為準。',
        content1: '2) 交易記錄查詢功能提供最近12個月的記錄。'
      }
    },
    // 证券提存
    stockMovement: {
      market: '市場',
      allMarket: '所有',
      hkAUSAsotck: '香港，中國A股，美國及場外市場',
      cnBStock: '中國B股',
      otherMarket: '其它市場',
      project: '項目',
      securities: '證券',
      futures: '期貨',
      date1: '日期',
      oneWeek: '一周',
      oneMonth: '一個月',
      threeMonths: '三個月',
      code: '股票',
      stock: '指定股票',
      record: '記錄直至',
      date2: '交易日期',
      date3: '入賬日期',
      code1: '參考編號',
      query: '查詢項目',
      instructions: '說明',
      code2: '證券代號',
      number: '數量',
      currency: '貨幣',
      amount: '金額',
      note: '備註',
      content: '1) 所有交易項目以結單顯示記錄為準。',
      content1: '2) 交易記錄查詢功能提供最近12個月的記錄。'
    },
    // 我的结单
    myStatement: {
      type: '結單類型',
      all: '所有',
      dayStatement: '日結單',
      monthlyStatement: '月結單',
      date: '日期',
      oneWeek: '一周',
      oneMonth: '一個月',
      threeMonths: '三個月',
      time: '時間',
      file: '戶口編號',
      type2: '結單類型',
      download: '下載'
    },
    // 我的报表
    myReport: {
      code: '基金代碼',
      date: '日期',
      oneWeek: '一周',
      oneMonth: '一個月',
      threeMonths: '三個月',
      name: '報告名稱',
      time: '時間',
      file: '報告文件',
      allDownload: '下載全部報告',
      download: '下載',
      start: '開始日期',
      to: '至 ',
      end: '結束日期'
    }
  },
  //我的设定
  mySettings: {
    //个人资料
    changeParticulars: {
      //baseStep
      gerenziliao: '个人資料',
      back: '返回',
      next: '下一步',
      confirm: '確認',
      choose: '請選擇',
      shoutiPhone: '手提電話',
      guojiahaoma: '國家及地區號碼',
      dianhuahaoma: '電話號碼',
      youbian: '郵編',
      tianxieyoubian: '填写郵編 (如有)',
      dizhi: '地址',
      tianxiedizhi: '填写地址',
      email: '電子郵箱',
      inputEmail: '填写電子郵箱',
      shouquhukou: '收取戶口結單方式(如需要更改收取戶口結單方式請選擇以下選項)',
      shouqufangshi: '收取方式',
      dianzijiedan: '收取電子結單',
      youjijiedan: '收取郵寄結單',
      jiedanyuyan: '結單語言',
      en: '英文',
      cn: '簡體',
      hk: '繁體',
      editorMore: '修改更多資料',
      explain:
        '吾等會盡快（在任何情況下，在30天內）向貴公司提供所需的額外文件，包括但不限於更新資料變更後的自我證明。如本人／吾等未能在指定時間內提供所需的額外文件，本人／吾等明白貴公司可能根據有關的資料變更向相關司法管轄區內的合資格監管及／或政府當局（包括但不限於美國國家稅務局、美國財政部和香港稅務局）披露及／或提交本人/吾等之相關賬戶資料，以符合FATCA、《共同匯報標準條例》和其他相關法規、守則和規則的規定。',
      explian1: '· 網上更改資料只接受個人賬戶客戶。',
      explian2: '· 本公司將於下一個工作天收到閣下的指示。',
      explian3: '· 如需修改住宅地址，請填妥及交回',
      aLink1: '更改資料及易結單服務表格',
      explian4: '· 如需修改指定銀行戶口，請填妥及回',
      aLink2: '更改/新增指定銀行戶口表格',
      explian5: '· 請輸入英文或中文通訊地址。',
      explian6:
        '· 更改的資料會更新閣下存於以下公司的記錄: 海通國際證券有限公司、海通國際期貨有限公司、海通國際資產管理有限公司、海通國際投資經理有限公司、海通資產管理(香港)有限公司、海通國際創富理財有限公司、HTI Advisory Company Limited 及海通國際財務有限公司。',
      explian7: '重要提示',
      explain8:
        '· 客戶若更改手提電話或同時更改通訊地址及電郵地址，客戶服務部在收到閣下的更改資料指示後，將致電閣下進行電話確認。如未能成功聯絡或確認，閣下的賬戶服務和交易功能將被暫停。閣下如需重啟交易賬戶，須致電客戶服務部以作電話確認，本公司亦有可能要求閣下重新遞交更改指示。',
      //detailStep
      zhuzhaidianhua: '住宅電話',
      bangongdianhua: '辦公室電話',
      chuanzhenhaoma: '傳真號碼',
      jiaoyuchengdu: '教育程度及職業資料',
      jiaoyu: '教育程度',
      zhiye: '職業',
      guzhuming: '僱主名稱',
      tianxieguzhu: '填写僱主名稱',
      congyenianfen: '從業年數',
      qingtianxie: '請填寫',
      zhiwei: '職位',
      tianxiezhiwei: '填写職位',
      caiwuziliao: '財務資料',
      zhuwu: '住屋',
      caifulaiyuan: '持續財富來源',
      laiyuanxuanze:
        '薪金及/或花紅|儲蓄|業務收入|退休金|遺贈或禮物|投资回报|其他',
      laiyuanqita: '請說明',
      caifuzhuanyi: '持續資金來源(a)資金轉移方式',
      zhuanyixuanze: '現金|電匯|支票/銀行本票|其他',
      caifulaiyuandi: '持續資金來源(b)資金來源地',
      laiyuandixuanze: '香港|中國|美國|其他',
      zongshouru: '每年總收入',
      jingzichan: '凈流動資產值:',
      touzimudi: '投資經驗及目的',
      touzijingyan: '投資經驗',
      touzijinyanxuanze:
        '没有|證券|認股權證|期權|期貨|外匯|貴金屬|基金|其他衍生工具',
      touzinianfen: '投資經驗年資:',
      touzinianfenxuanze: '没有|一至三年|三至五年|五至十年|超過十年',
      touzimudi: '投資目的',
      touzimudixuanze: '資本增長|定期收入|對沖|投機|其他',
      cofirmInfo: '請確認以下修改的資料',
      tijiaozhishi: '您修改的資料已提交',
      zhishixinxi: '指示將於下壹個工作天收到',
      educaitionLevel: '小學或以下/中學/大專或以上',
      occupation:
        '會計/法律/審計|廣告|農業|藝術/媒體|銀行/金融|美容/保健|生物科技/醫藥|公務員|企業|顧問|設計|教育|工程|家庭主婦|人力資源|工業|保險|投資|物流|市場營銷|醫療|采購|印刷|物業|公共關系|零售/批發|退休|科技|電訊|貿易|運輸|待業|其他',
      house: '自置物業/按揭物業/租用物業/宿舍/與家人同住',
      changeInformationLink: 'http://www.htisec.com/zh-hk/form-download/1782',
      bankFormLink: 'http://www.htisec.com/zh-hk/form-download/1782'
    },
    //更改密码
    changePassword: {
      oldPassword: '旧密碼',
      oldPasswordTip: '請輸入旧密碼',
      newPassword1: '新密碼',
      newPassword1Tip: '請輸入新密碼',
      newPassword2: '确认新密碼',
      newPassword2Tip: '請再次輸入新密碼',
      attention: '注意事項',
      attentionInfo:
        '*密碼必須是數字(0-9)+英文字母 ( A - Z, a - z ) 之組合，合計8-10位，新密碼將即時生效於所有電子交易渠道。',
      confirm: '確認',
      changePassword: '更改密碼',
      updatePassword: '密碼已經更新'
    },
    //密码确认
    passwordConfirm: {
      state: '「要求密碼確認」狀態',
      started: '已啟動',
      editor: '修改「要求密碼確認」設定',
      adapt: '（適用於網上證券交易平台）',
      loginName: '登入名稱',
      startedInfo: '啟動「要求密碼確認」步驟',
      cancelInfo: '取消「要求密碼確認」步驟',
      cancelTip: '請細閱取消「要求密碼確認」步驟之聲明',
      cancelTitle: '取消「要求密碼確認」步驟之聲明',
      cancelExpian1:
        '本人現授權海通國際證券有限公司於本人名下之證券戶口, 取消一切在進行發出證券交易新盤、更改及刪除指示、轉賬及提款指示時所需重新輸入「要求密碼確認」步驟。',
      cancelExpian2:
        '本人清楚明白及願意承擔, 取消「要求密碼確認」步驟可能引起之一切額外風險, 並同意貴公司毋須就本人放棄使用上述之步驟所遭受之損失承擔任何責任。此外, 本人瞭解在完成證券交易後或在離開電腦前應先行「登出」證券戶口並關閉有關系統, 避免他人使用本人的證券戶口交易、轉賬或閱覽賬戶資料。',
      tip:
        '# 證券交易新盤、更改及刪除指示的取消「要求密碼確認」步驟只適用於香港、中國A股、美國及場外交易。',
      password: '密碼',
      inputPassword: '请输入密碼',
      confirm: '確認',
      passwordConfirm: '密碼確認',
      changeSuccess: '「要求密碼確認」步驟修改成功'
    },
    //信贷额申请
    marginApplication: {
      customName: '客戶姓名',
      accountId: '賬戶號碼',
      existCredit: '現有信貸額',
      currentMargin: '現有證券抵押值',
      newCredit: '申請信貸額',
      currency: '港幣',
      wan: '萬',
      customData:
        '如您申請的額度超過800萬港幣, 請填寫申請的金額。 根據您的信用記錄以及在海通國際的持倉及賬戶余額, 我們為您準備了預設額度, 如您申請的額度超過預設額度或者申請的額度在800萬港幣以上,我們將派專人與您跟進。',
      totalIncome: '每年總收入(港幣)',
      job: '職業',
      currentAsset: '淨流動資產(港幣)',
      incomeFrom: '財富來源',
      profitVal: '稅後利潤估值(港幣)',
      netAssetVal: '資產淨值(港幣)',
      suppleInfo: '補充信貸資料',
      action: '注意事項',
      explian1:
        '1.	該項信貸申請只適用於海通國際證劵有限公司(下稱“本公司”或“海通國際”)開立之保證金證劵網上交易賬戶，而閣下授予本公司之《證劵常設授權》必須仍然生效，否則有關申請將被拒絕。',
      explian2:
        '2.	信貸額度乃本公司給予該保證金證劵網上交易賬戶的保證金貸款額度上限，賬戶之實際購買力的計算方法是參照當時賬戶內之現金餘額及證劵按倉值的總和。',
      // explian3:
      //   '3.	此信貸額度只適用於在香港聯合交易所有限公司上市或交易之證劵。如欲申請提升美股交易之信貸額度，請聯絡閣下之客戶經理。',
      // explian4:
      //   '4.	若申請額度超過賬戶資產淨值之4倍，客戶須提供最近三個月內之收入 / 資產證明文件副本，並將相關文件傳真至(852) 2526-7612 或電郵至 credit@htisec.com，否則申請將被自動拒絕。如有查詢，請與信貸管理部聯絡 (852)2801-2657。',
      explian5:
        '3.	海通國際有絕對酌情權因應客戶之財務狀況或信貸記錄的變更，隨時對已批出的信貸額度作出檢討及調整而不作另行通知。',
      explian6:
        '4.	在審批客戶之信貸額度申請，海通國際會考慮的因素包括但不限於客戶的信貸紀錄、股票抵押品的質素、波動性、流通性、最新市況、賬戶資產及證劵按倉值。本公司有絕對酌情權拒絕任何申請或批出較客戶申請為低之信貸額度。',
      // explian7:
      //   '7.	本公司只於香港交易日辦理信貸申請。於非交易日提交之信貸申請，將於下一交易日辦理。',
      // explian8:
      //   '8.	本公司將透過手機短訊形式及/或電郵通知客戶有關申請結果，若客戶於本公司並無任何手機或電郵登記記錄，本公司則會有專人致電通知客戶有關申請結果。',
      explian9:
        '5.	閣下應明白藉存放抵押品而為交易取得融資的虧損風險可能極大，客戶可能會在短時間內被要求存入額外的保證金款項。',
      explian10:
        '6.	如閣下未能在指定的時間內支付所需的保證金及/或利息，客戶的部份或所有證券可能在不獲通知的情況下被強制出售。',
      privateAgree:
        '本人已閱讀及暸解注意事項及確認所提供的問卷資料在提供當時均屬真確。',
      companyAgree: '本人已閱讀及暸解注意事項。',
      marginApply: '更改信貸額',
      comfirmTip: '请請檢查以下資料無誤，方作確認提交。',
      caiwuInfo: '根據您的信用記錄以及在海通國際的持倉及賬戶余額，您的帳戶',
      caiwuInfo1: '信貸額將更改至港幣$',
      caiwuInfo2: '(即時生效)。',
      caiwuInfo3: '您是否同意提交申請？',
      cancel: '修改',
      confirm: '確認',
      submitInfor: '您為賬戶',
      submitInfor1: '於',
      submitInfor2: '申請了更改信貸額至港幣$',
      submitInfor3: '已通過審批。',
      submitInfor4: '提交了更改信貸額的申請。現已完成審批，您現有信貸額為港幣$',
      submitTip: '相關申請參考編號為：'
    },
    //投资者风险取向问卷
    investProfile: {
      info:
        '於進行任何投資交易前，請完成風險取向問卷以更新您的投資風險取向記錄。',
      input: '開始填寫',
      chuli: '您的風險取向問卷正在處理中。',
      orientation: '投資風險取向',
      assessment: '場外衍生工具知識評估',
      content1: '如需更新您的投資風險取向記錄，请',
      content2: '按此',
      content3: '完成風險取向問卷',
      content4: '根據您最近一次的風險評估記錄，您的風險取向為',
      content5: '保守',
      content6: '中度保守',
      content7: '平穩',
      content8: '中度進取',
      content9: '進取',
      content10: '投資風險評估總分:',
      content11: '投資風險取向:',
      content12: '有效日期至:',
      content13: '2020-03-11',
      content14: '是否具備金融衍生工具的知識:',
      content15: '是',
      content16: '否',
      content17: '根據您最近一次的場外衍生工具知識評估記錄，您',
      content18: '不具備金融衍生工具的知識',
      content19: '具備金融衍生工具的知識',
      answer: '請回答所有問題',
      prompt: '您的投資風險取向問卷已提交',
      jiaoyuLink: 'http://www.htisec.com/zh-hk/investor-education',
      conservative:
        '根據閣下/貴公司於第三題的答案，閣下/貴公司的主要投資目標為保本，因此閣下/貴公司的風險取向將被評定為保守',
      digital: '請輸入8位數字',
      prompt1: '閣下的金融衍生工具交易經驗與所提供的不配對，請返回修改。',
      // 个人问卷
      personalQuestionnaire: {
        questionnaire: '投資風險取向問卷',
        title: '個人/聯名投資取向問卷',
        name: '姓名：',
        account: '賬戶號碼：',
        content:
          '本問卷旨在幫助我們確定和評估閣下的風險取向、投資經驗和是否具備衍生工具知識。我們將會根據閣下所提供的資料，評估閣下是否了解個別投資產品的性質和風險。聯名賬戶的賬戶持有人須個別填妥一份問卷，以風險取向較低者為準。本問卷共分為兩部份，如閣下不欲投資衍生產品，閣下只須填妥第一部份風險取向，第二部份衍生工具知識評估則不用填寫。',
        important: '重要事項：',
        info:
          '閣下的風險取向是根據您在此問卷所有問題的答案整合得出，而非基於閣下就任何個別問題給予的答案（第3條除外） 。在回答閣下的財務或投資資料的問題時，例如可投資資產金額或交易資料，閣下的答案應基於您在本行、其他證券行、銀行及金融機構所持全部資產及交易，而不單限於本行持有資產及交易。',
        oneContent: '第一部分：風險取向',
        oneInfo:
          '此部分收集閣下之財務狀況、投資態度及投資經驗以評估閣下對風險的承受能力。請在適當的選項內勾選並回答全部13條問題。',
        one: '1 您的教育程度？',
        oneA: 'A. 小學以下',
        oneB: 'B. 小學',
        oneC: 'C. 中學',
        oneD: 'D. 大專或以上',
        two:
          '2 您現時有否供養家庭成員？ 如有，請問多少名家庭成員需要閣下供養？',
        twoA: 'A. 4名或以上',
        twoB: 'B. 3名',
        twoC: 'C. 2名或以下',
        three: '3 您的投資目的是？',
        threeA:
          'A. 我的主要投資目標是保本，不願意接受投資於任何時候有任何虧損。（請注意：所有投資均涉及投資風險。如您不願意接受任何投資於任何時候有任何虧損，並只希望本公司根據此問題的答案，而非本問卷的全部答案去評估您的風險取向，您屬於一個保守型的投資者，您比較適合傳統保守產品。） （如答A，請直接到第5題。）',
        threeB:
          'B. 我的主要投資目標是獲得少量回報並願意接受於投資期限內有輕微虧損，但對投資有中度至大幅虧損感到不安。（請注意：如您只願意接受輕微虧損，並只希望本公司根據此問題的答案去評估您的風險取向，您將不會被評定為一個中度進取或進取型的投資者。）',
        threeC:
          'C. 我的主要投資目標是獲得中度回報並願意接受於投資期限內有中度虧損，但會對投資有大幅虧損感到不安。',
        threeD:
          'D. 我的主要投資目標是獲得大幅回報並願意接受於投資期限內有大幅波動及投資價值虧損。',
        four: '4 您願意投資於波幅多大的投資產品？',
        fourA: 'A. 介乎–5%至+5%之間的波幅',
        fourB: 'B. 介乎–10%至+10%之間的波幅',
        fourC: 'C. 介乎–20%至+20%之間的波幅',
        fourD: 'D. 介乎–20%以上至+20%以上之間的波幅',
        five:
          '5 平均來說，您每月可動用的資金有多少？[可動用資金的定義：可動用資金指扣除稅項、退休金供款及必需開支（例如按揭供款或租金、汽車貸款、保險、食品、衣履、照顧兒童或長者和水、電、煤、差餉等開支）後剩餘的金額（包括銀行存款、工資、股息、花紅等）]',
        fiveA: 'A. 4,000至15,000港元',
        fiveB: 'B. 15,001至60,000港元',
        fiveC: 'C. 60,001至100,000港元',
        fiveD: 'D. 超過100,000港元',
        six: '6 您是否依靠投資回報以應付您供養家庭成員的日常開支？',
        sixA: 'A. 是，超過20%',
        sixB: 'B. 是，超過10%至20%',
        sixC: 'C. 是，超過0%至10%',
        sixD: 'D. 否',
        seven: '7 您可用作投資的金額佔每月收入百分比為多少？',
        sevenA: 'A. 超過0%至10%',
        sevenB: 'B. 超過10%至25%',
        sevenC: 'C. 超過25%至50%',
        sevenD: 'D. 超過50%',
        eight:
          '8 您的儲備金額大約可應付多少個月的基本家庭開支及滿足額外的抵押要求？',
        eightA: 'A. 少於3個月',
        eightB: 'B. 3個月至少於6個月',
        eightC: 'C. 6個月至少於9個月',
        eightD: 'D. 9個月或以上',
        nine: '9 買賣投資產品時，您可以接受的投資年期是多少？',
        nineA: 'A. 1年或以下',
        nineB: 'B. 1年以上至5年',
        nineC: 'C. 5年以上至10年',
        nineD: 'D. 超過10年',
        ten: '10 在過往一年，您曾執行過多少次交易？',
        tenA: ' A. 少於5次交易',
        tenB: ' B. 5至10次交易',
        tenC: ' C. 11至20次交易',
        tenD: ' D. 超過20次交易',
        eleven: '11 您對金融市場和投資的認識有多少？',
        elevenA: 'A. 沒有認識：我對金融市場和投資完全沒有任何認識。',
        elevenB:
          'B. 低水平：我對金融市場只有一些基本知識，例如股票和債券的分別。',
        elevenC:
          'C. 中等水平：達基本知識以上的水平，明白分散投資的重要性，並作出分散投資（即把資金配置於不同類別的投資，以分散風險）。',
        elevenD:
          'D. 高水平：我懂得閱讀一家公司的財務報告（即損益表及資產負債表），並明白影響股票和債券價格的因素。',
        elevenE:
          'E. 精通：我熟識大部分金融產品（包括債券、股票、認股權證、期權及期貨），並明白可能影響這些金融產品的風險和表現的各項因素。',
        twelve:
          '12 您的淨流動資產值是（包括您所有現金及投資組合總和（不包括物業價值）再減去結欠如私人貸款及信用卡結欠（不包括物業貸款））：',
        twelve1: '估計淨流動資產值：港幣 $：',
        thirteen:
          '13 在下表中，請選出您曾經參與的投資產品（如適用，可選擇多於一項）',
        thirteen1: '交易經驗年數',
        thirteen2: '無',
        thirteen3: '有限',
        thirteen4: '良好',
        thirteen5: '豐富',
        thirteen6: '產品',
        thirteen7: '認股權證／牛熊證',
        thirteen8: '交易所買賣基金',
        thirteen9: '結構性產品（例如：保本或非保本產品）',
        thirteen10: '槓桿及反向產品',
        thirteen11: '期貨／期權',
        thirteen12: '上市股票',
        thirteen13: '場外衍生工具（例如：場外期權）',
        thirteen14: '股票沽空',
        thirteen15: '證券配售',
        thirteen16: '外幣',
        thirteen17: '互惠基金／單位信託基金',
        thirteen18: '對沖基金／私募股權基金',
        thirteen19: '債券',
        note: '備註：',
        note1: '1. 如您之前不具備相關知識／經驗或對此不確定，請選擇「無」。',
        note2:
          '2. 問題13內填報的各種投資產品之交易經驗年數將被視為客戶的最新投資經驗年數。',
        twoContent: '第二部分：衍生工具知識評估',
        twoInfo:
          '此部分旨在協助評估您是否具備衍生工具知識。本公司將根據您所提供資料，評估您是否了解衍生產品的性質和風險。請在適當的選項內勾選並回答全部問題。',
        one1: '1 您對金融衍生工具的認知？',
        one2: '沒有：我不具備金融衍生工具的知識，亦沒有興趣了解這方面的知識。',
        one3:
          '少許認知：我只具備金融衍生工具的一些基本知識，例如傳統投資工具如股票等與衍生工具屬於不同類型資產。',
        one4:
          '中等認知：我具備基本以上的知識及明白金融衍生工具的價值可因應相關資產的價值而波動及其升跌幅度可大於傳統投資工具。我懂得如何閱讀金融衍生工具合約或銷售文件的條款及細則及明白影響金融衍生工具價格的一般因素。',
        one5:
          '非常認知：我熟悉大部分金融衍生工具及在過往多年經常買賣金融衍生工具。',
        two1: '2 您對以下金融衍生工具的投資經驗（可選擇多於一項）？',
        two2:
          '香港或海外上市的金融衍生工具（如期貨合約、商品合約、期權及認股權證等）',
        two3:
          '場外結構性產品或金融衍生工具（如結構性／可換股債券、信貸掛鈎票據、商品掛鈎票據及股票掛鈎票據等）',
        two4: '對沖基金或廣泛地投資於金融衍生工具以達到投資目的的基金',
        two5: '其他 （請註明）： ',
        two6: '沒有 （如答沒有，請直接到第4題。）',
        three1:
          '3 您有否在過去3年間就問題2所述產品（不論是否於交易所買賣）執行5項或以上交易？',
        three2: '有;請註明：',
        three3: '金融機構名稱：',
        three4: '總交易金額：',
        three5: '沒有',
        four1:
          '4 您有否曾經接受及／或參加由學術機構或金融機構所提供有關上述衍生工具及／或結構性產品的在線或面授形式培訓及／或課程，而閣下亦完全了解這類投資產品的性質和風險？',
        four2:
          '有，我已透過貴公司網站有關債券、埸內及場外衍生工具之培訓短片了解相關產品的性質和風險',
        four3: '日期：',
        four4: '驗證碼：',
        four5: '按此觀看投資者教育短片',
        four6: '有，有關培訓及／或課程由以下提供機構提供',
        four7: '機構名稱：',
        four8: '課程名稱：',
        five1:
          '5 您有否擁有1年以上有關上述衍生工具及／或結構性產品的工作經驗？',
        five2: '公司名稱：',
        five3: '部門名稱：',
        five4: '工作性質：',
        five5: '任職年期',
        prompt:
          '本人明白如問卷內填寫的內容不實，海通國際將不能評估所要求服務是否適合本人。',
        submit: '提交'
      },
      // 公司问卷
      groupQuestionnaire: {
        title: '公司投資取向問卷',
        name: '公司名稱：',
        account: '賬戶號碼：',
        content:
          '本問卷旨在幫助我們確定和評估貴公司的風險取向、投資經驗和是否具備衍生工具知識。我們將會根據貴公司所提供的資料，考慮貴公司的獲授權人是否了解個別投資產品的性質和風險。本問卷共分為兩部份，如貴公司不欲投資衍生產品，貴公司只須填妥第一部份風險取向，第二部份衍生工具知識評估則不用填寫。',
        important: '重要事項：',
        info:
          '貴公司的風險取向是根據貴公司的獲授權人在此問卷所有問題的答案整合得出，而非基於貴公司的獲授權人就任何個別問題給予的答案（第3條除外）。在回答貴公司的財務或投資資料的問題時，例如可投資資產金額或交易資料，貴公司的獲授權人的答案應基於貴公司在本行、其他證券行、銀行及金融機構所持全部資產及交易，而不單限於本行持有資產及交易。',
        oneContent: '第一部分：風險取向',
        oneInfo:
          '此部分收集貴公司之財務狀況、投資態度及獲授權人的投資經驗以評估貴公司對風險的承受能力。請在適當的選項內勾選並回答全部13條問題。',
        one:
          '1 貴公司屬私人公司並由公司持有人負責投資決定或貴公司屬具規模公司並由投資團隊負責投資決定？',
        oneA: 'A. 本公司屬私人公司並由公司持有人負責投資決定',
        oneB: 'B. 本公司屬具規模公司並由投資團隊負責投資決定',
        two: '2 有關貴公司的企業架構、實質的投資程序及監控措施：',
        twoA:
          'A. 本公司設有由具備勝任能力及適當資格的專業人士組成的專責投資委員會，負責投資策略及投資程序；及 (i) 該委員會代表本公司作出投資決定或 (ii) 本公司在作出有根據的投資決定時會考慮該委員會的意見或建議；',
        twoB:
          'B. 本公司內部設有由具備勝任能力及適當資格的專業人士組成的庫務、投資或類似職能，負責投資策略及投資程序；',
        twoC:
          'C. 本公司委聘由具備勝任能力及適當資格的專業人士組成的外部投資顧問團隊，負責投資策略及投資程序；及 (i) 該團隊代表本公司者作出投資決定或 (ii) 本公司在作出有根據的投資決定時會考慮該團隊的意見或建議；',
        twoD:
          'D. 本公司依據及遵循其有連繫法團的投資策略、意見及建議，該有連繫法團： (i) 設有內部庫務、投資或類似職能； (ii) 設有專責投資委員會；或 (iii) 委聘符合上述的條件的外部投資顧問團隊；',
        twoE: 'E. 以上四項皆沒有',
        three: '3 投資產品價值下跌對貴公司有何影響？',
        threeA:
          'A. 本公司的主要目標是保本，不願意接受投資於任何時候有任何虧損。（請注意：所有投資均涉及投資風險。如貴公司不願意接受任何投資於任何時候有任何虧損，並只希望本公司根據此問題的答案，而非本問題的全部答案去評估貴公司的風險取向，貴公司屬於保守型的投資者。）（如答A，請直接到第5題。）',
        threeB:
          'B. 本公司接受於投資期限內有輕微虧損，但對投資有中度至大幅虧損感到不安。',
        threeC:
          'C. 本公司願意接受於投資期限內有中度虧損，但會對投資有大幅虧損感到不安。',
        threeD:
          'D. 本公司願意接受於投資期限內有大幅波動及投資價值虧損，以獲得最高長期潛在回報。',
        four: '4 貴公司願意投資於波幅多大的投資產品？',
        fourA: 'A. 介乎–5%至+5%之間的波幅',
        fourB: 'B. 介乎–10%至+10%之間的波幅',
        fourC: 'C. 介乎–20%至+20%之間的波幅',
        fourD: 'D. 介乎–20%以上至+20%以上之間的波幅',
        five:
          '5 貴公司的負債與總資本比率現為多少？（負債與總資本比率定義為：（流動負債總額 + 非流動負債總額）／有形淨值）',
        fiveA: 'A. 高於200%',
        fiveB: 'B. 100.1%與200%之間',
        fiveC: 'C. 50.1%與100%之間',
        fiveD: 'D. 20.1%與50%之間',
        fiveE: 'E. 低於20%',
        six: '6 買賣投資產品時，貴公司可以接受的投資年期是多少？',
        sixA: 'A. 1年或以下',
        sixB: 'B. 1年以上至5年',
        sixC: 'C. 5年以上至10年',
        sixD: 'D. 超過10年',
        seven:
          '7 貴公司在最近五年的純利狀況是？（如屬非牟利機構，請以淨現金流量代替純利走勢）',
        sevenA: 'A. 非常不穩定',
        sevenB: 'B. 不穩定',
        sevenC: 'C. 尚算穩定',
        sevenD: 'D. 穩定並與經濟增長看齊',
        sevenE: 'E. 穩定並領先經濟增長',
        eight:
          '8 貴公司現時是否持有以下任何投資產品？（如為多項，請選擇最高分數的一項）',
        eightA: 'A. 現金、存款',
        eightB: 'B. 債券、債券基金',
        eightC: 'C. 股票、開放式基金、非保本投資產品',
        eightD: 'D. 認股權證（窩輪）、期權、期貨',
        nine: '9 在過往一年，貴公司曾執行過多少次交易？',
        nineA: 'A. 少於5次交易',
        nineB: 'B. 5至10次交易',
        nineC: 'C. 11至20次交易',
        nineD: 'D. 超過20次交易',
        ten:
          '10 貴公司期望每年的投資回報率為多少？ 一般來說，風險與回報通常成正比。回報越高，所負擔的風險越高。',
        tenA: 'A. 5%或以下',
        tenB: 'B. 6% - 15%',
        tenC: 'C. 16% - 25%',
        tenD: 'D. 25%以上',
        eleven: '11 貴公司各獲授權人對金融市場和投資的整體認識有多少？',
        elevenA:
          'A. 沒有認識：本公司各獲授權人對金融市場和投資完全沒有任何認識。',
        elevenB:
          'B. 低水平：本公司各獲授權人對金融市場只有一些基本知識，例如股票和債券的分別。',
        elevenC:
          'C. 中等水平：本公司各獲授權人達基本知識以上的水平，明白分散投資的重要性，並作出分散投資（即把資金配置於不同類別的投資，以分散風險）。',
        elevenD:
          'D. 高水平：本公司各獲授權人懂得閱讀一家公司的財務報告（即損益表及資產負債表），並明白影響股票和債券價格的因素。',
        twelve:
          '12 貴公司的可投資資產的總值是 （包括貴公司所有投資組合總和（不包括物業價值）及現金再減去公司任何貸款及債務的金額（不包括物業貸款）） ：',
        twelve1: '估計可投資資產的總值： 港幣 $：',
        thirteen:
          '13 在下表中，請選出貴公司各獲授權人曾經參與的投資產品（如適用，可選擇多於一項）',
        thirteen1: '交易經驗年數',
        thirteen2: '無',
        thirteen3: '有限',
        thirteen4: '良好',
        thirteen5: '豐富',
        thirteen6: '產品',
        thirteen7: '認股權證／牛熊證',
        thirteen8: '交易所買賣基金',
        thirteen9: '結構性產品（例如：保本或非保本產品）',
        thirteen10: '槓桿及反向產品',
        thirteen11: '期貨／期權',
        thirteen12: '上市股票',
        thirteen13: '場外衍生工具（例如：場外期權）',
        thirteen14: '股票沽空',
        thirteen15: '證券配售',
        thirteen16: '外幣',
        thirteen17: '互惠基金／單位信託基金',
        thirteen18: '對沖基金／私募股權基金',
        thirteen19: '債券',
        note: '備註：',
        note1:
          '1. 如貴公司各獲授權人之前不具備相關知識／經驗或對此不確定，請選擇「無」。',
        note2:
          '2. 問題13內填報的各種投資產品之交易經驗年數將被視為客戶的最新投資經驗年數。',
        twoContent: '第二部分：衍生工具知識評估',
        twoInfo:
          '此部分旨在協助評估貴公司各獲授權人整體上是否具備衍生工具知識。本公司將根據貴公司所提供資料，評估貴公司各獲授權人整體上是否了解衍生產品的性質和風險。請在適當的選項內勾選並回答全部問題。',
        one1: '1 貴公司各獲授權人整體上對金融衍生工具的認知？',
        one2:
          '沒有，本公司各獲授權人整體上不具備金融衍生工具的知識，亦沒有興趣了解這方面的知識。',
        one3:
          '少許認知，本公司各獲授權人整體上只具備金融衍生工具的一些基本知識，例如傳統投資工具如股票等與衍生工具屬於不同類型資產。',
        one4:
          '中等認知，本公司各獲授權人整體上具備基本以上的知識及明白金融衍生工具的價值可因應相關資產的價值而波動及其升跌幅度可大於傳統投資工具。我們懂得如何閱讀金融衍生工具合約或銷售文件的條款及細則及明白影響金融衍生工具價格的一般因素。',
        one5:
          '非常認知，本公司各獲授權人整體上熟悉大部分金融衍生工具及在過往多年經常買賣金融衍生工具。',
        two1:
          '2 貴公司各獲授權人整體上對以下金融衍生工具的投資經驗（可選擇多於一項）？',
        two2:
          '香港或海外上市的金融衍生工具（如期貨合約、商品合約、期權及認股權證等）',
        two3:
          '場外結構性產品或金融衍生工具（如結構性／可換股債券、信貸掛鈎票據、商品掛鈎票據及股票掛鈎票據等）',
        two4: '對沖基金或廣泛地投資於金融衍生工具以達到投資目的的基金',
        two5: '其他 （請註明 ）： ',
        two6: '沒有 （如答沒有，請直接到第4題。）',
        three1:
          '3 貴公司各獲授權人整體上有否在過去3年間就問題2所述產品（不論是否於交易所買賣）執行5項或以上交易？',
        three2: '有;請註明：',
        three3: '金融機構名稱：',
        three4: '總交易金額：',
        three5: '沒有',
        four1:
          '4 貴公司各獲授權人整體上有否曾經接受及／或參加由學術機構或金融機構所提供有關上述衍生工具及／或結構性產品的在線或面授形式培訓及／或課程，而你們亦完全了解這類投資產品的性質和風險？',
        four2:
          '有，我/我們已透過貴公司網站有關債券、場內及場外衍生工具之培訓短片了解相關產品的性質和風險 ',
        four3: '日期：',
        four4: '驗證碼：',
        four5: '按此觀看投資者教育短片',
        four6: '有，有關培訓及／或課程由以下提供機構提供',
        four7: '機構名稱：',
        four8: '課程名稱：',
        five1:
          '5 貴公司各獲授權人整體上有否擁有1年以上有關上述衍生工具及／或結構性產品的工作經驗？',
        five2: '公司名稱：',
        five3: '部門名稱：',
        five4: '工作性質：',
        five5: '任職年期：',
        prompt:
          '本人／吾等明白如問卷內填寫的內容不實，海通國際將不能評估所要求服務是否適合本人。',
        submit: '提交'
      }
    },
    //中华通北向交易同意书
    consentForConnnect: {
      title: '中華通北向交易同意書',
      title1: '有關中華通證券北向交易的個人資料收集聲明',
      content1:
        '除非下文另有界定，本有關中華通證券北向交易的個人資料收集聲明(「本個人資料收集聲明」)所用詞彙與本公司的[現金]賬戶條款和條件及其附件所規定的定義具有相同涵義。若本個人資料收集聲明的英文本與中文本在解釋或意義方面有任何歧義，以英文版本為準。',
      content2: '處理個人資料作為北向交易的一部份',
      content3:
        '閣下確認並同意本公司為閣下提供透過互聯互通進行中華通證券北向交易服務將須:',
      content4:
        'i.	在閣下每個送達內地互聯互通系統的訂單，附加本公司為閣下或為閣下的聯名戶口(如適用)編派唯一的券商客戶編碼(「BCAN」或「券商客戶編碼」)。',
      content5:
        'ii.	就聯交所根據交易所規則可能提出的要求，向聯交所提供閣下的劵商客戶編碼及有關閣下的識別資料(「CID」或「客戶識別信息」)。',
      content6:
        '不限於任何本公司已向閣下發出的提示或本公司已從閣下收到同意就有關閣下戶口或本公司提供的服務而處理閣下的個人資料，閣下確認並同意本公司為閣下提供透過中華通進行中華通證券北向交易服務可能須要收集、儲存、使用、披露及轉移有關閣下的個人資料，包括:',
      content7:
        'a.	不時向聯交所及相關聯交所子公司披露及轉移券商客戶編碼及客戶識別信息，包括在提交內地互聯互通系統的中華通訂單中附加上券商客戶編碼，再實時轉遞至相關中華通市場營運者；',
      content8:
        'b.	允許聯交所及每一個相關聯交所子公司 (i) 收集、使用及儲存閣下的券商客戶編碼、客戶識別信息及任何由相關中國結算提供已綜合、認可及配對的券商客戶編碼及客戶識別信息（由任何一方或透過香港交易所儲存），用作市場監控和監察目的及執行交易所規則；(ii) 基於以下(c)及(d)項列出之目的不時向中華通市場營運者（直接或透過中國結算）轉移此等資料；及(iii) 向在香港的相關監管機構及執法機關披露此等資料，以助他們履行有關香港證券市場的監控、監察及執法職能；',
      content9:
        'c.	允許中國結算(i) 收集、使用及儲存閣下的券商客戶編碼及客戶識別信息，以便綜合及認可券商客戶編碼與客戶識別信息，並將此類信息與其本身的投資者身份數據庫進行配對，以提供該已綜合、認可及配對的券商客戶編碼及客戶識別信息給中華通市場營運者、聯交所和相關聯交所子公司；(ii) 使用閣下的券商客戶編碼及客戶識別信息來協助其履行證券賬戶管理的監管職能;及(iii) 向管轄中國結算的內地監管機構及執法機關披露此等資料，以助他們履行有關內地證券市場的監控、監察及執法職能；',
      content10:
        'd.	允許中華通市場營運者(i) 收集、使用及儲存閣下的券商客戶編碼及客戶識別信息，以助其就互聯互通下在相關中華通市場進行的證券交易進行監管與監察及執行中華通市場營運者規則；及(ii) 向內地的監管機構及執法機關披露此等資料，以助他們履行有關內地證券市場的監管、監察及執法職能；',
      content11:
        '在指示本公司進行有關中華通證券交易時，閣下確認並同意本公司可就提供透過互聯互通進行中華通證券北向交易服務為遵從聯交所的要求或不時生效的聯交所規則使用閣下的個人資料。閣下同時確認即使閣下往後撤回同意，閣下的個人資料不論在上述撤回同意前或後仍可能會為上述目的繼續被儲存、使用、披露、轉移及處理。',
      content12: '未能提供個人資料或同意的後果',
      content13:
        '如閣下未能提供上述個人資料或同意給本公司，可導致本公司不能或無法繼續執行閣下的交易指示或提供北向交易服務。',
      content14: '確認並同意',
      content15:
        '本人確認本人已閱讀及清楚本有關中華通證券北向交易的個人資料收集聲明。在以下格上勾選，本人表示同意或拒絕海通國際證券集團有限公司及其附屬公司(「海通國際證券集團」或「貴司」)根據本個人資料收集聲明所述的條款及目的使用本人的個人資料。',
      content16:
        '本人同意海通國際證券集團根據本個人資料收集聲明所述的目的使用本人的個人資料。',
      content17:
        '本人拒絕海通國際證券集團根據本個人資料收集聲明所述的目的使用本人的個人資料並確認海通國際證券集團將無法繼續執行本人的交易指示或提供北向交易服務。本人進一步確認:',
      content18:
        '本人沒有提供類似同意給任何其他證券商、銀行或金融機構根據本個人資料收集聲明所述的目的使用本人的個人資料。',
      content19:
        '本人有提供類似同意給任何其他證券商、銀行或金融機構根據本個人資料收集聲明所述的目的使用本人的個人資料，而本人拒絕海通國際證券集團根據本個人資料收集聲明所述的目的使用本人的個人資料的原因為：',
      content20:
        '如本人未能提供任何原因/解釋或本人上述之原因/解釋不能令貴司合理滿意，貴司有權堅持索取本人的同意，且在本人未作出該等同意之前海通國際證券集團有權不再執行本人下達的任何中華通訂單。',
      confirm: '確認',
      cancel: '取消',
      content21: '閣下的中華通證券北向交易個人資料收集聲明已成功提交。',
      content22:
        '閣下的中華通證券北向交易個人資料收集聲明未能成功提交, 請稍後再重試或聯絡海通國際客戶服務部。熱線電話: (852) 3583 3388 (香港) / (86) 755 8266 3232 (中國內地)。',
      content23: '關閉窗口',
      ipt: '請填寫',
      prompt: '下次登錄時不要提醒我'
    }
  }
}
