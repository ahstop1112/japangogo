<!--日期选择控件-->
<template>
  <div class="date-wrap">
    <span class="time-slelector heavyColor">
      <el-date-picker @change="onChange" v-model="vModel2" :type="type" :picker-options="pickerBeginDateBefore" :style="styleCss" :value-format="valueFormat" :format="format" :placeholder="startPlaceholder" :clearable="clearable" :editable="editable" :disabled="disabled"></el-date-picker>
      <i class="iconfont icon-date"></i>
      {{ rangeSeparator
    }}<el-date-picker @change="onChange" v-model="vModel1" :type="type" :picker-options="pickerBeginDateAfter" :style="styleCss" :value-format="valueFormat" :format="format" :placeholder="endPlaceholder" :clearable="clearable" :editable="editable" :disabled="disabled"></el-date-picker>
      <span class="icon-wrap"><i class="iconfont icon-date icon-date1"></i></span>
    </span>
    <div class="time" v-if="isShow">
      <span class="heavyColor" v-for="(item,index) in xuanxiang" :key="index" @click="fn(index)" :class="{active:index==isShowtime}">{{item}}</span>
    </div>
  </div>

</template>

<script>
import timeSelector from "./timeSelector.scss"

export default {
  props: {
    isShow: {
      type: Boolean,
      default: true
    },
    change: {
      type: Object,
      default: function () {
        return {

        }
      }
    },
    startPlaceholder: {
      type: String,
      default: ''
    },
    endPlaceholder: {
      type: String,
      default: ''
    },
    rangeSeparator: {
      type: String,
      default: ''
    },
    clearable: {
      type: Boolean,
      default: true
    },
    editable: {
      type: Boolean,
      default: false
    },
    disabled: {
      type: Boolean,
      default: false
    },
    type: {
      type: String,
      default: 'date'
    },
    valueFormat: {
      type: String,
      default: 'yyyy-MM-dd'
    },
    styleCss: {
      type: String,
      default: 'width:160px !important;'
    },
    format: {
      type: String,
      default: 'yyyy-MM-dd'
    },
  },
  data() {
    return {
      vModel1: '',
      vModel2: '',
      xuanxiang: [this.$t('myInquiry.myReport.oneWeek'), this.$t('myInquiry.myReport.oneMonth'), this.$t('myInquiry.myReport.threeMonths')],
      isShowtime: NaN,
      pickerBeginDateBefore: {
        disabledDate: time => {
          if (this.vModel2) {
            let hm =
              new Date(this.vModel2.substr(0, 10) + ' 23:59:59').getTime() -
              new Date(this.vModel2).getTime()
            let endDT = new Date(this.vModel2).getTime() + hm
            if (endDT) {
              return time.getTime() > endDT
            }
          }
        }
      },
      pickerBeginDateAfter: {
        disabledDate: time => {
          if (this.vModel1) {
            let hm =
              new Date(this.vModel1).getTime() -
              new Date(this.vModel1.substr(0, 10) + ' 00:00:00').getTime()
            let beginDT = new Date(this.vModel1).getTime() - hm
            if (beginDT) {
              return time.getTime() < beginDT
            }
          }
        }
      }
    }
  },
  methods: {
    msToDateStr(ms) {
      const date = new Date(ms)
      const y = date.getFullYear()
      const m = date.getMonth() + 1
      const d = date.getDate()

      return `${y}-${m < 10 ? '0' : ''}${m}-${d < 10 ? '0' : ''}${d}`
    },
    fn(e) {
      const start = new Date();
      console.log(start);
      var zhou = start.getTime() - 3600 * 1000 * 24 * 7;   // 获取一周以后的时间戳
      var yue = start.getTime() - 3600 * 1000 * 24 * 30;   // 获取一个月以后的时间戳
      var jidu = start.getTime() - 3600 * 1000 * 24 * 90;   // 获取三个月以后的时间戳

      this.isShowtime = e;
      if (this.xuanxiang[e] == this.xuanxiang[0]) {
        this.vModel1 = this.msToDateStr(start.getTime());    //对时间选择器赋值   一周以后的时间-今天的时间
        this.vModel2 = this.msToDateStr(zhou);
      } else if (this.xuanxiang[e] == this.xuanxiang[1]) {
        this.vModel1 = this.msToDateStr(start.getTime());  //对时间选择器赋值   一周以后的时间-今天的时间
        this.vModel2 = this.msToDateStr(yue);
      } else if (this.xuanxiang[e] == this.xuanxiang[2]) {
        this.vModel1 = this.msToDateStr(start.getTime());  //对时间选择器赋值   一周以后的时间-今天的时间
        this.vModel2 = this.msToDateStr(jidu);
      }
      this.$emit('change', [this.vModel1, this.vModel2])
    },
    onChange() {
      this.$emit('change', [this.vModel1, this.vModel2])
    }
  }
}
</script>