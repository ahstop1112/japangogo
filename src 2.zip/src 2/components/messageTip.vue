<template>
    <div class="message-content messageBgColor">
      {{content}}
    </div>
</template>

<script>
import messageTip from "./messageTip.scss"

export default {
  props: {
    content: ""
  },  
  data () {
    return {
    };
  },
  methods: {},
  mounted(){},

}

</script>