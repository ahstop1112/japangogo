<!--下单页面-->
<template>
  <div class="trading-content">
      <ul class="trading-wrap">
        <li class="trading-item">
          <span class="text mediumColor">
             <span class="type">{{$t('security.mainMarket.type')}}</span>
             <span class="tip"><i class="iconfont icon-detail"></i></span>
          </span>
          <span class="val">
            <el-select class="trading-type" v-model="type">
              <el-option
                  v-for="item in tradingType"
                  :key="item.value"
                  :label="item.label"
                  :value="item.value">
              </el-option>
            </el-select>
          </span>
        </li>
        <li class="trading-item">
          <span class="text mediumColor">{{$t('security.mainMarket.code')}}</span>
          <span class="val">
            <span class="right-input">
                <el-autocomplete
                class="ipt"
                v-model="code"
                :fetch-suggestions="querySearchAsync" 
                placeholder="00665"
                @select="handleSelect"
                ></el-autocomplete>
                <span class="icons contentLeftBorder">
                   <img src="@/assets/img/search.png" />
                </span>
            </span>
          </span>
        </li>
        <li class="trading-item" v-if="type != 2">
          <span class="text mediumColor">{{$t('security.mainMarket.prc')}}</span>
          <span class="val">
            <el-input-number v-model="price" @change="handleChange1" :step="0.01" :min="0"></el-input-number>
            <el-dropdown class="contentAllBorder" size="medium" trigger="click" >
              <span class="el-dropdown-link">
                <i class="el-icon-arrow-down el-icon--right heavyColor"></i>
              </span>
              <el-dropdown-menu slot="dropdown">
                 <el-dropdown-item>{{$t('security.mainMarket.price1')}}</el-dropdown-item>
                 <el-dropdown-item v-if="curMarket == 'A-shareTrading'">{{$t('security.mainMarket.price2')}}</el-dropdown-item>
                 <el-dropdown-item v-if="curMarket == 'A-shareTrading'">{{$t('security.mainMarket.price3')}}</el-dropdown-item>
              </el-dropdown-menu>
            </el-dropdown>
          </span>
        </li>
        <li class="trading-item" v-if="type == 4">
          <span class="text mediumColor">{{$t('security.mainMarket.condition')}}</span>
          <span class="val">
            <el-select class="trading-type" v-model="condition">
              <el-option :label="$t('security.mainMarket.condition1')" value="up"></el-option>
              <el-option :label="$t('security.mainMarket.condition2')" value="down"></el-option>
            </el-select>
          </span>
        </li>
        <li class="trading-item" v-if="type == 4">
          <span class="text mediumColor">{{$t('security.mainMarket.chufaPrice')}}</span>
          <span class="val">
            <el-input-number v-model="chufaPrice" @change="handleChange1" :step="0.01" :min="0"></el-input-number>
          </span>
        </li>
        <li class="trading-item">
          <span class="text mediumColor">{{$t('security.mainMarket.nums')}}</span>
          <span class="val">
            <el-input-number v-model="num" @change="handleChange1" :step="100" :min="0"></el-input-number>
            <el-dropdown class="contentAllBorder" size="medium" trigger="click"  @command="handleCommand">
              <span class="el-dropdown-link">
                <i class="el-icon-arrow-down el-icon--right heavyColor"></i>
              </span>
              <el-dropdown-menu slot="dropdown">
                <el-dropdown-item command="a">1/4</el-dropdown-item>
                <el-dropdown-item command="b">1/3</el-dropdown-item>
                <el-dropdown-item command="c">1/2</el-dropdown-item>
                <el-dropdown-item command="d">{{$t('security.mainMarket.whole')}}</el-dropdown-item>
              </el-dropdown-menu>
            </el-dropdown>
          </span>
        </li>
        <li class="trading-item" v-if="curMarket == 'A-shareTrading'">
          <span class="text mediumColor">{{$t('security.mainMarket.custormId')}}</span>
          <span class="val">
            <el-input v-model="custormId"></el-input>
          </span>
        </li>
        <li class="expain">
          <div class="max-buy"  v-if="orderType =='buy' || orderType =='all' ">
             <span class="txt mediumColor">{{$t('security.mainMarket.maxBuy')}}</span>
              <span class="num activeFontColor">3000</span>
          </div>
          <div class="max-sell "  v-if="orderType =='sell' || orderType =='all' ">
             <span class="txt mediumColor">{{$t('security.mainMarket.maxSell')}}</span>
              <span class="num">0</span>
          </div>
        </li>
      </ul>
      <div class="btn-wrap">
          <div class="allOrCancel">
            <el-checkbox v-model="isCancel">{{curMarket == 'usTrading'?$t('security.mainMarket.aon1'):$t('security.mainMarket.aon2')}}</el-checkbox>
          </div>  
          <div class="buyOrSell">
             <el-button class="buy" v-if="orderType =='buy' || orderType =='all' " type="primary" @click="openNextWrap('buy')">{{$t('security.mainMarket.buys')}}</el-button>
             <el-button class="sell" v-if="orderType =='sell' || orderType =='all' " type="warning" @click="openNextWrap('sell')">{{$t('security.mainMarket.guchu')}}</el-button>
          </div>
      </div>  
    </div>
</template>

<script>
import orderPannel from "./orderPannel.scss"

export default {
  data () {
    return {
      type: "1",
      code:"00665 海通国际",
      price:'2.600',
      condition:"up",
      chufaPrice:"2.600",
      num:"100",
      custormId:"",
      isCancel: false,
    };
  },
  props: {
    orderType: '',
    curMarket:'',//当前的市场 hkTrading usTrading A-shareTrading
  },
  computed: {
    //根据不同的市场加载不同类型的
    tradingType() {
        let  curMarket = this.curMarket;
        let orgArr = [
            {
                label: this.$t('security.mainMarket.type1'),
                value:"1",
                type:"hkTrading,A-shareTrading",//哪些市场可用
            },
            {
                label: this.$t('security.mainMarket.type3'),
                value:"2",
                type:"hkTrading",
            },
            {
                label: this.$t('security.mainMarket.type4'),
                value:"3",
                type:"hkTrading",
            },
            {
                label: this.$t('security.mainMarket.type5'),
                value:"4",
                type:"hkTrading",
            },
            {
                label: this.$t('security.mainMarket.type2'),
                value:"5",
                type:"usTrading",
            }
        ];
        for(let i=orgArr.length-1;i >=0;i--) {
            if(orgArr[i].type.indexOf(curMarket) == -1) {
                orgArr.splice(i,1);
            }
        }
        if(!orgArr.length) {
          return;
        }
        //默认赋值第一个数
        this.type = orgArr[0].value;
        return orgArr
    }    
  },
  methods: {
    handleCommand(command) {
      console.log(command)
    },
    handleChange1(val) {
      console.log(val)
    },
    handleSelect(item) {
        console.log(item);
    },
    querySearchAsync(queryString, cb) {
        console.log(queryString)
    },
    openNextWrap(type) {
        this.$emit('goToNextStep',type);
    },
  },
  mounted(){

  }
}

</script>