<!--页面顶部导航组件-->
<template>
    <div class="router-wrap contentBg">
      <el-scrollbar class="el-scrollbar">
        <div class="router-item" v-for="(item,index) in routerArr" :key="index" >
            <router-link active-class="activeColor" class="lightColor" tag="a" :to="{name: item.path}" exac>
                <img :src="item.img"  v-if="item.img"/>
                <span class="txt">{{item.name}}</span>
            </router-link>
        </div>       
      </el-scrollbar>   
    </div>
</template>

<script>
import pageNav from "./pageNav.scss"

export default {
  props: {
    routerArr: {},    //对象数组 @params 如 img require("@/assets/img/flag_HK@2x.png"), name:"港股交易",path:"hkTrading"
  },  
  data () {
    return {
        
    };
  },
  methods: {},
  mounted(){},

}

</script>