<!--证券交易中的搜索框组件-->
<template>
  <div class="search-box">
    <el-autocomplete
        class="ipt"
        v-model="input"
        :fetch-suggestions="querySearchAsync"
        :placeholder="placeholderVal"
        @select="handleSelect"
        :trigger-on-focus= "false"
    ></el-autocomplete>
    <span class="icons contentLeftBorder">
        <img src="@/assets/img/search.png" />
    </span>
  </div>
</template>

<script>
import { getSearchAsset } from "@/api/security"
import searchBox from "./searchBox.scss" 

export default {
  props: {
      curMarket:'',//当前的市场 hkTrading A-shareTrading  usTrading
      isShowInput: false,//是否在输入框显示选中的结果
      placeholderVal: {
          type: String,
          default: '00665'
      },
      inInput:'',//传入的Input值
  },  
  watch: {
    inInput(val) {
        this.input = val;
    }
  },
  data () {
    return {
        input:"",
    };
  },
  methods: {
    querySearchAsync(queryString, cb) {
        if(queryString == "") {
            return;
        }
        let curMarket = this.curMarket;
        let mktCode = "";
        curMarket == 'hkTrading'?mktCode = 'HK':curMarket == 'A-shareTrading'?mktCode = 'SH':mktCode = 'US';
        let parmas = {
            "params": {
                key: queryString,
                mktCode: mktCode,
                limit:""
            }
        }
        getSearchAsset(
            parmas
        ).then(res => {
            let stocks = res.result;
            let result = stocks.map(item => {
                return {
                    assetId: item.assetId,
                    value: item.stkCode +" "+ item.stkName,
                    stkCode: item.stkCode,
                    secType: item.secType,//港股 类型   1-股票 2-债券 3-基金 4-涡轮 5-指数 6-牛熊证 0-其他 7-界内证 
                }    
            })
            cb(result);
        }).catch(error => {
            //console.log(error)
        })
    },
    handleSelect(item) {
        this.$emit('handleSelect', item);
        if(this.isShowInput) {
            this.input =  item.value;
            return;
        }
        this.input = "";
    },
  },
  mounted(){

  },
}

</script>