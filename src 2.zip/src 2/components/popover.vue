<!--弹出框信息-->
<template>
  <transition name="popover">
    <div class="popover-wrap" v-show="showPopover">
      <div class="bg" @touchmove.prevent></div>
      <div class="layout">
        <div class="popover-content contentBg">
          <div class="popover-title contentBorder" :style="{'background': titleBgColor}" :class="titleBgColor == '#fff'?'':'noBorder'">
            <span class="text" :class="titleBgColor == '#fff'?'':'otherColor'">{{ title }}</span>
            <span class="iconfont icon-close close" :class="titleBgColor == '#fff'?'':'otherColor'" @click="closePopover"></span>
          </div>
          <div class="content" ref="contentWrap">
            <el-scrollbar style="height:100%">
              <slot></slot>
            </el-scrollbar>
          </div>
        </div>
      </div>
    </div>
  </transition>
</template>

<script>
import { mapGetters } from 'vuex'
import popover from "./popover.scss"

export default {
  props: {
    title: '',
    titleColor: '',
    showPopover: true,
    isFirst: true,//当前的步骤信息
  },
  data() {
    return {
      titleBgColor: '#fff'
    }
  },
  computed: {
    ...mapGetters(['getBgColor']),
  },
  watch: {
    showPopover(val) {
      if (val) {
        this.stopMove();
        this.setTitleBgColor();
        this.$nextTick(() => {
          this.calcContentHeight();
        })
      } else {
        this.Move();
      }
    },
    isFirst(val) {
      if (!this.isFirst) {
        this.$nextTick(() => {
          this.$refs.contentWrap.style.height = 'auto';
        })
      }
    }
  },
  //避免用户在弹出框里面跳转路由造成页面不能滚动
  beforeDestroy() {
    this.Move();
  },
  methods: {
    setTitleBgColor() {
      if (this.titleColor) {
        this.titleBgColor = this.titleColor;
      } else {
        this.getBgColor == 'bg-anhei' ? this.titleBgColor = '#333' : this.titleBgColor = '#fff';
      }
    },
    calcContentHeight() {
      this.$refs.contentWrap.style.height = 'auto';
      //计算元素的滚动高度，只有超出可视区域的高度才显示滚动条
      let maxHeight = document.documentElement.clientHeight - 80;
      let contentHeight = this.$refs.contentWrap.offsetHeight;
      if (contentHeight >= maxHeight) {
        this.$refs.contentWrap.style.height = maxHeight + 'px';
      }
    },
    closePopover() {
      this.$emit('close')
    },
    //停止页面滚动
    stopMove() {
      let m = function (e) {
        e.preventDefault();
      };
      document.body.style.overflow = 'hidden';
      //document.addEventListener("touchmove",m,{ passive:false });//禁止页面滑动
      // this.$emit('change', [this.vModel1, this.vModel2])
    },
    //开启页面滚动
    Move() {
      let m = function (e) {
        e.preventDefault();
      };
      document.body.style.overflow = '';//出现滚动条
      // document.removeEventListener("touchmove",m,{ passive:true });
    }
  },
  mounted() {

  }
}
</script>