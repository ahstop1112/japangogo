<!--功能模块的title-->
<template>
  <div class="title-wrap contentBorder">
      <span class="text activeFontColor">{{title}}</span>
      <slot></slot>
  </div>
</template>

<script>
import mainTitle from "./mainTitle.scss"

export default {
  data () {
    return {
    };
  },
  props: {
      title: ""
  },
  methods: {},
  mounted(){},

}

</script>