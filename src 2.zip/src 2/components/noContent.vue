<!--没有内容的时候显示图标加文案-->
<template>
  <div class="noContent-wrap" :style="{height: height}">
    <div class="layout-content">
       <img src="@/assets/img/default_no content@2x.png" :width="width"/>
       <span class="text lightColor">{{content}}</span>   
    </div>
  </div>
</template>

<script>
import noContent from "./noContent.scss"

export default {
  props: {
    content: "" ,//显示的内容
    height:"",  //可显示区域高度
    width: {
      type: String,
      default: "183",
    }//图片显示的宽度
  },  
  data () {
    return {
       
    };
  },
  methods: {},
  mounted(){},

}

</script>