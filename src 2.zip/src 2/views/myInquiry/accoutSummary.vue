<!--我的资产(我的查询)-->
<template>
  <div class="account-summary">
    <transactionComponent :curMarket="curMarket" :tradType="tradType" :showTradingWrap="showTradingWrap" @closeTradingWrap='closeTradingWrap' />
    <popover :title="$t('myInquiry.accoutSummary.xiugaichenben')" @close="closePopover" :showPopover="showPopover" :isFirst="firstStep">
      <div class="first-wrap" v-if="firstStep">
        <ul class="base-info">
          <li class="info-item">
            <span class="txt mediumColor">{{$t('myInquiry.accoutSummary.market')}}</span>
            <span class="val heavyColor">港股</span>
          </li>
          <li class="info-item">
            <span class="txt mediumColor">{{$t('myInquiry.accoutSummary.gupiao')}}</span>
            <span class="val heavyColor">211 STYLAND HOLD</span>
          </li>
          <li class="info-item">
            <span class="txt mediumColor">{{$t('myInquiry.accoutSummary.gupiaoshuliang')}}</span>
            <span class="val heavyColor">5000</span>
          </li>
          <li class="info-item">
            <span class="txt mediumColor">{{$t('myInquiry.accoutSummary.pingjunmairujia')}}</span>
            <span class="val heavyColor">HKD 6.400</span>
          </li>
          <li class="info-item">
            <span class="txt mediumColor">{{$t('myInquiry.accoutSummary.pingjunjia')}}</span>
            <span class="val heavyColor">HKD 6.400</span>
          </li>
        </ul>
        <div class="explain-wrap mediumColor">
          <div class="explain-title">{{$t('myInquiry.accoutSummary.beizhu')}}:</div>
          <div class="explain-item">{{$t('myInquiry.accoutSummary.beizhuxiangqin1')}}</div>
          <div class="explain-item">{{$t('myInquiry.accoutSummary.beizhuxiangqin2')}}</div>
          <div class="explain-item">{{$t('myInquiry.accoutSummary.beizhuxiangqin3')}}</div>
          <div class="explain-item">{{$t('myInquiry.accoutSummary.beizhuxiangqin4')}}</div>
          <div class="explain-item">{{$t('myInquiry.accoutSummary.beizhuxiangqin5')}}<a class="activeFontColor" :href="linkUrl" target="_blank">{{$t('myInquiry.accoutSummary.beizhuanniu')}}</a>。</div>
        </div>
        <div class="avg-wrap contentTopBorder">
          <span class="txt mediumColor">{{$t('myInquiry.accoutSummary.xinpingjunjia')}}</span>
          <span class="val">
            <el-input v-model="newAvgVal"></el-input>
          </span>
        </div>
        <div class="confirm-btn">
          <el-button type="primary" @click="goToSuccess">{{$t('myInquiry.accoutSummary.queren')}}</el-button>
        </div>
      </div>
      <div class="second-wrap" v-else>
        <div class="layout-wrap">
          <div class="success-wrap">
            <span class="icons"><i class="iconfont icon-status_success activeFontColor"></i></span>
            <span class="text activeFontColor">{{$t('myInquiry.accoutSummary.zhishi1')}}</span>
          </div>
          <div class="success-info heavyColor">{{$t('myInquiry.accoutSummary.zhishi2')}}</div>
        </div>
      </div>
    </popover>
    <el-row class="topRow" :gutter="gutter">
      <el-col class="elCol" :lg="12" :md="24" :sm="24" :xs="24">
        <div class="left-wrap contentBg">
          <el-row class="account-detail">
            <el-col class="account-wrap contentRightBorder" :md="12" :sm="12" :xs="24">
              <ul class="left-accout">
                <li class="accout-item">
                  <span class="txt mediumColor" style="flex: 0 0 100px">{{$t('myInquiry.accoutSummary.market')}}</span>
                  <span class="val heavyColor">香港，中國A股，美國及場外市場</span>
                </li>
                <li class="accout-item">
                  <span class="txt mediumColor">{{$t('myInquiry.accoutSummary.buypower')}}</span>
                  <span class="val heavyColor">950,283.96</span>
                </li>
                <li class="accout-item">
                  <span class="txt mediumColor">{{$t('myInquiry.accoutSummary.hukoujiecun')}}</span>
                  <span class="val heavyColor">110,000.24</span>
                </li>
                <li class="accout-item">
                  <span class="txt mediumColor">{{$t('myInquiry.accoutSummary.keyongjiecun')}}</span>
                  <span class="val heavyColor">95,283.96</span>
                </li>
                <li class="accout-item">
                  <span class="txt mediumColor">{{$t('myInquiry.accoutSummary.xianjinjiecun')}}</span>
                  <span class="val heavyColor">110,000.24</span>
                </li>
                <li class="accout-item">
                  <span class="txt mediumColor">{{$t('myInquiry.accoutSummary.leijilixi')}}</span>
                  <span class="val heavyColor">0.21</span>
                </li>
                <li class="accout-item">
                  <span class="txt mediumColor">{{$t('myInquiry.accoutSummary.zhipiao1')}}</span>
                  <span class="val heavyColor">0.00</span>
                </li>
                <li class="accout-item">
                  <span class="txt mediumColor">{{$t('myInquiry.accoutSummary.zhipiao2')}}</span>
                  <span class="val heavyColor">0.00</span>
                </li>
              </ul>
            </el-col>
            <el-col class="account-wrap" :md="12" :sm="12" :xs="24">
              <ul class="left-accout">
                <li class="accout-item">
                  <span class="txt mediumColor">{{$t('myInquiry.accoutSummary.duiyinghuobi')}}</span>
                  <span class="val heavyColor">HKD</span>
                </li>
                <li class="accout-item">
                  <span class="txt mediumColor">{{$t('myInquiry.accoutSummary.xindaie')}}</span>
                  <span class="val heavyColor">不適用</span>
                </li>
                <li class="accout-item">
                  <span class="txt mediumColor">{{$t('myInquiry.accoutSummary.zhengquanshizhi')}}</span>
                  <span class="val heavyColor">52,400.00</span>
                </li>
                <li class="accout-item">
                  <span class="txt mediumColor">{{$t('myInquiry.accoutSummary.dongjiejine')}}</span>
                  <span class="val heavyColor">4,936.28</span>
                </li>
                <li class="accout-item">
                  <span class="txt mediumColor">{{$t('myInquiry.accoutSummary.daijiaoshou1')}}</span>
                  <span class="val heavyColor">0.00</span>
                </li>
                <li class="accout-item">
                  <span class="txt mediumColor">{{$t('myInquiry.accoutSummary.daijiaoshou2')}}</span>
                  <span class="val heavyColor">0.21</span>
                </li>
                <li class="accout-item">
                  <span class="txt mediumColor">{{$t('myInquiry.accoutSummary.daijiaoshou3')}}</span>
                  <span class="val heavyColor">-54,780.00</span>
                </li>
                <li class="accout-item">
                  <span class="txt mediumColor">{{$t('myInquiry.accoutSummary.ancanzhi')}}</span>
                  <span class="val heavyColor">39,300.00</span>
                </li>
              </ul>
            </el-col>
          </el-row>
        </div>
      </el-col>
      <el-col class="elCol" :lg="12" :md="24" :sm="24" :xs="24">
        <div class="right-wrap">
          <el-row class="echart-detail" :gutter="gutter">
            <el-col class="echart-wrap" :md="12" :sm="12" :xs="24">
              <div class="layout contentBg">
                <div class="echart-title mediumColor">{{$t('myInquiry.accoutSummary.zongzichan')}}</div>
                <div class="echart" ref="pieChart1"></div>
                <ul class="echart-info">
                  <li class="info-item heavyColor">
                    <span class="icons yellow"></span>
                    <span class="text">{{$t('myInquiry.accoutSummary.xianjin')}}</span>
                    <span class="num noLine">64,633.91</span>
                  </li>
                  <li class="info-item heavyColor">
                    <span class="icons purple"></span>
                    <span class="text">{{$t('myInquiry.accoutSummary.ganggu')}}</span>
                    <span class="num">
                      <el-popover placement="right-start" trigger="hover">
                        <div class="wrap">
                          <div class="classify-money">
                            <span class="classify-name mediumColor">HKD</span>
                            <span class="classify-num heavyColor">996.00</span>
                          </div>
                          <div class="classify-money">
                            <span class="classify-name mediumColor">CNY</span>
                            <span class="classify-num heavyColor">157,123.00</span>
                          </div>
                          <div class="classify-money">
                            <span class="classify-name mediumColor">USD</span>
                            <span class="classify-num heavyColor">2,130.81</span>
                          </div>
                        </div>
                        <em class="jiecun-num" slot="reference">95,283.96</em>
                      </el-popover>
                    </span>
                  </li>
                  <li class="info-item heavyColor">
                    <span class="icons red"></span>
                    <span class="text">{{$t('myInquiry.accoutSummary.agu')}}</span>
                    <span class="num">
                      <el-popover placement="right-start" trigger="hover">
                        <div class="wrap">
                          <div class="classify-money">
                            <span class="classify-name mediumColor">HKD</span>
                            <span class="classify-num heavyColor">996.00</span>
                          </div>
                          <div class="classify-money">
                            <span class="classify-name mediumColor">CNY</span>
                            <span class="classify-num heavyColor">157,123.00</span>
                          </div>
                          <div class="classify-money">
                            <span class="classify-name mediumColor">USD</span>
                            <span class="classify-num heavyColor">2,130.81</span>
                          </div>
                        </div>
                        <em class="jiecun-num" slot="reference">57.60</em>
                      </el-popover>
                    </span>
                  </li>
                  <li class="info-item heavyColor">
                    <span class="icons brown"></span>
                    <span class="text">{{$t('myInquiry.accoutSummary.chanwaijiaoyi')}}</span>
                    <span class="num">
                      <el-popover placement="right-start" trigger="hover">
                        <div class="wrap">
                          <div class="classify-money">
                            <span class="classify-name mediumColor">HKD</span>
                            <span class="classify-num heavyColor">996.00</span>
                          </div>
                          <div class="classify-money">
                            <span class="classify-name mediumColor">CNY</span>
                            <span class="classify-num heavyColor">157,123.00</span>
                          </div>
                          <div class="classify-money">
                            <span class="classify-name mediumColor">USD</span>
                            <span class="classify-num heavyColor">2,130.81</span>
                          </div>
                        </div>
                        <em class="jiecun-num" slot="reference">431.20</em>
                      </el-popover>
                    </span>
                  </li>
                  <li class="info-item heavyColor">
                    <span class="icons blue"></span>
                    <span class="text">{{$t('myInquiry.accoutSummary.meigu')}}</span>
                    <span class="num">
                      <el-popover placement="right-start" trigger="hover">
                        <div class="wrap">
                          <div class="classify-money">
                            <span class="classify-name mediumColor">HKD</span>
                            <span class="classify-num heavyColor">996.00</span>
                          </div>
                          <div class="classify-money">
                            <span class="classify-name mediumColor">CNY</span>
                            <span class="classify-num heavyColor">157,123.00</span>
                          </div>
                          <div class="classify-money">
                            <span class="classify-name mediumColor">USD</span>
                            <span class="classify-num heavyColor">2,130.81</span>
                          </div>
                        </div>
                        <em class="jiecun-num" slot="reference">1243.76</em>
                      </el-popover>
                    </span>
                  </li>
                </ul>
                <div class="echart-explain lightColor">
                  {{$t('myInquiry.accoutSummary.duihuanlv')}}21/9/ 2019 14:12)
                </div>
              </div>
            </el-col>
            <el-col class="echart-wrap" :md="12" :sm="12" :xs="24">
              <div class="layout noMargin contentBg">
                <div class="echart-title mediumColor">{{$t('myInquiry.accoutSummary.keyongjiecun')}}</div>
                <div class="echart" ref="pieChart2"></div>
                <ul class="echart-info">
                  <li class="jiecun-item">
                    <div class="info-item heavyColor">
                      <span class="icons purple"></span>
                      <span class="text">HKD</span>
                      <span class="num">64,633.91</span>
                    </div>
                  </li>
                  <li class="jiecun-item">
                    <div class="info-item heavyColor">
                      <span class="icons red"></span>
                      <span class="text">CNY</span>
                      <span class="num">283.96</span>
                    </div>
                    <div class="hkd-money lightColor">
                      <span class="text">HKD</span>
                      <span class="num">=1,633.91</span>
                    </div>
                  </li>
                  <li class="jiecun-item">
                    <div class="info-item heavyColor">
                      <span class="icons blue"></span>
                      <span class="text">USD</span>
                      <span class="num">1,283.96</span>
                    </div>
                    <div class="hkd-money lightColor">
                      <span class="text">HKD</span>
                      <span class="num">=17,686.05</span>
                    </div>
                  </li>
                </ul>
                <div class="echart-explain lightColor">
                  {{$t('myInquiry.accoutSummary.duihuanlv')}}21/9/ 2019 14:12)
                </div>
              </div>
            </el-col>
          </el-row>
        </div>
      </el-col>
    </el-row>
    <div class="position-detail clearfix contentBg">
      <mainTitle :title="$t('myInquiry.accoutSummary.chicanxiangqing')">
        <span class="icons"><i class="iconfont icon-more lightColor"></i></span>
      </mainTitle>
      <div class="volume-content">
        <div class="market-wrap">
          <conditionChoose :conditionArr="conditionArr" @btnChoose="btnChoose" />
        </div>
        <div class="volume-value clearfix">
          <div class="value-item">
            <span class="value-text mediumColor">{{$t('home.volume.volumeVal')}}:</span>
            <span class="value-num heavyColor">44,897.00</span>
          </div>
          <div class="value-item">
            <span class="value-text mediumColor">{{$t('home.volume.Profit')}}:</span>
            <span class="value-num heavyColor">6,923.00</span>
          </div>
          <div class="value-item">
            <span class="value-text mediumColor">{{$t('home.volume.todyProfit')}}:</span>
            <span class="value-num heavyColor">-327.00</span>
          </div>
        </div>
      </div>
      <div class="table-wrap">
        <el-table :data="tableData" :row-class-name="tableRowClass" :header-cell-style="headeRowClass" style="width: 100%">
          <el-table-column :label="$t('myInquiry.accoutSummary.gupiao')" prop="stock">
          </el-table-column>
          <el-table-column prop="price" align="right" :label="$t('myInquiry.accoutSummary.xianjia')">
          </el-table-column>
          <el-table-column prop="cost" align="right" :label="$t('myInquiry.accoutSummary.chenben')">
          </el-table-column>
          <el-table-column prop="totalNum" align="right" :label="$t('myInquiry.accoutSummary.zongshuliang')">
          </el-table-column>
          <el-table-column prop="sellNum" align="right" :label="$t('myInquiry.accoutSummary.kemaishuliang')">
          </el-table-column>
          <el-table-column prop="pl" align="right" :label="$t('myInquiry.accoutSummary.cankaoyinkui')">
            <template slot-scope="scope">
              <span :class="calcUpDownColor(scope.row.pl)">{{scope.row.pl}}</span>
            </template>
          </el-table-column>
          <el-table-column prop="todayPL" align="right" :label="$t('myInquiry.accoutSummary.jinriyinkui')">
            <template slot-scope="scope">
              <span :class="calcUpDownColor(scope.row.todayPL)">{{scope.row.todayPL}}</span>
            </template>
          </el-table-column>
          <el-table-column prop="MV" align="right" :label="$t('myInquiry.accoutSummary.shizhi')">
          </el-table-column>
          <el-table-column prop="DV" align="right" :label="$t('myInquiry.accoutSummary.ancangzhi')">
          </el-table-column>
          <el-table-column fixed="right" align="right" width="220" :label="$t('myInquiry.accoutSummary.caozuo')">
            <template slot-scope="scope">
              <span class="small-btn small-btn-blue" @click="openTradingWrap($t('myInquiry.accoutSummary.mairu'),'buy')" :class="{notClick:userData.allowTrade == false}">{{$t('myInquiry.accoutSummary.mairu')}}</span>
              <span class="small-btn small-btn-yellow" @click="openTradingWrap($t('myInquiry.accoutSummary.maichu'),'sell')" :class="{notClick:userData.allowTrade == false}">{{$t('myInquiry.accoutSummary.maichu')}}</span>
              <span class="small-btn small-btn-light" @click="openPopover" :class="{notClick:userData.allowTrade == false}">{{$t('myInquiry.accoutSummary.xiugaichenben')}}</span>
              <span class="small-btn small-btn-light" @click="goRouter('/myInquiry/tradeHistory')">{{$t('myInquiry.accoutSummary.jiaoyijilu')}}</span>
            </template>
          </el-table-column>
        </el-table>
      </div>
    </div>
    <div class="accout-explain mediumColor">{{$t('myInquiry.accoutSummary.explianInfo')}}</div>
  </div>
</template>

<script>
import echarts from 'echarts'
import mainTitle from "@/components/mainTitle";
import popover from "@/components/popover"
import conditionChoose from '@/components/conditionChoose'
import transactionComponent from '@/components/TransactionComponent'
import { setQuterColor } from "@/utils/mixinsQuterColor"
import { mapGetters } from 'vuex'
export default {
  data() {
    return {
      gutter: 24,
      pieChart1: null,//饼状图
      pieChart2: null,//饼状图
      options: {
        title: {
          text: "130,283.96",//主标题文本
          subtext: 'HKD',//副标题文本
          left: 'center',
          top: '36%',
          textStyle: {
            fontSize: 12,
            color: '#000',
            align: 'center',
            fontFamily: "SourceHanSansCN-Medium"
          },
          subtextStyle: {
            fontFamily: "SourceHanSansCN-Medium",
            fontSize: 14,
            color: "rgba(0,0,0,0.50)",
            align: 'center',
          }
        },
        tooltip: {
          axisPointer: 'line',
          trigger: 'item',
          backgroundcolor: "#1E1E1E",
          borderRadius: 3,
          padding: [2, 16, 2, 16],
          position: "right",
          textStyle: {
            color: '#fff',
            fontSize: 12,
            fontFamily: 'PingFangSC-Regular;',
          },
          formatter(params) {
            let str = params.marker + " " + params.data.name + "&nbsp;" + params.percent + "%" + "</br>" + "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;" + "$" + params.data.value
            return str
          }
        },
        series: [
          {
            name: "",
            labelLine: {
              show: false
            },
            label: {
              show: false,
              position: 'center'
            },
            type: "pie",
            radius: ['60%', '85%'],//图形大小
            center: ['50%', '50%'],//位置
          }
        ]
      },
      timer: null,
      showPopover: false,
      tableData: [
        {
          stock: "211 STYLAND HOLD",
          price: "HKD 7.846",
          cost: "HKD 6.400",
          totalNum: "5000",
          sellNum: "5000",
          pl: "7230.00",
          todayPL: "-225.00",
          MV: "39,230.00",
          DV: "0 (0%)",
        },
        {
          stock: "351 亞洲能源物流",
          price: "HKD 5.360",
          cost: "HKD 5.667",
          totalNum: "1000",
          sellNum: "1000",
          pl: "-307.00",
          todayPL: "-102.00",
          MV: "5,667.00",
          DV: "567.00 (10%)",
        },
      ],
      linkUrl: "",//新平均价说明地址
      newAvgVal: "",//新平均价
      firstStep: true, //是否显示第一步
      conditionArr: [],//保存选择市场的按钮信息
      maxHeight: "",
      showTradingWrap: false,
      tradType: {
        txt: '',//交易名
        code: '',//交易类型
      },
      curMarket: "hkTrading",
      userData: ''
    }
  },
  components: {
    mainTitle,
    popover,
    conditionChoose,
    transactionComponent
  },
  mixins: [setQuterColor],
  watch: {
    getLang: {
      handler: function (o, n) {
        if (o == 'en') {
          this.linkUrl = 'http://www.htisec.com/web_sec/eng/pl.jsp';
        } else if (o == 'zhCN') {
          this.linkUrl = 'http://www.htisec.com/web_sec/gb/pl.jsp';
        } else {
          this.linkUrl = 'http://www.htisec.com/web_sec/b5/pl.jsp';
        }
        this.conditionArr = [
          {
            title: this.$t('home.volume.market'),
            dataArr: [
              {
                name: this.$t('home.volume.hkStock'),
                code: "hkTrading"
              },
              {
                name: this.$t('home.volume.aStock'),
                code: "A-shareTrading"
              },
              {
                name: this.$t('home.volume.usStock'),
                code: "usTrading"
              },
              {
                name: this.$t('home.volume.outsideStock'),
                code: "usTrading"
              }
            ]
          }
        ]
      },
      immediate: true,

    },
    //侧边栏展开resize echart  
    getFixedSide() {
      this.resizeChart();
    },
    getDeviceBar(val) {
      if (val == 'mobile') {
        this.gutter = 12;
      } else {
        this.gutter = 24;
      }
    },
    //切换主题的时候加载
    getBgColor(val) {
      this.loadEchartBg(val);
    }
  },
  computed: {
    ...mapGetters(['getDeviceBar', 'getFixedSide', 'getLang', 'getBgColor'])
  },
  methods: {
    tableRowClass() {
      return 'tableRowClass'
    },
    headeRowClass({ row, column, rowIndex, columnIndex }) {
      //表头的背景颜色
      if (rowIndex == 0) {
        if (this.getBgColor == 'bg-anhei') {
          return 'background:rgb(51,51,51)';
        } else {
          return 'background:rgb(255,255,255)';
        }
      }
    },
    loadEchartBg(val) {
      let color = 'rgb(51,51,51)';
      if (val == 'bg-anhei') {
        color = 'rgb(255,255,255)'
      }
      let option = {
        title: {
          textStyle: {//主标题文本样式
            color: color
          },
          subtextStyle: {//副标题文本样式{"color": "#aaa"}
            color: color
          },
        }
      }
      this.pieChart1.setOption(option);
      this.pieChart2.setOption(option);
    },
    openTradingWrap(txt, code) {
      if (this.userData.allowTrade !== false) {
        this.tradType.txt = txt;
        this.tradType.code = code;
        this.showTradingWrap = true;
      }
    },
    closeTradingWrap() {
      this.showTradingWrap = false;
    },
    goRouter(path) {
      this.$router.push(path);
      this.$store.commit('changeIsJumpRouter', true);
    },
    btnChoose(resultArr) {
      let type = resultArr[0].code;
      this.curMarket = type;
    },
    goToSuccess() {
      this.firstStep = false;
    },
    openPopover() {
      if (this.userData.allowTrade !== false) {
        this.firstStep = true;
        this.showPopover = true;
      }
    },
    //隐藏弹窗
    closePopover() {
      this.showPopover = false;
    },
    handleClick(row) {
      console.log(row);
    },
    initpieChart1() {
      this.pieChart1 = echarts.init(this.$refs.pieChart1);
      this.pieChart1.setOption(this.options);
      let option = {
        title: {
          text: "130,283.96",//主标题文本
          subtext: 'HKD',//副标题文本
        },
        color: ["#F1BF53", "#E00C00", "#8646C3", "#00A2E0", "#C57E63"],
        series: [
          {
            data: [
              { value: "110000.24", name: this.$t("home.asset.cash") },
              { value: "109000.56", name: this.$t("home.asset.hkStock") },
              { value: "13050.30", name: this.$t("home.asset.aStock") },
              { value: "65432.10", name: this.$t("home.asset.usStock") },
              { value: "32643.25", name: this.$t("home.asset.outsideStock") }
            ],
          }
        ]
      }
      this.pieChart1.setOption(option);
    },
    initpieChart2() {
      this.pieChart2 = echarts.init(this.$refs.pieChart2);
      this.pieChart2.setOption(this.options);
      let option = {
        title: {
          text: "15,178,12.30",//主标题文本
          subtext: 'HKD',//副标题文本
        },
        color: ["#E00C00", "#8646C3", "#00A2E0"],
        series: [
          {
            data: [
              { value: "109000.56", name: this.$t("home.asset.hkStock") },
              { value: "13050.30", name: this.$t("home.asset.aStock") },
              { value: "65432.10", name: this.$t("home.asset.usStock") }
            ]
          }
        ]
      }
      this.pieChart2.setOption(option);
    },
    resizeChart() {
      if (this.timer) {
        clearTimeout(this.timer)
      }
      this.timer = setTimeout(() => {
        if (this.pieChart1) {
          this.pieChart1.resize();
        }
        if (this.pieChart2) {
          this.pieChart2.resize();
        }
      }, 150)
    }
  },
  created() {
    this.userData = JSON.parse(sessionStorage.getItem("userData"));
  },
  mounted() {
    this.$nextTick(() => {
      this.initpieChart1();
      this.initpieChart2();
      this.loadEchartBg(this.getBgColor);
      window.addEventListener('resize', this.resizeChart)
    })
  },
  //释放资源
  beforeDestroy() {
    window.removeEventListener('resize', this.resizeChart);
    if (this.pieChart1) {
      this.pieChart1.dispose();
      this.pieChart1 = null;
    }
    if (this.pieChart2) {
      this.pieChart2.dispose();
      this.pieChart2 = null;
    }
  }
}

</script>
<style lang='scss' scoped>
.account-summary {
  width: 100%;
  height: 100%;
  .topRow {
    .left-wrap {
      min-height: 360px;
      padding: 24px 0;
      .account-wrap {
        padding: 0 24px;
        margin-bottom: 12px;
        .left-accout {
          width: 100%;
          .accout-item {
            padding: 5px 0;
            display: flex;
            flex-wrap: wrap;
            align-content: flex-start;
            font-size: 1rem;
            .txt {
              font-family: SourceHanSansCN-Regular;
              padding-right: 12px;
              flex: 0 0 120px;
              line-height: 20px;
            }
            .val {
              font-family: SourceHanSansCN-Normal;
              flex: 1;
              text-align: right;
              line-height: 18px;
            }
          }
        }
      }
    }
    .right-wrap {
      .layout {
        min-height: 360px;
        padding: 24px;
        .echart-title {
          font-family: SourceHanSansCN-Regular;
          font-size: 1rem;
        }
        .echart {
          width: 100%;
          height: 130px;
        }
        .echart-info {
          width: 100%;
          .info-item {
            display: flex;
            align-items: center;
            padding-bottom: 6px;
            .icons {
              width: 8px;
              height: 8px;
              display: inline-block;
              &.yellow {
                background: #f1bf53;
              }
              &.purple {
                background: #8646c3;
              }
              &.red {
                background: #e00c00;
              }
              &.brown {
                background: #c57e63;
              }
              &.blue {
                background: #00a2e0;
              }
            }
            .text {
              padding: 0 12px;
              font-size: 14px;
              font-family: SourceHanSansCN-Normal;
            }
            .num {
              flex: 1;
              font-size: 14px;
              text-align: right;
              font-family: Helvetica;
              cursor: pointer;
              text-decoration: underline;
              &.noLine {
                text-decoration: none;
                cursor: default;
              }
            }
          }
          .jiecun-item {
            .hkd-money {
              display: flex;
              font-size: 14px;
              padding-bottom: 8px;
              font-family: Helvetica;
              .text {
                padding-left: 20px;
              }
              .num {
                flex: 1;
                text-align: right;
              }
            }
            .num {
              text-decoration: none;
              cursor: default;
            }
          }
        }
        .echart-explain {
          font-family: SourceHanSansCN-Regular;
          font-size: 14px;
          line-height: 16px;
          padding-top: 12px;
        }
      }
    }
  }
  .position-detail {
    width: 100%;
    min-height: 360px;
    margin: 24px 0;
    .icons {
      width: 36px;
      height: 100%;
      text-align: right;
      display: inline-block;
      float: right;
      cursor: pointer;
    }
    .volume-content {
      width: 100%;
      padding: 0 24px;
      .market-wrap {
        width: 100%;
        padding: 12px 0;
      }
      .volume-value {
        width: 100%;
        .value-item {
          float: left;
          margin-bottom: 24px;
          padding-right: 24px;
          .value-text {
            font-family: SourceHanSansCN-Regular;
            font-size: 1rem;
            white-space: nowrap;
          }
          .value-num {
            padding: 0 10px;
            text-align: left;
            white-space: nowrap;
            font-family: Avenir-Book;
            font-size: 1rem;
          }
        }
      }
    }
    .table-wrap {
      width: 100%;
      padding: 0 24px;
      .notClick {
        background: grey;
        cursor: not-allowed;
      }
    }
  }
  .accout-explain {
    padding-top: 12px;
    font-family: SourceHanSansCN-Regular;
    font-size: 1rem;
    line-height: 20px;
  }
  //弹出框内容
  .first-wrap {
    width: 100%;
    .base-info {
      padding: 24px 24px 12px 24px;
      .info-item {
        padding: 4px 0;
        display: flex;
        flex-wrap: wrap;
        align-content: flex-start;
        .txt {
          font-family: SourceHanSansCN-Regular;
          font-size: 1rem;
          flex: 0 0 100px;
          line-height: 20px;
        }
        .val {
          flex: 1;
          font-family: Avenir-Book;
          font-size: 1rem;
          text-align: right;
          line-height: 18px;
        }
      }
    }
    .explain-wrap {
      padding: 0 24px 12px 24px;
      font-family: SourceHanSansCN-Regular;
      font-size: 14px;
      .explain-item {
        line-height: 16px;
        margin-top: 12px;
        a {
          text-decoration: underline;
        }
      }
    }
    .avg-wrap {
      width: 100%;
      padding: 24px;
      display: flex;
      align-items: center;
      .txt {
        flex: 0 0 80px;
        font-family: SourceHanSansCN-Regular;
        font-size: 1rem;
      }
      .val {
        flex: 1;
      }
    }
    .confirm-btn {
      padding: 0 24px 24px 24px;
      text-align: right;
    }
  }
  .second-wrap {
    .layout-wrap {
      width: 100%;
      height: 100%;
      padding: 24px;
      .success-wrap {
        text-align: center;
        span {
          display: block;
        }
        .icons {
          padding: 24px 0;
          i {
            font-size: 58px;
          }
        }
        .text {
          font-family: SourceHanSansCN-Medium;
          font-size: 18px;
        }
      }
      .success-info {
        padding: 6px 0;
        font-family: SourceHanSansCN-Regular;
        font-size: 14px;
        line-height: 16px;
        text-align: center;
      }
    }
  }
}
@media screen and (max-width: 1200px) {
  .elCol:first-child {
    margin-bottom: 24px;
  }
}
@media screen and (max-width: 768px) {
  .elCol {
    margin-bottom: 12px !important;
  }
  .account-summary .topRow .right-wrap .layout {
    padding: 12px;
    margin-bottom: 12px;
    &.noMargin {
      margin: 0;
    }
  }
  .account-summary .position-detail {
    margin-bottom: 12px;
    margin-top: 0px;
  }
  .account-summary .accout-explain {
    padding-top: 12px;
  }
  .account-summary .topRow .left-wrap .account-wrap.contentRightBorder {
    border: none !important;
  }
  .account-summary .topRow .left-wrap .account-wrap {
    padding: 0 12px;
  }
  .account-summary .topRow .left-wrap {
    padding: 12px 0;
  }
  .account-summary .position-detail .table-wrap {
    padding: 0 12px;
  }
  .account-summary .position-detail .volume-content {
    padding: 0 12px;
  }
}
</style>