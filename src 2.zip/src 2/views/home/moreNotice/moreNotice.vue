<template>
  <!-- 通知列表 -->
  <div class="moreNotice contentBg">
    <div class="top">
      <div class="top-box">
        <img src="@/assets/img/1@3x.png" alt="" />
        <span>{{$t('topBar.notice')}}</span>
      </div>
    </div>
    <div class="moreNotice-wrap">
      <el-table 
        :data="tableData" 
        :row-class-name="tableRowClass"  
        :header-cell-style="headeRowClass"
        style="width: 100%"
      >
        <el-table-column prop="date" :label="$t('home.notice.time')" width="120" height="51">
        </el-table-column>
        <el-table-column prop="name" :label="$t('home.notice.theme')">
        </el-table-column>
        <el-table-column prop="address" align="center" width="110" :label="$t('home.notice.operation')"><template slot-scope="scope">
            <el-button @click="toNewNotice" size="mini" type="primary">{{$t('home.notice.toView')}}</el-button>
          </template></el-table-column>
      </el-table>
    </div>

  </div>
</template>

<script>
import { loadThemColor } from '@/utils/loadTheme'
export default {
  data() {
    return {
      tableData: [
        {
          date: '2019-12-17',
          name: '有关部分海外邮寄结单服务延迟通知'
          // address: '上海市'
        },
        {
          date: '2019-12-17',
          name: '美股交易孖展利率低至P+2.5%*'
          // address: '上海市'
        }
      ]
    }
  },
  created() {
    let configColor = localStorage.getItem('bgColor') || 'bg-Blue';
    loadThemColor(configColor);
  },
  methods: {
    tableRowClass() {
      return 'tableRowClass'
    },  
    headeRowClass({row, column, rowIndex, columnIndex}) {
       //表头的背景颜色
      if(rowIndex==0){
        let configColor = localStorage.getItem('bgColor') || 'bg-Blue';
        if(configColor == 'bg-anhei') {
            return 'background:rgb(51,51,51)';
          }else{
            return 'background:rgb(255,255,255)';
          }
      }
    },
    // 查看按钮点击事件
    toNewNotice() {
      let routeNotice = this.$router.resolve({
        path: '/newNotice'
      })
      window.open(routeNotice.href, '_blank');
    }
  },

}
</script>

<style lang="scss" scoped>
.moreNotice {
  overflow: auto;
  width: 100%;
  min-height: 100%;
  .top {
    display: flex;
    align-items: center;
    padding: 16px 0;
    background: #003da5;
    box-shadow: 6px 0 6px 0 rgba(162, 140, 133, 0.3);
    @media screen and(max-width: 1080px) {
      padding: 12px 24px;
    }
    @media screen and(max-width: 768px) {
      padding: 12px 12px;
    }
    .top-box {
      display: flex;
      align-items: center;
      margin: 0 auto;
      width: 1000px;
      img {
        margin-right: 25px;
        width: 95px;
        height: 32px;
      }
      span {
        padding-left: 25px;
        font-family: SourceHanSansCN-Medium;
        font-size: 18px;
        color: #ffffff;
        line-height: 25px;
        border-left: 1px #fff solid;
      }
    }
  }
  .moreNotice-wrap {
    margin: 25px auto;
    width: 1000px;
    @media screen and(max-width: 1080px) {
      padding: 0 24px;
      width: 100%;
    }
    @media screen and(max-width: 768px) {
      padding: 0 12px;
    }
    >>> .el-table__header-wrapper {
      font-family: SourceHanSansCN-Regular;
      font-size: 1rem;
      color: rgba(51, 51, 51, 0.5);
      line-height: 16px;
    }

    >>> .el-table__body-wrapper {
      font-family: SourceHanSansCN-Regular;
      font-size: 1rem;
      color: #333333;
      line-height: 16px;
    }
    >>> .el-scrollbar__wrap {
      margin-bottom: 0px !important;
    }
  }
}
</style>
