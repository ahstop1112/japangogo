<!--主页(我的资产)-->
<template>
  <div class="asset-wrap contentBg">
    <mainTitle :title="$t('home.asset.title')" />
    <div class="total-asset">
        <div class="leftWrap">
          <div class="pie-chart" ref="pieChart"></div>
        </div>
        <div class="rightWrap">
          <div class="total mediumColor">
            <span class="total-text">{{$t('home.asset.total')}}</span>
            <span class="total-num">130,283.96 HKD</span>
          </div>
          <div class="asset-detail clearfix">
             <div class="asset-item">
               <span class="item-text mediumColor">{{$t('home.asset.account')}}</span>
                <span class="item-num heavyColor">
                  <el-popover
                  placement="right-start"
                  trigger="hover"
                  >
                  <div class="wrap">
                    <div class="classify-money">
                      <span class="classify-name mediumColor">HKD</span>
                      <span class="classify-num heavyColor">40.00</span>
                    </div>
                    <div class="classify-money">
                      <span class="classify-name mediumColor">CNY</span>
                      <span class="classify-num heavyColor">157,123.00</span>
                    </div>
                    <div class="classify-money">
                      <span class="classify-name mediumColor">USD</span>
                      <span class="classify-num heavyColor">2,130.81</span>
                    </div>
                  </div>
                  <em class="jiecun-num contentMediumBorder" slot="reference">110,000.24</em>
                </el-popover>
                </span>
              </div>  
              <div class="asset-item">
               <span class="item-text mediumColor">{{$t('home.asset.purchPower')}}</span>
                <span class="item-num heavyColor">950,283.96</span>
              </div>  
              <div class="asset-item">
               <span class="item-text mediumColor">{{$t('home.asset.available')}}</span>
                <span class="item-num heavyColor">
                <el-popover
                  placement="right-start"
                  trigger="hover"
                  >
                    <div class="wrap">
                      <div class="classify-money">
                        <span class="classify-name mediumColor">HKD</span>
                        <span class="classify-num heavyColor">996.00</span>
                      </div>
                      <div class="classify-money">
                        <span class="classify-name mediumColor">CNY</span>
                        <span class="classify-num heavyColor">157,123.00</span>
                      </div>
                      <div class="classify-money">
                        <span class="classify-name mediumColor">USD</span>
                        <span class="classify-num heavyColor">2,130.81</span>
                      </div>
                    </div>
                     <em class="jiecun-num contentMediumBorder" slot="reference">95,283.96</em>
                  </el-popover>
                </span>
              </div>  
              <div class="asset-item">
               <span class="item-text mediumColor">{{$t('home.asset.stockVal')}}</span>
                <span class="item-num heavyColor">52,400.00</span>
              </div>  
              <div class="asset-item">
               <span class="item-text mediumColor">{{$t('home.asset.cashTotal')}}</span>
                <span class="item-num heavyColor">
                  <el-popover
                  placement="right-start"
                  trigger="hover"
                  >
                    <div class="wrap">
                      <div class="classify-money">
                        <span class="classify-name mediumColor">HKD</span>
                        <span class="classify-num heavyColor">996.00</span>
                      </div>
                      <div class="classify-money">
                        <span class="classify-name mediumColor">CNY</span>
                        <span class="classify-num heavyColor">157,123.00</span>
                      </div>
                      <div class="classify-money">
                        <span class="classify-name mediumColor">USD</span>
                        <span class="classify-num heavyColor">2,130.81</span>
                      </div>
                    </div>
                     <em class="jiecun-num contentMediumBorder" slot="reference">95,283.96</em>
                  </el-popover>
                </span>
              </div>  
              <div class="asset-item">
               <span class="item-text mediumColor">{{$t('home.asset.stockHasVal')}}</span>
                <span class="item-num heavyColor">39,300.00</span>
              </div>        
          </div>
          <div class="asset-tip lightColor">
            {{$t('home.asset.explain')}} 21/9/2019 14:12)
          </div>
        </div>
    </div>
    <div class="interval-wrap">
      <div class="layout-wrap">
          <div class="btn-wrap contentLightColor">
            <span class="btn-item lightColor" :class="btnIndex == 0?'activeColor':''" @click="chooseDate(0)">{{$t('home.asset.oneMonth')}}</span>
            <span class="btn-item lightColor" :class="btnIndex == 1?'activeColor':''" @click="chooseDate(1)">{{$t('home.asset.threeMonth')}}</span>
            <span class="btn-item lightColor" :class="btnIndex == 2?'activeColor':''" @click="chooseDate(2)">{{$t('home.asset.halfOfYear')}}</span>
            <span class="btn-item lightColor" :class="btnIndex == 3?'activeColor':''" @click="chooseDate(3)">{{$t('home.asset.oneYear')}}</span>
            <span class="btn-item lightColor" :class="btnIndex == 4?'activeColor':''" @click="chooseDate(4)">{{$t('home.asset.twoYear')}}</span>
          </div>
      </div>
      <div class="line-chart">
        <div class="chart-info">
          <span class="info-item lightColor">
            {{$t('home.asset.money')}}:<em :class="calcUpDownColor(127.09)"> +127.09 HKD</em>
          </span>
          <span class="info-item lightColor" style="margin: 0;">
            {{$t('home.asset.percent')}}:<em :class="calcUpDownColor(0.032)"> +3.23%</em>
          </span>
        </div>  
        <div class="chartWrap"  ref="lineChart"></div>
      </div>
    </div>
  </div>
</template>

<script>
import echarts from 'echarts'
import mainTitle from "@/components/mainTitle";
import { setQuterColor } from "@/utils/mixinsQuterColor"
import { mapGetters } from 'vuex'
import asset from './asset.scss'

export default {
  data () {
    return {
      pieChart: null,//饼状图
      lineChart: null,//折线图
      btnIndex: 0,
      timer: null,//优化resize事件，不多次执行
    };
  },
  computed: {
    ...mapGetters(['getLang','getFixedSide','getBgColor'])
  },
  mixins:[ setQuterColor ],
  //监听切换语言的动作
  watch: {
    getLang() {
      //更新echart的文字
      this.$nextTick( () => {
        if(this.pieChart) {
          this.pieChart.setOption({
            legend: {
              data: [this.$t("home.asset.cash"),this.$t("home.asset.hkStock"),this.$t("home.asset.aStock"),this.$t("home.asset.usStock"),this.$t("home.asset.outsideStock")]
            },
             series: [
               {
                 data: [
                    {value: "110000.24", name: this.$t("home.asset.cash")},
                    {value: "109000.56", name: this.$t("home.asset.hkStock")},
                    {value: "13050.30", name: this.$t("home.asset.aStock")},
                    {value: "65432.10",  name: this.$t("home.asset.usStock")},
                    {value: "32643.25", name: this.$t("home.asset.outsideStock")}
                ]
               }
             ]
          })
        }
      })
    },
    getFixedSide() {
      let transitionWrap = document.getElementById("appRight");
      transitionWrap.addEventListener('transitionend',  this.resizeChart)
    },
    getBgColor(val) {
      this.loadBgColor(val);
    }
  },
  components: {
    mainTitle
  },
  methods: {
    loadBgColor(val) {
       //如果是暗黑主体重新渲染echart图
      let fontColor = '';
      let lineColor = '';
      let lineStyle = '';
      let pieColor = '';
      val == 'bg-anhei'?fontColor = 'rgba(255,255,255,0.5)':fontColor ='rgba(51,51,51,0.5)';
      val == 'bg-anhei'?lineColor = 'rgba(255,255,255,0.75)':lineColor ='rgba(51,51,51,0.75)';
      val == 'bg-anhei'?lineStyle = '#4D88FF':lineStyle ='#003da5';
      val == 'bg-anhei'?pieColor = ' rgb(255,255,255)':pieColor ='rgb(51,51,51)';
      let option1 = {
        lineStyle: {
          color: lineStyle
        },
        xAxis: {
            axisLine: {
              lineStyle: {
                  type: 'solid',
                  color: fontColor,
                  width:'2'
              }
            },
          axisLabel: {
            textStyle: {
                color: lineColor,//坐标值得具体的颜色
            }
          }
        },
        yAxis:{
          axisLine: {
            lineStyle: {
                type: 'solid',
                color: fontColor,
                width:'2'
            }
          },
          axisLabel: {
            textStyle: {
                color: lineColor,//坐标值得具体的颜色
            }
          }
        }
      }
      this.lineChart.setOption(option1);
      let option2 = {
        legend: {
          textStyle : {
            color: pieColor,
          }
        }
      }
      this.pieChart.setOption(option2);
    },
    chooseDate(index) {
      this.btnIndex = index;
    },
    initpieChart() {
      this.pieChart = echarts.init(this.$refs.pieChart);
      let option = {
        tooltip: {
          axisPointer: 'line', 
          trigger: 'item',
          backgroundcolor: "rgb(255,255,255,0.15)",
          borderRadius : 3,
          padding: [2,16,2,16],
          position: "right",
          textStyle: {
            color: '#fff',
            fontSize: 12,
            fontFamily: 'PingFangSC-Regular;',
          },
          formatter(params) {
            let str = params.marker+ " "+params.data.name +"&nbsp;"+ params.percent+"%"+"</br>"+"&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;"+"$"+ params.data.value
            return str
          }
        },
        color: ["#F1BF53","#E00C00","#8646C3","#00A2E0","#C57E63"],
        legend: {
            bottom: 0,
            data: [this.$t("home.asset.cash"),this.$t("home.asset.hkStock"),this.$t("home.asset.aStock"),this.$t("home.asset.usStock"),this.$t("home.asset.outsideStock")],
            textStyle : {
              color: "#333",
              fontFamily: "SourceHanSansCN-Regula",
              fontSize: 12,
              textAlign: "center"
            },
            icon:'rect',
            itemWidth:8,
            itemHeight:8,
        },
        series: [
          {
            name: "",
            labelLine: {
                show: false
            },
            label: {
                show: false,
                position: 'center'
            },
            type: "pie",
            radius: ['40%','75%'],//图形大小
            center: ['50%','40%'],//位置
            data: [
                {value: "110000.24", name: this.$t("home.asset.cash")},
                {value: "109000.56", name: this.$t("home.asset.hkStock")},
                {value: "13050.30", name: this.$t("home.asset.aStock")},
                {value: "65432.10",  name: this.$t("home.asset.usStock")},
                {value: "32643.25", name: this.$t("home.asset.outsideStock")}
            ],   
          },

        ]
      }
      this.pieChart.setOption(option);
    },
    initLineChart() {
      this.lineChart = echarts.init(this.$refs.lineChart);
      let options = {
        grid:{
          left: 60,
          top: 24,
          right: 24,
          bottom: 24
        },
         tooltip: {
          trigger: 'axis',
          backgroundcolor: "rgba(255,255,255,0.15)",
          textStyle: {
            color: '#fff',
            fontSize: 12,
            fontFamily: 'PingFangSC-Regular;',
          }
        },
        xAxis: {
            type: 'category',
            data: ['2020/9/1', '2020/9/2', '2020/9/3','2020/9/4','2020/9/5','2020/9/6','2020/9/7',],
            splitLine: {
              show: false
            }
        },
        yAxis: {
            type: 'value',
            splitLine: {
              show: false
            }
        },
         lineStyle: {
            color:"rgba(0,61,165,.75)"
         },
         series: [{
            data: [820, 932, 901, 934, 1290, 1330, 500],
            type: 'line'
         }]
      }
      this.lineChart.setOption(options);
    },
    resizeChart() {
        if(this.timer) {
          clearTimeout(this.timer)
        }
        this.timer = setTimeout( () => {
           this.lineChart.resize();
           this.pieChart.resize();
        }, 150)
    }
  },
  mounted(){
    this.$nextTick( () => {
      this.initpieChart();
      this.initLineChart();
      this.loadBgColor(this.getBgColor);
      window.addEventListener('resize', this.resizeChart)
    })
  },
  beforeDestroy() {
    window.removeEventListener('resize', this.resizeChart);
    if (this.pieChart) {
      this.pieChart.dispose();
      this.pieChart = null;
    }
    if (this.lineChart) {
      try{
        let transitionWrap = document.getElementById("appRight");
        transitionWrap.removeEventListener('transitionend',  this.resizeChart)
      }catch(err){

      }
      this.lineChart.dispose();
      this.lineChart = null;
    }
  },
}

</script>