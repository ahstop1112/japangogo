<!--主页(我的持仓)-->
<template>
  <div class="volume-wrap contentBg">
    <transactionComponent :tradType="tradType" :curMarket="curMarket" :showTradingWrap="showTradingWrap" @closeTradingWrap='closeTradingWrap' />
    <mainTitle :title="$t('home.volume.title')" />
    <div class="volume-content">
      <div class="market-wrap">
        <conditionChoose :conditionArr="conditionArr" @btnChoose="btnChoose" />
      </div>
      <div class="volume-value clearfix">
        <div class="value-item">
          <span class="value-text mediumColor">{{$t('home.volume.volumeVal')}}:</span>
          <span class="value-num heavyColor">44,897.00</span>
        </div>
        <div class="value-item">
          <span class="value-text mediumColor">{{$t('home.volume.Profit')}}:</span>
          <span class="value-num heavyColor">6,923.00</span>
        </div>
        <div class="value-item">
          <span class="value-text mediumColor">{{$t('home.volume.todyProfit')}}:</span>
          <span class="value-num heavyColor">-327.00</span>
        </div>
      </div>
      <div class="volume-stock">
        <div class="stock-title clearfix">
          <div class="title-item width15">
            <span class="txt lightColor">{{$t('home.volume.stock')}}</span>
          </div>
          <div class="title-item width15">
            <span class="txt lightColor">{{$t('home.volume.curPrice')}}</span>
            <span class="txt lightColor">/{{$t('home.volume.cost')}}</span>
          </div>
          <div class="title-item width20">
            <span class="txt lightColor">{{$t('home.volume.totalNum')}}</span>
            <span class="txt lightColor">/{{$t('home.volume.sellNum')}}</span>
          </div>
          <div class="title-item width20">
            <span class="txt lightColor">{{$t('home.volume.stockTodyProfit')}}</span>
            <span class="txt lightColor">/{{$t('home.volume.stockProfit')}}</span>
          </div>
          <div class="title-item width15">
            <span class="txt lightColor">{{$t('home.volume.marketVal')}}</span>
            <span class="txt lightColor">/{{$t('home.volume.chicangVal')}}</span>
          </div>
          <div class="title-item title-btn width15">
            <span class="txt lightColor">{{$t('home.volume.operation')}}</span>
          </div>
        </div>
        <ul class="stock-content" v-show="stockArr.length">
          <li class="stock-item clearfix hoverBgColor">
            <div class="stock-name fl heavyColor width15"><span>211</span> STYLAND HOLD</div>
            <div class="num-wrap fl width15">
              <span class="num heavyColor">HKD 7.846</span>
              <span class="num heavyColor">HKD 6.400</span>
            </div>
            <div class="num-wrap fl width20">
              <span class="num heavyColor">5000</span>
              <span class="num heavyColor">5000</span>
            </div>
            <div class="today-earn fl width20">
              <span class="earn-num" :class="calcUpDownColor(-225.00)">-225.00</span>
              <span class="earn-num" :class="calcUpDownColor(7230.00)">7,230.00</span>
            </div>
            <div class="num-wrap fl width15">
              <span class="num heavyColor">39,230.00</span>
              <span class="num heavyColor">0</span>
            </div>
            <div class="operation fl width15">
              <span class="num">
                <span class="small-btn small-btn-yellow" @click="openTradingWrap($t('home.volume.sell'),'sell')" :class="{notClick:userData.allowTrade == false}">{{$t('home.volume.sell')}}</span>
              </span>
              <span class="num">
                <span class="small-btn small-btn-light" @click="goRouter('/myInquiry/tradeHistory')"> {{$t('home.volume.tradHistory')}}</span>
              </span>
            </div>
          </li>
          <li class="stock-item clearfix hoverBgColor" v-for="item in stockArr">
            <div class="stock-name fl heavyColor width15"><span>351</span> 亞洲能源物流</div>
            <div class="num-wrap fl width15">
              <span class="num heavyColor">HKD 5.360</span>
              <span class="num heavyColor">HKD 5.667</span>
            </div>
            <div class="num-wrap fl width20">
              <span class="num heavyColor">1000</span>
              <span class="num heavyColor">1000</span>
            </div>
            <div class="today-earn fl width20">
              <span class="earn-num" :class="calcUpDownColor(-102.00)">-102.00</span>
              <span class="earn-num" :class="calcUpDownColor(-307.00)">-307.00</span>
            </div>
            <div class="num-wrap fl width15">
              <span class="num heavyColor">5,667.00</span>
              <span class="num heavyColor">566.70</span>
            </div>
            <div class="operation fl width15">
              <span class="num">
                <span class="small-btn small-btn-yellow" @click="openTradingWrap($t('home.volume.sell'),'sell')" :class="{notClick:userData.allowTrade == false}">{{$t('home.volume.sell')}}</span>
              </span>
              <span class="num">
                <span class="small-btn small-btn-light" @click="goRouter('/myInquiry/tradeHistory')">{{$t('home.volume.tradHistory')}}</span>
              </span>
            </div>
          </li>
        </ul>
        <div class="pagination-wrap">
          <el-pagination @current-change="handleCurrentChange" :current-page.sync="curPage" :page-size="10" :hide-on-single-page=true layout="prev, pager, next, jumper" :total="stockArr.length">
          </el-pagination>
        </div>
        <noContent v-if="!stockArr.length" :content="$t('home.volume.noResult')" />
      </div>

    </div>
  </div>
</template>

<script>
import mainTitle from "@/components/mainTitle";
import noContent from "@/components/noContent";
import conditionChoose from '@/components/conditionChoose'
import transactionComponent from '@/components/TransactionComponent'
import { setQuterColor } from "@/utils/mixinsQuterColor"
import { mapGetters } from 'vuex'
import volume from './volume.scss'

export default {
  data() {
    return {
      curPage: 1, //当前页
      conditionArr: [],//保存选择市场的按钮信息
      stockArr: [1],
      tradType: {
        txt: '',//交易名
        code: '',//交易类型
      },
      curMarket: "hkTrading",//当前市场
      showTradingWrap: false,
      userData: ''
    };
  },
  computed: {
    ...mapGetters(['getLang'])
  },
  mixins: [setQuterColor],
  watch: {
    getLang: {
      handler: function (o, n) {
        this.conditionArr = [
          {
            title: this.$t('home.volume.market'),
            dataArr: [
              {
                name: this.$t('home.volume.hkStock'),
                code: "hkTrading"
              },
              {
                name: this.$t('home.volume.aStock'),
                code: "A-shareTrading"
              },
              {
                name: this.$t('home.volume.usStock'),
                code: "usTrading"
              },
              {
                name: this.$t('home.volume.outsideStock'),
                code: "usTrading"
              }
            ]
          }
        ]
      },
      immediate: true
    }
  },
  components: {
    mainTitle,
    noContent,
    conditionChoose,
    transactionComponent
  },
  methods: {
    openTradingWrap(txt, code) {
      if (this.userData.allowTrade !== false) {
        this.tradType.txt = txt;
        this.tradType.code = code;
        this.showTradingWrap = true;
      }
    },
    closeTradingWrap() {
      this.showTradingWrap = false;
    },
    goRouter(path) {
      this.$router.push(path);
      this.$store.commit('changeIsJumpRouter', true);
    },
    handleCurrentChange(val) {
      console.log(val)
    },
    btnChoose(resultArr) {
      this.curMarket = resultArr[0].code;
      if (resultArr[0].code == 'usTrading') {
        this.stockArr = [];
      } else {
        this.stockArr = [1];
      }
    }
  },
  created() {
    this.userData = JSON.parse(sessionStorage.getItem("userData"));
  },
  mounted() { },

}

</script>