
<!--主页(常用功能)-->
<template>
  <div class="commonFunc-wrap contentBg">
    <mainTitle :title="$t('home.commonFunc.title')" />
    <ul class="main-content clearfix">
      <li class="common-item" @click="goRouter('/myInquiry/tradeHistory')">
        <i class="iconfont icon-05-2TradeHistory" />
        <span class="text mediumColor">{{$t('home.commonFunc.tradHistory')}}</span>
      </li>
      <li class="common-item" @click="goRouter('/myInquiry/stockMovement')">
        <span class="icons activeFontColor"><i class="iconfont icon-05-4StockMovement"></i></span>
        <span class="text mediumColor">{{$t('home.commonFunc.stockPush')}}</span>
      </li>
      <li v-if="!(userData.primeBrokerageFunds.length !== 0)" class="common-item" @click="goRouter('/myInquiry/myStatement')">
        <span class="icons activeFontColor"><i class="iconfont icon-05-5MyStatement"></i></span>
        <span class="text mediumColor">{{$t('home.commonFunc.jiedan')}}</span>
      </li>
      <li v-else class="common-item" @click="goRouter('/myInquiry/myReport')">
        <span class="icons activeFontColor"><i class="iconfont icon-05-5MyStatement"></i></span>
        <span class="text mediumColor">{{$t('home.commonFunc.baobiao')}}</span>
      </li>
    </ul>
  </div>
</template>

<script>
import mainTitle from "@/components/mainTitle";
import commonFunc from './commonFunc.scss'
export default {
  data() {
    return {
      userData: ''
    };
  },
  components: {
    mainTitle
  },
  methods: {
    goRouter(path) {
      this.$router.push(path);
      this.$store.commit('changeIsJumpRouter', true);
    }
  },
  mounted() { },
  created() {
    this.userData = JSON.parse(sessionStorage.getItem("userData"));
  }

}
</script>