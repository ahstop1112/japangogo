<template>
  <div class="wrap">
    <el-row class="row mobile" :gutter="gutter">
      <el-col class="elCol" :xl="8" :lg="12" :md="12" :sm="24" :xs="24">
        <asset />
      </el-col>
      <el-col class="elCol" :xl="8" :lg="12" :md="12" :sm="24" :xs="24">
        <volume />
      </el-col>
      <el-col class="elCol" :xl="8" :lg="12" :md="12" :sm="24" :xs="24">
        <ipo v-if="userData.primeBrokerageFunds.length  == 0 " />
      </el-col>
      <el-col class="elCol" :xl="8" :lg="12" :md="12" :sm="24" :xs="24">
        <commonFunc />
      </el-col>
      <el-col class="elCol" :xl="8" :lg="12" :md="12" :sm="24" :xs="24">
        <notice />
      </el-col>
    </el-row>
    <el-row class="row desktop" :gutter="gutter">
      <el-col class="elCol" :xl="8" :lg="12" :md="12" :sm="24" :xs="24">
        <asset />
      </el-col>
      <el-col class="elCol" :xl="8" :lg="12" :md="12" :sm="24" :xs="24">
        <commonFunc />
      </el-col>
      <el-col class="elCol" :xl="8" :lg="12" :md="12" :sm="24" :xs="24">
        <notice />
      </el-col>
      <el-col class="elCol" :xl="8" :lg="12" :md="12" :sm="24" :xs="24">
        <volume />
      </el-col>
      <el-col class="elCol" :xl="8" :lg="12" :md="12" :sm="24" :xs="24">
        <ipo v-if="userData.primeBrokerageFunds.length  == 0 " />
      </el-col>
    </el-row>
  </div>
</template>

<script>
import { mapGetters } from 'vuex'
import asset from "./asset"
import commonFunc from "./commonFunc"
import ipo from "./ipo"
import notice from "./notice"
import volume from "./volume"
import { localGet } from '@/utils/mylocal'
import index from './index.scss'

export default {
  data() {
    return {
      gutter: 12,
      mobile: false,
      userData: ''
    };
  },
  components: {
    asset,
    commonFunc,
    ipo,
    notice,
    volume
  },
  computed: {
    ...mapGetters(['getDeviceBar'])
  },
  watch: {
    getDeviceBar(val) {
      if (val == 'mobile') {
        this.gutter = 12;
        this.mobile = true;
      } else {
        this.gutter = 24;
        this.mobile = false;
      }

      console.log(this.mobile);
    }
  },
  created() {
    // 判断是否获取token值
    if (!sessionStorage.getItem('token')) {
      // 如果没有取到值,跳转至登录页
      this.$router.push("/login");
      return;
    }
    this.userData = JSON.parse(sessionStorage.getItem("userData"));
    // 获取当前角色
    // this.$store.state.role = this.userData.deptCode
    // if (!this.$route.meta.roles.includes(this.userData.deptCode)) {
    //   // 提示信息
    //   alert('您无权访问该页面')
    //   // 删除token
    //   removeLocal("token");
    //   // 跳转到登录页
    //   this.$router.push("/login");
    // }
    // // 获取保安提示弹窗的不提示选中状态
    // const checked = localGet('checked')
    // // 获取北向交易声明弹窗的不提示选中状态
    // const checked1 = localGet('checked1')
    // if (checked) {
    //   // 新窗口打开保安提示
    //   let prompt = this.$router.resolve({ path: "/prompt" });
    //   window.open(prompt.href, "_blank");
    // }
    // if (this.userData.nbTrdEcnsntAllw == true) {
    //   if (!checked1) {
    //     // 新窗口打开北向交易声明弹窗
    //     let prompt = this.$router.resolve({ path: "/mySettings/consentForConnect" });
    //     window.open(prompt.href, "_blank");
    //   }
    // }
  },
  methods: {

  },
  mounted() {

  },
}

</script>