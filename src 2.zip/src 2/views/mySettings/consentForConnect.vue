<!--中华通北向交易同意书(我的设定)-->
<template>
  <div class="consentForConnect contentBg">
    <div class="top">
      <div class="top-box">
        <img src="@/assets/img/1@3x.png" alt="" />
        <span>{{$t('mySettings.consentForConnnect.title')}}</span>
      </div>
    </div>
    <div class="box" v-if="infoShow == 0">
      <h4 class="title activeFontColor">{{$t('mySettings.consentForConnnect.title1')}}</h4>
      <div class="content mediumColor">
        <p>
          {{$t('mySettings.consentForConnnect.content1')}}
        </p>
        <p class="txt activeFontColor">
          {{$t('mySettings.consentForConnnect.content2')}}
        </p>
        <p>
          {{$t('mySettings.consentForConnnect.content3')}}
        </p>
        <p style="text-indent:2em;">
          {{$t('mySettings.consentForConnnect.content4')}}
        </p>
        <p style="text-indent:2em;">
          {{$t('mySettings.consentForConnnect.content5')}}
        </p>
        <p>
          {{$t('mySettings.consentForConnnect.content6')}}
        </p>
        <p style="text-indent:2em;">
          {{$t('mySettings.consentForConnnect.content7')}}
        </p>
        <p style="text-indent:2em;">
          {{$t('mySettings.consentForConnnect.content8')}}
        </p>
        <p style="text-indent:2em;">
          {{$t('mySettings.consentForConnnect.content9')}}
        </p>
        <p style="text-indent:2em;">
          {{$t('mySettings.consentForConnnect.content10')}}
        </p>
        <p>
          {{$t('mySettings.consentForConnnect.content11')}}
        </p>
        <p class="txt activeFontColor">
          {{$t('mySettings.consentForConnnect.content12')}}
        </p>
        <p>
          {{$t('mySettings.consentForConnnect.content13')}}
        </p>
        <p class="txt activeFontColor">
          {{$t('mySettings.consentForConnnect.content14')}}
        </p>
        <p> {{$t('mySettings.consentForConnnect.content15')}}</p>
        <el-form ref="form" :model="form">
          <el-form-item prop="radio1">
            <el-radio-group v-model="form.radio1">
              <el-radio :label="1"> {{$t('mySettings.consentForConnnect.content16')}}</el-radio>
              <el-radio :label="2"> {{$t('mySettings.consentForConnnect.content17')}}</el-radio>
            </el-radio-group>
          </el-form-item>
          <el-form-item prop="radio2">
            <el-radio-group v-model="form.radio2" :disabled="form.radio1==1">
              <el-radio :label="3" style="padding-left:25px"> {{$t('mySettings.consentForConnnect.content18')}}</el-radio>
              <el-radio :label="4" style="padding-left:25px"> {{$t('mySettings.consentForConnnect.content19')}}
                <template>
                  <el-form-item prop="input">
                    <el-input v-model="form.input" :disabled="form.radio1==1||form.radio2==3" :placeholder="$t('mySettings.consentForConnnect.ipt')"></el-input>
                  </el-form-item>
                </template>
              </el-radio>
            </el-radio-group>
          </el-form-item>
        </el-form>
        <p>
          {{$t('mySettings.consentForConnnect.content20')}}
        </p>
      </div>
      <div class="btn">
        <el-button plain @click="close" class="cancel">{{$t('mySettings.consentForConnnect.cancel')}}</el-button>
        <el-button :disabled="form.radio1!==1&&form.radio1!==2||form.radio1==2&&form.radio2!==3&&form.radio2!==4||form.radio2==4&&btnState == false" type="primary" @click="confirm('form')">{{$t('mySettings.consentForConnnect.confirm')}}</el-button>
      </div>
      <div class="ck">
        <el-checkbox v-model="checked"> {{$t('mySettings.consentForConnnect.prompt')}}</el-checkbox>
      </div>
    </div>
    <!-- 成功信息 -->
    <div class="success" v-else-if="infoShow == 1">
      <div class="imgs">
        <i class="iconfont icon-status_success activeFontColor"></i>
      </div>
      <div class="info activeFontColor">
        <p>{{$t('mySettings.consentForConnnect.content21')}}</p>
      </div>
      <el-button class="btn" type="primary" @click="isClose">{{$t('mySettings.consentForConnnect.content23')}}</el-button>
    </div>
    <!-- 失败信息 -->
    <div class="success" v-else>
      <div class="imgs img"><img src="@/assets/img/icon_pass@3x.png" alt="" /></div>
      <div class="info failure">
        <p>{{$t('mySettings.consentForConnnect.content22')}}</p>
      </div>
      <el-button class="btn" @click="isClose" type="primary">{{$t('mySettings.consentForConnnect.cancel')}}</el-button>
    </div>
    <!-- 底部组件 -->
    <bottombar :isShow="false" :class="[infoShow == 1 ? 'bottom' : '']"></bottombar>
  </div>
</template>

<script>
import bottombar from '@/views/_layout/bottombar'
import { localGet, localSet } from '@/utils/mylocal.js'
import { loadThemColor } from '@/utils/loadTheme'
export default {
  components: {
    bottombar
  },
  computed: {
    btnState() {
      return (
        this.form.input !== ''
      )
    }
  },
  created() {
    let configColor = localStorage.getItem('bgColor') || 'bg-Blue';
    loadThemColor(configColor);
  },
  data() {
    return {
      checked: false, // 登陸提醒
      infoShow: 0, // 当前显示的页面
      form: {
        radio1: '',
        radio2: '',
        input: '',
      },
    };
  },
  methods: {
    confirm(form) {
      this.$refs.form.validate(val => {
        if (val) {
          // 跳转成功页面
          this.infoShow = 1
          // 保存不提示选中状态
          localSet('checked1', this.checked)
        }
      })

    },
    // 关闭当前页
    close() {
      window.close()
      // 保存不提示选中状态
      localSet('checked1', this.checked)
    },
    // 关闭当前页
    isClose() {
      window.close()
    }
  },
  mounted() { },

}

</script>