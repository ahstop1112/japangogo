<!--信贷额申请(我的设定)-->
<template>
  <div class="marginApplication">
    <!-- 没有审批记录 -->
    <div class="noRecord-wrap" v-if="isShowRecord==true">
      <span class="text heavyColor">{{$t('mySettings.marginApplication.submitInfor')}} 02-0913420-33 {{$t('mySettings.marginApplication.submitInfor1')}} yyyy-mm-dd {{$t('mySettings.marginApplication.submitInfor4')}} XXX,XXX.XX。</span>
      <p class="heavyColor">{{$t('mySettings.marginApplication.submitTip')}}xxxxxxx。</p>
      <div class="btn">
        <el-button type="primary" @click="toRecord">{{$t('mySettings.marginApplication.marginApply')}}</el-button>
      </div>
    </div>
    <!-- 有审批记录 -->
    <div class="marginApplication-wrap contentBg" v-else>
      <popover :title="$t('mySettings.marginApplication.marginApply')" @close="closePopover" :showPopover="showPopover" :isFirst="firstStep">
        <div class="first-wrap" v-if="firstStep">
          <div class="custorm-info">
            <div class="custorm-title mediumColor">{{$t('mySettings.marginApplication.caiwuInfo')}}02-0913420-33{{$t('mySettings.marginApplication.caiwuInfo1')}}XXX,XXX.XX{{$t('mySettings.marginApplication.caiwuInfo2')}}</div>
            <div class="custorm-title mediumColor">{{$t('mySettings.marginApplication.caiwuInfo3')}}</div>
          </div>
          <div class="confirm-btn">
            <el-button @click="closePopover">{{$t('mySettings.marginApplication.cancel')}}</el-button>
            <el-button type="primary" @click="lastConfirm">{{$t('mySettings.marginApplication.confirm')}}</el-button>
          </div>
        </div>
        <div class="second-wrap" v-else>
          <ul class="success-wrap">
            <li class="icons"><i class="iconfont icon-status_success activeFontColor"></i></li>
            <li class="title activeFontColor">{{$t('mySettings.marginApplication.submitInfor')}} 02-0913420-33 {{$t('mySettings.marginApplication.submitInfor1')}} yyyy-mm-dd {{$t('mySettings.marginApplication.submitInfor2')}}XXX,XXX.XX,{{$t('mySettings.marginApplication.submitInfor3')}}</li>
            <li class="text heavyColor">{{$t('mySettings.marginApplication.submitTip')}}xxxxxxxx。</li>
          </ul>
        </div>
      </popover>
      <ul class="base-info">
        <li class="info-item">
          <span class="txt mediumColor">{{$t('mySettings.marginApplication.customName')}}</span>
          <span class="val heavyColor">Client 0011448</span>
        </li>
        <li class="info-item">
          <span class="txt mediumColor">{{$t('mySettings.marginApplication.accountId')}}</span>
          <span class="val heavyColor">02-0011448-33</span>
        </li>
        <li class="info-item">
          <span class="txt mediumColor">{{$t('mySettings.marginApplication.existCredit')}}</span>
          <span class="val heavyColor">{{$t('mySettings.marginApplication.currency')}}49.9{{$t('mySettings.marginApplication.wan')}}</span>
        </li>
        <li class="info-item">
          <span class="txt mediumColor"></span>
          <span class="val heavyColor">
            <div class="canvas-wrap" id="canvasTest" style="width:250px;height:240px;" @touchmove.prevent>
            </div>
          </span>
        </li>
        <li class="info-item">
          <span class="txt mediumColor">{{$t('mySettings.marginApplication.newCredit')}}</span>
          <span class="val heavyColor">
            {{$t('mySettings.marginApplication.currency')}}
            <el-input class="input-wrap" v-model="newApplyVal">
              <template slot="append">
                <span class="text ">{{$t('mySettings.marginApplication.wan')}}</span>
              </template>
            </el-input>
          </span>

        </li>
      </ul>
      <div class="apply-info">
        <div class="apply-title mediumColor">{{$t('mySettings.marginApplication.customData')}}</div>
      </div>
      <div class="explain-wrap">
        <div class="explain-title heavyColor">{{$t('mySettings.marginApplication.action')}}</div>
        <ul class="explain-info mediumColor">
          <li class="info-item">
            {{$t('mySettings.marginApplication.explian1')}}
          </li>
          <li class="info-item">
            {{$t('mySettings.marginApplication.explian2')}}
          </li>
          <li class="info-item">
            {{$t('mySettings.marginApplication.explian5')}}
          </li>
          <li class="info-item">
            {{$t('mySettings.marginApplication.explian6')}}
          </li>
          <li class="info-item">
            {{$t('mySettings.marginApplication.explian9')}}
          </li>
          <li class="info-item">
            {{$t('mySettings.marginApplication.explian10')}}
          </li>
        </ul>
        <div class="agree-wrap">
          <el-checkbox label="" v-model="hasCheck"></el-checkbox>
          <span class="text heavyColor">{{$t('mySettings.marginApplication.companyAgree')}}</span>
        </div>
      </div>
      <div class="btn-wrap">
        <el-button type="primary" @click="confirmInfo" :disabled="!hasCheck">{{$t('mySettings.marginApplication.confirm')}}</el-button>
      </div>
    </div>
  </div>

</template>

<script>
import popover from "@/components/popover"
import DragAcr from '@/utils/canvas.js'
import { mapGetters } from 'vuex'
import marginApplication from "./marginApplication.scss"

export default {
  data() {
    return {
      isShowRecord: true, // 控制是否显示下一步
      firstStep: true,//确认弹窗是否为第一步
      showPopover: false,
      newApplyVal: "800",
      hasCheck: false,
      chart:null,
    };
  },
  components: {
    popover,
  },
  computed: { //detail data from lang
    ...mapGetters(['getBgColor']),
  },
  watch: {
    getBgColor: {
      handler: function(o,v) {
          this.toRecord(o);
      },
      immediate: true
    }
  },
  methods: {
    lastConfirm() {
      this.firstStep = false;
    },
    confirmInfo() {
      this.firstStep = true;
      this.showPopover = true;
    },
    //隐藏弹窗
    closePopover() {
      this.showPopover = false;
    },
    toRecord(val) {
      this.isShowRecord = false
      let fontColor = '#333'
      if(val == 'bg-anhei') {
        fontColor = '#fff'
      }
      this.$nextTick(() => {
        let el = document.getElementById('canvasTest');
        //页面切换的时候加载不同文字颜色
        if(this.chart) {
          this.chart.txtColor = fontColor;
          this.chart.draw(0);
          return;
        }
        this.chart = new DragAcr({
          el: el,
          value: 800,//传入的信贷额值
          text: '萬', //传入的单位
          txtColor: fontColor,
          change: (v) => {
            console.log(v);//当前滑动的值
            this.newApplyVal = v
          }
        })
        
      })
    },
  },
  created() {
  },
  mounted() {
  }
}
</script>