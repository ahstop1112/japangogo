<template>
  <div class="success-wrap">
    <div class="success-top">
      <div class="top-wrap">
        <img src="@/assets/img/logo_horizontal@2x.png" />
        <span class="line">|</span>
        <span class="title">{{title}}</span>
      </div>
    </div>
    <div class="success-content">
      <div class="content-wrap">
        <slot></slot>
      </div>
      <div class="btn-wrap">
        <el-button type="primary" @click="btnEvent">{{btnName}}</el-button>
      </div>
    </div>
    <div class="success-bottom">
      <p class="center">{{ $t('bottomBar.company') }}</p>
      <p class="center">
        <a class="link-info" :href="mianzeUrl" target="_Blank">{{
            $t('bottomBar.mianze')
            }}</a> {{ $t('bottomBar.ji')}}
        <a class="link-info" :href="personUrl" target="_Blank">{{
            $t('bottomBar.pernsonInfo')
            }}</a>
      </p>
    </div>
  </div>
</template>

<script>
import { mapGetters } from 'vuex'
export default {
  props: {
    title: "",
    btnName: "",
  },
  data() {
    return {
      mianzeUrl: '',
      personUrl: ''
    }
  },
  computed: {
    ...mapGetters(['getLang'])
  },
  //监听切换语言的动作
  watch: {
    getLang: {
      handler: function (val, n) {
        if (val == 'en') {
          this.mianzeUrl = 'http://www.htisec.com/en-us/disclaimers'
          this.personUrl =
            'http://www.htisec.com/sites/all/themes/hitong/files/Data_Privacy_Policy_Sec_EN.pdf'
        } else if (val == 'zhCN') {
          this.mianzeUrl = 'http://www.htisec.com/en-cn/disclaimers'
          this.personUrl =
            'http://www.htisec.com/sites/all/themes/hitong/files/Data_Privacy_Policy_Sec_SC.pdf'
        } else {
          this.mianzeUrl = 'http://www.htisec.com/zh-hk/disclaimers'
          this.personUrl =
            'http://www.htisec.com/sites/all/themes/hitong/files/Data_Privacy_Policy_Sec_TC.pdf'
        }
      },
      immediate: true
    }
  },
  methods: {
    btnEvent() {
      this.$emit("btnEvent");
    }
  },
  mounted() { },

}

</script>
<style lang='scss' scoped>
.success-wrap {
  position: fixed;
  left: 0;
  top: 0;
  width: 100%;
  height: 100%;
  z-index: 1500;
  background: #fff;
  .success-top {
    width: 100%;
    height: 64px;
    background: #003da5;
    color: #fff;
    .top-wrap {
      width: 70%;
      height: 64px;
      line-height: 64px;
      margin: 0 auto;
      display: flex;
      align-items: center;
      img {
        width: 96px;
        vertical-align: middle;
      }
      .line {
        font-size: 24px;
        padding: 0 12px;
      }
      .title {
        font-family: SourceHanSansCN-Medium;
        font-size: 18px;
        line-height: 18px;
      }
    }
  }
  .success-content {
    width: 100%;
    .content-wrap {
      min-height: 200px;
    }
    .btn-wrap {
      width: 100%;
      text-align: center;
    }
  }
  .success-bottom {
    position: absolute;
    left: 0;
    bottom: 0;
    width: 100%;
    height: 64px;
    color: #fff;
    text-align: center;
    background: #00244c;
    padding: 14px 0;
    .center {
      font-family: SourceHanSansCN-Normal;
      font-size: 12px;
      padding-bottom: 6px;
      .link-info {
        font-family: SourceHanSansCN-Medium;
        font-size: 12px;
        color: #4191ff;
        text-decoration: underline;
      }
    }
  }
}
@media screen and (max-width: 768px) {
  .success-wrap .success-top .top-wrap {
    width: 100%;
    justify-content: center;
    padding: 0 12px;
  }
  .success-wrap .bottom-wrap {
    padding: 12px;
  }
}
</style>