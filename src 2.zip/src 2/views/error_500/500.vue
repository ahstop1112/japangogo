<template>
  <div style="display: table;height: 100%;width: 80%;margin: 0 auto;">
    <div style="display: table-cell;height: 100%;vertical-align: middle;width: 50%;padding: 0 30px;">
      <div style="display: inline-block;">
        <h2 class="error-subtitle">服务异常！！！请联系管理员</h2>
        <div>
        </div>
      </div>
    </div>
    <div style="display: table-cell;height: 100%;vertical-align: middle;width: 50%;padding: 0 30px;">
      <img src="@/assets/img/error_500.png" alt="error" style="width: 100%;">
    </div>
  </div>
</template>