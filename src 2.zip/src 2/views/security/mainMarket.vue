<!--港A美股(证券交易)-->
<template>
  <div class="mainMarket">
    <div class="top-wraps">
      <div class="pagNav-wrap">
        <pageNav :routerArr="routerArr"/>
      </div>
      <div class="refresh">
        <el-button type="primary" @click="reloadPage">
          <i class="iconfont icon-refresh"></i>
          <span class="txt">{{$t("security.mainMarket.refresh")}}</span>
        </el-button>
      </div>
      </div>
    <div class="content-wrap">
      <router-view v-if="isRouterAlive"/>
    </div>
  </div>
</template>

<script>
import pageNav from "@/components/pageNav"
import mainMarket from './mainMarket.scss'

export default {
  provide () {
      return {
        reload: this.reload
      }
  },
  data () {
    return {
      isRouterAlive: true,
    };
  },
  computed: {
    routerArr() {
      return [
        {
          img: require("@/assets/img/flag_HK@2x.png"),
          name: this.$t("security.mainMarket.hkTrading"),
          path:"hkTrading"
        },
        {
          img: require("@/assets/img/flag_CN@2x.png"),
          name:this.$t("security.mainMarket.chinaTrading"),
          path:"A-shareTrading"
        },
        {
          img: require("@/assets/img/flag_US@2x.png"),
          name:this.$t("security.mainMarket.usTrading"),
          path:"usTrading"
        }
      ]
    }
  },
  components: {
    pageNav
  },
  methods: {
    reloadPage() {
      this.reload();
    },
     // 刷新当前页
    reload() {
        this.isRouterAlive = false;
        this.$nextTick(function(){
            this.isRouterAlive = true;
        })
    },
  },
  mounted(){},

}

</script>