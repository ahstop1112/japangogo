<!--按仓比率(证券交易)-->
<template>
  <div class="marginFinancingRatios-wrap contentBg">
    <transactionComponent :curMarket="curMarket" :tradType="tradType" :showTradingWrap="showTradingWrap" @closeTradingWrap='closeTradingWrap' />
    <div class="conditions">
      <conditionChoose :conditionArr="conditionArr" @btnChoose="btnChoose" />
    </div>
    <div class="marginFinancingRatios-choose">
      <div class="choose-wrap">
        <conditionChoose :conditionArr="conditionArr1" @btnChoose="btnChoose" />
      </div>
      <div class="input-wrap" v-show="isZhiding">
        <el-input class="ipt" v-model="input">
        </el-input>
        <span class="icon contentLeftBorder">
          <img src="@/assets/img/search.png" />
        </span>
      </div>
    </div>
    <div class="noContent" v-if="isShow">
      <noContent :content="$t('security.marginFinancingRatios.noRecord')" height="400px"></noContent>
    </div>
    <div class="marginFinancingRatios-detail" v-if="!isShow">
      <div class="marginFinancingRatios-form">
        <el-table :data="tableData" :row-class-name="tableRowClass" :header-cell-style="headeRowClass" style="width: 100%">
          <el-table-column prop="market" min-width="70" :label="$t('cash.fxConversion.market')">
            <template slot-scope="scope">
              <div class="img"><img src="@/assets/img/flag_US@2x.png" alt=""></div>
              <span>{{ scope.row.market }}</span>
            </template>
          </el-table-column>
          <el-table-column prop="stock" align="left" :label="$t('security.marginFinancingRatios.stock')">
          </el-table-column>
          <el-table-column prop="ratio" align="right" min-width="70" :label="$t('security.marginFinancingRatios.ratio')">
          </el-table-column>
          <el-table-column prop="operation" align="center" min-width="70" :label="$t('security.marginFinancingRatios.operation')">
            <template>
              <span :class="{notClick:userData.allowTrade == false}" class="small-btn small-btn-blue" @click="openTradingWrap($t('security.marginFinancingRatios.maimai'),'all')">{{$t('security.marginFinancingRatios.maimai')}}</span>
            </template>
          </el-table-column>
        </el-table>
      </div>
      <div class="block">
        <el-pagination background @size-change="handleSizeChange" @current-change="handleCurrentChange" :current-page.sync="currentPage" :page-size="100" layout="prev, pager, next, jumper" :total="1000">
        </el-pagination>
      </div>
    </div>

  </div>

</template>

<script>
import conditionChoose from '@/components/conditionChoose'
import timeSelector from '@/components/timeSelector'
import noContent from '@/components/noContent'
import transactionComponent from '@/components/TransactionComponent'
import { mapGetters } from 'vuex'
import marginFinancingRatios from './marginFinancingRatios.scss'

export default {
  computed: {
    ...mapGetters(['getLang', 'getBgColor'])
  },
  components: {
    conditionChoose,
    timeSelector,
    noContent,
    transactionComponent
  },
  data() {
    return {
      currentPage: 5, // 默认选择第五页
      input: '', // 搜索框
      conditionArr: [],// 市场条件选择
      conditionArr1: [], // 股票条件选择
      isShow: false,  // 是否显示搜索无记录
      tableData: [
        {
          market: '美股',
          stock: "CKH HOLDINGS",
          ratio: "60%",
        },
        {
          market: '美股',
          stock: "CKH HOLDINGS",
          ratio: "60%",
        }
      ],
      curMarket: "hkTrading",
      tradType: {
        txt: '',//交易名
        code: '',//交易类型
      },
      showTradingWrap: false,
      userData: '',
      isZhiding: false,//是否是选择的指定股票
    };
  },
  watch: {
    getLang: {
      handler: function (o, n) {
        this.conditionArr = [
          {
            title: this.$t('cash.fxConversion.market'),
            dataArr: [
              {
                name: this.$t('security.marginFinancingRatios.ganggu'),
                code: ""
              },
              {
                name: this.$t('security.marginFinancingRatios.hugutong'),
                code: ""
              },
              {
                name: this.$t('security.marginFinancingRatios.ganggutong'),
                code: ""
              },
              {
                name: this.$t('security.marginFinancingRatios.meigu'),
                code: ""
              }
            ]
          }
        ],
          this.conditionArr1 = [
            {
              title: this.$t('security.marginFinancingRatios.stock'),
              dataArr: [
                {
                  name: this.$t('myInquiry.stockMovement.allMarket'),
                  code: "allMarket"
                },
                {
                  name: this.$t('myInquiry.stockMovement.stock'),
                  code: ""
                },
              ]
            }
          ]
      },
      immediate: true
    }
  },
  methods: {
    tableRowClass() {
      return 'tableRowClass'
    },
    headeRowClass({ row, column, rowIndex, columnIndex }) {
      //表头的背景颜色
      if (rowIndex == 0) {
        if (this.getBgColor == 'bg-anhei') {
          return 'background:rgb(51,51,51)';
        } else {
          return 'background:rgb(255,255,255)';
        }
      }
    },
    openTradingWrap(txt, code) {
      if (this.userData.allowTrade !== false) {
        this.tradType.txt = txt;
        this.tradType.code = code;
        this.showTradingWrap = true;
      }
    },
    closeTradingWrap() {
      this.showTradingWrap = false;
    },
    btnChoose(resultArr) {
      if (resultArr[0].name == '指定股票') {
        this.isZhiding = true;
      } else {
        this.isZhiding = false;
      }
    },
    handleSizeChange(val) {
      console.log(`每页 ${val} 条`);
    },
    handleCurrentChange(val) {
      console.log(`当前页: ${val}`);
    },
  },
  created() {
    this.userData = JSON.parse(sessionStorage.getItem("userData"));
  },
  mounted() { },

}

</script>