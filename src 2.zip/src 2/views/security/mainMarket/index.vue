
 <!--港A美股主题内容-->
<template>
  <div class="layout-wrap">
    <el-row class="topRow" :gutter="gutter">
      <el-col class="elCol" :xl="6" :lg="6" :md="10" :sm="24" :xs="24">
        <selfSelectStock></selfSelectStock>
      </el-col>
      <el-col class="elCol" :xl="8" :lg="8" :md="14" :sm="24" :xs="24">
        <marketChart></marketChart>
        <tradingPanel></tradingPanel>
      </el-col>
      <el-col class="elCol" :xl="10" :lg="10" :md="24" :sm="24" :xs="24">
        <tradingStatus v-if="userData.allowTrade !== false"></tradingStatus>
        <stockBalance></stockBalance>
      </el-col>
    </el-row>
  </div>
</template>

<script>
import selfSelectStock from "./selfSelectStock"
import marketChart from "./marketChart"
import tradingPanel from "./tradingPanel"
import tradingStatus from "./tradingStatus"
import stockBalance from "./stockBalance"
import { mapGetters } from "vuex"
import index from "./index.scss"

export default {
  data() {
    return {
      gutter: 24,
      userData: ''
    };
  },
  components: {
    selfSelectStock,
    marketChart,
    tradingPanel,
    tradingStatus,
    stockBalance
  },
  comments: {
    ...mapGetters(['device'])
  },
  watch: {
    device: {
      handler: function (o, n) {
        if (o == 'mobile') {
          this.gutter = 12;
        }
      },
      immediate: true
    }
  },
  methods: {

  },
  created() {
    this.userData = JSON.parse(sessionStorage.getItem("userData"));
  },
  mounted() { },

}

</script>