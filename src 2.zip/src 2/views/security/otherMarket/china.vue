<template>
  <div class="china-wrap">
    <tradingInfo date="T+1" oneCurrency="1TWD" currency="TWD" HKD="0.257HKD" :leftImg="require('@/assets/img/flag_TW@2x.png')" :rightImg="require('@/assets/img/flag_HK@2x.png')">
      <span>{{$t('security.otherMarket.time6')}}</span>
    </tradingInfo>
  </div>
</template>

<script>
import tradingInfo from './tradingInfo'
import china from './china.scss'

export default {
  components: {
    tradingInfo
  },
  data() {
    return {
    };
  },
  methods: {

  },
  mounted() {
  },
}
</script>