<template>
  <div class="prospectusForm">
    <div class="top">
      <div class="top-box">
        <img src="@/assets/img/1@3x.png" alt="" />
        <span>08512 凯富善集团控股有限公司 - 申请认购的香港招股股份数目</span>
      </div>
    </div>
    <span class="title">08512 凯富善集团控股有限公司 - 申请认购的香港招股股份数目</span>
    <div class="box">
      <div class="content">
        <table width="100%">
          <thead>
            <tr>
              <th width="20%">{{$t('security.ipoSubscriptions.prospectusForm.number')}}</th>
              <th>{{$t('security.ipoSubscriptions.prospectusForm.amount')}}</th>
            </tr>
          </thead>
          <tbody>
            <tr v-for="(item,index) in list" :key="index">
              <td>{{item.amount}}</td>
              <td>{{item.money}}</td>
            </tr>
          </tbody>
        </table>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  data() {
    return {
      list: [
        { amount: '1,000', money: '$54,522.65' },
        { amount: '1,000', money: '$54,522.65' },
      ]
    };
  },
  created() {

  },
  methods: {

  }
};
</script>