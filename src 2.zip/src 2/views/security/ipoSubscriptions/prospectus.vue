<template>
  <div class="prospectus">
    <div class="top">
      <div class="top-box">
        <img src="@/assets/img/1@3x.png" alt="" />
        <span>{{$t('security.ipoSubscriptions.prospectus.title')}}</span>
      </div>
    </div>
    <span class="title">{{$t('security.ipoSubscriptions.prospectus.title')}}</span>
    <div class="box">
      <div class="content">
        <el-scrollbar wrap-class="scrollbar-wrapper" style="height: 100%;">
          <p>
            {{$t('security.ipoSubscriptions.prospectus.content')}}
          </p>
          <p>{{$t('security.ipoSubscriptions.prospectus.content1')}}</p>
          <p style="text-indent:1em;">
            {{$t('security.ipoSubscriptions.prospectus.content2')}} <a :href="$t('security.ipoSubscriptions.prospectus.link')" target="_blank">{{$t('security.ipoSubscriptions.prospectus.link')}}</a>
          </p>
          <p style="text-indent:1em;">
            {{$t('security.ipoSubscriptions.prospectus.content3')}}
          </p>
          <p style="text-indent:1em;">
            {{$t('security.ipoSubscriptions.prospectus.content4')}}
          </p>
          <p>{{$t('security.ipoSubscriptions.prospectus.content5')}}</p>
          <p>{{$t('security.ipoSubscriptions.prospectus.content6')}}</p>
          <p class="text">{{$t('security.ipoSubscriptions.prospectus.content7')}}</p>
        </el-scrollbar>
      </div>
    </div>

    <div class="btn">
      <el-button type="primary" @click="close">{{
        $t('prompt.Close')
      }}</el-button>
    </div>
  </div>
</template>

<script>
export default {

  data() {
    return {
    };
  },
  created() {

  },
  methods: {
    // 关闭当前页
    close() {
      window.close()
    }
  },

};
</script>