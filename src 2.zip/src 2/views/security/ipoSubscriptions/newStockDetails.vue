<template>
  <div class="newStockDetails">
    <main-title :title="$t('security.ipoSubscriptions.details')" />
    <div class="newStockDetails-wrap mediumColor">
      <div class="newStockDetails-title heavyColor">{{eipoDetail.instrDsplyCode}} {{eipoDetail.ipoName}}
        <span class="text activeFontColor">{{eipoDetail.ipoMFSubStatus == "SUSPEND"?$t('security.ipoSubscriptions.zanting'):$t('security.ipoSubscriptions.jieshou')}}</span>
      </div>
      <ul class="newStockDetails-info">
        <li class="newStockDetails-item">
          <span class="newStockDetails-text">{{$t('security.ipoSubscriptions.jiaoYiSuo')}}</span>
          <span class="newStockDetails-val heavyColor">{{eipoDetail.mrktCode}}</span>
        </li>
        <li class="newStockDetails-item">
          <span class="newStockDetails-text">{{$t('security.ipoSubscriptions.currency')}}</span>
          <span class="newStockDetails-val heavyColor">{{eipoDetail.ccyCode}}</span>
        </li>
        <li class="newStockDetails-item">
          <span class="newStockDetails-text">{{$t('security.ipoSubscriptions.price')}}</span>
          <span class="newStockDetails-val heavyColor">{{eipoDetail.offerPrice}}</span>
        </li>
        <li class="newStockDetails-item">
          <span class="newStockDetails-text">{{$t('security.ipoSubscriptions.commission')}}</span>
          <span class="newStockDetails-val heavyColor" style="flex: 0 0 90px;">{{commissionRate}}</span>
        </li>
        <li class="newStockDetails-item">
          <span class="newStockDetails-text">{{$t('security.ipoSubscriptions.huiFei')}}</span>
          <span class="newStockDetails-val heavyColor">{{transactionLevy}}</span>
        </li>
        <li class="newStockDetails-item">
          <span class="newStockDetails-text">{{$t('security.ipoSubscriptions.huiFei1')}}</span>
          <span class="newStockDetails-val heavyColor" style="flex: 0 0 60px;">{{compensationFee}}</span>
        </li>
        <li class="newStockDetails-item">
          <span class="newStockDetails-text">{{$t('security.ipoSubscriptions.zaFei')}}</span>
          <span class="newStockDetails-val heavyColor">{{miscFee}}</span>
        </li>
        <li class="newStockDetails-item">
          <span class="newStockDetails-text">{{$t('security.ipoSubscriptions.jiaoYiFei')}}</span>
          <span class="newStockDetails-val heavyColor" style="flex: 0 0 90px;">{{tradingFee}}</span>
        </li>
        <li class="newStockDetails-item">
          <span class="newStockDetails-text">{{$t('security.ipoSubscriptions.date')}}</span>
          <span class="newStockDetails-val heavyColor" v-if="eipoDetail.refundDate">{{eipoDetail.refundDate.substring(0,10)}}</span>
        </li>
        <li class="newStockDetails-item">
          <span class="newStockDetails-text">{{$t('security.ipoSubscriptions.date1')}}</span>
          <span class="newStockDetails-val heavyColor" style="flex: 0 0 90px;" v-if="eipoDetail.collectionDate">{{eipoDetail.collectionDate.substring(0,10)}}</span>
        </li>
        <li class="newStockDetails-item">
          <span class="newStockDetails-text">{{$t('security.ipoSubscriptions.date2')}}</span>
          <span class="newStockDetails-val heavyColor" v-if="eipoDetail.listingDate">{{eipoDetail.listingDate.substring(0,10)}}</span>
        </li>
        <li class="newStockDetails-item">
          <span class="newStockDetails-text">{{$t('security.ipoSubscriptions.sharesNumber')}}</span>
          <span class="newStockDetails-val heavyColor">{{eipoDetail.lotSize}}</span>
        </li>
      </ul>
      <hr />
      <p class="heavyColor">{{$t('security.ipoSubscriptions.way')}}</p>
      <p class="heavyColor" v-show="cashShow">{{$t('security.ipoSubscriptions.cash')}}</p>
      <ul class="newStockDetails-info" v-show="cashShow">
        <li class="newStockDetails-item">
          <span class="newStockDetails-text">{{$t('security.ipoSubscriptions.date3')}}</span>
          <span class="newStockDetails-val heavyColor" v-if="eipoDetail.endDateTime">{{eipoDetail.endDateTime.replace( 'T',' ' )}}</span>
        </li>
        <li class="newStockDetails-item">
          <span class="newStockDetails-text">{{$t('security.ipoSubscriptions.date4')}}</span>
          <span class="newStockDetails-val heavyColor" v-if="eipoDetail.paymentDeadlineDateTime">{{eipoDetail.paymentDeadlineDateTime.replace( 'T',' ' )}}</span>
        </li>
        <li class="newStockDetails-item">
          <span class="newStockDetails-text">{{$t('security.ipoSubscriptions.date5')}}</span>
          <span class="newStockDetails-val heavyColor" v-if="eipoDetail.depositDate">{{eipoDetail.depositDate.replace( 'T',' ' )}}</span>
        </li>
        <li class="newStockDetails-item">
          <span class="newStockDetails-text">{{$t('security.ipoSubscriptions.poundage')}}</span>
          <span class="newStockDetails-val heavyColor">{{eipoDetail.handlingCharge|num}}</span>
        </li>
      </ul>
      <p class="heavyColor" v-show="marginShow">{{$t('security.ipoSubscriptions.subscribe')}}</p>
      <ul class="newStockDetails-info" v-show="marginShow">
        <li class="newStockDetails-item">
          <span class="newStockDetails-text">{{$t('security.ipoSubscriptions.date3')}}</span>
          <span class="newStockDetails-val heavyColor" v-if="eipoDetail.endDateTimeMF">{{eipoDetail.endDateTimeMF.replace( 'T',' ' )}}</span>
        </li>
        <li class="newStockDetails-item">
          <span class="newStockDetails-text">{{$t('security.ipoSubscriptions.date4')}}</span>
          <span class="newStockDetails-val heavyColor" v-if="eipoDetail.paymentDeadlineDateTimeMF">{{eipoDetail.paymentDeadlineDateTimeMF.replace( 'T',' ' )}}</span>
        </li>
        <li class="newStockDetails-item">
          <span class="newStockDetails-text">{{$t('security.ipoSubscriptions.date5')}}</span>
          <span class="newStockDetails-val heavyColor" v-if="eipoDetail.depositDate">{{eipoDetail.depositDate.replace( 'T',' ' )}}</span>
        </li>
        <li class="newStockDetails-item">
          <span class="newStockDetails-text">{{$t('security.ipoSubscriptions.date6')}}</span>
          <span class="newStockDetails-val heavyColor">{{numberInterestBearingDay}}</span>
        </li>
        <li class="newStockDetails-item">
          <span class="newStockDetails-text">{{$t('security.ipoSubscriptions.interestRate')}}</span>
          <span class="newStockDetails-val heavyColor">{{interestRateMF}}</span>
        </li>
        <li class="newStockDetails-item">
          <span class="newStockDetails-text">{{$t('security.ipoSubscriptions.amount')}}</span>
          <span class="newStockDetails-val heavyColor" style="flex: 0 0 90px;" v-if="eipoDetail.minLoanAmount">{{eipoDetail.minLoanAmount|num}}</span>
        </li>
        <li class="newStockDetails-item">
          <span class="newStockDetails-text">{{$t('security.ipoSubscriptions.proportion')}}</span>
          <span class="newStockDetails-val heavyColor">{{maximumDepositRate}}</span>
        </li>
        <li class="newStockDetails-item">
          <span class="newStockDetails-text">{{$t('security.ipoSubscriptions.poundage')}}</span>
          <span class="newStockDetails-val heavyColor">{{eipoDetail.handlingChargeMF|num}}</span>
        </li>
      </ul>
    </div>
  </div>
</template>

<script>
import mainTitle from '@/components/mainTitle';
import newStockDetails from "./newStockDetails.scss"

export default {
  components: {
    mainTitle
  },
  computed: {
  },
  props: {
    eipoDetail: {
      type: Object,
      default() {
        return {}
      }
    },
    cashShow: {
      type: Boolean
    },
    marginShow: {
      type: Boolean
    }
  },
  data() {
    return {
    }
  },
  watch: {

  },
  methods: {
  },
  created() {
  },
  computed: {
    numberInterestBearingDay: {
      get: function () {
        let a1 = Date.parse(this.eipoDetail.depositDate)
        let a2 = Date.parse(this.eipoDetail.refundDate)
        return Math.ceil((a2 - a1) / (1000 * 60 * 60 * 24));
      }
    },
    maximumDepositRate: {
      get: function () {
        let a3 = 1 - this.eipoDetail.minDepositRate
        let str = Number(a3 * 100).toFixed();
        str += "%";
        return str
      }
    },
    interestRateMF: {
      get: function () {
        let a4 = this.eipoDetail.interestRateMF
        let str = Number(a4 * 100).toFixed();
        str += "%";
        return str
      }
    },
    tradingFee: {
      get: function () {
        let a5 = this.eipoDetail.tradingFee
        let str = Number(a5 * 100).toFixed(3);
        str += "%";
        return str
      }
    },
    miscFee: {
      get: function () {
        let a6 = this.eipoDetail.miscFee
        if (a6 == 0) {
          return 0;
        }
        let str = Number(a6 * 100).toFixed(2);
        str += "%";
        return str
      }
    },
    transactionLevy: {
      get: function () {
        let a7 = this.eipoDetail.transactionLevy
        let str = Number(a7 * 100).toFixed(4);
        str += "%";
        return str
      }
    },
    commissionRate: {
      get: function () {
        let a8 = this.eipoDetail.commissionRate
        let str = Number(a8 * 100).toFixed();
        str += "%";
        return str
      }
    },
    compensationFee: {
      get: function () {
        let a9 = this.eipoDetail.compensationFee
        let str = Number(a9 * 100).toFixed();
        str += "%";
        return str
      }
    },
  },
  mounted() {
  },
}
</script>