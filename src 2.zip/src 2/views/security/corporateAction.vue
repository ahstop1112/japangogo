<!--公司行动(证券交易)-->
<template>
  <div class="corporateAction">
    <!-- 彈框 -->
    <popover :title="$t('security.corporateAction.title')" :showPopover="showPopover" @close="closePopover">
      <div class="second-wrap">
        <div class="success-wrap">
          <span class="icons"><i class="iconfont icon-status_success activeFontColor"></i></span>
          <span class="text activeFontColor">{{$t('security.corporateAction.successInfo')}}</span>
          <span class="text activeFontColor">{{$t('security.corporateAction.successInfo1')}}</span>
          <div class="success-btn">
            <el-button plain @click="goToRoute('/myInquiry/tradeHistory/companyAction')">{{$t('security.corporateAction.btn')}}</el-button>
          </div>
        </div>
      </div>
    </popover>
    <el-row :gutter="24">
      <el-col :xs="24" :sm="24" :md="12" :lg="12" :xl="12">
        <div class="corporateAction-list contentBg">
          <main-title :title="$t('security.corporateAction.list')" />
          <div class="corporateAction-wrap">
            <el-table :data="tableData" highlight-current-row @current-change="handleCurrentChange" :row-class-name="tableRowClass" :header-cell-style="headeRowClass" style="width: 100%">
              <el-table-column prop="marketName" width="70" :label="$t('security.corporateAction.market')">
                <template slot-scope="scope">
                  <div class="img">
                    <img v-if="scope.row.marketCode == 'HKEX'" src="@/assets/img/flag_HK@2x.png" alt="">
                    <img v-if="scope.row.marketCode != 'HKEX'" src="@/assets/img/flag_CN@2x.png" alt="">
                  </div>
                  <span>{{ scope.row.marketName }}</span>
                </template>
              </el-table-column>
              <el-table-column prop="instrName" align="left" min-width="90" :label="$t('security.corporateAction.stock')">
              </el-table-column>
              <el-table-column prop="ceventTypeName" align="center" width="110" :label="$t('security.corporateAction.type')" >
              </el-table-column>
              <el-table-column prop="replyDeadlineDate" align="center" min-width="110" :label="$t('security.corporateAction.date')"  :formatter="forMatterTime1">
              </el-table-column>
              <el-table-column prop="exptPayDate" align="center" min-width="110" :label="$t('security.corporateAction.date1')" :formatter="forMatterTime2">
              </el-table-column>
              <el-table-column prop="isReply" align="center" min-width="100" :label="$t('security.corporateAction.state')" :formatter="forMatterStatus">
              </el-table-column>
            </el-table> 
          </div>
        </div>
      </el-col>
      <el-col :xs="24" :sm="24" :md="12" :lg="12" :xl="12">
        <div class="corporateAction-details contentBg">
          <detailsOne v-if="isShow"></detailsOne>
          <detailsTwo v-if="!isShow"></detailsTwo>
          <div class="btn">
            <el-button type="primary" @click="openPopover" :class="{notClick:userData.allowTrade == false}" :disabled="userData.allowTrade === false">{{$t('security.corporateAction.tijiao')}}</el-button>
          </div>
        </div>
      </el-col>
    </el-row>
  </div>
</template>

<script>
import mainTitle from '@/components/mainTitle';
import detailsOne from './corporateAction/detailsOne';
import detailsTwo from './corporateAction/detailsTwo';
import dayjs from 'dayjs'
import popover from '@/components/popover';
import { mapGetters } from 'vuex';
import { eceEnquiry } from "@/api/security"
import corporateAction from './corporateAction.scss'

export default {
  components: {
    mainTitle,
    detailsOne,
    detailsTwo,
    popover
  },
  computed: {
    ...mapGetters(['getBgColor','getLang','getActiveAccountId']),
  },
  data() {
    return {
      showPopover: false,
      currentRow: '',
      isShow: true,
      tableData: [],
      userData: ''
    };
  },
  watch: {
    getLang() {
      this.getEceEnquiry();
    },
    getActiveAccountId: {
      handler: function(val) {
        if(val) {
          this.getEceEnquiry();
        }
      },
      immediate: true
    }
  },
  methods: {
    forMatterTime1(row, column) {    
      return dayjs(row.replyDeadlineDate).format('YYYY-MM-DD')
    },
    forMatterTime2(row, column) {    
      let time = dayjs(row.exptPayDate).format('YYYY-MM-DD')
      return time
    },
    forMatterStatus(row, column) {
      if(row.isReply == 'Y') {
        return this.$t('security.corporateAction.yihuifu');
      }else if(row.isReply == 'N') {
        return this.$t('security.corporateAction.weihuifu');
      }
    },
    tableRowClass() {
      return 'tableRowClass'
    },
    headeRowClass({ row, column, rowIndex, columnIndex }) {
      //表头的背景颜色
      if (rowIndex == 0) {
        if (this.getBgColor == 'bg-anhei') {
          return 'background:rgb(51,51,51)';
        } else {
          return 'background:rgb(255,255,255)';
        }
      }
    },
    goToRoute(path) {
      this.$router.push(path);
      this.$store.commit('changeIsJumpRouter', true);
    },
    openPopover() {
      this.showPopover = true;
    },
    // 隐藏弹窗
    closePopover() {
      this.showPopover = false;
    },
    // 公司行动列表点击事件
    handleCurrentChange(val) {
      this.currentRow = val;
      if (this.currentRow.stock == "00005 汇丰控股") {
        this.isShow = true
      } else {
        this.isShow = false
      }
    },
    getEceEnquiry() {
      let params = {
        "accountId": this.getActiveAccountId,
        "lang": this.getLang
      }
      eceEnquiry(   
        params
      ).then(res => {
          let tableList = res.data.accountList || [];
          this.tableData = tableList;
      })
    }
  },
  created() {
    this.userData = JSON.parse(sessionStorage.getItem("userData"));
  },
  mounted() {
   
  },
}

</script>