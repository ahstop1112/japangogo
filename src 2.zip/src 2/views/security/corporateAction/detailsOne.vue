<template>
  <div class="detailsOne">
    <main-title :title="$t('security.corporateAction.details')" />
    <div class="detailsOne-wrap mediumColor">
      <div class="detailsOne-title heavyColor">00005 汇丰控股</div>
      <ul>
        <li class="detailsOne-item">
          <span class="detailsOne-text">{{$t('security.corporateAction.code')}}</span>
          <span class="detailsOne-val heavyColor">CA0795525</span>
        </li>
        <li class="detailsOne-item">
          <span class="detailsOne-text">{{$t('security.corporateAction.dividend')}}</span>
          <span class="detailsOne-val heavyColor">HKD 10</span>
        </li>
      </ul>
      <p>{{$t('security.corporateAction.describe')}}</p>
      <p>{{$t('security.corporateAction.info')}}</p>
      <p>{{$t('security.corporateAction.info1')}} <a class="activeTagColor" href="http://www.hkex.com.hk" target="_blank">http://www.hkex.com.hk</a> {{$t('security.corporateAction.info2')}}</p>
      <hr />
      <p>{{$t('security.corporateAction.info3')}}</p>
      <p class="txt heavyColor">{{$t('security.corporateAction.info4')}} 1,000</p>
      <el-radio v-model="radio1" label="1">{{$t('security.corporateAction.info5')}}</el-radio>
      <div class="radio-group contentLightColor">
        <el-radio-group v-model="radio2">
          <el-radio :label="1">{{$t('security.corporateAction.info6')}}</el-radio>
          <el-radio :label="2">{{$t('security.corporateAction.info7')}}</el-radio>
          <el-radio :label="3">{{$t('security.corporateAction.info8')}}</el-radio>
        </el-radio-group>
      </div>
    </div>
  </div>
</template>

<script>
import mainTitle from '@/components/mainTitle';
import detailsOne from "./detailsOne";

export default {
  components: {
    mainTitle
  },
  data() {
    return {
      radio1: '1',
      radio2: 1,
    }
  },
  methods: {
  },
  mounted() { },
}
</script>

<style lang='scss' scoped>
.detailsOne {
  .detailsOne-wrap {
    padding: 12px 24px;
    font-family: SourceHanSansCN-Regular;
    font-size: 1rem;
    @media screen and(max-width: 768px) {
      padding: 12px;
    }
    .detailsOne-title {
      margin-bottom: 12px;
      font-family: SourceHanSansCN-Medium;
      font-size: 18px;
    }
    .detailsOne-item {
      display: flex;
      justify-content: flex-start;
      padding-bottom: 10px;
      line-height: 17px;
      .detailsOne-text {
        flex: 0 0 100px;
      }
      .detailsOne-val {
        flex: 0 0 130px;
        text-align: right;
        font-family: Avenir-Book;
      }
    }
    p {
      margin: 15px 0px;
    }
    a {
      font-family: SourceHanSansCN-Medium;
    }
    .txt {
      font-family: SourceHanSansCN-Medium;
    }
    .radio-group {
      margin-top: 10px;
      padding: 10px 20px;
      width: 100%;
    }
  }
}
</style>