<template>
  <div class="detailsTwo">
    <main-title :title="$t('security.corporateAction.details')" />
    <div class="detailsTwo-wrap mediumColor">
      <div class="detailsTwo-title heavyColor">00351 亞洲能源物流</div>
      <ul>
        <li class="detailsTwo-item">
          <span class="detailsTwo-text">{{$t('security.corporateAction.code')}}</span>
          <span class="detailsTwo-val heavyColor">CA0795525</span>
        </li>
        <li class="detailsTwo-item">
          <span class="detailsTwo-text">{{$t('security.corporateAction.dividend')}}</span>
          <span class="detailsTwo-val heavyColor">HKD 2.1354</span>
        </li>
        <li class="detailsTwo-item">
          <span class="detailsTwo-text">{{$t('security.corporateAction.newShares')}}</span>
          <span class="detailsTwo-val heavyColor">HKD 5.68</span>
        </li>
      </ul>
      <p>{{$t('security.corporateAction.describe1')}}</p>
      <p>{{$t('security.corporateAction.info')}}</p>
      <p>{{$t('security.corporateAction.info1')}} <a  class="activeTagColor" href="http://www.hkex.com.hk" target="_blank">http://www.hkex.com.hk</a> {{$t('security.corporateAction.info2')}}</p>
      <hr />
      <p>{{$t('security.corporateAction.info3')}}</p>
      <p class="txt heavyColor">{{$t('security.corporateAction.info4')}} 1,000</p>
      <el-radio-group class="radio-group-wrap " v-model="radio1">
        <el-radio :label="1">{{$t('security.corporateAction.info5')}}</el-radio>
        <el-radio :label="2">{{$t('security.corporateAction.info9')}}</el-radio>
        <el-radio :label="3">{{$t('security.corporateAction.info10')}}</el-radio>
      </el-radio-group>
      <div class="radio-group contentLightColor" v-if="radio1 == 1 || radio1 == 3">
        <el-radio v-if="radio1==1" v-model="radio2" label="4">{{$t('security.corporateAction.info6')}}</el-radio>
        <ul v-if="radio1==3">
          <li class="count">
            <span class="count-text mediumColor">{{$t('security.corporateAction.info11')}}</span>
            <el-input-number size="mini" v-model="num1" @change="handleChange1" :step="100" :min="0"></el-input-number>
            <el-radio class="radio" v-model="radio3" label="5">{{$t('security.corporateAction.info6')}}</el-radio>
          </li>
          <li class="count">
            <span class="count-text mediumColor">{{$t('security.corporateAction.info12')}}</span>
            <el-input-number size="mini" v-model="num2" @change="handleChange2" :step="100" :min="0"></el-input-number>
          </li>
        </ul>
      </div>

    </div>
  </div>
</template>

<script>
import mainTitle from '@/components/mainTitle';
import detailsTwo from "./detailsTwo";

export default {
  components: {
    mainTitle,
  },
  data() {
    return {
      radio1: 1,
      radio2: '4',
      radio3: '5',
      num1: 3000,
      num2: 3000,
    }
  },
  methods: {
    handleChange1(val) {
      console.log(val)
    },
    handleChange2(val) {
      console.log(val)
    },
  },
  mounted() { },
}
</script>