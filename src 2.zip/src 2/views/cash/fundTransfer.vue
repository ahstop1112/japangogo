<!-- 账户转账 -->
<template>
  <div class="fundTransfer-wrap contentBg" v-if="userData.onlineTrnfAllw===true">
    <!-- 弹出框 -->
    <popover :title="$t('cash.fundTransfer.heshi')" @close="closePopover" :showPopover="showPopover">
      <div class="exchange-main" v-if="firstStep">
        <div class="exchange-Info contentBorder">
          <div class="exchange-explain">
            <p class="explain-item lightColor">
              {{$t('cash.fundTransfer.heshiinfo')}}
            </p>
          </div>
          <ul class="exchange-base">
            <li class="exchange-base-item">
              <span class="text mediumColor">{{$t('cash.fundTransfer.money')}}</span>
              <span class="num heavyColor">HKD 6,847.50</span>
            </li>
            <li class="exchange-base-item">
              <span class="text mediumColor">{{$t('cash.fundTransfer.chuzhangzhanghu')}}</span>
              <span class="num heavyColor">02-0071828-33 (香港,中國A股,美國及場外市場)</span>
            </li>
            <li class="exchange-base-item">
              <span class="text mediumColor">{{$t('cash.fundTransfer.ruzhangAccount')}}</span>
              <span class="num heavyColor">02-0071828-00 (香港,中國A股,美國及場外市場)</span>
            </li>
          </ul>
        </div>
        <div class="password-wrap">
          <span class="txt mediumColor">{{$t('cash.fundTransfer.password')}}</span>
          <span class="password">
            <el-input v-model="password" type="password"></el-input>
          </span>
        </div>
        <div class="confirm-btn">
          <el-button @click="changeExchangeInfo">{{$t('cash.fundTransfer.change')}}</el-button>
          <el-button type="primary" @click="goNextStep">{{$t('cash.fundTransfer.confirm')}}</el-button>
        </div>
      </div>
      <div class="success-wrap" v-else>
        <ul class="success-content">
          <li class="success-icon">
            <i class="iconfont icon-status_success activeFontColor"></i>
          </li>
          <li class="success-text activeFontColor">
            {{$t('cash.fundTransfer.zhishi')}}
          </li>
          <li class="success-num heavyColor">
            {{$t('cash.fundTransfer.bianhao')}}：MP800052167
          </li>
        </ul>
        <div class="confirm-btn">
          <el-button>{{$t('cash.fundTransfer.zhanghujiecun')}}</el-button>
          <el-button type="primary">{{$t('cash.fundTransfer.print')}}</el-button>
        </div>
      </div>
    </popover>
    <!-- 账户 -->
    <div class="exchange-wrap" v-show="btnIndex == 0">
      <el-row class="exchange-content" :gutter="12">
        <el-col :xs="24" :sm="24" :md="12" :lg="12" :xl="12">
          <div class="content-left contentBg">
            <!-- 出賬戶口 -->
            <div class="form-wrap">
              <div class="form-title heavyColor">{{$t('cash.fundTransfer.chuzhangAccout')}}</div>
              <ul class="form-content">
                <li class="form-item">
                  <span class="form-text mediumColor">{{$t('cash.fundTransfer.chuzhangzhanghu')}}</span>
                  <span class="form-val heavyColor">
                    <el-select class="market" v-model="outAccount">
                      <el-option v-for="item in outAccountList" :key="item.value" :label="item.label" :value="item.value" style="width:100%">
                      </el-option>
                    </el-select>
                  </span>
                </li>
                <li class="form-item">
                  <span class="form-text mediumColor">{{$t('cash.fundTransfer.marketAndCurrency')}}</span>
                  <span class="form-val heavyColor">
                    <el-select class="market" v-model="marketsAndCurrencies">
                      <el-option v-for="item in marketsCurrenciesList" :key="item.value" :label="item.label" :value="item.value">
                      </el-option>
                    </el-select>
                  </span>
                </li>
                <li class="form-item">
                  <span class="form-text mediumColor">{{$t('cash.fundTransfer.money')}}</span>
                  <span class="form-val heavyColor">
                    <el-input :placeholder="$t('cash.fundTransfer.moneyPlaceholder')" v-model="extractVal" class="input-with-select">
                    </el-input>
                  </span>
                </li>
              </ul>
            </div>
            <!-- 入賬戶口 -->
            <div class="form-wrap">
              <div class="form-title heavyColor">{{$t('cash.fundTransfer.ruzhang')}}</div>
              <ul class="form-content">
                <li class="form-item">
                  <span class="form-text mediumColor">{{$t('cash.fundTransfer.zhanghuType')}}</span>
                  <span class="form-val heavyColor">
                    <el-select class="market" v-model="typeAccount" @change="selectMarket">
                      <el-option v-for="item in typeAccountList" :key="item.value" :label="item.label" :value="item.value">
                      </el-option>
                    </el-select>
                  </span>
                </li>
                <li class="form-item">
                  <span class="form-text mediumColor">{{$t('cash.fundTransfer.ruzhangAccount')}}</span>
                  <span class="form-val heavyColor">
                    <el-select class="market" v-model="collectionAccount">
                      <el-option v-for="item in collectionAccountList" :key="item.value" :label="item.label" :value="item.value">
                      </el-option>
                    </el-select>
                  </span>
                </li>
                <li class="form-item">
                  <span class="form-text mediumColor">{{$t('cash.fundTransfer.market')}}</span>
                  <span class="form-val heavyColor">
                    <el-select class="market" v-model="market">
                      <el-option v-for="item in marketList" :key="item.value" :label="item.label" :value="item.value">
                      </el-option>
                    </el-select>
                  </span>
                </li>
              </ul>
            </div>
            <div class="query-wrap">
              <el-button type="primary" @click="openQueryInfo">
                {{$t('cash.fundTransfer.nextStep')}}
              </el-button>
            </div>
          </div>
        </el-col>
        <!-- 注意事项 -->
        <el-col :xs="24" :sm="24" :md="12" :lg="12" :xl="12">
          <div class="content-right">
            <div class="disclaimer-title heavyColor">
              {{$t('cash.fundTransfer.zhuyi')}}
            </div>
            <div class="disclaimer-wrap">
              <p class="disclaimer-item mediumColor">
                {{$t('cash.fundTransfer.zhuyiinfo1')}}
              </p>
              <p class="disclaimer-item mediumColor">
                {{$t('cash.fundTransfer.zhuyiinfo2')}}
              </p>
              <p class="disclaimer-item mediumColor">
                {{$t('cash.fundTransfer.zhuyiinfo3')}}
              </p>
              <p class="disclaimer-item mediumColor">
                {{$t('cash.fundTransfer.zhuyiinfo4')}}
              </p>
            </div>
          </div>
        </el-col>
      </el-row>
      <div></div>
    </div>
  </div>
  <div class="investProfile-wrap" v-else>
    <span class="text heavyColor">{{$t('cash.fundTransfer.formCheck3')}}</span>
  </div>
</template>

<script>
import { mapGetters } from 'vuex'
import popover from '@/components/popover'
export default {
  components: {
    popover
  },
  computed: {
    ...mapGetters(['getLang'])
  },
  watch: {
    getLang: {
      handler: function (o, n) {
        this.$nextTick(() => {
          this.typeAccountList = [
            {
              value: 'Securities',
              label: this.$t("cash.fundTransfer.accoutType1")
            },
            {
              value: 'Futures',
              label: this.$t("cash.fundTransfer.accoutType2")
            }
          ]
          this.selectMarket(this.typeAccount);
        })
      },
      immediate: true
    }
  },
  data() {
    return {
      btnIndex: 0,
      showPopover: false, //是否显示弹出
      firstStep: true, //是否显示第一步
      // 出账户口
      outAccountList: [
        {
          value: '(孖展)02-0087618-00 HKD-82,536,086.91',
          label: '(孖展)02-0087618-00 HKD-82,536,086.91'
        },
        {
          value: '02-0071828-34(香港,中國A股,美國及場外市場)',
          label: '02-0071828-34(香港,中國A股,美國及場外市場)'
        },
        {
          value: '02-0071828-35(香港,中國A股,美國及場外市場)',
          label: '02-0071828-35(香港,中國A股,美國及場外市場)'
        }
      ],
      // 市场及货币
      marketsCurrenciesList: [
        {
          value: '香港，中国A股，美国及场外市场（HKD） 可提取结',
          label: '香港，中国A股，美国及场外市场（HKD） 可提取结'
        },
        {
          value: '中國B股市場',
          label: '中國B股市場'
        },
        {
          value: '其他市場',
          label: '其他市場'
        }
      ],
      // 账户类别
      typeAccountList: [],
      // 收款账户
      collectionAccountList: [
        {
          value: '(孖展)02-0087618-33',
          label: '(孖展)02-0087618-33'
        },
        {
          value: '中國B股市場',
          label: '中國B股市場'
        },
        {
          value: '其他市場',
          label: '其他市場'
        }
      ],
      // 市场
      marketList: [],
      // 出账户口
      outAccount: '(孖展)02-0087618-00 HKD-82,536,086.91',
      // 市场及货币
      marketsAndCurrencies: '香港，中国A股，美国及场外市场（HKD） 可提取结',
      // 转账金额
      extractVal: '',
      // buyVal: '',
      // 账户类别
      typeAccount: 'Securities',
      // 收款账户
      collectionAccount: '(孖展)02-0087618-33',
      // 市场
      market: '',
      password: '',
      marketIndex: 0,
      userData: ''
    }
  },
  methods: {
    //切換市場按鈕點擊
    selectMarket(val) {
      if (val == 'Securities') {
        this.marketList = [
          {
            value: 'mainMarket',
            label: this.$t("cash.fundTransfer.zhengquanMarket1")
          },
          {
            value: 'bSotckMarket',
            label: this.$t("cash.fundTransfer.zhengquanMarket2")
          },
          {
            value: 'otherMarket',
            label: this.$t("cash.fundTransfer.zhengquanMarket3")
          }
        ]
        this.market = 'mainMarket';
      } else if (val == 'Futures') {
        this.marketList = [
          {
            value: 'localMarket',
            label: this.$t("cash.fundTransfer.qihuoMarket1")
          },
          {
            value: 'OverseasMarket',
            label: this.$t("cash.fundTransfer.qihuoMarket2")
          }
        ]
        this.market = 'localMarket';
      }
    },
    chooseMarket(index) {
      this.marketIndex = index
    },
    goNextStep() {
      this.firstStep = false
    },
    changeExchangeInfo() {
      this.showPopover = false
    },
    //打开弹窗
    openQueryInfo() {
      let reg = /^\d*[.]?\d{1,2}$/;
      if (!reg.test(this.extractVal)) {
        this.$notify({
          message: this.$t("cash.fundTransfer.formCheck1"),
          duration: 3000,
        })
        return;
      } else if (Number(this.extractVal) < 1) {
        this.$notify({
          message: this.$t("cash.fundTransfer.formCheck2"),
          duration: 3000,
        })
        return;
      }
      //校验表单提交
      // if (this.sellCurrency == this.buyCurrency) {
      //   this.$notify({
      //     message: '沽出货币与买入货币不可以相同'
      //   })
      //   return
      // } else if (this.sellVal && this.buyVal) {
      //   this.$notify({
      //     message: '沽出货币和买入货币只能输入其中一个'
      //   })
      //   return
      // }
      this.showPopover = true
      this.firstStep = true
    },
    //隐藏弹窗
    closePopover() {
      this.showPopover = false
    },
    chooseItem(index) {
      this.btnIndex = index
    }
  },
  created() {
     this.userData = JSON.parse(sessionStorage.getItem("userData"));
  },
  mounted() {

  }
}
</script>
<style lang="scss" scoped>
.fundTransfer-wrap {
  width: 100%;
  .exchange-main .exchange-Info {
    padding: 12px 24px 48px 24px;
    width: 100%;
    .exchange-base {
      .exchange-base-item {
        display: flex;
        padding-top: 10px;
        .text {
          flex: 0 0 140px;
          font-family: SourceHanSansCN-Regular;
          font-size: 1rem;
        }
        .num {
          flex: 1;
          text-align: right;
          font-family: Avenir-Book;
          font-size: 1rem;
        }
      }
    }
    .exchange-explain {
      margin-bottom: 12px;
      .explain-item {
        margin-top: 12px;
        font-family: SourceHanSansCN-Regular;
        font-size: 14px;
        line-height: 16px;
      }
    }
  }
  .exchange-main .password-wrap {
    padding: 24px;
    display: flex;
    .txt {
      font-family: SourceHanSansCN-Regular;
      font-size: 1rem;
      line-height: 36px;
      padding-right: 48px;
    }
    .password {
      flex: 1;
    }
  }
  .exchange-main .confirm-btn {
    padding: 0 24px 12px 0;
    text-align: right;
  }
  .success-wrap {
    padding: 24px;
    .success-content {
      padding: 24px 0;
      .success-icon {
        text-align: center;
        padding-bottom: 12px;
        i {
          font-size: 58px;
        }
      }
      .success-text {
        text-align: center;
        font-family: SourceHanSansCN-Medium;
        font-size: 18px;
        padding: 12px 0;
        font-weight: 550;
      }
      .success-num {
        font-family: SourceHanSansCN-Regular;
        font-size: 14px;
        text-align: center;
      }
    }
    .confirm-btn {
      padding: 24px 0 48px 0;
      text-align: center;
      button {
        margin-right: 12px;
        font-weight: 600;
      }
    }
  }

  .exchange-wrap {
    width: 100%;
    .exchange-content {
      width: 100%;
      .content-left {
        padding: 24px;
        .form-wrap {
          width: 100%;
          .form-title {
            font-family: SourceHanSansCN-Medium;
            font-size: 20px;
          }
          .form-content {
            padding-bottom: 30px;
            .form-item {
              display: flex;
              align-items: center;
              padding: 12px 0;
              .form-text {
                flex: 0 0 120px;
                line-height: 18px;
                font-family: SourceHanSansCN-Regular;
                font-size: 1rem;
              }
              .form-val {
                flex: 1;
                font-family: Avenir-Book;
                font-size: 1rem;
                .input-with-select {
                  >>> .el-input__inner {
                    border-right: 1px solid rgba(51, 51, 51, 0.25);
                  }
                }
                .market {
                  width: 100%;
                }
              }
            }
          }
        }
        .query-wrap {
          padding: 12px 0;
          text-align: right;
        }
      }
      .content-right {
        padding: 24px;
        .disclaimer-title {
          margin-bottom: 24px;
          font-family: SourceHanSansCN-Medium;
          font-size: 1rem;
        }
        .disclaimer-wrap {
          .disclaimer-item {
            margin-top: 12px;
            font-family: SourceHanSansCN-Regular;
            font-size: 1rem;
            line-height: 20px;
          }
        }
      }
    }
  }
}
.investProfile-wrap {
  padding-top: 150px;
  text-align: center;
  .text {
    font-family: SourceHanSansCN-Regular;
    font-size: 1rem;
  }
}
@media screen and (max-width: 768px) {
  .el-col {
    padding: 0 !important;
  }
  .fundTransfer-wrap .btn-item {
    margin-left: 12px;
  }
  .fundTransfer-wrap .market-choose .market-info .market-item {
    margin-right: 12px;
  }
  .fundTransfer-wrap .exchange-wrap .exchange-content {
    margin: 0 !important;
  }
  .fundTransfer-wrap .exchange-wrap .exchange-content .content-left {
    padding: 12px;
  }
  .fundTransfer-wrap .exchange-wrap .exchange-content .content-right {
    padding: 12px;
    margin-top: 12px;
  }
  .fundTransfer-wrap
    .exchange-wrap
    .exchange-content
    .content-left
    .form-wrap
    .form-content
    .form-item
    .form-text {
    flex: 0 0 80px;
  }
}
</style>
