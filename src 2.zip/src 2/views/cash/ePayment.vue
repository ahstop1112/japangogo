<!--资金存入-->
<template>
  <div class="ePayment">
    <!-- 主页面 -->
    <ul class="mediumColor">
      <li class="contentBg largBorderRight">
        <div class="imgs">
          <img width="67" height="60" v-if="command == 'en_US'" src="@/assets/img/zhuanshukuai_en.jpg" alt="" />
          <img width="67" height="60" v-else src="@/assets/img/zhuanshukuai.jpg" alt="" />
        </div>
        <div class="text">
          <p>
            <span class="dot">•</span> {{$t('cash.ePayment.fps.information1')}}<a href="javascript:;" @click="$router.push('/cash/fps')">{{$t('cash.ePayment.fps.link')}}</a>{{$t('cash.ePayment.fps.information2')}}
          </p>
          <p class="top">
            <span class="dot">• </span>
            <a href="javascript:;" @click="$router.push('/cash/fps')">{{$t('cash.ePayment.fps.link')}}</a>{{$t('cash.ePayment.fps.information3')}}
          </p>
        </div>
      </li>
      <li class="contentBg largBorderRight">
        <div class="imgs">
          <img width="77" height="60" src="@/assets/img/EPS.jpg" alt="" />
        </div>
        <div class="text">
          <p>
            <span class="dot">• </span>{{$t('cash.ePayment.eps.information1')}}<a href="javascript:;" @click="$router.push('/cash/eps')">{{$t('cash.ePayment.eps.link')}}</a>{{$t('cash.ePayment.eps.information2')}}
          </p>
          <p class="top">
            {{$t('cash.ePayment.eps.information3')}}
          </p>
        </div>
      </li>
      <li class="contentBg largBorderRight">
        <div class="imgs">
          <img width="84" height="60" v-if="command == 'en_US'" src="@/assets/img/yizhuanshu_EN.jpg" alt="" />
          <img width="84" height="60" v-else src="@/assets/img/yizhuanshu.jpg" alt="" />
        </div>
        <div class="text">
          <p>
            <span class="dot">•</span><a href="javascript:;">{{$t('cash.ePayment.easyRevolutions.link1')}}</a>{{$t('cash.ePayment.easyRevolutions.information1')}}
          </p>
          <p>
            <a href="http://www.htisec.com" class="underline" target="_blank">{{$t('cash.ePayment.easyRevolutions.link2')}}</a>{{$t('cash.ePayment.easyRevolutions.information2')}}<a href="javascript:;">{{$t('cash.ePayment.easyRevolutions.link3')}}</a>{{$t('cash.ePayment.easyRevolutions.information3')}}<span class="red">{{$t('cash.ePayment.easyRevolutions.red')}}</span>{{$t('cash.ePayment.easyRevolutions.information4')}}
          </p>
          <p class="top">
            <span class="dot">• </span>
            {{$t('cash.ePayment.easyRevolutions.information5')}}<a class="underline" href="http://www.htisec.com" target="_blank">{{$t('cash.ePayment.easyRevolutions.link4')}}</a>{{$t('cash.ePayment.easyRevolutions.information6')}}<a href="javascript:;">{{$t('cash.ePayment.easyRevolutions.link5')}}</a>{{$t('cash.ePayment.easyRevolutions.information7')}}<a href="javascript:;">{{$t('cash.ePayment.easyRevolutions.link6')}}</a>{{$t('cash.ePayment.easyRevolutions.information8')}}<span class="red">{{$t('cash.ePayment.easyRevolutions.red1')}}</span>{{$t('cash.ePayment.easyRevolutions.information9')}}

          </p>
        </div>
      </li>
      <li class="contentBg largBorderRight">
        <div class="imgs">
          <img width="148" height="46" src="@/assets/img/pps_logo.jpg" alt="" />
        </div>
        <div class="text">
          <p>
            <span class="dot">• </span>
            {{$t('cash.ePayment.pps.information1')}}<span class="red">{{$t('cash.ePayment.pps.red1')}}</span>{{$t('cash.ePayment.pps.information2')}}<span class="red">{{$t('cash.ePayment.pps.red2')}}</span>{{$t('cash.ePayment.pps.information3')}}
          </p>
          <p class="top">
            <span class="dot">•</span>{{$t('cash.ePayment.pps.information4')}}
            <a :href="$t('cash.ePayment.pps.link')" target="_blank">{{$t('cash.ePayment.pps.link1')}}</a>
            {{$t('cash.ePayment.pps.information5')}}<span class="red"> {{$t('cash.ePayment.pps.red3')}}</span>{{$t('cash.ePayment.pps.information6')}}
          </p>
        </div>
      </li>
      <li class="contentBg largBorderRight">
        <div class="imgs">
          <img width="242" height="42" src="@/assets/img/BOC.jpg" alt="" />
        </div>
        <div class="text">
          <p>
            <span class="dot">• </span>
            {{$t('cash.ePayment.boc.information1')}}<a href="javascript:;"> {{$t('cash.ePayment.boc.link1')}}</a>{{$t('cash.ePayment.boc.information2')}}<span class="red">{{$t('cash.ePayment.boc.red')}}</span>{{$t('cash.ePayment.boc.information3')}}
          </p>
        </div>
      </li>
      <li class="contentBg largBorderRight">
        <div class="imgs">
          <img width="238" height="31" src="@/assets/img/huifeng.jpg" alt="" />
        </div>
        <div class="text">
          <p>
            <span class="dot">• </span>{{$t('cash.ePayment.hsbc.information1')}} <a :href="$t('cash.ePayment.hsbc.link3')" target="_blank">{{$t('cash.ePayment.hsbc.link1')}}</a> {{$t('cash.ePayment.hsbc.information2')}}<strong class="bold heavyColor">{{$t('cash.ePayment.hsbc.information3')}}</strong>{{$t('cash.ePayment.hsbc.information4')}}<strong class="bold heavyColor">{{$t('cash.ePayment.hsbc.information5')}}</strong>{{$t('cash.ePayment.hsbc.information6')}}
          </p>
          <p class="top">
            * {{$t('cash.ePayment.hsbc.information8')}}
            <a :href="$t('cash.ePayment.hsbc.link4')" target="_blank">{{$t('cash.ePayment.hsbc.link2')}}</a>{{$t('cash.ePayment.hsbc.information7')}}
          </p>
        </div>
      </li>
      <li class="contentBg largBorderRight">
        <div class="imgs">
          <img width="251" height="44" v-if="command == 'en_US'" src="@/assets/img/hengsheng_EN.jpg" alt="" />
          <img width="188" height="44" v-else src="@/assets/img/hengsheng.jpg" alt="" />
        </div>
        <div class="text">
          <p>
            <span class="dot">• </span>{{$t('cash.ePayment.hsb.information1')}}<a :href="$t('cash.ePayment.hsb.link3')" target="_blank">{{$t('cash.ePayment.hsb.link1')}}</a>{{$t('cash.ePayment.hsb.information2')}}<strong class="bold">{{$t('cash.ePayment.hsb.information3')}}</strong>{{$t('cash.ePayment.hsb.information4')}}
          </p>
          <p class="top">
            * {{$t('cash.ePayment.hsb.information6')}}
            <a :href="$t('cash.ePayment.hsb.link4')" target="_blank">{{$t('cash.ePayment.hsb.link2')}}</a>{{$t('cash.ePayment.hsb.information5')}}
          </p>
        </div>
      </li>
      <li class="contentBg largBorderRight">
        <div class="imgs">
          <img width="130" height="52" src="@/assets/img/zhada.jpg" alt="" />
        </div>
        <div class="text">
          <p>
            <span class="dot">• </span>{{$t('cash.ePayment.scb.information1')}}<a :href="$t('cash.ePayment.scb.link')" target="_blank">{{$t('cash.ePayment.scb.link1')}}</a>{{$t('cash.ePayment.scb.information2')}}<strong class="bold">{{$t('cash.ePayment.scb.information3')}}</strong>{{$t('cash.ePayment.scb.information4')}}<strong class="bold heavyColor">{{$t('cash.ePayment.scb.information5')}}</strong>{{$t('cash.ePayment.scb.information6')}}
          </p>
        </div>
      </li>
    </ul>
  </div>
</template>

<script>
import * as event from "@/utils/EventEmitter.js"
import { localGet } from '@/utils/mylocal.js'
export default {
  data() {
    return {
      // 切换语言的值
      command: '',
    }
  },
  methods: {
    onCommand(command) {
      this.command = command
    },
  },
  mounted() {
    event.addListener('langChange', this.onCommand)
    this.command = localGet('lang') || 'zh_TW'
  }
}
</script>
<style lang="scss" scoped>
.ePayment {
  ul {
    li {
      float: left;
      overflow: hidden;
      margin-bottom: 24px;
      padding: 24px;
      width: 33.33%;
      height: 280px;
      border-radius: 4px;
      @media screen and (max-width: 768px) {
        padding: 12px;
      }
      &:nth-child(-n + 3) {
        height: 300px;
      }
      @media screen and (max-width: 1650px) and (min-width: 1480px) {
        &:nth-child(-n + 6) {
          height: 330px;
        }
      }
      @media screen and (max-width: 1480px) and (min-width: 1280px) {
        &:nth-child(-n + 6) {
          height: 380px;
        }
      }
      @media screen and (max-width: 1150px) {
        &:nth-child(-n + 2) {
          height: 350px;
        }
      }
      @media screen and (max-width: 1279px) {
        float: left;
        width: 50%;
        &:nth-child(2n) {
          border-right: 0px solid #e9ecf1 !important;
        }
        &:nth-child(3) {
          //border-right: 24px solid #e9ecf1 !important;
          height: 280px;
        }
      }
      @media screen and (max-width: 980px) {
        float: left;
        margin-bottom: 12px;
        width: 100%;
        height: 100% !important;
        border-right: 0px solid #e9ecf1 !important;
        &:nth-child(3) {
          border-right: 0px solid #e9ecf1 !important;
        }
      }
      &:nth-child(3n) {
        // border-right: 0px solid #e9ecf1;
      }
      .text {
        margin-top: 15px;
        p,
        .bold,
        .red,
        .underline {
          font-family: SourceHanSansCN-Regular;
          font-size: 14px;
          line-height: 18px;
        }
        a {
          font-family: SourceHanSansCN-Medium;
          font-size: 14px;
          color: #4191ff;
          line-height: 10px;
          border-bottom: 1px solid #4191ff;
        }
        .red {
          color: rgba(255, 0, 0, 0.75);
        }
        .bold {
          font-family: SourceHanSansCN-Medium;
        }
        .top {
          margin-top: 7px;
        }
        .dot {
          font-size: 18px;
          color: #bfbfbf;
          line-height: 0px;
        }
        .underline {
          border-bottom: none;
        }
      }
    }
  }
}
</style>
