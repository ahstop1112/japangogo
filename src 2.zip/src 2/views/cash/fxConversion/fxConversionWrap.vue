<template>
  <div class="exchange-wrap">
    <popover :title="$t('cash.fxConversion.zhishi')" @close="closePopover" :showPopover="showPopover">
      <div class="exchange-main" v-if="firstStep">
        <div class="exchange-Info contentBorder">
          <ul class="exchange-base">
            <li class="exchange-base-item">
              <span class="text mediumColor">{{$t('cash.fxConversion.huilv')}}:</span>
              <span class="num heavyColor">1.00HKD = 0.872481 CNY</span>
            </li>
            <li class="exchange-base-item">
              <span class="text mediumColor">{{$t('cash.fxConversion.duichu')}}:</span>
              <span class="num heavyColor">100.00 HKD</span>
            </li>
            <li class="exchange-base-item">
              <span class="text mediumColor">{{$t('cash.fxConversion.duiru')}}:</span>
              <span class="num heavyColor">87.25 CNY </span>
            </li>
          </ul>
          <div class="exchange-explain">
            <p class="explain-item lightColor">{{$t('cash.fxConversion.duihuanlv')}}21/9/2019 14:12）</p>
            <p class="explain-item lightColor">{{$t('cash.fxConversion.duihuanExplain')}}</p>
          </div>
        </div>
        <div class="password-wrap">
          <span class="txt mediumColor">{{$t('cash.fxConversion.password')}}</span>
          <span class="password">
            <el-input v-model="password" type="password"></el-input>
          </span>
        </div>
        <div class="confirm-btn">
          <el-button @click="changeExchangeInfo">{{$t('cash.fxConversion.change')}}</el-button>
          <el-button type="primary" @click="goNextStep">{{$t('cash.fxConversion.confirm')}}</el-button>
        </div>
      </div>
      <div class="success-wrap" v-else>
        <ul class="success-content">
          <li class="success-icon">
            <i class="iconfont icon-status_success activeFontColor"></i>
          </li>
          <li class="success-text activeFontColor">
            {{$t('cash.fxConversion.duihuanSuccess')}}
          </li>
          <li class="success-num heavyColor">
            {{$t('cash.fxConversion.bianhao')}}：2167
          </li>
        </ul>
        <div class="confirm-btn">
          <el-button>{{$t('cash.fxConversion.duihuanjilu')}}</el-button>
          <el-button type="primary">{{$t('cash.fxConversion.print')}}</el-button>
        </div>
      </div>
    </popover>
    <div class="explain-wrap">
      <p class="explain-item mediumColor">{{$t('cash.fxConversion.explain1')}}</p>
      <p class="explain-item mediumColor">{{$t('cash.fxConversion.explain2')}}</p>
    </div>
    <el-row class="exchange-content contentBg" :gutter="12">
      <el-col :xs="24" :sm="24" :md="12" :lg="12" :xl="12">
        <div class="content-left">
          <div class="form-wrap">
            <div class="form-title heavyColor">{{$t('cash.fxConversion.sell')}}</div>
            <ul class="form-content">
              <!--
              <li class="form-item">
                <span class="form-text mediumColor">{{$t('cash.fxConversion.accountName')}}</span>
                <span class="form-val heavyColor">
                  Client 00900090
                </span>
              </li>
              <li class="form-item">
                <span class="form-text mediumColor">{{$t('cash.fxConversion.accountNum')}}</span>
                <span class="form-val heavyColor">02-0014861-30</span>
              </li>
              -->
              <li class="form-item">
                <span class="form-text mediumColor">{{$t('cash.fxConversion.market')}}</span>
                <span class="form-val heavyColor">
                  <el-select class="market" v-model="sellMarket">
                    <el-option v-for="item in market" :key="item.value" :label="item.label" :value="item.value">
                    </el-option>
                  </el-select>
                </span>
              </li>
              <li class="form-item">
                <span class="form-text mediumColor">{{$t('cash.fxConversion.money')}}</span>
                <span class="form-val heavyColor">
                  <el-input :placeholder="$t('cash.fxConversion.sellMoney')" v-model="sellVal" class="input-with-select">
                    <el-select v-model="sellCurrency" slot="append">
                      <el-option v-for="item in currencyType" :key="item.value" :label="item.label" :value="item.value">
                      </el-option>
                    </el-select>
                  </el-input>
                </span>
              </li>
            </ul>
          </div>
          <div class="form-wrap">
            <div class="form-title heavyColor">{{$t('cash.fxConversion.buy')}}</div>
            <ul class="form-content">
              <!--
              <li class="form-item">
                <span class="form-text mediumColor">{{$t('cash.fxConversion.accountName')}}</span>
                <span class="form-val heavyColor">Client 00900090</span>
              </li>
              <li class="form-item">
                <span class="form-text mediumColor">{{$t('cash.fxConversion.accountNum')}}</span>
                <span class="form-val heavyColor">02-0014861-30</span>
              </li>
              -->
              <li class="form-item">
                <span class="form-text mediumColor">{{$t('cash.fxConversion.market')}}</span>
                <span class="form-val heavyColor">
                  <el-select class="market" v-model="buyMarket">
                    <el-option v-for="item in market" :key="item.value" :label="item.label" :value="item.value">
                    </el-option>
                  </el-select>
                </span>
              </li>
              <li class="form-item">
                <span class="form-text mediumColor">{{$t('cash.fxConversion.money')}}</span>
                <span class="form-val heavyColor">
                  <el-input :placeholder="$t('cash.fxConversion.buyMoney')" v-model="buyVal" class="input-with-select">
                    <el-select v-model="buyCurrency" slot="append">
                      <el-option v-for="item in currencyType" :key="item.value" :label="item.label" :value="item.value">
                      </el-option>
                    </el-select>
                  </el-input>
                </span>
              </li>
              <li class="form-item">
                <span class="form-text mediumColor">{{$t('cash.fxConversion.duihuanDate')}}</span>
                <span class="form-val heavyColor">
                  <el-date-picker ref="fxDatePick" v-model="buyDate" type="date" prefix-icon="iconfont icon-date" :picker-options="pickerOptions">
                  </el-date-picker>
                </span>
              </li>
            </ul>
          </div>
          <div class="query-wrap">
            <el-button type="primary" @click="openQueryInfo">{{$t('cash.fxConversion.query')}}</el-button>
          </div>
        </div>
      </el-col>
      <el-col :xs="24" :sm="24" :md="12" :lg="12" :xl="12">
        <div class="content-right">
          <div class="disclaimer-title heavyColor">
            {{$t('cash.fxConversion.mianze')}}
          </div>
          <div class="disclaimer-wrap">
            <p class="disclaimer-item mediumColor">
              {{$t('cash.fxConversion.mianzeContent1')}}
            </p>
            <p class="disclaimer-item mediumColor">
              {{$t('cash.fxConversion.mianzeContent2')}}
            </p>
            <p class="disclaimer-item mediumColor">
              {{$t('cash.fxConversion.mianzeContent3')}}
            </p>
          </div>
        </div>
      </el-col>
    </el-row>
  </div>
</template>

<script>
import { mapGetters } from 'vuex'
import popover from "@/components/popover"
export default {
  computed: {
    ...mapGetters(['getLang'])
  },
  watch: {
    getLang: {
      handler: function (o, n) {
        this.$nextTick(() => {
          this.market = [
            {
              value: 'HKUSACN',
              label: this.$t("cash.fxConversion.hkAUSAsotck")
            },
            {
              value: '"ChinaBMarket',
              label: this.$t("cash.fxConversion.cnBStock")
            },
            {
              value: 'otherMarket',
              label: this.$t("cash.fxConversion.otherMarket")
            }
          ]
        })
      },
      immediate: true
    }
  },
  components: {
    popover
  },
  data() {
    return {
      showPopover: false,//是否显示弹出
      firstStep: true,//是否显示第一步
      pickerOptions: {
        disabledDate(time) {
          //获取当前日期
          let curDate = new Date().getDay();
          let dateTimeSpace = 24 * 60 * 60 * 1000;
          let curTimeSpace = new Date(new Date().toLocaleDateString()).getTime();//当日零点的时间戳
          let timeArr = [];//存储时间戳(开始日期，结束日期)
          let holiyday = false;
          if (time.getDay() == 6 || time.getDay() == 0) {
            holiyday = true;
          }
          if (curDate == 0) { //星期天
            timeArr = [curTimeSpace + dateTimeSpace, curTimeSpace + dateTimeSpace * 4];
          } else if (curDate == 6) {//星期六
            timeArr = [curTimeSpace + dateTimeSpace * 2, curTimeSpace + dateTimeSpace * 5];
          } else if (curDate == 5 || curDate == 4 || curDate == 3) {
            timeArr = [curTimeSpace, curTimeSpace + dateTimeSpace * 5];
          } else if (curDate == 2 || curDate == 1) {
            timeArr = [curTimeSpace, curTimeSpace + dateTimeSpace * 3];
          }
          return holiyday || !(time.getTime() >= timeArr[0] && time.getTime() <= timeArr[1])
        }
      },
      market: [],
      currencyType: [{
        value: 'HKD',
        label: 'HKD'
      }, {
        value: 'CNY',
        label: 'CNY'
      }, {
        value: 'USD',
        label: 'USD'
      },
      {
        value: 'AUD',
        label: 'AUD'
      }, {
        value: 'JPY',
        label: 'JPY'
      }, {
        value: 'NZD',
        label: 'NZD'
      },
      {
        value: 'CAD',
        label: 'CAD'
      }, {
        value: 'CHF',
        label: 'CHF'
      },
      {
        value: 'GBP',
        label: 'GBP'
      },
      {
        value: 'EUR',
        label: 'EUR'
      }, {
        value: 'SGD',
        label: 'SGD'
      }],
      sellVal: "",
      sellCurrency: "HKD",
      sellMarket: 'HKUSACN',
      buyVal: "",
      buyCurrency: "HKD",
      buyMarket: "HKUSACN",
      buyDate: "",
      password: "",
    };
  },
  methods: {
    //得到4个工作日日期
    getDuihuanDate() {
      //获取当前日期
      let curDate = new Date().getDay();
      let dateTimeSpace = 24 * 60 * 60 * 1000;
      let curTimeSpace = new Date(new Date().toLocaleDateString()).getTime();//当日零点的时间戳
      let timeArr = [];//存储时间戳(开始日期，结束日期)
      if (curDate == 0) { //星期天
        timeArr = [curTimeSpace + dateTimeSpace, curTimeSpace + dateTimeSpace * 4];
      } else if (curDate == 6) {//星期六
        timeArr = [curTimeSpace + dateTimeSpace * 2, curTimeSpace + dateTimeSpace * 5];
      } else if (curDate == 5 || curDate == 4 || curDate == 3) {
        timeArr = [curTimeSpace, curTimeSpace + dateTimeSpace * 5];
      } else if (curDate == 2 || curDate == 1) {
        timeArr = [curTimeSpace, curTimeSpace + dateTimeSpace * 3];
      }
      this.buyDate = timeArr[0];
    },
    //最多只能输入2位小数
    checkMoneyNUm() {
      let reg = /^\d*[.]?\d{1,2}$/;
      if (!this.sellVal && !this.buyVal) {
        this.$notify({
          message: this.$t("cash.fxConversion.formCheck1"),
          duration: 3000,
        });
        return;
      } else if (!reg.test(this.sellVal) && !this.buyVal) {
        this.$notify({
          message: this.$t("cash.fxConversion.formCheck2"),
          duration: 3000,
        });
        return;
      } else if (!reg.test(this.buyVal) && !this.sellVal) {
        this.$notify({
          message: this.$t("cash.fxConversion.formCheck3"),
          duration: 3000,
        });
        return;
      } else if (this.sellVal && this.buyVal) {
        this.$notify({
          message: this.$t("cash.fxConversion.formCheck4"),
          duration: 3000,
        });
        return;
      }
      return true;
    },
    chooseMarket(index) {
      this.marketIndex = index;
    },
    goNextStep() {
      this.firstStep = false;
    },
    changeExchangeInfo() {
      this.showPopover = false;
    },
    //打开弹窗
    openQueryInfo() {
      //校验金额
      if (!this.checkMoneyNUm()) {
        return;
      }
      //校验表单提交
      if (this.sellCurrency == this.buyCurrency) {
        this.$notify({
          message: this.$t("cash.fxConversion.formCheck5"),
          duration: 3000,
        });
        return;
      }
      this.showPopover = true;
      this.firstStep = true;
    },
    //隐藏弹窗
    closePopover() {
      this.showPopover = false;
    },
    chooseItem(index) {
      this.btnIndex = index;
    }
  },
  mounted() {
    this.$nextTick(() => {
      this.getDuihuanDate();
      //组件的ref属性需要$el
      let datePick = this.$refs.fxDatePick.$el
      datePick.children[2].style.display = 'none';
      datePick.children[1].setAttribute("class", "el-input__suffix")
    })
  },
}

</script>
<style lang='scss' scoped>
.exchange-wrap {
  width: 100%;
  .exchange-main .exchange-Info {
    width: 100%;
    padding: 12px 24px 48px 24px;
    .exchange-base {
      .exchange-base-item {
        padding-top: 6px;
        display: flex;
        .text {
          flex: 0 0 80px;
          font-family: SourceHanSansCN-Regular;
          font-size: 1rem;
        }
        .num {
          flex: 1;
          text-align: right;
          font-family: Avenir-Book;
          font-size: 1rem;
        }
      }
    }
    .exchange-explain {
      margin-top: 24px;
      .explain-item {
        font-family: SourceHanSansCN-Regular;
        font-size: 14px;
        line-height: 16px;
        margin-top: 12px;
      }
    }
  }
  .exchange-main .password-wrap {
    padding: 24px;
    display: flex;
    .txt {
      font-family: SourceHanSansCN-Regular;
      font-size: 1rem;
      line-height: 36px;
      padding-right: 48px;
    }
    .password {
      flex: 1;
    }
  }
  .exchange-main .confirm-btn {
    padding: 0 24px 12px 0;
    text-align: right;
  }
  .success-wrap {
    padding: 24px;
    .success-content {
      padding: 24px 0;
      .success-icon {
        text-align: center;
        padding-bottom: 12px;
        i {
          font-size: 58px;
        }
      }
      .success-text {
        text-align: center;
        font-family: SourceHanSansCN-Medium;
        font-size: 18px;
        padding: 12px 0;
      }
      .success-num {
        font-family: SourceHanSansCN-Regular;
        font-size: 14px;
        text-align: center;
      }
    }
    .confirm-btn {
      padding: 24px 0 48px 0;
      text-align: center;
      button {
        margin-right: 12px;
      }
    }
  }
  .explain-wrap {
    padding-bottom: 24px;
    .explain-item {
      font-family: SourceHanSansCN-Regular;
      font-size: 14px;
      line-height: 16px;
      padding: 5px 0;
    }
  }
  .exchange-content {
    width: 100%;
    .content-left {
      padding: 24px;
      .form-wrap {
        width: 100%;
        .form-title {
          font-family: SourceHanSansCN-Medium;
          font-size: 20px;
        }
        .form-content {
          padding-bottom: 30px;
          .form-item {
            padding: 12px 0;
            display: flex;
            align-items: center;
            .form-text {
              flex: 0 0 140px;
              font-family: SourceHanSansCN-Regular;
              font-size: 1rem;
            }
            .form-val {
              flex: 1;
              font-family: Avenir-Book;
              font-size: 1rem;
              .market {
                width: 100%;
              }
            }
          }
        }
      }
      .query-wrap {
        padding: 12px 0;
        text-align: right;
      }
    }
    .content-right {
      padding: 24px;
      .disclaimer-title {
        font-family: SourceHanSansCN-Medium;
        font-size: 1rem;
        margin-bottom: 24px;
      }
      .disclaimer-wrap {
        .disclaimer-item {
          margin-top: 12px;
          font-family: SourceHanSansCN-Regular;
          font-size: 1rem;
          line-height: 20px;
        }
      }
    }
  }
}
@media screen and (max-width: 768px) {
  .el-col {
    padding: 0 !important;
  }
  .exchange-wrap .explain-wrap {
    padding-bottom: 12px;
  }
  .exchange-wrap .exchange-content {
    margin: 0 !important;
  }
  .exchange-wrap .exchange-content .content-left {
    padding: 12px;
  }
  .exchange-wrap .exchange-content .content-right {
    padding: 12px;
    margin-top: 24px;
  }
  .exchange-wrap
    .exchange-content
    .content-left
    .form-wrap
    .form-content
    .form-item
    .form-text {
    flex: 0 0 80px;
  }
}
</style>