<template>
  <div class="logo-wrap" :class="getSideBar?'small_logowrap':''">
    <span class="logo-info" :class="getSideBar?'small-logoInfo':''">
        <img v-show="!getSideBar" src="@/assets/img/logo_horizontal@2x.png" />
        <img  v-show="getSideBar" src="@/assets/img/logo_stacked@2x.png" /> 
    </span>
    <span v-if="getDevice == 'desktop' &&  !getSideBar" class="logo-btn" @click="fixedSideBar">
      <i class="iconfont" :class="getFixedSide?'icon-menu_nor':'icon-menu_pre'"></i>    
    </span>      
  </div>
</template>

<script>
import { mapGetters } from 'vuex'
import sidebar from './sidebar.scss'

export default {
  data () {
    return {

    };
  },
  computed: {
    ...mapGetters(['getSideBar','getDevice','getFixedSide'])
  },
  methods: {
    fixedSideBar() {
      this.$store.commit("changeFixedSide");
    }
  },
  mounted(){
    
  },
}

</script>