<template>
  <div class="sidebar-wrap">
    <logo />  
    <sideItem />
    <backOld />
  </div>
</template>

<script>
import logo from "./logo"
import sideItem from "./sideItem"
import backOld from "./backOld"
import sidebar from './sidebar.scss'

export default {
  components: {
    logo,
    sideItem,
    backOld    
  }, 
  data () {},
  methods: {},
  mounted(){},
}
</script>