
<template>
  <!-- 弹框 -->
  <el-dialog :title="$t('register.addDialog.title')" :visible.sync="isShow" width="360px" class="addDialog" :close-on-click-modal="false" :show-close="false" :close-on-press-escape="false">
    <div class="imgs">
      <i slot="prefix" class="iconfont icon-status_warning"></i>
    </div>
    <span class="txt">
      {{ $t('register.addDialog.content') }}
    </span>
    <span slot="footer" class="dialog-footer">
      <el-button @click="close" class="btn">
        {{ $t('twoFaLogin.phoneLogin.btn1') }}</el-button>
      <el-button type="primary" @click="$router.push('/register')">{{
        $t('twoFaLogin.phoneLogin.btn2')
      }}</el-button>
    </span>
  </el-dialog>
</template>

<script>
import { verifyMobileApi } from '@/api/login'
import errTables from '@/utils/errTables'
import addDialog from './addDialogs.scss'

export default {
  data() {
    return {
      isShow: false
    }
  },
  mounted() {

  },
  methods: {
    close() {
      this.isShow = false
      const userData = JSON.parse(sessionStorage.getItem("userData"));
      // 发送获取验证码请求
      verifyMobileApi({ mobileNumber: userData.mobileNumber }).then(res => {
        sessionStorage.setItem('deviceId', res.data.deviceId)
        sessionStorage.setItem('resendTime', res.data.resendTimeInterval)
        sessionStorage.setItem('endTime', res.data.otpValidityEndTime)
        if (res.data.errorCode) {
          this.$notify({
            message: this.$t(errTables[res.data.errorCode]),
            duration: 3000
          });
        } else {
          // 跳转填写验证码页面
          this.$router.push({
            name: 'code',
            // params: {
            //   val
            // }
          })
        }
      })

    }
  }
}
</script>