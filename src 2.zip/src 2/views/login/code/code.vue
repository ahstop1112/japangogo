<template>
  <!-- 验证码填写页面 -->
  <div class="code">
    <div class="img">
      <img src="@/assets/img/login_HT_logo Copy@3x.png" alt="" />
    </div>
    <div class="imgs">
      <a v-if="command == 'en_US'" href="http://www.htisec.com/en-us/account-opening"><img src="@/assets/img/开设户口_EN@2x.png" alt="" /></a>
      <a v-else-if="command == 'zh_TW'" href="http://www.htisec.com/zh-hk/account-opening"><img src="@/assets/img/login_开设户口@3x.png" alt="" /></a>
      <a v-else href="http://www.htisec.com/zh-cn/account-opening"><img src="@/assets/img/开设户口_SC@2x.png" alt="" /></a>
    </div>
    <div class="box">
      <div class="box-left">
        <div class="logo">
          <img src="@/assets/img/login_HT_logo@3x.png" alt="" />
        </div>
        <span class="text" :class="[command == 'en_US' ? 'txt' : '']">
          {{ $t('login.system') }}
        </span>
        <div class="left-bg">
          <img src="@/assets/img/login_HT_logo_bg@3x.png" alt="" />
        </div>
      </div>
      <div class="box-right">
        <!-- 登陆导航 -->
        <div class="right-nav">
          <a href="javascript:;" :class="[ loginWay == true?'active':'',command == 'en_US' ? 'text1' : '' ]" @click="toSms">{{ $t('twoFaLogin.phoneLogin.Sms') }}</a>
          <a v-if="userData.authOptions[0].enrollmentStatus == 'Y' " href="javascript:;" :class="[ loginWay == false?'active':'',command == 'en_US' ? 'text1' : '' ]" @click="toOtp">{{ $t('twoFaLogin.phoneLogin.coding') }}</a>
        </div>
        <!-- 登陆内容 -->
        <div>
          <!-- 短信认证登陆 -->
          <div v-show="loginWay == true">
            <p class="txt">
              {{ $t('codeLogin.code') }}
            </p>
            <p class="txt txt2">
              {{ $t('codeLogin.time') }} {{optValidityEndTime}}{{ $t('codeLogin.shixiao') }}
            </p>
            <!-- 表单 -->
            <el-form :model="smsForm" :rules="rules1" ref="smsForm" class="form" :inline="true">
              <el-form-item prop="otp">
                <el-input :placeholder="$t('codeLogin.prompt')" v-model="smsForm.otp">
                  <i slot="prefix" class="iconfont icon-login_vcode"></i>
                  <el-button v-if="show" slot="suffix" class="time" type="primary" @click="getPhoneCode">
                    {{ $t('codeLogin.resend1') }}
                  </el-button>
                  <span onselectstart="return false" slot="suffix" class="time" v-if="!show">{{ count }}s {{ $t('codeLogin.resend') }}</span>
                </el-input>
              </el-form-item>
              <el-form-item>
                <div class="box-btn">
                  <el-button class="btn" plain @click="$router.push('/twoFaLogin')">
                    {{ $t('twoFaLogin.phoneLogin.btn1') }}
                  </el-button>
                  <el-button class="btn" type="primary" @click="toRisk1('smsForm')" :loading="loading">
                    {{ $t('twoFaLogin.phoneLogin.btn2') }}
                  </el-button>
                </div>
              </el-form-item>
            </el-form>
            <div class="txt txt1 fr">
              <el-popover ref="popover1" placement="right" width="200" trigger="hover" :content="$t('codeLogin.content1')">
              </el-popover>
              <div v-popover:popover1>
                <span class="txt3">{{ $t('codeLogin.no') }}</span>
                <i class="el-icon-info"></i>
              </div>
            </div>
            <div class="txt txt1">
              <p class="txt4">
                {{ $t('twoFaLogin.phoneLogin.prompt2') }}
              </p>
            </div>
            <!-- 下拉菜单 -->
            <el-select v-model="value" :placeholder="$t('twoFaLogin.phoneLogin.supplier1')">
              <el-option v-for="item in options" :key="item.value" :label="item.label" :value="item.value">
              </el-option>
            </el-select>
          </div>
          <!-- 保安编码认证登陆 -->
          <div v-show="loginWay == false">
            <p class="txt">
              {{ $t('twoFaLogin.codingLogin.coding1') }}
            </p>
            <!-- 表单 -->
            <el-form :model="softTokenForm" :rules="rules2" ref="softTokenForm" class="form" :inline="true">
              <el-form-item prop="mobileOtp">
                <el-input :placeholder="$t('twoFaLogin.codingLogin.coding2')" v-model="softTokenForm.mobileOtp" clearable>
                  <i slot="prefix" class="iconfont icon-login_otp"></i>
                </el-input>
              </el-form-item>
              <el-form-item>
                <div class="box-btn">
                  <el-button class="btn btn1" plain @click="$router.push('/twoFalogin')">
                    {{ $t('twoFaLogin.phoneLogin.btn1') }}
                  </el-button>
                  <el-button class="btn" type="primary" @click="toRisk2('softTokenForm')" :loading="loading">
                    {{ $t('twoFaLogin.phoneLogin.btn2') }}
                  </el-button>
                </div>
              </el-form-item>
            </el-form>
            <div class="txt txt1">
              <p class="txt2">
                {{ $t('twoFaLogin.phoneLogin.prompt2') }}
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
    <!-- 底部组件 -->
    <bottombar></bottombar>
  </div>
</template>

<script>
import bottombar from '@/views/_layout/bottombar'
import * as event from "@/utils/EventEmitter"
import { localGet, localSet } from '@/utils/mylocal'
import { login2FaApi, resendOtpApi, verifyMobileApi } from '@/api/login'
import errTables from '@/utils/errTables'
let TIME_COUNT = ''; // 设置一个全局倒计时的时间
export default {
  components: {
    bottombar
  },
  data() {
    return {
      userData: '',
      loading: false,
      show: true,
      count: '',
      timer: null,
      loginWay: true,
      optValidityEndTime: '',
      // 下拉菜单
      options: [
        {
          value: '选项1',
          label: this.$t('twoFaLogin.phoneLogin.supplier1')
        },
        {
          value: '选项2',
          label: this.$t('twoFaLogin.phoneLogin.supplier2')
        },
        {
          value: '选项3',
          label: this.$t('twoFaLogin.phoneLogin.supplier3')
        },
        {
          value: '选项4',
          label: this.$t('twoFaLogin.phoneLogin.supplier4')
        }
      ],
      value: '',
      smsForm: {
        otp: ''
      },
      softTokenForm: {
        mobileOtp: ''
      },
      // 切换语言的值
      command: '',
      //  校验规则
      rules1: {
        otp: [
          { required: true, message: this.$t('codeLogin.check1'), trigger: 'change' },
          {
            validator: (rule, value, callback) => {
              let reg = /^\d{6}$/
              if (reg.test(value)) {
                callback()
              } else {
                callback(new Error(this.$t('codeLogin.check2')))
              }
            },
            trigger: 'change'
          }
        ]
      },
      rules2: {
        mobileOtp: [
          { required: true, message: this.$t('twoFaLogin.phoneLogin.check2'), trigger: 'change' },
          {
            validator: (rule, value, callback) => {
              let reg = /^\d{6}$/
              if (reg.test(value)) {
                callback()
              } else {
                callback(new Error(this.$t('twoFaLogin.phoneLogin.check3')))
              }
            },
            trigger: 'change'
          }
        ]
      }
    }
  },
  created() {
    let _self = this;
    window.document.onkeydown = function (e) {
      let key = window.event.keyCode;
      if (key == 13 || key == 100) {
        _self.toRisk1();
      }
    }
    this.optValidityEndTime = sessionStorage.getItem('endTime')
    TIME_COUNT = sessionStorage.getItem('resendTime')
    this.userData = JSON.parse(sessionStorage.getItem("userData"));
    if (this.userData.authOptions[0].enrollmentStatus == 'Y') {
      // if (sessionStorage.regtime) {
      //   this.loginWay = true
      // } else {
      //   this.loginWay = false
      // }
      this.loginWay = false
    }
    // 进入页面时获取倒计时中止的位置，并继续计时
    // && sessionStorage.regtime <= TIME_COUNT
    if (sessionStorage.regtime > 0) {
      TIME_COUNT = sessionStorage.regtime;
      this.count = TIME_COUNT;
      this.show = false;
      this.timer = setInterval(() => {
        if (this.count > 0 && this.count <= TIME_COUNT) {
          this.count--
          sessionStorage.regtime = this.count;
        } else {
          this.show = true;
          clearInterval(this.timer);
          this.timer = null
        }
      }, 1000)
    }
  },
  mounted() {
    // 阻止浏览器后退行为
    history.pushState(null, null, document.URL);
    window.addEventListener('popstate', function () {
      history.pushState(null, null, document.URL);
    });
    event.addListener('langChange', this.onCommand)
    this.command = localGet('lang') || 'zh_TW'
    if (this.userData.authOptions[0].enrollmentStatus == 'N') {
      this.getCode()
    }
  },
  methods: {
    getCode() {
      // 验证码倒计时
      if (!this.timer) {
        this.count = TIME_COUNT
        sessionStorage.regtime = this.count;
        this.show = false
        this.timer = setInterval(() => {
          if (this.count > 0 && this.count <= TIME_COUNT) {
            this.count--
            sessionStorage.regtime = this.count;
          } else {
            this.show = true
            clearInterval(this.timer)
            this.timer = null
          }
        }, 1000)
      }
    },
    // 短信验证码登录按钮
    toRisk1(smsForm) {
      // 效验
      this.$refs.smsForm.validate(val => {
        if (val) {
          // 将加载状态设置为 true
          this.loading = true
          login2FaApi({
            otp: this.smsForm.otp,
            deviceId: sessionStorage.getItem('deviceId')
          }).then(res => {
            // 将加载状态设置为 false
            this.loading = false
            if (res.data.errorCode) {
              this.$notify({
                message: this.$t(errTables[res.data.errorCode]),
                duration: 3000
              });
            } else {
              // 登录成功后存储用户数据
              sessionStorage.setItem('userData', JSON.stringify(res.data))
              // 登录成功后存储token
              sessionStorage.setItem('token', res.headers['token'])
              // 跳转到风险披露声明页
              this.$router.push('/risk')
            }
          }).catch(error => {
            console.log(error);
          });
        } else {
          this.loading = false
        }
      })
    },
    // OTP登录按钮
    toRisk2(softTokenForm) {
      // 效验
      this.$refs.softTokenForm.validate(val => {
        if (val) {
          // 将加载状态设置为 true
          this.loading = true
          login2FaApi({
            mobileOtp: this.softTokenForm.mobileOtp,
            deviceId: sessionStorage.getItem('deviceId')
          }).then(res => {
            // 将加载状态设置为 false
            this.loading = false
            if (res.data.errorCode) {
              this.$notify({
                message: this.$t(errTables[res.data.errorCode]),
                duration: 3000
              });
            } else {
              // 登录成功后存储用户数据
              sessionStorage.setItem('userData', JSON.stringify(res.data))
              // 登录成功后存储token
              sessionStorage.setItem('token', res.headers['token'])
              // 跳转到风险披露声明页
              this.$router.push('/risk')
            }
          }).catch(error => {
            console.log(error);
          });
        } else {
          this.loading = false
        }
      })
    },
    onCommand(command) {
      this.command = command
    },
    // 点击按钮 重新发送手机验证码
    getPhoneCode() {
      resendOtpApi({
        mobileNumber: this.userData.mobileNumber,
        deviceId: sessionStorage.getItem('deviceId')
      }).then(res => {
        sessionStorage.setItem('endTime', res.data.otpValidityEndTime)
        this.optValidityEndTime = sessionStorage.getItem('endTime')
        if (res.data.errorCode) {
          this.$notify({
            message: this.$t(errTables[res.data.errorCode]),
            duration: 3000
          });
        } else {
          // 显示倒计时
          this.show = false
          // 验证码倒计时
          TIME_COUNT = sessionStorage.getItem('resendTime')
          this.count = TIME_COUNT
          sessionStorage.regtime = this.count;
          this.timer = setInterval(() => {
            if (this.count > 0 && this.count <= TIME_COUNT) {
              this.count--
              sessionStorage.regtime = this.count;
            } else {
              this.show = true
              clearInterval(this.timer)
              this.timer = null
            }
          }, 1000)
        }
      }).catch(error => {
        console.log(error);
      });

    },
    toSms() {
      this.loginWay = true
      this.$refs.softTokenForm.resetFields();
      verifyMobileApi({ mobileNumber: this.userData.mobileNumber }).then(res => {
        sessionStorage.setItem('deviceId', res.data.deviceId)
        sessionStorage.setItem('resendTime', res.data.resendTimeInterval)
        sessionStorage.setItem('endTime', res.data.otpValidityEndTime)
        if (res.data.errorCode) {
          this.$notify({
            message: this.$t(errTables[res.data.errorCode]),
            duration: 3000
          });
        } else {
          // 显示倒计时
          this.show = false
          // 验证码倒计时
          this.optValidityEndTime = sessionStorage.getItem('endTime')
          TIME_COUNT = sessionStorage.getItem('resendTime')
          this.count = TIME_COUNT
          sessionStorage.regtime = this.count;
          this.timer = setInterval(() => {
            if (this.count > 0 && this.count <= TIME_COUNT) {
              this.count--
              sessionStorage.regtime = this.count;
            } else {
              this.show = true
              clearInterval(this.timer)
              this.timer = null
            }
          }, 1000)
        }
      })
    },
    toOtp() {
      this.loginWay = false
      this.$refs.smsForm.resetFields();
    }
  }
}
</script>

<style lang="scss" scoped>
.code {
  position: relative;
  overflow: auto;
  width: 100%;
  height: 100%;
  .img {
    position: absolute;
    top: 0px;
    right: 0px;
    width: 815px;
    height: 844px;
    z-index: -99;
    img {
      width: 100%;
      height: 100%;
    }
  }
  .imgs {
    position: absolute;
    right: 30px;
    top: 20px;
    width: 160px;
    height: 80px;
    img {
      width: 100%;
      height: 100%;
    }
  }
  .box {
    display: flex;
    margin: 150px auto 153px;
    width: 880px;
    min-height: calc(100vh - 417px);

    .box-left {
      position: relative;
      width: 400px;
      height: 520px;
      background: #003da5;
      z-index: 0;
      .logo {
        margin: 50px auto 20px;
        width: 280px;
        height: 96px;
        img {
          width: 100%;
          height: 100%;
        }
      }
      .text {
        display: block;
        text-align: center;
        font-family: SourceHanSansCN-Heavy;
        font-size: 30px;
        color: #ffffff;
        letter-spacing: 4.5px;
        line-height: 20px;
      }
      .txt {
        font-family: Avenir-Heavy;
        letter-spacing: 0px;
        font-size: 20px;
      }
      .left-bg {
        position: absolute;
        left: 0;
        bottom: -4px;
        z-index: -10;
        img {
          width: 100%;
          height: 100%;
        }
      }
    }
    .box-right {
      padding: 24px 35px 0;
      width: 480px;
      height: 520px;
      background: #ffffff;
      // 头部导航
      .right-nav {
        display: flex;
        margin-bottom: 24px;
        width: 100%;
        height: 48px;
        border-bottom: 1px solid rgba(51, 51, 51, 0.25);
        a {
          display: inline-block;
          margin-right: 24px;
          height: 47px;
          font-size: 20px;
          font-family: SourceHanSansCN-Medium;
          color: rgba(51, 51, 51, 0.5);
          text-align: center;
          line-height: 48px;
          font-weight: 550;
          @media screen and (max-width: 768px) {
            &:nth-child(2) {
              margin-right: 0px;
            }
          }
          @media screen and (max-width: 425px) {
            &:nth-child(1) {
              margin-right: 15px;
            }
          }
          @media screen and (max-width: 395px) {
            &:nth-child(1) {
              margin-right: 10px;
            }
          }
          @media screen and (max-width: 340px) {
            &:nth-child(1) {
              margin-right: 8px;
            }
          }
        }
        .text1 {
          @media screen and (max-width: 395px) {
            font-size: 18px;
          }
          @media screen and (max-width: 356px) {
            font-size: 1rem;
          }
          @media screen and (max-width: 322px) {
            font-size: 15px;
          }
        }
        .active {
          border-bottom: 2px solid #003da5;
          color: #003da5;
        }
      }
      // 表单
      .form {
        margin-top: 20px;
        width: 100%;
        >>> .el-form-item__content {
          width: 100%;
        }
        .el-input {
          position: relative;
          width: 410px;
          font-family: SourceHanSansCN-Regular;
          font-size: 18px;
          color: rgba(51, 51, 51, 0.5);
          .icon-login_vcode {
            font-size: 24px;
            color: #003da5;
            margin-left: 8px;
            line-height: 48px;
          }
          .time {
            position: absolute;
            right: 6px;
            top: 1px;
            display: flex;
            align-items: center;
            justify-content: center;
            width: 120px;
            height: 35px;
          }
          >>> .el-input__clear {
            font-size: 20px;
          }
          >>> .el-input__inner {
            height: 48px;
            padding: 0px 105px 0px 48px;
          }
          >>> .el-input__suffix {
            margin-top: 5px;
            border-left: none;
          }
          .icon-login_otp {
            margin-left: 8px;
            font-size: 24px;
            color: #003da5;
            line-height: 48px;
          }
          span {
            padding: 6px 0px;
            font-family: SourceHanSansCN-Bold;
            font-size: 1rem;
            color: #ffffff;
            letter-spacing: 0;
            background-color: #bdbdbd;
            border: none;
            border-radius: 7px;
          }
        }

        .box-btn {
          display: flex;
          justify-content: space-between;
          width: 410px;
          .btn {
            width: 50%;
            font-family: SourceHanSansCN-Bold;
            font-size: 1rem;
          }
        }
      }
      // 文本
      .txt {
        font-family: SourceHanSansCN-Regular;
        font-size: 1rem;
        color: rgba(51, 51, 51, 0.75);
        line-height: 20px;
      }
      .txt1 {
        font-size: 14px;
        line-height: 16px;
      }
      .txt2 {
        margin: 8px 0;
      }
      .txt3 {
        border-bottom: 1px solid #000;
      }
      .txt4 {
        margin: 30px 0 8px 0;
      }
      .el-icon-info {
        padding-left: 5px;
      }

      // 下拉菜单
      .el-select {
        width: 202px;
      }
    }
  }
  .bottom-wrap {
    width: 100%;
    // position: fixed;
    // bottom: 0px;
  }
}
@media screen and (max-height: 940px) {
  .code .box {
    box-shadow: 10px 20px 24px 0 rgba(0, 0, 0, 0.1);
  }
}
@media screen and (max-width: 768px) {
  .code {
    width: 100%;
    min-height: 100%;
  }
  .code .img {
    display: none;
  }
  .code .imgs {
    display: none;
  }
  .code .box {
    width: 100%;
    margin: 0;
    box-shadow: none;
    flex-wrap: wrap;
    padding-bottom: 200px;
    min-height: calc(100vh - 118px);

  }
  .code .box .box-left {
    width: 100%;
    height: 241px;
    overflow: hidden;
  }
  .code .box .box-left .logo {
    margin: 48px auto 20px;
    width: 280px;
    height: 96px;
  }

  .code .box .box-left .left-bg {
    position: absolute;
    left: 0;
    top: 0;
    bottom: -100px;
  }
  .code .box .box-left .left-bg img {
    width: 400px;
    height: auto;
  }
  .code .box .box-right {
    padding: 24px 24px 0px;
    width: 100%;
    height: 100%;
  }
  .code .box .box-right .right-nav {
    width: 100%;
  }
  .code .box .box-right .form {
    width: 100%;
  }
  .code .box .box-right .form .el-form-item {
    width: 100%;
  }
  .code .box .box-right .form .el-form-item .el-form-item__content .el-input {
    width: 100%;
  }
  .code .box .box-right .form .box-btn {
    width: 100%;
  }
  .code .box .box-right .el-select {
    display: none;
  }
  // .code .bottom-wrap {
  //   width: 100%;
  //   position: static;
  // }
}
</style>
