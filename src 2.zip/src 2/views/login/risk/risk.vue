<template>
  <!-- 风险披露声明页面 -->
  <div class="risk">
    <div class="top">
      <img src="@/assets/img/login_HT_logo_blue@3x.png" alt="" />
    </div>
    <div class="box">
      <div class="content">
        <el-scrollbar wrap-class="scrollbar-wrapper">
          <p v-html="$t('risk.content1')" />
          <p v-html="$t('risk.content2')" class="content2" />
        </el-scrollbar>
      </div>
    </div>

    <div class="btn">
      <el-button type="primary" @click="toHome">{{
        $t('twoFaLogin.phoneLogin.btn2')
      }}</el-button>
    </div>
  </div>
</template>

<script>
import { localGet } from '@/utils/mylocal'
import risk from './risk.scss'

export default {
  data() {
    return {
      userData: ''
    }
  },
  created() {
    let _self = this;
    window.document.onkeydown = function (e) {
      let key = window.event.keyCode;
      if (key == 13 || key == 100) {
        _self.toHome();
      }
    }
    this.userData = JSON.parse(sessionStorage.getItem("userData"));
  },
  methods: {
    toHome() {
      this.$router.push('/')
      // 获取保安提示弹窗的不提示选中状态
      const checked = localGet('checked')
      // 获取北向交易声明弹窗的不提示选中状态
      const checked1 = localGet('checked1')
      // if (this.$store.state.user_data.hasOwnProperty('02-0233221-33') && !checked) {
      //   // 新窗口打开保安提示
      //   let prompt = this.$router.resolve({ path: "/prompt" });
      //   window.open(prompt.href, "_blank");
      // } else if (this.$store.state.user_data.hasOwnProperty('02-0273376-33') && !checked) {
      //   // 新窗口打开保安提示
      //   let prompt = this.$router.resolve({ path: "/prompt" });
      //   window.open(prompt.href, "_blank");
      // }



      if (!checked) {
        // 新窗口打开保安提示
        let prompt = this.$router.resolve({ path: "/prompt" });
        window.open(prompt.href, "_blank");
      }
      if (this.userData.nbTrdEcnsntAllw == true) {
        if (!checked1) {
          // 新窗口打开北向交易声明弹窗
          let prompt = this.$router.resolve({ path: "/mySettings/consentForConnect" });
          window.open(prompt.href, "_blank");
        }
      }
    }
  }
}
</script>