<template>
  <!-- 2FA登录验证页面 -->
  <div class="twoFaLogin">
    <div class="layout" v-show="!isShowSuccess">
      <div class="img">
        <img src="@/assets/img/login_HT_logo Copy@3x.png" alt="" />
      </div>
      <div class="imgs">
        <a v-if="command == 'en_US'" href="http://www.htisec.com/en-us/account-opening"><img src="@/assets/img/开设户口_EN@2x.png" alt="" /></a>
        <a v-else-if="command == 'zh_TW'" href="http://www.htisec.com/zh-hk/account-opening"><img src="@/assets/img/login_开设户口@3x.png" alt="" /></a>
        <a v-else href="http://www.htisec.com/zh-cn/account-opening"><img src="@/assets/img/开设户口_SC@2x.png" alt="" /></a>
      </div>
      <div class="box">
        <div class="box-left">
          <div class="logo">
            <img src="@/assets/img/login_HT_logo@3x.png" alt="" />
          </div>
          <span class="text" :class="[command == 'en_US' ? 'txt' : '']">
            {{ $t("login.system") }}
          </span>
          <div class="left-bg">
            <img src="@/assets/img/login_HT_logo_bg@3x.png" alt="" />
          </div>
        </div>
        <!-- 短讯认证 -->
        <div class="box-right">
          <!-- 登陆导航 -->
          <div class="right-nav">
            <a href="javascript:;" :class="[ loginWay == true?'active':'',command == 'en_US' ? 'text1' : '' ]">{{ $t("twoFaLogin.phoneLogin.Sms") }}</a>
            <!-- <a href="javascript:;" :class="[ loginWay == false?'active':'', ,command == 'en' ? 'text1' : '' ]" @click="toOtp">{{ $t("twoFaLogin.phoneLogin.coding") }}</a> -->
          </div>
          <!-- 登陆内容 -->
          <div>
            <!-- 短信认证 -->
            <div>
              <p class="txt">
                {{ $t("twoFaLogin.phoneLogin.code") }}
              </p>
              <!-- 表单 -->
              <el-form :model="form1" :rules="rules1" ref="form1" class="form" :inline="true">
                <el-form-item prop="mobileNumber">
                  <el-input :placeholder="$t('twoFaLogin.phoneLogin.phone')" v-model="form1.mobileNumber" clearable>
                    <i slot="prefix" class="iconfont icon-login_phone"></i>
                  </el-input>
                </el-form-item>
                <el-form-item>
                  <div class="box-btn">
                    <el-button class="btn" plain @click="cancelBack">
                      {{ $t("twoFaLogin.phoneLogin.btn1") }}
                    </el-button>
                    <el-button class="btn" type="primary" @click="toCode(form1)" :loading="loading">
                      {{ $t("twoFaLogin.phoneLogin.btn2") }}
                    </el-button>
                  </div>
                </el-form-item>
              </el-form>
              <div class="txt txt1">
                <p>
                  {{ $t("twoFaLogin.phoneLogin.prompt1") }}
                </p>
                <p class="txt2">
                  {{ $t("twoFaLogin.phoneLogin.prompt2") }}
                </p>
              </div>
              <!-- 下拉菜单 -->
              <el-select v-model="value" :placeholder="$t('twoFaLogin.phoneLogin.supplier1')">
                <el-option v-for="item in options" :key="item.value" :label="item.label" :value="item.value">
                </el-option>
              </el-select>
            </div>
            <!-- 保安编码登陆 -->
            <!-- <div v-if="loginWay == false">
              <p class="txt">
                {{ $t("twoFaLogin.codingLogin.coding1") }}
              </p> -->
            <!-- 表单 -->
            <!-- <el-form :model="form2" :rules="rules2" ref="form2" class="form" :inline="true">
                <el-form-item prop="coding1">
                  <el-input :placeholder="$t('twoFaLogin.codingLogin.coding2')" v-model="form2.coding1" clearable>
                    <i slot="prefix" class="iconfont icon-login_otp"></i>
                  </el-input>
                </el-form-item>
                <el-form-item>
                  <div class="box-btn">
                    <el-button class="btn btn1" plain @click="$router.push('/twoFaLogin')">
                      {{ $t("twoFaLogin.phoneLogin.btn1") }}
                    </el-button>
                    <el-button class=" btn" type="primary" @click="toRisk(form2)">
                      {{ $t("twoFaLogin.phoneLogin.btn2") }}
                    </el-button>
                  </div>
                </el-form-item>
              </el-form>
              <div class="txt txt1">
                <p class="txt2">
                  {{ $t("twoFaLogin.phoneLogin.prompt2") }}
                </p>
              </div>
            </div> -->
          </div>
        </div>

      </div>
    </div>
    <!-- 底部组件 -->
    <bottombar></bottombar>
    <!-- 提交成功 -->
    <success v-if="isShowSuccess" :title="$t('mySettings.changeParticulars.gerenziliao')" :btnName="$t('mySettings.changeParticulars.back')" @btnEvent="backLink">
      <div class="info-wrap">
        <p class="info-title">
          <i class="iconfont icon-status_success"></i>
          <span class="title">{{
            $t("mySettings.changeParticulars.tijiaozhishi")
          }}</span>
        </p>
        <p class="tip">{{ $t("mySettings.changeParticulars.zhishixinxi") }}</p>
      </div>
    </success>
    <!-- 注册otp弹框 -->
    <addDialog ref="addDialog"></addDialog>
  </div>
</template>

<script>
import bottombar from "@/views/_layout/bottombar";
import success from "@/views/other/success";
import * as event from "@/utils/EventEmitter"
import { localGet, localSet } from '@/utils/mylocal'
import { verifyMobileApi } from '@/api/login'
import errTables from '@/utils/errTables'
import addDialog from '../addDialog'
import twoFaLogin from './twoFaLogin.scss'

export default {
  components: {
    bottombar,
    success,
    addDialog
  },
  data() {
    return {
      loading: false,
      // 切换语言的值
      command: "",
      // 登陆方式的切换
      loginWay: true,
      // 表单
      form1: {
        mobileNumber: "",
      },
      form2: {
        coding1: "",
      },
      source: "", //路由跳转的来源
      isShowSuccess: false,
      // 下拉菜单
      options: [
        {
          value: "选项1",
          label: this.$t("twoFaLogin.phoneLogin.supplier1")
        },
        {
          value: "选项2",
          label: this.$t("twoFaLogin.phoneLogin.supplier2")
        },
        {
          value: "选项3",
          label: this.$t("twoFaLogin.phoneLogin.supplier3")
        },
        {
          value: "选项4",
          label: this.$t("twoFaLogin.phoneLogin.supplier4")
        }
      ],
      value: "",
      //  校验规则
      rules1: {
        mobileNumber: [
          {
            required: true,
            message: this.$t("twoFaLogin.phoneLogin.check"),
            trigger: "change"
          },
          {
            validator: (rule, value, callback) => {
              let reg = /^\d{8,11}$/;
              if (reg.test(value)) {
                callback();
              } else {
                callback(new Error(this.$t("twoFaLogin.phoneLogin.check1")));
              }
            },
            trigger: "change"
          }
        ]
      },
      rules2: {
        coding1: [
          {
            required: true,
            message: this.$t("twoFaLogin.phoneLogin.check2"),
            trigger: "change"
          },
          {
            validator: (rule, value, callback) => {
              let reg = /^\d{6}$/;
              if (reg.test(value)) {
                callback();
              } else {
                callback(new Error(this.$t("twoFaLogin.phoneLogin.check3")));
              }
            },
            trigger: "change"
          }
        ]
      }
    };
  },
  created() {
    let _self = this;
    window.document.onkeydown = function (e) {
      let key = window.event.keyCode;
      if (key == 13 || key == 100) {
        _self.toCode()
      }
    }
  },
  mounted() {
    // 阻止浏览器后退行为
    history.pushState(null, null, document.URL);
    window.addEventListener('popstate', function () {
      history.pushState(null, null, document.URL);
    });
    event.addListener("langChange", this.onCommand);
    this.command = localGet("lang") || "zh_TW";
    let params = this.$route.query.source;
    if (params == "changeParticulars") {
      this.source = "changeParticulars";
      // this.loginWay = false;
    }
  },
  methods: {
    backLink() {
      this.isShowSuccess = false;
      this.$router.replace({
        path: "/mySettings/changeParticulars",
        replace: true
      });
    },
    // 短讯认证返回
    cancelBack() {
      //如果从资料修改的页面进入的就返回到该页面
      if (this.source == "changeParticulars") {
        this.$router.push({
          path: "/mySettings/changeParticulars",
          query: {
            source: "twoFaLogin"
          }
        });
      } else {
        this.$router.push("/login");
      }
    },
    toCode() {
      // 效验
      this.$refs.form1.validate(val => {
        if (val) {
          // 将加载状态设置为 true
          this.loading = true
          if (this.source == "changeParticulars") {
            this.isShowSuccess = true;
          } else {
            // 发送验证手机号码请求(发送OTP)
            verifyMobileApi(this.form1)
              .then(res => {
                // 将加载状态设置为 false
                this.loading = false
                sessionStorage.setItem('deviceId', res.data.deviceId)
                sessionStorage.setItem('resendTime', res.data.resendTimeInterval)
                sessionStorage.setItem('endTime', res.data.otpValidityEndTime)
                if (res.data.errorCode) {
                  this.$notify({
                    message: this.$t(errTables[res.data.errorCode]),
                    duration: 3000
                  });
                  this.$router.push('/login')
                } else {
                  // 跳转填写验证码页面
                  this.$router.push({
                    name: 'code',
                    // params: {
                    //   val
                    // }
                  })
                }
              }).catch(error => {
                console.log(error);
              });
          }
        } else {
          // 将加载状态设置为 false
          this.loading = false
        }
      });
    },
    // toRisk() {
    //   // 效验
    //   this.$refs.form2.validate(val => {
    //     if (val) {
    //       if (this.source == "changeParticulars") {
    //         this.isShowSuccess = true;
    //       } else {
    //         // 跳转到风险披露声明页
    //         this.$router.push("/risk");
    //       }
    //     }
    //   });
    // },
    onCommand(command) {
      this.command = command;
    },
    // toOtp() {
    //   const data = localGet("userData")
    //   if (data.authOptions[0].enrollmentStatus == 'N') {
    //     // 打开注册弹窗
    //     this.$refs.addDialog.isShow = true
    //   } else {
    //     loginWay = false
    //   }
    // }
  }
};
</script>