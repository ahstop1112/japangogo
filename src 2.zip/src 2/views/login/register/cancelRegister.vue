<template>
  <!-- 取消流动保安编码注册页面 -->
  <div class="cancelRegister">
    <div class="top">
      <div class="top-box">
        <img src="@/assets/img/1@3x.png" alt="" />
        <span>{{ $t('register.unregister.title') }}</span>
      </div>
    </div>
    <!-- 表单 -->
    <div class="box " v-if="isSuccess == 0">
      <el-form :model="form" :rules="rules" ref="form" class="form " :inline="false">
        <h4>{{ $t('register.registerCode.name') }}</h4>
        <el-form-item prop="loginId">
          <el-input :placeholder="$t('register.registerCode.promptName')" v-model="form.loginId" clearable>
            <i slot="prefix" class="iconfont icon-login_username"></i>
          </el-input>
        </el-form-item>
        <h4>{{ $t('register.registerCode.password') }}</h4>
        <el-form-item prop="password">
          <el-input :type="show?'text':'password'" :placeholder="$t('register.registerCode.promptPassword')" v-model="form.password" clearable>
            <i slot="prefix" class="iconfont icon-login_password"></i>
            <i v-if="form.password!==''" slot="suffix" @click="show=!show" style="cursor:pointer; font-size: 40px;" :class="show?'iconfont icon-header_eye_show':'iconfont icon-header_eye_hide'"></i>
          </el-input>
        </el-form-item>
        <div class="btn">
          <el-button class="fr " type="primary" @click="confirm(form)" :loading="isLoading">{{
        $t('twoFaLogin.phoneLogin.btn2')
      }}</el-button>
        </div>
      </el-form>
    </div>

    <!-- 确认取消注册 -->
    <div class="success1" v-else-if="isSuccess == 1">
      <div class="info">
        <p>{{ $t('register.unregister.CancelRegister') }}</p>
      </div>
      <div class="btn">
        <el-button plain @click="$router.push('/login')">{{
          $t('twoFaLogin.phoneLogin.btn1')
        }}</el-button>
        <el-button type="primary" @click="toSuccess" :loading="loading">{{
          $t('twoFaLogin.phoneLogin.btn2')
        }}</el-button>
      </div>
    </div>
    <!-- 取消注册成功 -->
    <div class="success" v-else>
      <div class="info-wrap">
        <div class="imgs"><img src="@/assets/img/icon_pass@2x.png" alt="" /></div>
        <div class="info">
          <p>{{ $t('register.unregister.complete') }}</p>
        </div>
      </div>
      <span class="link"> <a href="javascript:;" @click="$router.push('/register')">{{
        $t('register.unregister.zaici')
      }}</a></span>
      <el-button class="btn" type="primary" @click="$router.push('/login')">{{
        $t('twoFaLogin.phoneLogin.btn2')
      }}</el-button>
    </div>
    <!-- 底部组件 -->
    <bottombar />
  </div>
</template>

<script>
import bottombar from '@/views/_layout/bottombar'
import { removeSoftwareTokenApi } from '@/api/register'
import { login1FaApi } from '@/api/login'
import errTables from '@/utils/errTables'
import cancelRegister from './cancelRegister.scss'

export default {
  components: {
    bottombar
  },
  data() {
    return {
      loading: false,
      isLoading: false,
      show: false,
      isSuccess: 0,
      form: {
        loginId: '',
        password: ''
      },
      //  校验规则
      rules: {
        loginId: [
          {
            required: true,
            message: this.$t('login.information1'),
            trigger: 'blur'
          }
        ],
        password: [
          {
            required: true,
            message: this.$t('login.information2'),
            trigger: 'blur'
          },
        ]
      }
    }
  },
  created() {
    let _self = this;
    window.document.onkeydown = function (e) {
      let key = window.event.keyCode;
      if (key == 13 || key == 100) {
        _self.confirm();
      }
    }
  },
  mounted() {

  },
  methods: {
    confirm() {
      // 效验
      this.$refs.form.validate(val => {
        if (val) {
          // 将加载状态设置为 true
          this.isLoading = true
          login1FaApi({
            loginId: this.form.loginId,
            password: this.form.password,
          }).then(res => {
            // 将加载状态设置为 false
            this.isLoading = false
            sessionStorage.setItem('entitySequence', res.data.entitySequence)
            if (res.data.errorCode) {
              this.$notify({
                message: this.$t(errTables[res.data.errorCode]),
                duration: 3000
              });
            } else {
              // 跳转页面
              this.isSuccess = 1
            }
          }).catch(error => { console.log(error); });
        } else {
          // 将加载状态设置为 false
          this.isLoading = false
        }
      })
    },
    toSuccess() {
      // 将加载状态设置为 true
      this.loading = true
      removeSoftwareTokenApi({
        loginId: this.form.loginId,
        entitySequence: sessionStorage.getItem("entitySequence")
      }).then(res => {
        // 将加载状态设置为 false
        this.loading = false
        if (res.data.errorCode) {
          this.$notify({
            message: this.$t(errTables[res.data.errorCode]),
            duration: 3000
          });
        } else {
          // 跳转页面
          this.isSuccess = 2
        }
      }).catch(error => { console.log(error); });

    }
  }
}
</script>