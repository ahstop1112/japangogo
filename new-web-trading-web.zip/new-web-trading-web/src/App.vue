<template>
  <div id="app" :class="[lang]">
    <router-view />
  </div>
</template>

<script>
import { localGet, localSet } from '@/utils/mylocal.js'
export default {
  name: 'App',
  methods: {},
  data() {
    return {
      // 切换语言的值
      lang: ""
    };
  },
  mounted() {
    this.lang = localGet("lang") || "zh_TW";
    localStorage.setItem('hasInterceptors', 'false');
  },
}
</script>

<style>
</style>
