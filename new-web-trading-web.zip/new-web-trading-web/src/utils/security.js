import {  getIsTradingDay } from "@/api/security"

//是否是交易日
export function _getIsTradingDay(curMarket) {
    let regionCode = "";
    let isTradeDay = false;
    curMarket == 'hkTrading'?regionCode = 'HK':curMarket == 'A-shareTrading'?regionCode = 'ML':regionCode = 'US';
    let parmas = {
        "params": {
            "regionCode": regionCode
        }
    }
    //返回promise
    return getIsTradingDay(
        parmas
    ).then(res => {
        if( res.result.isTradeDay) {
            isTradeDay = res.result.isTradeDay;
        }
        return isTradeDay
    }).catch(error => {
        //console.log(error)
    })
}
//根据市场判断是否是交易时间段 参数 当前市场， 和执行函数
export function _calTradyTime(curMarket,Func, datas) {
     //获取当前的日期
     let time = new Date();
     let month = time.getMonth() + 1;  //月
     let h = Number(time.getHours());  //时
     let m = Number((time.getMinutes()/60).toFixed(2));  //分
     let curHouse = h+m;
     let isRun = false;
     //港股交易时间段  9点 -  12点 13点-16点
     //A股交易时间段 9点15 - 11点半 13点到 15点
     //美股交易时间段 4月到11月 夏季 21.30 - 4  11月到4月冬季 22.30 到5点
     if(curMarket == 'hkTrading') {
         if((curHouse>=9 && curHouse<=12) || (curHouse>=13 && curHouse<=16)) {
           isRun = true;
         }    
     }else if(curMarket == 'A-shareTrading') {
        if((curHouse>=9.25 && curHouse <= 11.5)   || (curHouse>=13 && curHouse<=15)) {
           isRun = true;
         }  
     }else if(curMarket == 'usTrading'){
         //夏季
         if(month>=4 && month<11) {
             if((curHouse>= 21.5 && curHouse<=24)   || (curHouse>=0 && curHouse<=4)) {
                 isRun = true;
             }  
         }
         //冬季
         else{
             if((curHouse>= 22.5 && curHouse<=24)   || (curHouse>=0 && curHouse<=5)) {
                 isRun = true;
             }  
         }
     }
     if(isRun) {
         Func(datas)
     }
}
