//加载主题函数
export function loadThemColor(command) {
  let href = ''
  if (command == 'bg-anhei') {
    href = './static/theme/anhei.css';
  } else if (command == 'bg-guijin') {
    href = './static/theme/yellow.css';
  } else if (command == 'bg-hulan') {
    href = './static/theme/huBlue.css';
  } else {
    href = './static/theme/blue.css';
  }
  let linkObj = document.getElementById("themeColor");
  linkObj.setAttribute('href', href);
}