let eventCallbacks = {}

export function addListener (eventName, callback) {
  eventCallbacks[eventName] = callback
}

export function emit (eventName, data) {
  const callback = eventCallbacks[eventName]
  callback && callback(data)
}
