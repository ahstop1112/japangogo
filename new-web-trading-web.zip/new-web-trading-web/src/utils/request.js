import axios from 'axios'
import i18n from '../lang'
import { Notification, MessageBox } from 'element-ui'
import router from '../router/index'
// 创建 axios 实例
const myhttp = axios.create({
  withCredentials: true,
  baseURL: ''
})

//创建基础数据实例
const baseAPI = axios.create({
  baseURL: '',
  timeout: 3000
})

//创建行情实例
const marketAPI = axios.create({
  baseURL: '/mktinfo_api', //使用前端代理的接口
  timeout: 5000
})
//request拦截器
marketAPI.interceptors.request.use(
  config => {
    if (true) {
      //给需要加上token的响应头
      config.headers['Content-Type'] = ' application/json'
      config.headers['User-Token'] = ''
    }
    return config
  },
  error => {
    return Promise.reject(error)
  }
)
//response拦截器
marketAPI.interceptors.response.use(
  response => {
    const res = response.data
    if (res.code != 0) {
      Notification({
        message: res.message || '请求异常,请重试',
        duration: 5 * 1000
      })
      /* return Promise.reject({
                code: res.code,
                message: res.message
            })*/
    } else {
      return res
    }
  },
  error => {
    //处理各种请求错误
    if (error && error.response) {
      switch (error.response.code) {
        case 400:
          error.message = '错误请求'
          break
        case 500:
          error.message = '服务器错误'
          break
      }
    }
  }
)

// 设置請求拦截器
myhttp.interceptors.request.use(
  function (config) {
    if (true) {
      config.data.channelType = 'WEB'
    }
    const needToken = config.needToken
    // 判断是否需要携带 token
    if (needToken) {
      // 得到 token
      const token = sessionStorage.getItem('token')
      // 判断是否存在 token
      if (token) {
        // 携带 token
        config.headers.Authorization = token
      }
    }
    // if (config.url != '/login') {
    //   //如果不是登录得请求
    //   if (sessionStorage.getItem('token')) {
    //     //判断浏览器中是否有token
    //     config.headers.Authorization = sessionStorage.getItem('token') //如果有token就带上token请求服务器数据
    //   } else {
    //     router.push('/login') //如果浏览器中没有token就跳转到登陆界面
    //   }
    // }
    // 在发送请求之前做些什么
    return config
  },
  function (error) {
    // 对请求错误做些什么
    return Promise.reject(error)
  }
)

// 添加响应拦截器
myhttp.interceptors.response.use(
  function (response) {
    // 处理正常返回数据
    // 对响应数据做点什么
    return response
  },
  function (error) {
    if (error && error.response) {
      //判断是否已经拦截了，拦截了就直接不在拦截
      let hasInterceptors = localStorage.getItem('hasInterceptors')
      if(hasInterceptors == 'true') {
        return;
      }
      switch (error.response.status) { //i18n.t('login.bounced18')
        case 401:
          MessageBox({
            message: i18n.t('login.bounced18'),
            confirmButtonText: i18n.t('mySettings.changePassword.confirm'),
            type: 'warning',
            callback: action => {
              sessionStorage.clear()
              location.reload()
              router.push({ name: 'login' })
            }
          })
          break  
        case 404:
          sessionStorage.clear()
          router.push({ name: '404' })
          break;
        case 500:
          sessionStorage.clear()
          router.push({ name: '500' })
          break;
        default:
          error.message = `连接出错(${error.response.status})!`
      }
      localStorage.setItem('hasInterceptors','true')
    }
    // 对响应错误做点什么
    return Promise.reject(error)
  }
)
export { marketAPI, myhttp }
