<template>
  <div class="app-wrapper" >
    <div class="draw-bg"  @touchmove.prevent v-if="device == 'mobile' && getDeviceBar" @click="closeDrawBg"></div>
    <div class="app-left" @touchmove.prevent  :class="appLeftClass" @mouseenter="openSideBar" @mouseleave="closeSideBar">   
      <sidebar />
    </div>    
    <div id="appRight" class="app-right"  :class="[getFixedSide?'close-right':'',device=='mobile'?'mobile-right':'']">
      <div class="right-wrap">
        <topbar/>
        <middlebar/>
        <bottombar/>
      </div>
    </div>         
  </div>
</template>

<script>
import { mapGetters } from 'vuex'
import  topbar  from '@/layout/topbar'
import  sidebar  from '@/layout/sidebar/index'
import  middlebar  from '@/layout/middlebar'
import  bottombar  from '@/layout/bottombar'
import { loadThemColor } from '@/utils/loadTheme'
export default {
  components: {
    topbar, 
    sidebar, 
    middlebar, 
    bottombar
  },
  computed: {
    ...mapGetters(['getSideBar','getDeviceBar','getFixedSide']),
    appLeftClass() { //计算侧边栏的class类
      let className = "";
      if(this.device=='desktop') {
        this.getSideBar?className = '':className = 'open-left';  
      }else{
        this.getDeviceBar?className ='mobile-left-show':className ='mobile-right-show'
      }
      return className;
    }
  },
  data () {
    return {
      device:"",
      timer: null
    };
  },
  methods: {
    //打开侧边栏
    openSideBar() {
      //防止用户在边界多次触发事件
      if(this.timer !== null) {
        clearTimeout(this.timer)
      }
      this.timer = setTimeout( () => {
        this.$store.commit("changeSideBar",false);
      }, 50)
    },
    //隐藏侧边栏
    closeSideBar() {
      //是固定侧边栏
      if(this.getFixedSide || this.device == 'mobile') {
        return;
      }
      this.$store.commit("changeSideBar",true);
    },
    closeDrawBg() {
      this.$store.commit("changeDeviceBar");     
    },
    $_resizeHandler() {
      const rect = document.body.getBoundingClientRect().width;
      rect < 768 ? this.device = 'mobile':this.device = 'desktop';
      //初始化顯示狀態
      if(this.device == 'mobile') {
        this.$store.state.toggleSideBar = false;
      }else{
        //如果用户宽侧边栏下没有设定固定侧边栏，就让侧边栏显示小宽度
        if(!this.getFixedSide) {
          this.$store.state.toggleSideBar = true;
        }
      }
      this.$store.commit("changeDevice", this.device);
    }
  },
  created() {
    let configColor = localStorage.getItem('bgColor') || 'bg-Blue';
    loadThemColor(configColor);
    this.$_resizeHandler();
  },
  beforeMount() {
    window.addEventListener('resize', this.$_resizeHandler)
  },
  beforeDestroy() {
    window.removeEventListener('resize', this.$_resizeHandler);
    //登录页面的加载蓝色背景即可
    let configColor = 'bg-Blue';
    loadThemColor(configColor);
  },
  mounted(){

  }
}

</script>
<style lang="scss" scoped>
 @import "~@/styles/variables.scss";
 .app-wrapper{
   width: 100%;
   height: 100%;
   position: relative;
   transition:width .5s;
 }
 .app-left{
   position: fixed;
   left: 0;
   top: 0;
   z-index: 1000;
   width: 64px;
   height: 100%;
   overflow: hidden;
   transition-property: width , transform; 
   transition-duration: 0.5s , 0.5s;
 }
 .app-right{
   min-height: 100%;
   margin-left: 64px;
   transition:margin-left .5s;
 }
 .right-wrap{
   width: 100%;
   min-height: 100%;
   position: relative;
   background: #e9ecf1;
 }
 .open-left{
   width: 240px;
 }
 .close-right{
   margin-left: 240px;
 }
  .mobile-left-show{
   width: 240px;
   transform: translate3d(0,0,0);//去除菜单栏的阴影
   box-shadow: none;
 }
  .mobile-right-show{
   width: 240px;
   box-shadow: none;
   transform: translate3d(-240px,0,0);
 }
 .mobile-right{
   margin-left: 0;
 }
.draw-bg{
    position: fixed;
    background: rgba(0,0,0,.3);
    width: 100%;
    top: 0;
    left: 0;
    height: 100%;
    z-index: 999;
}
</style>