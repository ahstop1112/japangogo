<template>
  <div class="sideItem-wrap" @touchmove.stop>
    <el-scrollbar wrap-class="scrollbar-wrapper" style="width:100%;height: 100%;">
      <ul class="sidebar-container" ref="siderBarContainer">
        <li class="first-wrapper" :class="fistLevelIndex == index?'firstLevel-active':''" v-for="(level,index) in menuList" :key="level.name">
          <div class="menu-title" :class="getSideBar?'small-menu-title':''" @click="openSecondMenu(index,level.authName)">
            <span class="first-menu-icon" :class="getSideBar?'small-first-menu-icon':''">
              <i :class="level.icon"></i>
            </span>
            <span class="menu-text" :class="getSideBar?'small-menu-text':''">{{getSideBar?level.otherName:level.authName}}</span>
            <i v-show="!getSideBar" class="el-submenu__icon-arrow el-icon-arrow-right" :class="fistLevelIndex == index?'openArrow':''"></i>
          </div>
          <ul class="menu">
            <li class="second-wrapper" :class="[getSideBar?'small-second-wrapper':'',secondLevelIndex == secondIndex?'secondLevel-active':'']" v-for="(level2,secondIndex) in level.children" :key="level2.authName" @click="goBackView(secondIndex, level2.path,level2.authName)">
              <span class="second-menu-icon" :class="getSideBar?'small-second-menu-icon':''">
                <i :class="level2.icon"></i>
              </span>
              <span v-show="!getSideBar" class="menu-text">{{level2.authName}}</span>
              <el-badge v-if="!getSideBar && level2.badge && barVal" :value="barVal" class="second-right-icon"></el-badge>
            </li>
          </ul>
        </li>
      </ul>
    </el-scrollbar>
  </div>
</template>

<script>
import { mapGetters } from 'vuex'
import { eceCount } from "@/api/security"
export default {
  computed: {
    ...mapGetters(['getSideBar', 'getLang', 'getDeviceBar', 'getIsJumpRouter', 'getActiveAccountId'])
  },
  data() {
    return {
      fistLevelIndex: 0,//-1代表没有选中任何菜单。 -2代表选中的是右边顶部的图标菜单
      secondLevelIndex: -1,
      menuList: [],
      orginMenuList: [],//保存初始化的菜单数据
      userData: '',
      barVal: "",
      type: ''
    };
  },
  //监听切换语言的动作
  watch: {
    //监听路由信息设置其它导航的title信息
    $route(to, from) {
      //页面跳转回到顶部
      document.documentElement.scrollTop = 0;
      document.body.scrollTop = 0;
      let firstIndex = this.$route.meta.firstLevel;
      //不是侧边栏的页面跳转
      if (firstIndex == -2 || this.getIsJumpRouter) {
        this.otherRouteJump();
      }
    },
    getLang: {
      handler: function (o, n) {
        this.$nextTick(() => {
          if (this.userData.primeBrokerageFunds.length !== 0) {
            this.menuList.splice(1, 2)
            this.menuList[1].children.splice(4, 1)
            this.menuList[2].children.splice(0, 1)
            this.menuList[2].children.splice(2, 3)
            return
          } else {
            this.menuList[3].children.splice(5, 1)
          }

          let accountProfiles = this.userData.accountProfiles
          for (let i = 0; i < accountProfiles.length; i++) {
            if (accountProfiles[i].subAccountType != "INDIVIDUAL" || !sessionStorage.getItem("authenticationType")) {
              this.menuList[4].children.splice(0, 1)
            }
            if (accountProfiles[i].entityRole == "TPA" || accountProfiles[i].entityRole == "AP") {
              this.menuList[2].children.splice(0, 3)
              this.menuList[4].children.splice(4, 1)
            }
            if (accountProfiles[i].subAccountType == "CORPORATE") {
              this.menuList[4].children.splice(4, 1)
            }
            this.orginMenuList = this.menuList;
            return
          }
        })
        this.initLang();
        //右边当前选择的菜单信息
        this.fistLevelIndex = this.$route.meta.firstLevel;
        if (this.$route.meta.firstLevel > 0) {
          this.secondLevelIndex = this.$route.meta.secondLevel;
        }
        let lang = o;
        this.$nextTick(() => {
          //用户在汇款服务的时候切换为英文状态，让它跳到主页
          if (lang == 'en_US' && this.$route.name == 'remittanceServices') {
            this.goBackView(0, '/', this.menuList[0].authName, true);
            return;
          }
          if (this.fistLevelIndex != -2) {
            let titlteName = "";
            //没有选择子菜单，回到主页
            if (this.secondLevelIndex == -1) {
              this.goBackView(0, '/', this.menuList[0].authName, true);
            } else {
              titlteName = this.menuList[this.fistLevelIndex].children[this.secondLevelIndex].authName;
              //更新右边菜单栏的titleName
              this.$store.commit("updateCurrentTitle", titlteName);
            }
          } else {
            let title = this.$t("topBar")[this.$route.meta.title];
            this.$store.commit("updateCurrentTitle", title);
          }
        })

      },
      immediate: true
    },
    //重新计算侧边栏的高度
    getSideBar() {
      setTimeout(() => {
        this.calSideBarHeight();
      }, 500)
    },
    getActiveAccountId: {
      handler: function (val) {
        if (val) {
          this.getCorporationNum();
          this.changeClassifyMenu();
        }
      },
      immediate: true
    }
  },
  methods: {
    //根据accountId不同，加载不同的菜单
    changeClassifyMenu() {
      let totalAccoutId = this.userData.accountProfiles;
      let type = '';
      for (let i = 0; i < totalAccoutId.length; i++) {
        if (totalAccoutId[i].accountId == this.getActiveAccountId) {
          type = totalAccoutId[i].accountCategory;
        }
      }
      if (type != 'M') {
        let menuList = JSON.parse(JSON.stringify(this.orginMenuList));
        menuList[4].children.splice(2, 1);
        this.menuList = menuList;
      } else {
        this.menuList = this.orginMenuList;
      }
      setTimeout(() => {
        this.calSideBarHeight();
      }, 150)
    },
    getCorporationNum() {
      //PB账户不显示公司行动，不加载待办公司行动数量
      let isPBAccout = this.userData.primeBrokerageFunds.length ? true : false;
      if (isPBAccout) {
        return;
      }
      if (!this.getActiveAccountId) {
        return;
      }
      let params = {
        accountList: [this.getActiveAccountId]
      }
      eceCount(
        params
      ).then(res => {
        this.barVal = res.data.todoCount;
      }).catch(error => {
        //console.log(error)
      })
    },
    //内部页面跳转或者用户手动点击回退 
    otherRouteJump() {
      //右边当前选择的菜单信息
      this.fistLevelIndex = this.$route.meta.firstLevel;
      if (this.fistLevelIndex == 0) {
        this.secondLevelIndex = -1;
        this.$store.commit("updateCurrentTitle", this.menuList[0].authName);
      } else if (this.fistLevelIndex > 0) {
        this.secondLevelIndex = this.$route.meta.secondLevel;
        let titlteName = this.menuList[this.fistLevelIndex].children[this.secondLevelIndex].authName;
        //更新右边菜单栏的titleName
        this.$store.commit("updateCurrentTitle", titlteName);
        this.$store.commit('changeIsJumpRouter', false);
      } else {
        this.secondLevelIndex == -1;
        let title = this.$t("topBar")[this.$route.meta.title];
        this.$store.commit("updateCurrentTitle", title);
      }
      setTimeout(() => {
        this.calSideBarHeight();
      }, 150)
    },
    goBackView(index, path, title, isHome) {
      //中华通菜单点击直接打开新窗口
      if (path == '/mySettings/consentForConnect') {
        let routeData = this.$router.resolve({
          path: path,
          query: '',
        });
        window.open(routeData.href, '_blank');
        return;
      }
      //如果不是主页点击
      if (!isHome) {
        this.secondLevelIndex = index;
      }
      this.$router.push(path);
      this.$store.commit("updateCurrentTitle", title);
      //移动端点击关闭遮罩层
      if (this.getDeviceBar) {
        this.$store.commit("changeDeviceBar");
      }
    },
    openSecondMenu(index, title) {
      this.secondLevelIndex = -1;//清空二级分类
      if (index == 0) {
        this.goBackView(0, '/', title, true);
      }
      this.fistLevelIndex == index ? this.fistLevelIndex = -1 : this.fistLevelIndex = index;
      //计算侧边栏的高度
      this.calSideBarHeight();
    },
    calSideBarHeight() {
      //得到当前展开的元素
      //顶部导航栏的菜单点击 
      if (this.fistLevelIndex == -2 || this.fistLevelIndex == -1) {
        //清空所有的
        //evt.target 会冒泡
        let $li = this.$refs.siderBarContainer.children;
        for (let i = 0; i < $li.length; i++) {
          let $menu = $li[i].children[1];
          $menu.style.height = 0;
        }
        return;
      }
      let menu = this.$refs.siderBarContainer.children[this.fistLevelIndex].children[1];
      if (menu.children.length) {
        let $secondWrap = menu.children;
        let secondWrapHeight = 0;
        for (let i = 0; i < $secondWrap.length; i++) {
          secondWrapHeight += $secondWrap[i].clientHeight;
        }
        //如果再次点击的是当前元素不操作
        let totalHeight = secondWrapHeight + menu.children.length * 5;//需要加上每个元素的maring
        menu.style.height = totalHeight + "px"
      }
      //清空所有的
      let $li = this.$refs.siderBarContainer.children;
      for (let i = 0; i < $li.length; i++) {
        let $menu = $li[i].children[1];
        //如果再次点击的是当前元素不操作
        if (menu == $menu) {
          continue;
        }
        $menu.style.height = 0;
      }
    },
    //初始化多语言信息
    initLang() {
      this.menuList = [
        {
          id: 0,
          authName: this.$t("menuList.home.level1"),
          otherName: this.$t("menuList.home.level1_1"),
          path: "/", //默认打开主页
          icon: "iconfont icon-01home",
        },
        {
          id: 1,
          authName: this.$t("menuList.trad.level1"),
          otherName: this.$t("menuList.trad.level1_1"),
          icon: "iconfont icon-02security",
          children: [
            {
              authName: this.$t("menuList.trad.level2_1"),
              id: 1,
              path: "/security/mainMarket",
              icon: "iconfont icon-02-1HKMarkets",
              parentid: 1
            },
            {
              authName: this.$t("menuList.trad.level2_2"),
              id: 2,
              path: "/security/otherMarket",
              icon: "iconfont icon-02-2OtherMarkets",
              parentid: 1
            },
            {
              authName: this.$t("menuList.trad.level2_3"),
              id: 2,
              path: "/security/ipoSubscriptions",
              icon: "iconfont icon-02-3IPO",
              parentid: 1
            },
            {
              authName: this.$t("menuList.trad.level2_4"),
              id: 2,
              path: "/security/corporateAction",
              icon: "iconfont icon-02-4CorporateAction",
              parentid: 1,
              badge: true
            },
            {
              authName: this.$t("menuList.trad.level2_5"),
              id: 2,
              path: "/security/marginFinancingRatios",
              icon: "iconfont icon-02-5MarginFinancingRatios",
              parentid: 1
            }
          ]
        },
        {
          id: 2,
          authName: this.$t("menuList.control.level1"),
          otherName: this.$t("menuList.control.level1_1"),
          icon: "iconfont icon-04cash",
          children: [
            {
              authName: this.$t("menuList.control.level2_1"),
              id: 1,
              path: "/cash/fxConversion",
              icon: "iconfont icon-03_1FXConversion",
              parentid: 2
            },
            {
              authName: this.$t("menuList.control.level2_2"),
              id: 2,
              path: "/cash/fundTransfer",
              icon: "iconfont icon-03_2FundTransfer",
              parentid: 2
            },
            {
              authName: this.$t("menuList.control.level2_3"),
              id: 3,
              path: "/cash/fundWithdrawal",
              icon: "iconfont icon-03_3FundWithdrawal",
              parentid: 2
            },
            {
              authName: this.$t("menuList.control.level2_4"),
              id: 4,
              path: "/cash/ePayment",
              icon: "iconfont icon-03_4e-payment",
              parentid: 2
            },
            {
              authName: this.$t("menuList.control.level2_5"),
              id: 5,
              path: "/cash/remittanceServices",
              icon: "iconfont icon-03_5huikuanfuwu",
              parentid: 2,
              notShow: 'en_US',
            }
          ]
        },
        {
          id: 3,
          authName: this.$t("menuList.query.level1"),
          otherName: this.$t("menuList.query.level1_1"),
          icon: "iconfont icon-05TrasactionHistory",
          children: [
            {
              authName: this.$t("menuList.query.level2_1"),
              id: 1,
              path: "/myInquiry/accoutSummary",
              icon: "iconfont icon-05-1AccountSummary",
              parentid: 3
            },
            {
              authName: this.$t("menuList.query.level2_2"),
              id: 1,
              path: "/myInquiry/tradeHistory",
              icon: "iconfont icon-05-2TradeHistory",
              parentid: 3
            },
            {
              authName: this.$t("menuList.query.level2_3"),
              id: 1,
              path: "/myInquiry/fundMovement",
              icon: "iconfont icon-05-3FundMovement",
              parentid: 3
            },
            {
              authName: this.$t("menuList.query.level2_4"),
              id: 1,
              path: "/myInquiry/stockMovement",
              icon: "iconfont icon-05-4StockMovement",
              parentid: 3
            },
            {
              authName: this.$t("menuList.query.level2_5"),
              id: 1,
              path: "/myInquiry/myStatement",
              icon: "iconfont icon-05-5MyStatement",
              parentid: 3
            },
            {
              authName: this.$t("menuList.query.level2_6"),
              id: 1,
              path: "/myInquiry/myReport",
              icon: "iconfont icon-05-5MyStatement",
              parentid: 3
            },
          ]
        },
        {
          id: 4,
          authName: this.$t("menuList.seting.level1"),
          otherName: this.$t("menuList.seting.level1_1"),
          icon: "iconfont icon-07MySetting",
          children: [
            {
              authName: this.$t("menuList.seting.level2_1"),
              id: 1,
              path: "/mySettings/changeParticulars",
              icon: "iconfont icon-07_1Particular",
              parentid: 4
            },
            {
              authName: this.$t("menuList.seting.level2_2"),
              id: 1,
              path: "/mySettings/changePassword",
              icon: "iconfont icon-07_2ChangePassword",
              parentid: 4
            },
            {
              authName: this.$t("menuList.seting.level2_3"),
              id: 1,
              path: "/mySettings/passwordConfirm",
              icon: "iconfont icon-07_3PasswordConfirmationSetting",
              parentid: 4
            },
            {
              authName: this.$t("menuList.seting.level2_4"),
              id: 1,
              path: "/mySettings/marginApplication",
              icon: "iconfont icon-07_4MarginLimitApplication",
              parentid: 4
            },
            {
              authName: this.$t("menuList.seting.level2_5"),
              id: 1,
              path: "/mySettings/investProfile",
              icon: "iconfont icon-07_5InvestorCharacterizationQuestionnaire",
              parentid: 4
            },
            {
              authName: this.$t("menuList.seting.level2_6"),
              id: 1,
              path: "/mySettings/consentForConnect",
              icon: "iconfont icon-07_7ConsentforNorthboundTradingofChinaConnec",
              parentid: 4
            },
          ]
        },
      ]
      //如果是英文状态下删除资金存入按钮
      if (this.getLang == 'en_US') {
        let obj = {
          id: 2,
          authName: this.$t("menuList.control.level1"),
          otherName: this.$t("menuList.control.level1_1"),
          icon: "iconfont icon-04cash",
          children: [
            {
              authName: this.$t("menuList.control.level2_1"),
              id: 1,
              path: "/cash/fxConversion",
              icon: "iconfont icon-03_1FXConversion",
              parentid: 2
            },
            {
              authName: this.$t("menuList.control.level2_2"),
              id: 2,
              path: "/cash/fundTransfer",
              icon: "iconfont icon-03_2FundTransfer",
              parentid: 2
            },
            {
              authName: this.$t("menuList.control.level2_3"),
              id: 3,
              path: "/cash/fundWithdrawal",
              icon: "iconfont icon-03_3FundWithdrawal",
              parentid: 2
            },
            {
              authName: this.$t("menuList.control.level2_4"),
              id: 4,
              path: "/cash/ePayment",
              icon: "iconfont icon-03_4e-payment",
              parentid: 2
            }
          ]
        }
        this.menuList.splice(2, 1, obj);
      }
      setTimeout(() => {
        //重新计算菜单的高度
        this.calSideBarHeight();
      }, 150)
    },
    goBack() {
      this.otherRouteJump();
      document.documentElement.scrollTop = 0;
      document.body.scrollTop = 0;
    }
  },
  created() {
    this.userData = JSON.parse(sessionStorage.getItem("userData"));
  },
  mounted() {
    if (window.history && window.history.pushState) {
      window.addEventListener('popstate', this.goBack, false);
    }
  },
  destroyed() {
    window.removeEventListener('popstate', this.goBack, false);
  },
}

</script>
<style lang='scss' scoped>
.sideItem-wrap {
  width: 100%;
  flex: 1;
  margin-top: 36px;
  overflow: hidden;
}
.sidebar-container {
  width: 100%;
  .first-wrapper {
    .menu-title {
      width: 100%;
      padding: 0 15px 4px 20px;
      height: 60px;
      line-height: 60px;
      cursor: pointer;
      color: rgba(255, 255, 255, 0.75);
      position: relative;
      .first-menu-icon {
        margin-right: 10px;
        line-height: 20px;
        text-align: center;
        i {
          font-size: 22px;
        }
        &.small-first-menu-icon {
          display: block;
          margin-right: 0;
          width: 100%;
          line-height: 24px;
          height: 24px;
        }
      }
      .menu-text {
        font-size: 18px;
      }
      .small-menu-text {
        display: block;
        height: 24px;
        line-height: 24px;
        font-size: 14px;
      }
      .el-submenu__icon-arrow {
        font-size: 16px;
        right: 15px;
      }
      .openArrow {
        transform: rotate(90deg);
      }
      &.small-menu-title {
        height: 60px;
        padding: 4px 0;
        text-align: center;
      }
    }
    //二级菜单
    .menu {
      width: 100%;
      padding-left: 8px;
      transition: all 0.3s;
      height: 0;
      overflow: hidden;
      .second-wrapper {
        padding: 6px 35px 6px 10px;
        color: rgba(255, 255, 255, 0.75);
        position: relative;
        display: flex;
        align-items: center;
        cursor: pointer;
        font-size: 16px;
        margin-bottom: 5px;
        .second-menu-icon {
          display: inline-block;
          width: 20px;
          height: 20px;
          text-align: center;
          line-height: 20px;
          margin-right: 20px;
          i {
            font-size: 26px;
          }
          &.small-second-menu-icon {
            margin: 0;
          }
        }
        .menu-text {
          flex: 1;
          line-height: 20px;
        }
        .second-right-icon {
          position: absolute;
          right: 15px;
          top: 50%;
          margin-top: -6px;
          font-size: 12px;
          display: flex;
          align-items: center;
          height: inherit;
        }
        &.small-second-wrapper {
          text-align: center;
        }
      }
    }
  }
}
</style>