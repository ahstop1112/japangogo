<template>
  <div class="logo-wrap" :class="getSideBar?'small_logowrap':''">
    <span class="logo-info" :class="getSideBar?'small-logoInfo':''">
        <img v-show="!getSideBar" src="@/assets/logo_horizontal@2x.png" />
        <img  v-show="getSideBar" src="@/assets/logo_stacked@2x.png" /> 
    </span>
    <span v-if="getDevice == 'desktop' &&  !getSideBar" class="logo-btn" @click="fixedSideBar">
      <i class="iconfont" :class="getFixedSide?'icon-menu_nor':'icon-menu_pre'"></i>    
    </span>      
  </div>
</template>

<script>
import { mapGetters } from 'vuex'
export default {
  data () {
    return {

    };
  },
  computed: {
    ...mapGetters(['getSideBar','getDevice','getFixedSide'])
  },
  methods: {
    fixedSideBar() {
      this.$store.commit("changeFixedSide");
    }
  },
  mounted(){
    
  },
}

</script>
<style lang='scss' scoped>
    .logo-wrap{
        width: 100%;
        height: 64px;
        display: flex;
        padding: 8px;
        align-items: center;
        &.small_logowrap{
          padding: 0;    
        }
        .logo-info{
            flex:1;
            display: flex;
            align-items: center;
            padding-left: 10px;
            img{
                width: 95px;  
            }
          &.small-logoInfo{
            padding: 0;
            justify-content:center;
            img{
              width: 48px;  
            }
          }  
        }
        .logo-btn{
            flex: 0 0 24px;
            background:rgba(255,255,255,.25);
            border-radius: 3px;
            height: 24px;
            line-height: 24px;
            text-align: center;
            cursor: pointer;
            i{
                color: #fff;
                font-size: 20px;
            }
        }
    }   
</style>