<template>
  <div class="sidebar-wrap">
    <logo />  
    <sideItem />
    <backOld />
  </div>
</template>

<script>
import logo from "./logo"
import sideItem from "./sideItem"
import backOld from "./backOld"
export default {
  components: {
    logo,
    sideItem,
    backOld    
  }, 
  data () {
    return {

    }
  },
  methods: {
     
  },
  mounted(){

  },

}
</script>
<style lang='scss' scoped>
    .sidebar-wrap{
        width: 100%;
        height: 100%;
        display: flex;
        flex-direction: column;
    }
</style>