<template>
  <div class="backOld-wrap" >
    <a class="back">
      <em :class="getSideBar?'center':''">{{$t('asideBottom.old')}}</em>
      <em :class="getSideBar?'center':''">{{$t('asideBottom.Version')}}</em> 
    </a>
  </div>
</template>

<script>
import { mapGetters } from 'vuex'
import sidebar from './sidebar.scss'

export default {
  data () {
    return {
    };
  },
  computed: {
    ...mapGetters(['getSideBar'])
  },
  methods: {},
  mounted(){},

}
</script>