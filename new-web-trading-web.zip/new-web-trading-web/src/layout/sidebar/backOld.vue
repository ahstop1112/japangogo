<template>
  <div class="backOld-wrap" >
    <a class="back">
      <em :class="getSideBar?'center':''">{{$t('asideBottom.old')}}</em>
      <em :class="getSideBar?'center':''">{{$t('asideBottom.Version')}}</em> 
    </a>
  </div>
</template>

<script>
import { mapGetters } from 'vuex'
export default {
  data () {
    return {
    };
  },
  computed: {
    ...mapGetters(['getSideBar'])
  },
  methods: {},
  mounted(){},

}
</script>
<style lang='scss' scoped>
  .backOld-wrap{
    width: 100%;
    flex: 0 0 100px;
    display: flex;
    justify-content: center;
    align-items: center;
    a{
      color: #fff;
      font-size: 14px;
      width: 100%;
      text-align: center;
      .center{
        display: block;
        text-align: center;
      } 
    }
  }
</style>