<template>
  <div class="top-wrap" @click="hideSmallDetail" :class="[getFixedSide && getDevice != 'mobile' ? 'closeSideBar' : '',isOtherRouter?'otherHeight':'']">
    <div class="small-wrap" @touchmove.prevent v-if="getDevice == 'mobile'">
      <div class="small-top">
        <span class="leftBtn" @click="openSide"><i class="el-icon-s-unfold"></i></span>
        <span class="logo-info">
          <img src="@/assets/Haitong_logo.png" />
        </span>
        <span class="person" @click.stop="openSmallDetail"><i class="el-icon-s-custom"></i></span>
      </div>
      <div class="small-bg" v-show="showSmallDetail"></div>
      <transition name="bounce">
        <div class="small-content" v-show="showSmallDetail">
          <div class="layout contentBg" @click.stop>
            <div class="avater-wrap small-avater-wrap">
              <div class="avater">
                <span class="avater-img">LG</span>
              </div>
              <div class="user-base">
                <span class="name">{{userData.custName}}</span>
                <span class="numId">{{ $t('topBar.userID') }}: {{userData.custCode}}</span>
              </div>
              <div class="login-out" @click="exit">
                <span class="out">{{ $t('topBar.loginOut') }}</span>
                <i class="iconfont icon-header_me_logout"></i>
              </div>
            </div>
            <ul class="content-info contentBg">
              <li class="info-item contentBg contentBorder">
                <span class="lang-item lightColor" :class="langType == 'zh_TW'?'activeFontColor':''" @click="handleLang('zh_TW')">繁体</span>
                <span class="line lightColor">|</span>
                <span class="lang-item lightColor" :class="langType == 'zh_CN'?'activeFontColor':''" @click="handleLang('zh_CN')">简体</span>
                <span class="line lightColor">|</span>
                <span class="lang-item lightColor" :class="langType == 'en_US'?'activeFontColor':''" @click="handleLang('en_US')">ENG</span>
              </li>
              <li class="info-item contentBg contentBorder" @click="$router.push('/moreNotice')">
                <span class="icons mediumColor"><i class="iconfont icon-header_notices"></i></span>
                <span class="text mediumColor">{{$t('topBar.notice')}}</span>
              </li>
              <li class="info-item contentBg contentBorder" @click="$router.push('/newContact')">
                <span class="icons mediumColor"><i class="iconfont icon-header_servicer"></i></span>
                <span class="text mediumColor">{{$t('topBar.contact')}}</span>
              </li>
              <li class="info-item contentBg contentBorder" @click="$router.push('/newHelp')">
                <span class="icons mediumColor"><i class="iconfont icon-header_help"></i></span>
                <span class="text mediumColor">{{$t('topBar.help')}}</span>
              </li>
              <li class="info-item contentBg contentBorder" @click="toggleColorChoose">
                <span class="icons mediumColor"><i style="font-size:15px;margin-left:4px" class="iconfont icon-theme"></i></span>
                <span class="text mediumColor">{{$t('topBar.color')}}</span>
                <span class="rightIcons"><i class="el-submenu__icon-arrow el-icon-arrow-down mediumColor" :class="showColorWrap?'openArrow':''"></i></span>
              </li>
              <li class="color-wrap" :class="showColorWrap?'showColorWrap':''">
                <p class="color-item lightColor" :class="colorType == 'bg-Blue'?'activeFontColor':''" @click="handleCommand('bg-Blue')">{{ $t('topBar.blue') }}</p>
                <p class="color-item lightColor" :class="colorType == 'bg-guijin'?'activeFontColor':''" @click="handleCommand('bg-guijin')">{{ $t('topBar.yellow') }}</p>
                <p class="color-item lightColor" :class="colorType == 'bg-hulan'?'activeFontColor':''" @click="handleCommand('bg-hulan')">{{ $t('topBar.huBlue') }}</p>
                <p class="color-item lightColor" :class="colorType == 'bg-anhei'?'activeFontColor':''" @click="handleCommand('bg-anhei')">{{ $t('topBar.anhei') }}</p>
              </li>
              <li class="info-item contentBg contentBorder" @click="showQutorColor = !showQutorColor">
                <span class="icons mediumColor"><i class="iconfont icon-me_quotecolor"></i></span>
                <span class="text mediumColor">{{ $t('topBar.quoteColor') }}</span>
                <span class="rightIcons"><i class="el-submenu__icon-arrow el-icon-arrow-down mediumColor" :class="showQutorColor?'openArrow':''"></i></span>
              </li>
              <li class="color-wrap quote-wrap" :class="showQutorColor?'show-quoteColor':''">
                <p class="color-item lightColor" :class="quterType == 1?'activeFontColor':''" @click="handleQuteColor(1)">{{ $t('topBar.greenUpColor') }}</p>
                <p class="color-item lightColor" :class="quterType == 2?'activeFontColor':''" @click="handleQuteColor(2)">{{ $t('topBar.redUpColor') }}</p>
              </li>
              <li class="info-item contentBg contentBorder">
                <span class="icons mediumColor"><i class="iconfont icon-header_me_setting"></i></span>
                <span class="text mediumColor">{{$t('topBar.checkSetting')}}</span>
              </li>
              <li class="info-item contentBg contentBorder">
                <span class="icons mediumColor"><i class="iconfont icon-header_me_oldsystem"></i></span>
                <span class="text mediumColor">{{$t('topBar.backOld')}}</span>
              </li>
              <li class="people-info">
                <span class="telphone activeFontColor">{{ $t('topBar.middleman') }}:
                  <em class="num">{{userData.accountProfiles[0].aeName}}</em>
                </span>
                <span class="telphone activeFontColor">
                  {{ $t('topBar.telphone') }}:
                  <em class="num">(852){{userData.accountProfiles[0].aePhoneNumber}}</em>
                </span>
              </li>
            </ul>
          </div>
        </div>
      </transition>
    </div>
    <div class="user-num fl" v-if="!(!isShowAccount && getDevice == 'mobile')" :class="getDevice == 'mobile' ? 'small-user-num smallUserBg' : ''">
      <div class="layout-bg contentBg">
        <span v-if="getDevice != 'mobile'" class="cur-nav heavyColor" :class="isShowAccount?'contentRightBorder':''">
          {{getCurrentTitle}}
        </span>
        <div class="accout-wrap" v-if="accoutArr.length  == 1 && isShowAccount">
          <span class="account-txt">{{ $t('topBar.account') }}: </span>
          <span class="account-num">{{ openNumInfo ? accoutArr[0] : accoutArr2[0] }}</span>
        </div>
        <el-dropdown class="accout-wrap" trigger="click" v-if="accoutArr.length> 1 && isShowAccount" @command="handAccount" @visible-change="changeAccoutIcon">
          <span class="el-dropdown-link">
            <span class="account-txt">{{ $t('topBar.account') }}:</span>
            <span class="account-num">{{
               openNumInfo ?accoutArr[activeAccoutIndex]:accoutArr2[activeAccoutIndex]
            }}</span>
            <i ref="accountDownIcon" class="el-icon-arrow-down"></i>
          </span>
          <el-dropdown-menu slot="dropdown">
            <el-dropdown-item :command="index" v-for="(accout,index) in (openNumInfo ? accoutArr : accoutArr2)" :key="index">
              <span class="account-txt">{{ $t('topBar.account') }}:</span>
              <span class="account-num">{{ accout }}</span>
            </el-dropdown-item>
          </el-dropdown-menu>
        </el-dropdown>
        <span class="view" v-if="isShowAccount">
          <i @click="toggleNumInfo" :class="openNumInfo ? 'icon-header_eye_show' : 'icon-header_eye_hide'" class="iconfont"></i>
        </span>
      </div>
    </div>
    <div v-if="getDevice != 'mobile'" class="setting-wrap fr">
      <div class="layout-bg">
        <el-dropdown class="lang-wrap" trigger="click" @command="handleLang" @visible-change="changeIcon">
          <span class="el-dropdown-link">
            {{ activeLang}}
            <i ref="elDropdownIcon" class="el-icon-arrow-down"></i>
          </span>
          <el-dropdown-menu slot="dropdown">
            <el-dropdown-item command="zh_TW">中文（繁体）</el-dropdown-item>
            <el-dropdown-item command="zh_CN">中文（简体）</el-dropdown-item>
            <el-dropdown-item command="en_US">English</el-dropdown-item>
          </el-dropdown-menu>
        </el-dropdown>
        <span class="icons notify" :title="$t('topBar.notice')"><i class="iconfont icon-header_notices" @click="toMoreNotice"></i></span>
        <span class="icons" :title="$t('topBar.contact')"><i class="iconfont icon-header_servicer" @click="toNewContact"></i></span>
        <span class="icons" :title="$t('topBar.help')"><i class="iconfont icon-header_help" @click="toNewHelp"></i></span>
        <el-dropdown trigger="click" :title="$t('topBar.color')" class="change-color" @command="handleCommand">
          <span class="el-dropdown-link" :class="activeBg">
            <i class="iconfont icon-header_color_blue"></i>
          </span>
          <el-dropdown-menu slot="dropdown">
            <el-dropdown-item class="bg-Blue colorItem" icon="iconfont icon-header_color_blue" command="bg-Blue">{{ $t('topBar.blue') }}</el-dropdown-item>
            <el-dropdown-item class="bg-guijin colorItem" icon="iconfont icon-header_color_blue" command="bg-guijin">{{ $t('topBar.yellow') }}</el-dropdown-item>
            <el-dropdown-item class="bg-hulan colorItem" icon="iconfont icon-header_color_blue" command="bg-hulan">{{ $t('topBar.huBlue') }}</el-dropdown-item>
            <el-dropdown-item class="bg-anhei colorItem" icon="iconfont icon-header_color_blue" command="bg-anhei">{{ $t('topBar.anhei') }}</el-dropdown-item>
          </el-dropdown-menu>
        </el-dropdown>
        <span class="line"></span>
        <div class="user-wrap">
          <div class="user-info" @click.stop="showUserPannel = true">
            <span class="txt">{{ timeState }}, </span>
            <span class="name">{{userData.custName}}</span>
            <i class="el-icon-arrow-down"></i>
          </div>
          <ul @click.stop class="user-pannel userPannelBg" :class="!showUserPannel ? 'hideUserPannel' : ''">
            <li class="avater-wrap">
              <div class="avater">
                <span class="avater-img">LG</span>
              </div>
              <div class="user-base">
                <span class="name">{{userData.custName}}</span>
                <span class="numId">{{ $t('topBar.userID') }}: {{userData.custCode}}</span>
              </div>
              <div class="login-out" @click="exit">
                <span class="out">{{ $t('topBar.loginOut') }}</span>
                <i class="iconfont icon-header_me_logout"></i>
              </div>
            </li>
            <li class="pannel-item heavyColor contentBorder" style="cursor:pointer;" @click="showQutorColor = !showQutorColor">
              <i class="iconfont icon-me_quotecolor"></i>
              <span class="txt mediumColor">{{ $t('topBar.quoteColor') }}</span>
              <i class="el-submenu__icon-arrow el-icon-arrow-down" :class="showQutorColor?'openArrow':''"></i>
            </li>
            <li class="quotecolor-wrap" :class="showQutorColor?'show-quoteColor':''">
              <p class="quotecolor-item lightColor" :class="quterType == 1?'activeFontColor':''" @click="handleQuteColor(1)">{{ $t('topBar.greenUpColor') }}</p>
              <p class="quotecolor-item lightColor" :class="quterType == 2?'activeFontColor':''" @click="handleQuteColor(2)">{{ $t('topBar.redUpColor') }}</p>
            </li>
            <li class="pannel-item  heavyColor contentBorder">
              <i class="iconfont icon-header_me_setting"></i>
              <span class="txt mediumColor">{{ $t('topBar.checkSetting') }}</span>
            </li>
            <li class="pannel-item  heavyColor contentBorder">
              <i class="iconfont icon-header_me_oldsystem"></i>
              <span class="txt mediumColor">{{ $t('topBar.backOld') }}</span>
            </li>
            <li class="people-info">
              <span class="telphone activeFontColor">{{ $t('topBar.middleman') }}:
                <em class="num">{{userData.accountProfiles[0].aeName}}</em></span>
              <span class="telphone activeFontColor">{{ $t('topBar.telphone') }}:
                <em class="num">(852){{userData.accountProfiles[0].aePhoneNumber}}</em></span>
            </li>
          </ul>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import { mapGetters } from 'vuex'
import * as event from "@/utils/EventEmitter.js"
import { localGet, localSet, localRemove } from '@/utils/mylocal.js'
import { exitLoginApi } from '@/api/layout'
import { accountEnquiry } from "@/api/security"
import { loadThemColor } from '@/utils/loadTheme'
export default {
  data() {
    return {
      accoutArr: [],
      accoutArr2: [],
      isShowAccount: true,
      activeAccoutIndex: 0,
      activeAccoutId: '',
      langType: 'zh_TW',
      colorType: "bg-Blue",
      activeLang: '中文（繁体）',
      activeBg: 'bg-Blue',
      openNumInfo: false,
      showUserPannel: false,
      isOtherRouter: false,
      showColorWrap: false,
      showSmallDetail: false,
      timeState: '', //问候语
      showQutorColor: false,
      quterType: 1,//涨跌颜色设置
      userData: {},
      totalAccout:[],//得到所有可用的账号信息
    }
  },
  computed: {
    ...mapGetters([
      'getCurrentTitle',
      'getDevice',
      'getSideBar',
      'getLang',
      'getFixedSide',
      'getQuterType'
    ]),
  },
  //监听切换语言的动作
  watch: {
    //账户转账和资金提取不显示当前账户
    $route() {
      this.loadAccoutInfo();
    },
    getLang: {
      handler: function (to, from) {
        //右边当前选择的菜单信息
        this.$nextTick(() => {
          this.getTimeState(this.getLang);
        })
      },
      immediate: true
    }
  },
  created(){
    this.userData = JSON.parse(sessionStorage.getItem("userData"));
  },  
  methods: {
    loadActiveAccout(dataArr) {
      //1.如果用户自己选择了账户再切换页面的时候不变  2.如果用户没设置取tradingAccount  3.如果都没有取第一项
      let activeAccout =  this.userData.tradingAccount;
      if(this.activeAccoutId != "") {
        let index = dataArr.indexOf(this.activeAccoutId);
        if(index != -1) {
          index != -1? this.activeAccoutIndex = index :''
        }else if(dataArr.indexOf(activeAccout) != -1) {
          this.activeAccoutIndex = dataArr.indexOf(activeAccout);
        }else{
          this.activeAccoutIndex = 0;
        }
      }else if(dataArr.indexOf(activeAccout) != -1) {
        this.activeAccoutIndex = dataArr.indexOf(activeAccout);
      }else{
        this.activeAccoutIndex = 0;
      }
      this.$store.commit('updateActiveAccountId', dataArr[this.activeAccoutIndex]);
    },
    hideAccout(dataArr) {
      let accoutArrInfo = [];
      for (let i = 0; i < dataArr.length; i++) {
        let str = dataArr[i].substr(0, 3) + "*******" + dataArr[i].substr(10);
        accoutArrInfo.push(str)
      }
      return accoutArrInfo;
    },
    //根据不同的路由权限加载不同的账号信息
    loadAccoutInfo() {
      // 结单全部账户都展示（单独处理一下）
      if(this.$route.name == 'myStatement') {
        let spiceArr = [];
        let spiceAccout = this.userData.accountProfiles;
        for(let i = 0;i<spiceAccout.length;i++) {
          spiceArr.push(spiceAccout[i].accountId);
        }
        this.accoutArr = spiceArr;
        this.accoutArr2 = this.hideAccout(spiceArr);
        this.loadActiveAccout(spiceArr);
        this.hideSmallDetail();
        this.isShowAccount = true;
        this.isOtherRouter = false;
        return;
      }
      let accoutArr = this.totalAccout;
      let equire = this.$route.meta.accoutEnquire;
      let loadAccout = [];
      for(let i = 0;i<accoutArr.length;i++) {
        let accountType  = accoutArr[i].accountType.split(",");
        let offOn = accountType[1];
        let type = accountType[0];
        if(equire.offOn.indexOf(offOn) != -1 && equire.type.indexOf(type) != -1) {
          if(equire.hasOwnProperty('cies') &&  accoutArr[i].cies === false){
            loadAccout.push(accoutArr[i].accountId);
          }else{
            loadAccout.push(accoutArr[i].accountId);
          }
        }
      }
      if(!loadAccout.length) {
        this.isShowAccount = false;
        this.isOtherRouter = true;  //是否是特殊路由
      }else{
        this.isShowAccount = true;
        this.isOtherRouter = false;
      }
      this.accoutArr = loadAccout;
      this.accoutArr2 = this.hideAccout(loadAccout);
      this.loadActiveAccout(loadAccout);
      this.hideSmallDetail();
    },
    getAccountEnquiry() {
      let parmas = {
        "lang": this.getLang,
        "channelType":"WEB"
      }
      accountEnquiry(
        parmas
      ).then( res => {
        //另一个接口获取的
        let accoutEnquiryArr = res.data.accountDetails;
        //登录信息获取的
        let useAccoutEnquiry = this.userData.accountProfiles;
        //处理好的数据(取交集accountId相同就得到)
        let dataArr = [];
        for(let i=0;i<accoutEnquiryArr.length;i++) {
          for(let j=0; j<useAccoutEnquiry.length;j++) {
            //只有账户状态为可用的情况下
            if(accoutEnquiryArr[i].accountStatus == 1) {
              if(accoutEnquiryArr[i].accountId == useAccoutEnquiry[j].accountId) {
                  let obj = useAccoutEnquiry[j];
                  obj.accountType = accoutEnquiryArr[i].accountType;
                  dataArr.push(obj);
              }
            }
          }
        }
        this.totalAccout = dataArr;
        this.loadAccoutInfo();
      })
    },
    handleQuteColor(quterType) {
      this.quterType = quterType;
      //绿涨红跌1还是红涨绿跌2
      localStorage.setItem('quterType', quterType);
      this.$store.commit('changeQuterType', quterType);
    },
    openSmallDetail() {
      this.showSmallDetail = true;
    },
    hideSmallDetail() {
      this.showSmallDetail = false;
    },
    toggleColorChoose() {
      this.showColorWrap = !this.showColorWrap;
    },
    toggleNumInfo() {
      this.openNumInfo = !this.openNumInfo
    },
    handAccount(command) {
      console.log(command)
      this.activeAccoutIndex = command
      this.activeAccoutId =  this.accoutArr[this.activeAccoutIndex];
      this.$store.commit('updateActiveAccountId',  this.activeAccoutId );
    },
    openSide() {
      this.$store.commit('changeDeviceBar')
    },
    changeAccoutIcon(isVisible) {
      if (isVisible) {
        this.$refs.accountDownIcon.className = 'el-icon-arrow-up'
      } else {
        this.$refs.accountDownIcon.className = 'el-icon-arrow-down'
      }
    },
    changeIcon(isVisible) {
      if (isVisible) {
        this.$refs.elDropdownIcon.className = 'el-icon-arrow-up'
      } else {
        this.$refs.elDropdownIcon.className = 'el-icon-arrow-down'
      }
    },
    handleLang(command) {
      this.langType = command;
      //语言切换
      this.$i18n.locale = command
      localStorage.setItem('language', command)
      this.$store.commit('changeLang', command)
      command == 'zh_TW'
        ? (this.activeLang = '中文（繁体）')
        : command == 'zh_CN'
          ? (this.activeLang = '中文（简体）')
          : (this.activeLang = 'English')
      localSet('lang', command)
      event.emit('langChange', command)
    },
    handleCommand(command) {
      this.activeBg = command
      this.colorType = command;
      localStorage.setItem('bgColor', command);
      this.$store.commit("updateBgColor", command);
      //保存数据到vuex(提交到Mutatin)
      //this.$store.commit('updateBgColor', bgColor)
      loadThemColor(command);
    },
    //根据当前时间，得到问候语
    getTimeState(lang) {
      let timeNow = new Date()
      let hours = timeNow.getHours()
      let text = ''
      if (hours > 6 && hours <= 9) {
        lang == 'zh_TW'
          ? (text = '早上好')
          : lang == 'zh_CN'
            ? (text = '早上好')
            : (text = 'Good morning')
      } else if (hours > 9 && hours <= 11) {
        lang == 'zh_TW'
          ? (text = '上午好')
          : lang == 'zh_CN'
            ? (text = '上午好')
            : (text = 'Good morning')
      } else if (hours > 11 && hours <= 13) {
        lang == 'zh_TW'
          ? (text = '中午好')
          : lang == 'zh_CN'
            ? (text = '中午好')
            : (text = 'Good noon')
      } else if (hours > 13 && hours <= 17) {
        lang == 'zh_TW'
          ? (text = '下午好')
          : lang == 'zh_CN'
            ? (text = '下午好')
            : (text = 'Good afternoon')
      } else if (hours > 17 || hours <= 6) {
        lang == 'zh_TW'
          ? (text = '晚上好')
          : lang == 'zh_CN'
            ? (text = '晚上好')
            : (text = 'Good evening')
      }
      this.timeState = text
    },
    toMoreNotice() {
      let routeMoreNotice = this.$router.resolve({
        path: '/moreNotice'
      })
      window.open(routeMoreNotice.href, '_blank');
    },
    toNewContact() {
      let routeNewContact = this.$router.resolve({
        path: '/newContact'
      })
      window.open(routeNewContact.href, '_blank');
    },
    toNewHelp() {
      let routeNewHelp = this.$router.resolve({
        path: '/newHelp'
      })
      window.open(routeNewHelp.href, '_blank');
    },
    exit() {
      this.$confirm( this.$t('topBar.tishi'), {
        confirmButtonText: this.$t('topBar.confirm'),
        cancelButtonText: this.$t('topBar.cancel'),
        type: "warning"
      }).then(() => {
        exitLoginApi({})
        // localStorage.clear();
        sessionStorage.clear()
        // 3. 跳转到登录页
        this.$router.push("/login");
      });
    }
  },
  mounted() {
    this.$nextTick(() => {
          //获取账户信息
      this.getAccountEnquiry();
      //初始化下拉框的值
      let configColor = localStorage.getItem('bgColor') || 'bg-Blue'
      this.activeBg = configColor;
      this.colorType = configColor;
      this.$store.commit("updateBgColor", configColor);
      let language = localStorage.getItem('language') || 'zh_TW';
      this.langType = language;
      language == 'zh_TW'
        ? (this.activeLang = '中文（繁体）')
        : language == 'zh_CN'
          ? (this.activeLang = '中文（简体）')
          : (this.activeLang = 'English')
      this.quterType = this.getQuterType;
      let that = this
      document.addEventListener('click', function (e) {
        if (that.showUserPannel) {
          that.showUserPannel = false
        }
      })
    })
  }
}
</script>
<style lang="scss" scoped>
.top-wrap {
  position: fixed;
  right: 0;
  top: 0;
  width: calc(100% - 64px);
  overflow: hidden;
  z-index: 100;
  height: 64px;
  line-height: 64px;
  background: #fff;
  transition: width 0.5s;
  &.closeSideBar {
    width: calc(100% - 240px);
  }
  @media screen and (max-width: 784px) {
    width: 100%;
    left: 0;
    height: 136px;
    &.otherHeight {
      height: 64px;
    }
  }
  .small-wrap {
    width: 100%;
    height: 64px;
    position: relative;
    .small-top {
      display: flex;
      position: relative;
      z-index: 1300;
      .leftBtn,
      .person {
        flex: 0 0 64px;
        text-align: center;
        line-height: 64px;
        color: #fff;
        i {
          font-size: 18px;
        }
      }
      .logo-info {
        flex: 1;
        text-align: center;
        img {
          width: 95px;
          vertical-align: middle;
          image-rendering: crisp-edges;
          image-rendering: -webkit-optimize-contrast;
          -ms-interpolation-mode: nearest-neighbor;
          image-rendering: -moz-crisp-edges;
          image-rendering: -o-crisp-edges;
        }
      }
    }
    .small-bg {
      position: fixed;
      top: 62px;
      height: 100%;
      width: 100%;
      background: rgba(51, 51, 51, 0.5);
      z-index: 1000;
    }
    .small-content {
      position: fixed;
      top: 62px;
      height: 100%;
      width: 100%;
      z-index: 1200;
      .layout {
        .content-info {
          width: 100%;
          .info-item {
            position: relative;
            height: 40px;
            line-height: 40px;
            padding: 0 24px;
            z-index: 1;
            display: flex;
            align-items: center;
            cursor: pointer;
            .lang-item {
              height: 24px;
              line-height: 24px;
              font-size: 16px;
              text-align: left;
            }
            .line {
              width: 1px;
              height: 24px;
              line-height: 24px;
              margin: 0 10px;
            }
            .icons {
              flex: 0 0 50px;
              i {
                font-size: 24px;
              }
            }
            .rightIcons {
              text-align: right;
              i {
                font-size: 16px;
                font-weight: 600;
                &.openArrow {
                  transform: rotate(180deg);
                }
              }
            }
            .text {
              flex: 1;
              font-family: SourceHanSansCN-Regular;
              font-size: 16px;
            }
          }
          .people-info {
            padding: 10px 24px 10px 30px;
            font-family: SourceHanSansCN-Normal;
            .telphone {
              display: block;
              height: 24px;
              line-height: 24px;
              font-size: 14px;
              .num {
                margin-left: 4px;
              }
            }
          }
          .color-wrap {
            height: 0;
            transition: height 0.28s;
            visibility: hidden;
            .color-item {
              padding: 0 24px 0 76px;
              height: 32px;
              line-height: 32px;
            }
            &.showColorWrap {
              visibility: visible;
              height: 128px;
            }
          }
          .quote-wrap {
            &.show-quoteColor {
              visibility: visible;
              height: 64px;
            }
          }
        }
      }
    }
  }
}
.user-num {
  height: 100%;
  .layout-bg {
    height: 100%;
    display: flex;
    align-items: center;
  }
  &.small-user-num {
    width: 100%;
    height: auto;
    padding: 12px;
    .layout-bg {
      width: 100%;
      height: 48px;
      line-height: 48px;
    }
  }
  .cur-nav {
    font-size: 20px;
    font-family: 'SourceHanSansCN-Medium', 'Avenir-Medium';
    max-width: 300px;
    padding: 0 20px 0 24px;
    line-height: 20px;
  }
  .accout-wrap {
    display: inline-block;
    height: 28px;
    line-height: 28px;
    padding-left: 20px;
    color: #606266;
    cursor: pointer;
    .account-txt {
      font-size: 18px;
      font-family: SourceHanSansCN-Medium;
      line-height: 18px;
    }
    .account-num {
      font-size: 18px;
      font-family: HelveticaNeue;
    }
  }
  .view {
    width: 32px;
    height: 32px;
    line-height: 32px;
    cursor: pointer;
    color: #003da5;
    vertical-align: middle;
    i {
      font-size: 32px;
    }
  }
}
.setting-wrap {
  height: 100%;
  .layout-bg {
    height: 100%;
    display: flex;
    align-items: center;
  }
  .lang-wrap {
    height: 28px;
    line-height: 28px;
    font-size: 16px;
    font-family: SourceHanSansCN-Regular;
    color: #333;
    cursor: pointer;
  }
  .icons {
    color: #404040;
    cursor: pointer;
    padding: 0 2px;
    height: 32px;
    text-align: center;
    line-height: 32px;
    i {
      font-size: 30px;
    }
    &:hover {
      color: #003da5;
    }
  }
  .change-color {
    height: 30px;
    line-height: 30px;
    text-align: center;
    cursor: pointer;
    i {
      font-size: 30px;
    }
  }
  .line {
    width: 1px;
    height: 30px;
    margin: 0 6px;
    vertical-align: middle;
    display: inline-block;
    background: rgba(51, 51, 51, 0.25);
  }
  .user-wrap {
    padding: 0 24px 0 4px;
    display: inline-block;
    position: relative;
    .user-info {
      height: 24px;
      line-height: 24px;
      color: #606266;
      cursor: pointer;
      .txt {
        font-size: 16px;
        font-family: SourceHanSansCN-Regular;
        color: #333333;
      }
      .name {
        font-family: Avenir-Book;
        font-size: 16px;
        color: #1a1a1a;
        line-height: 18px;
      }
    }
    .user-pannel {
      position: fixed;
      right: 24px;
      top: 60px;
      width: 300px;
      transition: opacity 0.28s;
      visibility: visibility;
      opacity: 1;
      border-radius: 6px;
      &.hideUserPannel {
        opacity: 0;
        visibility: hidden;
      }
      .pannel-item {
        height: 40px;
        line-height: 40px;
        padding: 0 10px 0 20px;
        position: relative;
        z-index: 1;
        i {
          font-size: 20px;
          vertical-align: middle;
          &.openArrow {
            transform: rotate(180deg);
          }
        }
        .txt {
          font-family: SourceHanSansCN-Normal;
          font-size: 12px;
        }
      }
      .quotecolor-wrap {
        height: 0;
        visibility: hidden;
        transition: height 0.28s;
        &.show-quoteColor {
          height: 64px;
          visibility: visible;
        }
        .quotecolor-item {
          padding: 0 24px 0 46px;
          height: 32px;
          line-height: 40px;
          font-size: 14px;
          cursor: pointer;
        }
      }
      .people-info {
        padding: 10px 10px 20px 20px;
        .telphone {
          display: block;
          font-family: SourceHanSansCN-Normal;
          font-size: 12px;
          line-height: 20px;
          .num {
            margin-left: 4px;
          }
        }
      }
    }
  }
}
.avater-wrap {
  width: 100%;
  height: 80px;
  border-radius: 6px 6px 0px 0px;
  display: flex;
  padding: 20px 0;
  &.small-avater-wrap {
    border-radius: 0;
  }
  .avater {
    width: 80px;
    padding: 0 20px;
    .avater-img {
      width: 40px;
      height: 40px;
      line-height: 40px;
      text-align: center;
      display: inline-block;
      border-radius: 50%;
      background: #50e3c2;
      color: #fff;
      font-family: SFUIText-Medium;
      font-size: 20px;
      vertical-align: top;
    }
  }
  .user-base {
    flex: 1;
    .name {
      height: 16px;
      line-height: 16px;
      display: block;
      font-family: SourceHanSansCN-Medium;
      font-size: 14px;
      color: #ffffff;
    }
    .numId {
      height: 24px;
      line-height: 32px;
      display: block;
      font-family: SourceHanSansCN-Normal;
      font-size: 14px;
      color: rgba(255, 255, 255, 0.75);
    }
  }
  .login-out {
    flex: 0 0 90px;
    color: #ffffff;
    line-height: 40px;
    padding-right: 10px;
    text-align: right;
    cursor: pointer;
    .out {
      font-family: SourceHanSansCN-Normal;
      font-size: 14px;
    }
    i {
      font-size: 22px;
      vertical-align: middle;
    }
  }
}

.bg-guijin {
  color: #e0be59 !important;
}

.bg-hulan {
  color: #046f98 !important;
}

.bg-anhei {
  color: #999 !important;
}

.bounce-enter-active {
  animation: topTo 0.3s;
}
.bounce-leave-active {
  animation: topTo 0.3s reverse;
}
@keyframes topTo {
  from {
    transform: translate3d(0, -100%, 0);
  }
  to {
    transform: translate3d(0, 0, 0);
  }
}
</style>
<style>
.colorItem i {
  font-size: 28px;
  vertical-align: middle;
}
.el-dropdown-link {
  display: inline-block;
  height: 28px;
  line-height: 28px;
}
</style>
