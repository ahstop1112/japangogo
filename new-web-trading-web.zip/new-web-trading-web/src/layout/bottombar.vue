<!--
 * @Author: your name
 * @Date: 2020-10-20 16:31:41
 * @LastEditTime: 2021-01-27 11:51:11
 * @LastEditors: Please set LastEditors
 * @Description: In User Settings Edit
 * @FilePath: \new-web-trading\src\layout\bottombar.vue
-->
<template>
  <div class="bottom-wrap ">
    <div class="bottom-content">
      <p class="center">{{ $t('bottomBar.company') }}</p>
      <p class="center">
        <a class="link-info" :href="mianzeUrl" target="_Blank">{{
          $t('bottomBar.mianze')
        }}</a>{{ $t('bottomBar.ji')
        }}<a class="link-info" :href="personUrl" target="_Blank">{{
          $t('bottomBar.pernsonInfo')
        }}</a>
      </p>
      <div class="main-txt" v-if="isShow">
        {{ $t('bottomBar.mianzeInfo') }}
      </div>
    </div>
  </div>
</template>


<script>
import { mapGetters } from 'vuex'
export default {
  props: {
    isShow: {
      type: Boolean,
      default: true
    }
  },
  computed: {
    ...mapGetters(['getLang'])
  },
  //监听切换语言的动作
  watch: {
    getLang: {
      handler: function (val, n) {
        if (val == 'en_US') {
          this.mianzeUrl = 'http://www.htisec.com/en-us/disclaimers'
          this.personUrl =
            'http://www.htisec.com/sites/all/themes/hitong/files/Data_Privacy_Policy_Sec_EN.pdf'
        } else if (val == 'zh_CN') {
          this.mianzeUrl = 'http://www.htisec.com/en-cn/disclaimers'
          this.personUrl =
            'http://www.htisec.com/sites/all/themes/hitong/files/Data_Privacy_Policy_Sec_SC.pdf'
        } else {
          this.mianzeUrl = 'http://www.htisec.com/zh-hk/disclaimers'
          this.personUrl =
            'http://www.htisec.com/sites/all/themes/hitong/files/Data_Privacy_Policy_Sec_TC.pdf'
        }
      },
      immediate: true
    }
  },
  data() {
    return {
      mianzeUrl: '',
      personUrl: ''
    }
  },
  methods: {},
  mounted() { }
}
</script>
<style lang="scss" scoped>
.bottom-wrap {
  width: 100%;
  padding: 20px;
  transition: background 0.28s;
  font-size: 12px;
  color: #fff;
  position: relative;
  font-family: SourceHanSansCN-Normal;
  .center {
    width: 100%;
    text-align: center;
    line-height: 18px;
    .link-info {
      color: #4191ff;
      font-size: 14px;
      font-family: SourceHanSansCN-Medium;
      line-height: 12px;
      margin: 0 6px;
      text-decoration: underline;
    }
  }
  .main-txt {
    text-align: justify;
    line-height: 14px;
    margin-top: 10px;
  }
}
@media screen and (max-width: 768px) {
  .bottom-wrap {
    padding: 12px;
  }
}
</style>
