<template>
  <!-- 帮助中心 -->
  <div class="newHelp contentBg">
    <div class="top">
      <div class="top-box">
        <img src="@/assets/1@3x.png" alt="" />
        <span>{{ $t('topBar.help') }}</span>
      </div>
    </div>
    <div class="content">
      <p class="mediumColor">
        <a class="activeTagColor" href="#1F">{{ $t('newHelp.link1') }}</a>
      </p>
      <p class="mediumColor">
        <a class="activeTagColor" href="#2F">{{ $t('newHelp.link2') }}</a>
      </p>
      <p class="mediumColor">
        <a class="activeTagColor" href="#3F">{{ $t('newHelp.link3') }}</a>
      </p>
      <p class="mediumColor">
        <a class="activeTagColor" href="#4F">{{ $t('newHelp.link4') }}</a>
      </p>
      <p class="mediumColor">
        <a class="activeTagColor" href="#5F">{{ $t('newHelp.link5') }}</a>
      </p>
      <h4 class="heavyColor" id="1F">{{ $t('newHelp.content1') }}</h4>
      <p class="mediumColor">{{ $t('newHelp.content2') }}</p>
      <hr />
      <h4 class="heavyColor" id="2F">{{ $t('newHelp.content3') }}</h4>
      <p class="mediumColor">
        {{ $t('newHelp.content4') }}
      </p>
      <p class="mediumColor">
        {{ $t('newHelp.content16') }}
      </p>
      <hr />
      <h4 class="heavyColor" id="3F">{{ $t('newHelp.content5') }}</h4>
      <p class="mediumColor">
        {{ $t('newHelp.content6') }}
      </p>
      <hr />
      <h4 class="heavyColor" id="4F">{{ $t('newHelp.content7') }}</h4>
      <p class="mediumColor">{{ $t('newHelp.content8') }}</p>
      <p class="mediumColor">{{ $t('newHelp.content9') }}</p>
      <p class="mediumColor">{{ $t('newHelp.content10') }}</p>
      <p class="mediumColor">
        {{ $t('newHelp.content11') }}
      </p>
      <p class="mediumColor">
        {{ $t('newHelp.content12') }}
      </p>
      <p class="mediumColor">
        {{ $t('newHelp.content13') }}
      </p>
      <hr />
      <h4 class="heavyColor" id="5F">{{ $t('newHelp.content14') }}</h4>
      <p class="mediumColor">
        {{ $t('newHelp.content15') }}
      </p>
      <p class="mediumColor">
        {{ $t('newHelp.content16') }}
      </p>
      <p class="mediumColor">
        {{ $t('newHelp.content17') }}
      </p>
      <p class="mediumColor">
        {{ $t('newHelp.content18') }}
      </p>
      <p class="mediumColor">
        {{ $t('newHelp.content19') }}
      </p>
    </div>
  </div>
</template>

<script>
import { loadThemColor } from '@/utils/loadTheme'
export default {
  created() {
    let configColor = localStorage.getItem('bgColor') || 'bg-Blue';
    loadThemColor(configColor);
  },
}
</script>

<style lang="scss" scoped>
.newHelp {
  min-height: 100%;
  .top {
    display: flex;
    align-items: center;
    padding: 16px 0;
    height: 100%;
    background: #003da5;
    box-shadow: 6px 0 6px 0 rgba(162, 140, 133, 0.3);
    @media screen and(max-width: 1080px) {
      padding: 12px 24px;
    }
    @media screen and(max-width: 768px) {
      padding: 12px 12px;
    }
    .top-box {
      display: flex;
      align-items: center;
      margin: 0 auto;
      width: 1000px;
      img {
        margin-right: 25px;
        width: 95px;
        height: 32px;
      }
      span {
        padding-left: 25px;
        font-family: SourceHanSansCN-Medium;
        font-size: 18px;
        color: #ffffff;
        line-height: 25px;
        border-left: 1px #fff solid;
      }
    }
  }
  .content {
    margin: 0 auto;
    padding: 24px 0;
    width: 1000px;
    @media screen and(max-width: 1080px) {
      padding: 24px;
      width: 100%;
    }
    @media screen and(max-width: 768px) {
      padding: 24px 12px;
    }
    a {
      font-family: SourceHanSansCN-Medium;
      font-size: 16px;
      line-height: 28px;
    }
    h4 {
      font-family: SourceHanSansCN-Medium;
      font-size: 18px;
      line-height: 18px;
    }
    p {
      font-family: SourceHanSansCN-Regular;
      font-size: 16px;
      line-height: 25px;
    }
  }
}
</style>
