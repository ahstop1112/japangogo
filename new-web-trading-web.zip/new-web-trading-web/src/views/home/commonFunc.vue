
<!--主页(常用功能)-->
<template>
  <div class="commonFunc-wrap contentBg">
    <mainTitle :title="$t('home.commonFunc.title')" />
    <ul class="main-content clearfix">
      <li class="common-item" @click="goRouter('/myInquiry/tradeHistory')">
        <span class="icons activeFontColor"><i class="iconfont icon-05-2TradeHistory"></i></span>
        <span class="text mediumColor">{{$t('home.commonFunc.tradHistory')}}</span>
      </li>
      <li class="common-item" @click="goRouter('/myInquiry/stockMovement')">
        <span class="icons activeFontColor"><i class="iconfont icon-05-4StockMovement"></i></span>
        <span class="text mediumColor">{{$t('home.commonFunc.stockPush')}}</span>
      </li>
      <li v-if="!(userData.primeBrokerageFunds.length !== 0)" class="common-item" @click="goRouter('/myInquiry/myStatement')">
        <span class="icons activeFontColor"><i class="iconfont icon-05-5MyStatement"></i></span>
        <span class="text mediumColor">{{$t('home.commonFunc.jiedan')}}</span>
      </li>
      <li v-else class="common-item" @click="goRouter('/myInquiry/myReport')">
        <span class="icons activeFontColor"><i class="iconfont icon-05-5MyStatement"></i></span>
        <span class="text mediumColor">{{$t('home.commonFunc.baobiao')}}</span>
      </li>
    </ul>
  </div>
</template>

<script>
import mainTitle from "@/components/mainTitle";
export default {
  data() {
    return {
      userData: ''
    };
  },
  components: {
    mainTitle
  },
  methods: {
    goRouter(path) {
      this.$router.push(path);
      this.$store.commit('changeIsJumpRouter', true);
    }
  },
  mounted() { },
  created() {
    this.userData = JSON.parse(sessionStorage.getItem("userData"));
  }

}
</script>
<style lang='scss' scoped>
.commonFunc-wrap {
  width: 100%;
  min-height: 160px;
  .main-content {
    width: 100%;
    display: flex;
    flex-wrap: wrap;
    align-content: flex-start;
    .common-item {
      width: 25%;
      padding: 10px 0 24px 0;
      text-align: center;
      cursor: pointer;
      .icons {
        display: block;
        i {
          font-size: 50px;
        }
      }
      .text {
        display: block;
        min-width: 100px;
        padding: 0 24px;
        font-family: SourceHanSansCN-Regular, Avenir-Book;
        font-size: 16px;
        line-height: 16px;
      }
    }
  }
}
@media screen and (max-width: 768px) {
  .commonFunc-wrap .main-content .common-item .text {
    padding: 0 12px;
  }
  .commonFunc-wrap .main-content .common-item {
    width: 33.33%;
  }
}
</style>