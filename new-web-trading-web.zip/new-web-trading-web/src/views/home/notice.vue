<!--主页(通知)-->
<template>
  <div class="notice-wrap contentBg">
    <mainTitle :title="$t('home.notice.title')">
      <span class="more lightColor hoverFontColor" @click="toMoreNotice">{{
        $t('home.notice.more')
      }}</span>
    </mainTitle>
    <ul class="notice-content">
      <li class="notice-item contentBorder hoverBgColor">
        <div class="notice-title">
          <span class="title ellips heavyColor">有关部分海外邮寄结单服务延迟通知</span>
          <span class="time lightColor">2019-06-27</span>
        </div>
        <div class="notice-text ellips mediumColor">
          根据相关邮政局2020年3月27日通告，部分地区的海外邮政服务已经暂停使用啥的经暂停使用啥的经暂停使用啥的
        </div>
      </li>
      <li class="notice-item contentBorder hoverBgColor">
        <div class="notice-title">
          <span class="title ellips heavyColor ">美股交易孖展利率低至P+2.5%*</span>
          <span class="time lightColor">2019-06-27</span>
        </div>
        <div class="notice-text ellips mediumColor">
          由2019年03月22日起，经海通国际交易美股，可享孖展利率低至P+2.5
        </div>
      </li>
      <li class="notice-item contentBorder hoverBgColor">
        <div class="notice-title">
          <span class="title ellips heavyColor">美股交易孖展利率低至P+2.5%*</span>
          <span class="time lightColor">2019-06-27</span>
        </div>
        <div class="notice-text ellips mediumColor">
          由2019年03月22日起，经海通国际交易美股，可享孖展利率低至P+2.5
        </div>
      </li>
    </ul>
    <noContent v-if="false" height="320px" :content="$t('home.notice.noResult')" />
  </div>
</template>

<script>
import mainTitle from '@/components/mainTitle'
import noContent from '@/components/noContent'
export default {
  data() {
    return {}
  },
  components: {
    mainTitle,
    noContent
  },
  methods: {
    toMoreNotice() {
      let routeMoreNotice = this.$router.resolve({
        path: '/moreNotice'
      })
      window.open(routeMoreNotice.href, '_blank');
    },
  },
  mounted() { }
}
</script>
<style lang="scss" scoped>
.notice-wrap {
  width: 100%;
  min-height: 376px;
  .notice-content {
    width: 100%;
    padding: 0 24px;
    .notice-item {
      width: 100%;
      height: 110px;
      .notice-title {
        padding: 24px 0;
        display: flex;
        align-items: center;
        width: 100%;
        .title {
          flex: 1;
          font-family: SourceHanSansCN-Medium;
          font-size: 16px;
        }
        .time {
          flex: 0 0 80px;
          font-family: Avenir-Book;
          font-size: 14px;
        }
      }
      .notice-text {
        font-family: SourceHanSansCN-Regular;
        font-size: 16px;
      }
    }
    .notice-item:nth-child(3) {
      border-bottom: none;
    }
  }
}
.more {
  float: right;
  font-family: SourceHanSansCN-Regular;
  font-size: 14px;
  cursor: pointer;
}
@media screen and (max-width: 768px) {
  .notice-wrap .notice-content {
    padding: 0 12px;
  }
}
</style>
