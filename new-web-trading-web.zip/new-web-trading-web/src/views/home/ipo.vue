<!--主页(新股认购)-->
<template>
  <div class="ipo-wrap contentBg">
    <!-- 彈框 -->
    <popover :title="$t('security.ipoSubscriptions.popover.title')" :showPopover="showPopover" @close="closePopover" :isFirst="firstStep">
      <div class="first-wrap" v-if="firstStep">
        <div class="title messageBgColor">
          <span>{{$t('security.ipoSubscriptions.popover.headInfo')}} <a href="javascript:;" @click="toProspectus">{{$t('security.ipoSubscriptions.popover.headLink')}}</a>、<a href="javascript:;" @click="toProspectusForm">{{$t('security.ipoSubscriptions.popover.headLink1')}}</a> 。</span>
        </div>
        <div class="content-details">
          <ul class="content-wrap contentBorder">
            <li class="info-item">
              <span class="txt mediumColor">{{$t('myInquiry.tradeHistory.ipoSub.stockName')}}</span>
              <span class="val heavyColor">凯富善集团控股有限公司</span>
            </li>
            <li class="info-item">
              <span class="txt mediumColor">{{$t('myInquiry.tradeHistory.ipoSub.zhaogujia')}}</span>
              <span class="val heavyColor">$0.36</span>
            </li>
            <li class="info-item">
              <span class="txt mediumColor">{{$t('security.ipoSubscriptions.way')}}</span>
              <span class="val heavyColor">
                <el-radio style="margin-right:0px" v-model="radio" label="1">{{$t('security.ipoSubscriptions.cash')}}</el-radio>
                <el-radio v-model="radio" label="2">{{$t('security.ipoSubscriptions.subscribe')}}</el-radio>
              </span>
            </li>
            <li class="info-item">
              <span class="txt mediumColor">{{$t('security.ipoSubscriptions.popover.sharesNumber')}}</span>
              <span class="val heavyColor">
                <el-select v-model="value" placeholder="40,000股($ 146,663.18)">
                  <el-option v-for="item in options" :key="item" :label="item" :value="item">
                  </el-option>
                </el-select>
              </span>
            </li>
            <li class="info-item" v-if="radio==2">
              <span class="txt mediumColor">{{$t('security.ipoSubscriptions.popover.proportion')}}</span>
              <span class="val heavyColor">
                <el-select v-model="value1" placeholder="90%(融资金额：$131,9">
                  <el-option v-for="item in options1" :key="item" :label="item" :value="item">
                  </el-option>
                </el-select>
              </span>
            </li>
            <li class="info-item">
              <span class="txt mediumColor" style="flex: 0 0 145px;">{{$t('security.ipoSubscriptions.poundage')}}</span>
              <span class="val heavyColor">$3,636.28</span>
            </li>
            <li class="info-item">
              <span class="txt mediumColor" style="flex: 0 0 145px;">{{$t('security.ipoSubscriptions.popover.amount')}}</span>
              <span class="val heavyColor">90%</span>
            </li>
            <li class="info-item" v-if="radio==2">
              <span class="txt mediumColor" style="flex: 0 0 145px;">{{$t('myInquiry.tradeHistory.ipoSub.cankaolilv')}}</span>
              <span class="val heavyColor">4.48%</span>
            </li>
            <li class="info-item">
              <span class="txt mediumColor" style="flex: 0 0 145px;">{{$t('myInquiry.tradeHistory.ipoSub.jiaoyijine')}}</span>
              <span class="val heavyColor">$463.63</span>
            </li>
          </ul>
          <div class="options-wrap">
            <span class="options-title heavyColor">{{$t('security.ipoSubscriptions.popover.chekTitle')}}</span>
            <el-checkbox-group v-model="checkListOne">
              <el-checkbox :label="item" v-for="item in ConfirmInformation" :key="item"></el-checkbox>
            </el-checkbox-group>
          </div>
          <div class="info-wrap">
            <div class="info-title mediumColor">{{$t('security.ipoSubscriptions.popover.chekTitle2')}}
              <el-popover placement="right" width="180" trigger="click">
                <div class="explain lightColor">
                  {{$t('security.ipoSubscriptions.popover.detailsInfo')}}
                </div>
                <div class="info-text" slot="reference">
                  <i class="iconfont icon-detail"></i>
                  <span class="lightColor contentBorder">{{$t('security.ipoSubscriptions.popover.details')}}</span>
                </div>
              </el-popover>

            </div>
            <el-checkbox-group v-model="checkListTwo">
              <el-checkbox :label="item" v-for="item in PromptInformation" :key="item"></el-checkbox>
            </el-checkbox-group>
          </div>
        </div>
        <div class="avg-wrap contentTopBorder">
          <span class="txt mediumColor">{{$t('myInquiry.tradeHistory.ipoSub.password')}}</span>
          <span class="val">
            <el-input v-model="password" :placeholder="$t('myInquiry.tradeHistory.ipoSub.tip')"></el-input>
          </span>
        </div>
        <div class="confirm-btn">
          <el-button type="primary" @click="goToSuccess">{{$t('myInquiry.tradeHistory.ipoSub.cofirm')}}</el-button>
        </div>
      </div>
      <div class="second-wrap" v-else>
        <div class="layout-wrap">
          <div class="success-wrap">
            <span class="icons"><i class="iconfont icon-status_success activeFontColor"></i></span>
            <span class="text activeFontColor">{{$t('security.ipoSubscriptions.popover.submitInfo')}}</span>
            <div class="success-btn">
              <el-button plain @click="goRouter('/myInquiry/tradeHistory/ipoSubscription')">{{$t('security.ipoSubscriptions.popover.btn')}}</el-button>
            </div>
          </div>
        </div>
      </div>
    </popover>
    <mainTitle :title="$t('home.ipo.title')">
      <span class="more  lightColor hoverFontColor" @click="goRouter('/security/ipoSubscriptions')">{{$t('home.ipo.more')}}</span>
    </mainTitle>
    <ul class="ipo-content">
      <li class="ipo-item contentBorder hoverBgColor">
        <div class="ipo-name">
          <div class="ipo-code">
            <span class="code mediumColor">08512</span>
            <span class="name heavyColor">凱富善集團控股</span>
          </div>
          <div class="ipo-btn">
            <span class="small-btn small-btn-light" @click="openPopover" :class="{notClick:userData.allowTrade == false}">{{$t('home.ipo.rengou')}}</span>
          </div>
        </div>
        <div class="ipo-price">
          <div class="price">
            <span class="price-text mediumColor">{{$t('home.ipo.stockPrice')}}</span>
            <span class="price-num heavyColor">$0.36~$0.38</span>
          </div>
          <div class="time">
            <span class="time-text mediumColor">{{$t('home.ipo.endDate')}}</span>
            <span class="time-num heavyColor">2019-09-21</span>
          </div>
        </div>
      </li>
      <li class="ipo-item contentBorder hoverBgColor" v-for="item in [1,1]">
        <div class="ipo-name">
          <div class="ipo-code">
            <span class="code mediumColor">08512</span>
            <span class="name heavyColor">凱富善集團控股</span>
          </div>
          <div class="ipo-btn">
            <span class="small-btn small-btn-light" @click="openPopover" :class="{notClick:userData.allowTrade == false}">{{$t('home.ipo.rengou')}}</span>
          </div>
        </div>
        <div class="ipo-price">
          <div class="price">
            <span class="price-text mediumColor">{{$t('home.ipo.stockPrice')}}</span>
            <span class="price-num heavyColor">$32.06~$40.12</span>
          </div>
          <div class="time">
            <span class="time-text mediumColor">{{$t('home.ipo.endDate')}}</span>
            <span class="time-num heavyColor">2019-09-21</span>
          </div>
        </div>
      </li>
    </ul>
    <noContent v-if="false" height="310px" :content="$t('home.ipo.noReulst')" />
  </div>
</template>

<script>
import mainTitle from "@/components/mainTitle";
import noContent from "@/components/noContent";
import popover from '@/components/popover';
export default {
  data() {
    return {
      firstStep: true, //是否显示第一步
      showPopover: false,
      radio: '1',
      value: '',
      value1: '',
      password: '',
      checkListOne: [],
      checkListTwo: [],
      userData: ''
    };
  },
  components: {
    mainTitle,
    noContent,
    popover
  },
  computed: {
    ConfirmInformation() {
      return [this.$t('security.ipoSubscriptions.popover.chekInfo1'),
      this.$t('security.ipoSubscriptions.popover.chekInfo2'), this.$t('security.ipoSubscriptions.popover.chekInfo3'), this.$t('security.ipoSubscriptions.popover.chekInfo4')]
    },
    PromptInformation() {
      return [this.$t('security.ipoSubscriptions.popover.notice'), this.$t('security.ipoSubscriptions.popover.notice1')]
    },
    options() {
      return ['40,000股($ 146,663.18)', '10,000股($ 146,663.18)']
    },
    options1() {
      return ['90%(融资金额：$131,9', '80%(融资金额：$131,9']
    }
  },
  methods: {
    toProspectus() {
      let routeProspectus = this.$router.resolve({
        path: '/prospectus'
      })
      window.open(routeProspectus.href, '_blank');
    },
    toProspectusForm() {
      let routeProspectusForm = this.$router.resolve({
        path: '/prospectusForm'
      })
      window.open(routeProspectusForm.href, '_blank');
    },
    // 隐藏弹窗
    closePopover() {
      this.showPopover = false;
    },
    openPopover() {
      if (this.userData.allowTrade !== false) {
        this.firstStep = true;
        this.showPopover = true;
      }
    },
    goToSuccess() {
      this.firstStep = false;
    },
    goRouter(path) {
      this.$router.push(path);
      this.$store.commit('changeIsJumpRouter', true);
    }
  },
  created() {
    this.userData = JSON.parse(sessionStorage.getItem("userData"));
  },
  mounted() { },

}

</script>
<style lang='scss' scoped>
.ipo-wrap {
  width: 100%;
  min-height: 360px;
  .first-wrap {
    width: 100%;
    height: 100%;
    .title {
      padding-left: 24px;
      font-family: SourceHanSansCN-Regular;
      font-size: 12px;
      color: #333333;
      line-height: 25px;
      a {
        font-family: SourceHanSansCN-Medium;
        color: #4191ff;
        border-bottom: 1px solid #4191ff;
      }
    }
    .content-details {
      padding: 12px 24px;
      width: 100%;
      height: 100%;
      .content-wrap {
        padding-bottom: 12px;
        .info-item {
          display: flex;
          flex-wrap: wrap;
          align-content: flex-start;
          align-items: baseline;
          padding: 4px 0;
          .txt {
            flex: 0 0 100px;
            font-family: SourceHanSansCN-Regular;
            font-size: 16px;
            line-height: 20px;
          }
          .val {
            flex: 1;
            font-family: SourceHanSansCN-Regular;
            font-size: 16px;
            text-align: right;
            line-height: 20px;
          }
        }
      }
      .options-wrap {
        padding-top: 12px;
        border-bottom: 1px solid rgba(51, 51, 51, 0.25);
        .el-checkbox {
          display: block;
          margin-right: 12px;
          >>> .el-checkbox__label {
            overflow: hidden;
            display: inline-grid;
            white-space: pre-line;
            font-family: SourceHanSansCN-Regular;
            font-size: 16px;
            color: rgba(0, 0, 0, 0.75);
          }
        }
      }
      .info-wrap {
        padding-top: 12px;
        >>> .el-checkbox__label {
          font-family: SourceHanSansCN-Regular;
          font-size: 16px;
          color: rgba(51, 51, 51, 0.75);
        }
        .info-text {
          display: inline-block;
          cursor: pointer;
          .icon-detail {
            color: #9b9b9b;
          }
          span {
            display: inline-block;
            font-family: SourceHanSansCN-Medium;
            font-size: 12px;
            transform: translateY(-2px);
          }
        }
        .explain {
          font-family: SourceHanSansCN-Normal;
          font-size: 12px;
        }
      }
      .options-title,
      .info-title {
        display: inline-block;
        padding-bottom: 12px;
        font-family: SourceHanSansCN-Regular;
      }
    }
    .avg-wrap {
      display: flex;
      align-items: center;
      padding: 24px;
      width: 100%;
      .txt {
        flex: 0 0 80px;
        font-family: SourceHanSansCN-Regular;
        font-size: 16px;
      }
      .val {
        flex: 1;
      }
    }
    .confirm-btn {
      padding: 0 24px 24px 24px;
      text-align: right;
    }
  }
  .second-wrap {
    .layout-wrap {
      padding: 24px;
      width: 100%;
      height: 100%;
      .success-wrap {
        text-align: center;
        span {
          display: block;
        }
        .icons {
          padding: 24px 0;
          i {
            font-size: 58px;
          }
        }
        .text {
          font-family: SourceHanSansCN-Medium;
          font-size: 18px;
        }
        .success-btn {
          margin-top: 30px;
        }
      }
    }
  }
  .ipo-content {
    width: 100%;
    padding: 0 24px;
    .ipo-item {
      width: 100%;
      .ipo-name {
        padding: 16px 0;
        display: flex;
        width: 100%;
        .ipo-code {
          flex: 1;
          display: flex;
          align-items: center;
          .code {
            font-family: Avenir-Medium;
            font-size: 16px;
            margin-right: 22px;
          }
          .name {
            font-family: SourceHanSansCN-Medium;
            font-size: 16px;
          }
        }
        .ipo-btn {
          flex: 0 0 60px;
          text-align: right;
          .notClick {
            background: grey;
            cursor: not-allowed;
          }
        }
      }
      .ipo-price {
        width: 100%;
        display: flex;
        flex-wrap: wrap;
        align-content: flex-start;
        padding-bottom: 20px;
        .price {
          width: 44%;
          display: flex;
          align-items: center;
          .price-text {
            font-family: SourceHanSansCN-Regular;
            font-size: 16px;
          }
          .price-num {
            flex: 1;
            text-align: right;
            padding-left: 6px;
            font-family: Avenir-Book;
            font-size: 16px;
          }
        }
        .time {
          flex: 1;
          display: flex;
          align-items: center;
          padding-left: 10px;
          .time-text {
            flex: 1;
            text-align: center;
            font-family: SourceHanSansCN-Regular;
            font-size: 16px;
          }
          .time-num {
            flex: 0 0 96px;
            text-align: right;
            font-family: Avenir-Book;
            font-size: 16px;
          }
        }
      }
    }
    .ipo-item:nth-child(3) {
      border-bottom: none;
    }
  }
}
.more {
  float: right;
  font-family: SourceHanSansCN-Regular;
  font-size: 14px;
  cursor: pointer;
}
@media screen and (max-width: 768px) {
  .ipo-wrap .ipo-content {
    padding: 0 12px;
  }
  .ipo-wrap .ipo-content .ipo-item .ipo-price {
    display: block;
  }
  .ipo-wrap .ipo-content .ipo-item .ipo-price .price {
    width: 100%;
  }
  .ipo-wrap .ipo-content .ipo-item .ipo-price .time {
    padding: 0;
  }
  .ipo-wrap .ipo-content .ipo-item .ipo-price .time .time-text {
    text-align: left;
  }
}
</style>