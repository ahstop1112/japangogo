<template>
  <!-- 通知详情 -->
  <div class="newNotice contentBg">
    <div class="top">
      <div class="top-box">
        <img src="@/assets/1@3x.png" alt="" />
        <span>有關香港郵政局最新暫停部分海外郵政服務通告</span>
      </div>
    </div>
    <h4 class="title activeFontColor">有關香港郵政局最新暫停部分海外郵政服務通告</h4>
    <div class="box">
      <div class="content mediumColor">
        <el-scrollbar wrap-class="scrollbar-wrapper" style="height: 100%;">
          <p>
            尊貴的客戶︰
          </p>
          <p>感謝閣下一直以來對海通國際的支持!</p>
          <p>
            根據香港郵政局2020年3月27日通告，部分地區的海外郵政服務經已暫停，因此或會導致部分客戶的海外郵寄結單服務將被延遲，本公司建議客戶使用電子結單服務，以便更快捷收取閣下結單。
          </p>
          <p>
            客戶如需以其他傳遞方式收取最新結單，請致電客戶服務熱線(852) 3583
            3388或 (86) 755 8266 3232 與客戶服務主任聯絡，謝謝。
          </p>
          <p>
            有關香港郵政局最新暫停部分海外郵政服務通告，詳情請參考<a class="activeTagColor" href="https://www.hongkongpost.hk/tc/about_us/whats_new/notices/index_id_898.html" target="_blank">https://www.hongkongpost.hk/tc/about_us/whats_new/notices/index_id_898.html</a>
          </p>
          <p class="text">海通國際證券有限公司</p>
          <p>海通國際期貨有限公司</p>
          <p>謹啟</p>
          <p class="text">2020年4月1日</p>
        </el-scrollbar>
      </div>
    </div>

    <div class="btn">
      <el-button type="primary" @click="close">{{
        $t('prompt.Close')
      }}</el-button>
    </div>
  </div>
</template>

<script>
import { loadThemColor } from '@/utils/loadTheme'
export default {
  data() {
    return {}
  },
  methods: {
    // 关闭当前页
    close() {
      window.close()
    }
  },
  created() {
    let configColor = localStorage.getItem('bgColor') || 'bg-Blue';
    loadThemColor(configColor);
  },
}
</script>

<style lang="scss" scoped>
.newNotice {
  width: 100%;
  min-height: 100%;
  .top {
    display: flex;
    align-items: center;
    padding: 16px 0;
    background: #003da5;
    box-shadow: 6px 0 6px 0 rgba(162, 140, 133, 0.3);
    @media screen and(max-width: 1080px) {
      padding: 12px 24px;
    }
    @media screen and(max-width: 768px) {
      padding: 12px 12px;
    }
    .top-box {
      display: flex;
      align-items: center;
      margin: 0 auto;
      width: 1000px;
      img {
        margin-right: 25px;
        width: 95px;
        height: 32px;
      }
      span {
        padding-left: 25px;
        font-family: SourceHanSansCN-Medium;
        font-size: 18px;
        color: #ffffff;
        line-height: 25px;
        border-left: 1px #fff solid;
      }
    }
  }
  .title {
    padding: 0 24px;
    font-family: SourceHanSansCN-Medium;
    font-size: 18px;
    letter-spacing: 0;
    line-height: 18px;
    text-align: center;
    @media screen and(max-width: 768px) {
      padding: 0 12px;
    }
  }
  .box {
    margin: 53px auto 80px;
    width: 1000px;
    @media screen and(max-width: 1080px) {
      padding: 0 24px;
      width: 100%;
    }
    @media screen and(max-width: 768px) {
      padding: 0 12px;
      width: 100%;
    }
    .content {
      overflow: auto;
      width: 100%;
      font-family: SourceHanSansCN-Regular;
      font-size: 16px;
      letter-spacing: 0;
      line-height: 30px;
      >>> .el-scrollbar__wrap {
        margin-bottom: 0px !important;
      }
      .text {
        margin-top: 40px;
      }
      a {
        font-family: SourceHanSansCN-Regular;
        font-size: 16px;
        letter-spacing: 0;
      }
    }
  }
  .btn {
    text-align: center;
    padding-bottom: 24px;
  }
  .el-button {
    text-align: center;
    width: 120px;
    height: 40px;
    font-family: SourceHanSansCN-Bold;
    font-size: 16px;
    color: #ffffff;
    letter-spacing: 0;
    line-height: 14px;
  }
}
</style>
