<template>
  <!-- 联络我们 -->
  <div class="newContact contentBg">
    <div class="top">
      <div class="top-box">
        <img src="@/assets/1@3x.png" alt="" />
        <span>{{ $t('newContact.title') }}</span>
      </div>
    </div>
    <div class="imgs">
      <img v-if="isDark" src="@/assets/default_contact dark@2x.png" alt="" />
      <img v-else src="@/assets/default_contact us@2x.png" alt="" />
    </div>
    <h3 class="activeFontColor">{{ $t('newContact.title') }}</h3>
    <div class="content">
      <div class="content-left mediumColor">
        <p>{{ $t('newContact.content1') }}</p>
        <p>{{ $t('newContact.content2') }}</p>
        <p>{{ $t('newContact.content3') }}</p>
      </div>
      <div class="content-right heavyColor">
        <p>(852) 3583 3388</p>
        <p>(86) 755 8266 3232</p>
        <p><a class="activeTagColor" href="csdept@htisec.com" target="_blank">csdept@htisec.com</a></p>
      </div>
    </div>
  </div>
</template>

<script>
import { loadThemColor } from '@/utils/loadTheme'
export default {
  data() {
    return {
      isDark: ''
    }
  },
  created() {
    let configColor = localStorage.getItem('bgColor') || 'bg-Blue';
    configColor == 'bg-anhei'?this.isDark = true: this.isDark = false
    loadThemColor(configColor);
  },
}
</script>

<style lang="scss" scoped>
.newContact {
  text-align: center;
  min-height: 100%;
  .top {
    display: flex;
    align-items: center;
    padding: 16px 0;
    height: 100%;
    background: #003da5;
    box-shadow: 6px 0 6px 0 rgba(162, 140, 133, 0.3);
    @media screen and(max-width: 1080px) {
      padding: 12px 24px;
    }
    @media screen and(max-width: 768px) {
      padding: 12px 12px;
    }
    .top-box {
      display: flex;
      align-items: center;
      margin: 0 auto;
      width: 1000px;
      img {
        margin-right: 25px;
        width: 95px;
        height: 32px;
      }
      span {
        padding-left: 25px;
        font-family: SourceHanSansCN-Medium;
        font-size: 18px;
        color: #ffffff;
        line-height: 25px;
        border-left: 1px #fff solid;
      }
    }
  }
  .imgs {
    margin: 80px auto 30px;
    width: 400px;
    height: 240px;
    img {
      max-width: 100%;
      max-height: 100%;
    }
  }
  h3 {
    font-family: SourceHanSansCN-Medium;
    font-size: 18px;
    letter-spacing: 0;
    line-height: 18px;
  }
  .content {
    display: flex;
    align-items: center;
    justify-content: center;
    text-align: left;
    padding-bottom: 280px;
    .content-left {
      margin-right: 70px;
      font-family: SourceHanSansCN-Regular;
      font-size: 14px;
      letter-spacing: 0;
      line-height: 20px;
    }
    .content-right {
      font-family: SourceHanSansCN-Regular;
      font-size: 14px;
      letter-spacing: 0;
      text-align: left;
      line-height: 20px;
      a {
        font-family: SourceHanSansCN-Regular;
        font-size: 14px;
        letter-spacing: 0;
        line-height: 16px;
      }
    }
  }
}
@media screen and (max-width: 430px) {
  .newContact .imgs {
    // display: table-cell;
    // vertical-align: middle;
    width: 100%;
    height: 100%;
    padding: 0 12px;
  }
}
</style>
