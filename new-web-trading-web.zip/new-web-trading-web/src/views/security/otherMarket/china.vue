<template>
  <div class="china-wrap">
    <tradingInfo date="T+1" oneCurrency="1TWD" currency="TWD" HKD="0.257HKD" :leftImg="require('@/assets/flag_TW@2x.png')" :rightImg="require('@/assets/flag_HK@2x.png')">
      <span>{{$t('security.otherMarket.time6')}}</span>
    </tradingInfo>
  </div>
</template>

<script>
import tradingInfo from './tradingInfo'
export default {
  components: {
    tradingInfo
  },
  data() {
    return {
    };
  },
  methods: {

  },
  mounted() {
  },
}
</script>

<style lang="scss" scoped>
.china-wrap {
  width: 100%;
  height: 100%;
}
</style>