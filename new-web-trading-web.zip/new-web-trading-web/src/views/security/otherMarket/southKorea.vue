<template>
  <div class="southKorea-wrap">
    <tradingInfo date="T+2" oneCurrency="1KRW" currency="KRW" HKD="152.097HKD" :leftImg="require('@/assets/img/flag_KR@2x.png')" :rightImg="require('@/assets/img/flag_HK@2x.png')">
      <span>{{$t('security.otherMarket.time5')}}</span>
    </tradingInfo>
  </div>
</template>

<script>
import tradingInfo from './tradingInfo'
export default {
  components: {
    tradingInfo
  },
  data() {
    return {
    };
  },
  methods: {

  },
  mounted() {
  },
}
</script>

<style lang="scss" scoped>
.southKorea-wrap {
  width: 100%;
  height: 100%;
}
</style>