<template>
  <div class="japan-wrap">
    <tradingInfo date="T+3" oneCurrency="1WON" currency="WON" HKD="13.7341HKD" :leftImg="require('@/assets/flag_JP@2x.png')" :rightImg="require('@/assets/flag_HK@2x.png')">
      <ul class="info-wrap">
        <li>
          <span class="text">{{$t('security.otherMarket.time1')}}　</span>
          <span class="val">{{$t('security.otherMarket.time2')}}</span>
        </li>
        <li>
          <span class="text">{{$t('security.otherMarket.time3')}}　</span>
          <span class="val">{{$t('security.otherMarket.time4')}}</span>
        </li>
      </ul>
    </tradingInfo>
  </div>
</template>

<script>
import tradingInfo from './tradingInfo'
export default {
  components: {
    tradingInfo
  },
  data() {
    return {
    };
  },
  methods: {

  },
  mounted() {
  },
}
</script>

<style lang="scss" scoped>
.japan-wrap {
  width: 100%;
  height: 100%;
  .info-wrap {
    .text {
      font-family: SourceHanSansCN-Medium;
      padding-bottom: 5px;
    }
    .val {
      font-family: SourceHanSansCN-Regular;
    }
  }
}
</style>