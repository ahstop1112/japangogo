<!--其他市场（交易信息）-->
<template>
  <div class="tradingInfo-wrap">
    <el-row :gutter="24">
      <el-col :xs="24" :sm="24" :md="24" :lg="14" :xl="14">
        <div class="info-wrap contentBg">
          <div class="item-wrap contentBorder">
            <span class="title heavyColor">{{$t('security.otherMarket.service')}} </span>
            <span class="content mediumColor">{{$t('security.otherMarket.phone')}}(852) 2213-8333。</span>
          </div>
          <div class="item-wrap contentBorder">
            <span class="title heavyColor">{{$t('security.otherMarket.time')}}</span>
            <span class="content mediumColor">
              <slot></slot>
            </span>
          </div>
          <div class="item-wrap contentBorder">
            <span class="title heavyColor">{{$t('security.otherMarket.date')}}</span>
            <span class="content mediumColor">
              {{date}}
            </span>
          </div>
          <div class="item-wrap contentBorder">
            <span class="title heavyColor">{{$t('security.otherMarket.commission')}}</span>
            <span class="content mediumColor">{{$t('security.otherMarket.content')}} <a class="activeTagColor" href="http://www.htisec.com" target="_blank">{{$t('security.otherMarket.link')}}</a> {{$t('security.otherMarket.content1')}}</span>
          </div>
          <div class="item-wrap contentBorder">
            <span class="title heavyColor">{{$t('security.otherMarket.exchange')}}</span>
            <span class="content mediumColor">{{$t('security.otherMarket.info')}}</span>
          </div>
        </div>
      </el-col>
      <el-col :xs="24" :sm="24" :md="24" :lg="10" :xl="10">
        <div class="query-wrap contentBg">
          <span class="title heavyColor">{{$t('security.otherMarket.query')}}</span>
          <div class="content mediumColor">
            <p class="item">{{$t('security.otherMarket.reference')}}</p>
            <span class="titme">　{{$t('security.otherMarket.updateTime')}} 2019-12-02 08:05:00</span>
          </div>
          <div class="conversion">
            <img :src="leftImg" class="leftImg" alt="">
            <span class="heavyColor">{{oneCurrency}}　=　</span>
            <img :src="rightImg" class="rightImg" alt="">
            <span class="heavyColor">{{HKD}}</span>
          </div>
          <div class="conversion-wrap">
            <span class="heavyColor">{{currency}}</span>
            <el-input v-model="input" placeholder="请输入金额" onkeyup="this.value=this.value.replace(/[^\d]/g,'').replace(/^0{1,}/g,'')" onafterpaste="this.value=this.value.replace(/[^\d]/g,'').replace(/^0{1,}/g,'')"></el-input>
            <i class="iconfont icon-exchange activeFontColor"></i>
            <span class="heavyColor">HKD</span>
            <el-input v-model="input1" placeholder="请输入金额" onkeyup="this.value=this.value.replace(/[^\d]/g,'').replace(/^0{1,}/g,'')" onafterpaste="this.value=this.value.replace(/[^\d]/g,'').replace(/^0{1,}/g,'')"></el-input>
          </div>
          <div class="conversion-btn">
            <el-button type="primary" @click="conversion">
              {{$t('security.otherMarket.conversion')}}
            </el-button>
          </div>
        </div>
      </el-col>
    </el-row>
  </div>

</template>

<script>
export default {

  data() {
    return {
      input: '',
      input1: '',
      rate: 6.5363
    };
  },
  props: {
    date: "",
    leftImg: String,
    rightImg: String,
    oneCurrency: "",
    currency: '',
    HKD: ''
  },
  methods: {
    conversion() {
      if (this.input != '') {
        this.input1 = this.input * this.rate
      } else if (this.input1 != '') {
        this.input = this.input1 / this.rate
      }
    }
  },
  mounted() { },
  // watch: {
  //   input: {
  //     handler: function (newValue) {
  //       this.input1 = this.input * this.rate
  //     },
  //   },
  //   input1: {
  //     handler: function (newValue) {
  //       this.input = this.input1 / this.rate
  //     },
  //     immediate: true
  //   }
  // }
}
</script>

<style  lang="scss" scoped>
.tradingInfo-wrap {
  width: 100%;
  .title {
    display: block;
    font-family: SourceHanSansCN-Medium;
    font-size: 20px;
  }
  .content {
    display: block;
    padding: 12px 0;
    font-family: SourceHanSansCN-Regular;
    font-size: 16px;
    a {
      font-family: SourceHanSansCN-Medium;
    }
  }
  .info-wrap {
    padding: 24px;
    margin-bottom: 24px;
    .item-wrap {
      margin-bottom: 24px;
    }
  }
  .query-wrap {
    padding: 24px;
    .content {
      display: block;
      font-family: SourceHanSansCN-Regular;
      font-size: 14px;
    }
    .conversion {
      display: flex;
      align-items: center;
      padding-bottom: 12px;
      .leftImg,
      .rightImg {
        margin-right: 5px;
        width: 16px;
        height: 16px;
      }
    }
    .conversion-wrap {
      display: flex;
      align-items: center;
      .el-input {
        padding: 0 8px;
        >>> .el-input__inner {
          padding: 0 8px;
          padding-right: 0px !important;
        }
      }
      .icon-exchange {
        color: #406ebc;
        font-size: 22px;
        margin-right: 5px;
      }
    }
    .conversion-btn {
      margin: 48px 0 24px 0;
      .el-button {
        width: 100%;
      }
    }
  }
}
@media screen and (max-width: 768px) {
  .tradingInfo-wrap .info-wrap {
    margin-bottom: 12px;
    padding: 12px;
  }
  .tradingInfo-wrap .query-wrap {
    padding: 12px;
  }
}
</style>