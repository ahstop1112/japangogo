import echarts from"echarts"
//股票盈亏颜色
var greenUpColor = '#00BA57';
var greenDownColor = '#E00C00';
var redUpColor = '#E00C00';
var redDownColor = '#00BA57';
var grayColor = 'rgba(51,51,51,0.5)';

// ma  颜色
var ma5Color = "#39afe6";
var ma10Color = "#da6ee8";
var ma20Color = "#ffab42";
var ma30Color = "#00940b";
var ma60Color = "#999";

/* 通过用户设定的类型显示红涨绿跌还是绿涨红跌 */
function setQuterColor(val,yestclose, type) { 
    if(Number(val) - Number(yestclose) > 0 ) {
        return type == 1?greenUpColor:redUpColor
    }
    else if(Number(val) - Number(yestclose) < 0) {
        return type == 1?greenDownColor:redDownColor
    }
    else{
        return grayColor
    }
}
/*通过用户设置的主题来配置相关的颜色 */
function setChartBgColor(colorType) {
    let colorObj = {
        bgColor:'#fff',//背景图  181a23  rgba(51,51,51,0.5)
        lightColor:'rgba(51,51,51,0.25)', // x轴坐标颜色
        mediumColor:'rgba(51,51,51,0.5)', //y轴坐标颜色
        heavyColor:'rgb(51,51,51)',
        lineColor:'#003da5',//分时折线颜色
    }
    if(colorType == 'bg-anhei') {
        colorObj = {
            bgColor:'#333',
            lightColor:'rgba(255,255,255,0.25)', // x轴坐标颜色
            mediumColor:'rgba(255,255,255,0.5)', //y轴坐标颜色
            heavyColor:'rgb(255,255,255)',
            lineColor:'#4D88FF',
        }
    }
    return colorObj;
}
/**
 * 15:20 时:分 格式时间增加num分钟
 * @param {Object} time 起始时间
 * @param {Object} num
 */
function addTimeStr(time,num){ 
	var hour=time.split(':')[0];
	var mins=Number(time.split(':')[1]);
	var mins_un=parseInt((mins+num)/60);
	var hour_un=parseInt((Number(hour)+mins_un)/24);
	if(mins_un>0){
		if(hour_un>0){
			var tmpVal=((Number(hour)+mins_un)%24)+"";
			hour=tmpVal.length>1? tmpVal:'0'+tmpVal;//判断是否是一位
		}else{
			var tmpVal=Number(hour)+mins_un+"";
			hour=tmpVal.length>1? tmpVal:'0'+tmpVal;
		}
		var tmpMinsVal=((mins+num)%60)+"";
		mins=tmpMinsVal.length>1? tmpMinsVal:0+tmpMinsVal;//分钟数为 取余60的数
	}else{
		var tmpMinsVal=mins+num+"";
		mins=tmpMinsVal.length>1? tmpMinsVal:'0'+tmpMinsVal;//不大于整除60
	} 
	return hour+":"+mins;
}
//格式化金额
function forMatNum(num) {
    if(!num) {
        return "-" 
     }
     let val = ""
     let sizes = ['','万','亿','万亿']
     let k = 10000;
     if(num < k) {
         val = num;
     }else{
        let i = Math.floor(Math.log(num) / Math.log(k)); 
        val = ((num / Math.pow(k, i))).toFixed(2)+ sizes[i];
     } 
     return val;
}
//获取增加指定分钟数的 数组  如 09:30增加2分钟  结果为 ['09:31','09:32'] 
function getNextTime(startTime, endTIme, offset, resultArr) {
	var result = addTimeStr(startTime, offset);
	resultArr.push(result);
	if (result == endTIme) {
		return resultArr;
	} else {
		return getNextTime(result, endTIme, offset, resultArr);
	}
}


/**
 * 不同类型的股票的交易时间会不同  
 * @param {Object} type   hs=沪深  us=美股  hk=港股
 */
var time_arr = function(type) { 
	if(type.indexOf('us')!=-1){//生成美股时间段
		var timeArr = new Array();
		timeArr.push('09:30')
		return getNextTime('09:30', '16:00', 1, timeArr);
	}
	if(type.indexOf('hs')!=-1){//生成沪深时间段
		var timeArr = new Array();
			timeArr.push('09:30');
			timeArr.concat(getNextTime('09:30', '11:29', 1, timeArr)); 
			timeArr.push('13:00');
			timeArr.concat(getNextTime('13:00', '15:00', 1, timeArr)); 
		return timeArr;
	}
	if(type.indexOf('hk')!=-1){//生成港股时间段
		var timeArr = new Array();
			timeArr.push('09:30');
			timeArr.concat(getNextTime('09:30', '11:59', 1, timeArr)); 
			timeArr.push('13:00');
			timeArr.concat(getNextTime('13:00', '16:00', 1, timeArr)); 
		return timeArr;
	}
}


var get_m_data = function(m_data,type) {
	var priceArr = new Array();
	var avgPrice = new Array();
	var vol = new Array();
    var times = time_arr(type); 
    for(let i=0;i<m_data.length;i++) {
        let v = m_data[i];
        priceArr.push(v[1]);
		avgPrice.push(v[2]);
		vol.push(v[3]); 
    }
	return {
		priceArr: priceArr,
		avgPrice: avgPrice,
		vol: vol,
		times: times
	}
}

//==========================================分时表 option

/**
 * 生成分时option 
 * @param {Object} m_data 分时数据
 * @param {Object} type 股票类型  us-美股  hs-沪深  hk-港股
 */
function initMOption(type,data,yestclose, colorType, bgColorType){
    var m_datas = get_m_data(data,type); 
	return {
		tooltip: { //弹框指示器
			trigger: 'axis',
			axisPointer: {
				type: 'cross'
			},
			formatter: function(params, ticket, callback) {
				var i = params[0].dataIndex;
	
                var color;
                color =  `style="color:${setQuterColor(m_datas.priceArr[i], yestclose, colorType)}"`;
				var html = '<div class="commColor" style="width:100px;"><div>当前价 <span  '+color+' >' + m_datas.priceArr[i] + '</span></div>';
				html += '<div>均价 <span  '+color+' >' + m_datas.avgPrice[i] + '</span></div>';
				html += '<div>涨幅 <span  '+color+' >' + ratioCalculate(m_datas.priceArr[i],yestclose)+ '%</span></div>';
				html += '<div>成交量 <span  '+color+' >' + forMatNum(m_datas.vol[i]) + '</span></div></div>'
				return html;
			}
		},
		/*legend: { //图例控件,点击图例控制哪些系列不显示
			icon: 'rect',
			type: 'scroll',
			itemWidth: 14,
			itemHeight: 2,
			left: 0,
			top: '-1%',
			textStyle: {
				fontSize: 12,
				color: '#0e99e2'
			}
		},*/
		axisPointer: {
			show: true
		},
		color: [ma5Color, ma10Color],
		grid: [{
				id: 'gd1',
				left: '12',
				right: '12',
				height: '60%', //主K线的高度,
				top: '5%'
			},
			{
				id: 'gd2',
				left: '12',
				right: '12',
				height: '60%', //主K线的高度,
				top: '5%'
			}, {
				id: 'gd3',
				left: '12',
				right: '12',
				top: '68%',
				height: '25%' //交易量图的高度
			}
		],
		xAxis: [ //==== x轴
			{ //主图 
				gridIndex: 0,
				data: m_datas.times,
				axisLabel: { //label文字设置
					show: false
				},
				splitLine: {
					show: false,
                },
                axisTick: {
                    show: false
                },
                axisLine:{
                    lineStyle:{
                        color:setChartBgColor(bgColorType).lightColor,
                    }
                } 
			},
			{
				show:false,
				gridIndex: 1,
				data: m_datas.times,
				axisLabel: { //label文字设置
					show: false
				},
				splitLine: {
					show: false,
                },
                axisTick: {
                    show: false
                },
			}, { //交易量图
				splitNumber: 2,
				type: 'category',
				gridIndex: 2,
				data: m_datas.times,
				axisLabel: { //label文字设置
					color: '#9b9da9',
					fontSize: 10
                },
                axisLine:{
                    lineStyle:{
                        color:setChartBgColor(bgColorType).lightColor,
                    }
                } 
			}
		],
		yAxis: [ //y轴
			{
                axisTick: {
                    show: false
                },
                axisLine: {
                    show: false
                },
				gridIndex: 0,
				scale: true, 
                splitNumber: 3,
                offset:'10',
                axisLabel: { //label文字设置 
                    inside: true, //label文字朝内对齐 
                    interval: 100000,
                    showMinLabel: true,
                    showMaxLabel: true,
					//fontWeight:'bold',
					color:function(val){ 
                        return setQuterColor(val, yestclose, colorType);
					}
				},z:4,splitLine: { //分割线设置
					show: false,
					lineStyle: {
						color:  setChartBgColor(bgColorType).heavyColor
					}
				},  
			}, { 
                scale: true,  gridIndex: 1, splitNumber: 3,  
                position: 'right', z:4,
                axisLabel: { //label文字设置
                    showMinLabel: true,
                    showMaxLabel: true,
					color:function(val){ 
                        return setQuterColor(val, yestclose, colorType);
					},
					inside: true, //label文字朝内对齐 
					//fontWeight:'bold',
					formatter:function(val){
						var resul=ratioCalculate(val,yestclose);
						return  Number(resul).toFixed(2)+' %'}
				},
				splitLine: { //分割线设置
					show: false,
					lineStyle: {
						color:  setChartBgColor(bgColorType).heavyColor
					}
                },
                axisTick: {
                    show: false
                },
                axisLine: {
                    show: false
                },
				axisPointer:{show:true,
					label:{
						formatter:function(params){ //计算右边Y轴对应的当前价的涨幅比例
							return  ratioCalculate(params.value,yestclose)+'%';
						}
					}
				}
			} 
			, { //交易图
				gridIndex: 2,z:4,
                splitNumber: 3,
				axisLine: {
                    onZero: false,
                    lineStyle:{
                        color:setChartBgColor(bgColorType).lightColor,
                    }
				},
				axisTick: {
					show: false
				},
				splitLine: {
					show: false
				},
                axisLabel: { //label文字设置
					color: setChartBgColor(bgColorType).mediumColor,
					inside: true, //label文字朝内对齐 
					fontSize: 8
				},
			}
		],
		dataZoom: [
	
		],
		//animation:false,//禁止动画效果
		backgroundColor: setChartBgColor(bgColorType).bgColor,
		blendMode: 'source-over',
		series: [{
				name: '当前价',
				type: 'line',
				data: m_datas.priceArr,
				smooth: true,
				symbol: "circle", //中时有小圆点 
				lineStyle: {
					normal: {
						opacity: 1,
						color: setChartBgColor(bgColorType).lineColor,
						width: 1
					}
				},
				areaStyle: {
					normal: {
						color: new echarts.graphic.LinearGradient(0, 0, 0, 1, [{
							offset: 0,
							color: 'rgba(0, 136, 212, 0.7)'
						}, {
							offset: 0.8,
							color: 'rgba(0, 136, 212, 0.02)'
						}], false),
						shadowColor: 'rgba(0, 0, 0, 0.1)',
						shadowBlur: 10
					}
				}
			},
			{
				name: '均价',
				type: 'line',
				data: m_datas.avgPrice,
				smooth: true,
				symbol: "circle",
				lineStyle: { //标线的样式
					normal: {
						opacity: 1,
						color: '#f1a233',
						width: 1
					}
				}
			},{  
				type: 'line', 
				data: m_datas.priceArr,
				smooth: true,
				symbol: "none",
				gridIndex: 1,
				xAxisIndex: 1,
				yAxisIndex: 1,
				lineStyle: { //标线的样式 
					normal: { 
						width: 0
					}
				}
			},
			{
				name: 'Volumn',
				type: 'bar',
				gridIndex: 2,
				xAxisIndex: 2,
				yAxisIndex: 2,
				data: m_datas.vol,
				barWidth: '60%',
				itemStyle: {
					normal: {
						color: function(params) {
                            return setQuterColor(m_datas.priceArr[params.dataIndex], m_datas.priceArr[params.dataIndex-1], colorType);
						},
					}
				}
			}
		]
	};
}
/**
 * 计算价格涨跌幅百分比
 * @param {Object} price 当前价
 * @param {Object} yclose 昨收价
 */
function ratioCalculate(price,yclose){
	return ((price-yclose)/yclose*100).toFixed(2);
}


//数组处理
function splitData(rawData) {
    //对数据进行拷贝，不然会影响数据
    let orginData = JSON.parse(JSON.stringify(rawData));
    var datas = []; var times = [];var vols = [];
	for (var i = 0; i < orginData.length; i++) {
        times.push(orginData[i].splice(0, 1)[0]);
        vols.push(orginData[i][4]); 
        let precents = ratioCalculate(Number(orginData[i][3]),Number(orginData[i][11]))+"%";
        let obj = [
            orginData[i][0],//开盘价
            orginData[i][3],//收盘价
            orginData[i][2],//最低价
            orginData[i][1],//最高价
            Number(orginData[i][6]).toFixed(2),// 5日均线
            Number(orginData[i][7]).toFixed(2),// 10日均线
            Number(orginData[i][8]).toFixed(2),// 20日均线
            Number(orginData[i][9]).toFixed(2),// 30日均线
            Number(orginData[i][10]).toFixed(2),// 60日均线
            Number(orginData[i][11]).toFixed(2),// 收盘价
            precents,//涨跌幅
        ]
		datas.push(obj);
    }
	return {datas:datas,times:times,vols:vols};
}

//================================MA平均线
function calculateMA(dayCount,data, position) {
	var result = [];
	for (var i = 0, len = data.length; i < len; i++) {
        result.push(data[i][position]);
	}
	return result;
}

function initKOption(dataArr, colorType ,bgColorType) {
    var data = splitData(dataArr);
    let series =  [
         {
             name: 'K线周期图表',
             type: 'candlestick',
             data: data.datas,
             barWidth: '55%',
             large: true,
             largeThreshold: 100,
             itemStyle: {
                 normal: {
                     color: setQuterColor(1,0,colorType), //fd2e2e  ff4242
                     color0: setQuterColor(0,1,colorType),
                     borderColor: setQuterColor(1,0,colorType),
                     borderColor0: setQuterColor(0,1,colorType),
                     //opacity:0.8
                 }
             }
         },
         {
             name: 'MA5',
             type: 'line',
             data: calculateMA(5,data.datas, 4),
             smooth: true,
             symbol: "none", //隐藏选中时有小圆点
             lineStyle: {
                 normal: {
                     opacity: 0.8,
                     color: '#39afe6',
                     width: 1
                 }
             },
         },
         {
             name: 'MA10',
             type: 'line',
             data: calculateMA(10,data.datas, 5),
             smooth: true,
             symbol: "none",
             lineStyle: { //标线的样式
                 normal: {
                     opacity: 0.8,
                     color: '#da6ee8',
                     width: 1
                 }
             }
         },
         {
             name: 'MA20',
             type: 'line',
             data: calculateMA(20,data.datas, 6),
             smooth: true,
             symbol: "none",
             lineStyle: {
                 opacity: 0.8,
                 width: 1,
                 color: ma20Color
             }
         },
         {
             name: 'MA30',
             type: 'line',
             data: calculateMA(30,data.datas, 7),
             smooth: true,
             symbol: "none",
             lineStyle: {
                 normal: {
                     opacity: 0.8,
                     width: 1,
                     color: ma30Color
                 }
             }
         },
         {
             name: 'MA60',
             type: 'line',
             data: calculateMA(60,data.datas, 8),
             smooth: true,
             symbol: "none",
             lineStyle: {
                 normal: {
                     opacity: 0.8,
                     width: 1,
                     color: ma60Color
                 }
             }
         },
         {
             name: 'Volumn',
             type: 'bar',
             xAxisIndex: 1,
             yAxisIndex: 1,
             data: data.vols,
             barWidth: '60%',
             itemStyle: {
                 normal: {
                     color: function(params) {
                        return setQuterColor(data.datas[params.dataIndex][1],data.datas[params.dataIndex][0],colorType)
                     }
                 }           
             }
         },
         {
            name: 'MACD',
            type: 'bar',
            xAxisIndex: 2,
            yAxisIndex: 2,
            barWidth: '40%',
            itemStyle: {
                normal: {
                    color: function(params) {
                        return setQuterColor(params.data,0,colorType);
                    },
                }
            }
         },
         {
            name: 'DIF',
            type: 'line',
            symbol: "none",
            xAxisIndex: 2,
            yAxisIndex: 2,
            lineStyle: {
                normal: {
                    color: '#da6ee8',
                    width: 1
                }
            }
         },
         {
            name: 'DEA',
            type: 'line',
            symbol: "none",
            xAxisIndex: 2,
            yAxisIndex: 2,
            lineStyle: {
                normal: {
                    opacity: 0.8,
                    color: '#39afe6',
                    width: 1
                }
            }
         },
         {
            name: 'K',
            type: 'line',
            symbol: "none",
            xAxisIndex: 2,
            yAxisIndex: 2,
            lineStyle: {
                normal: {
                    opacity: 0.8,
                    color: '#39afe6',
                    width: 1
                }
            }
         },
         {
            name: 'D',
            type: 'line',
            symbol: "none",
            xAxisIndex: 2,
            yAxisIndex: 2,
            lineStyle: {
                normal: {
                    opacity: 0.8,
                    color: '#da6ee8',
                    width: 1
                }
            }
         },
         {
            name: 'J',
            type: 'line',
            symbol: "none",
            xAxisIndex: 2,
            yAxisIndex: 2,
            lineStyle: {
                normal: {
                    opacity: 0.8,
                    color: '#00940b',
                    width: 1
                }
            }
         },
         {
            name: 'Upper',
            type: 'line',
            symbol: "none",
            lineStyle: {
                normal: {
                    opacity: 0.8,
                    color: '#39afe6',
                    width: 1
                }
            }
         },
         {
            name: 'Avg',
            type: 'line',
            symbol: "none",
            lineStyle: {
                normal: {
                    opacity: 0.8,
                    color: '#da6ee8',
                    width: 1
                }
            }
         },
         {
            name: 'Lower',
            type: 'line',
            symbol: "none",
            lineStyle: {
                normal: {
                    opacity: 0.8,
                    color: '#00940b',
                    width: 1
                }
            }
         },
         {
            name: 'Rsi1',
            type: 'line',
            symbol: "none",
            xAxisIndex: 2,
            yAxisIndex: 2,
            lineStyle: {
                normal: {
                    opacity: 0.8,
                    color: '#39afe6',
                    width: 1
                }
            }
         },
         {
            name: 'Rsi2',
            type: 'line',
            symbol: "none",
            xAxisIndex: 2,
            yAxisIndex: 2,
            lineStyle: {
                normal: {
                    opacity: 0.8,
                    color: '#da6ee8',
                    width: 1
                }
            }
         },
         {
            name: 'Rsi3',
            type: 'line',
            symbol: "none",
            xAxisIndex: 2,
            yAxisIndex: 2,
            lineStyle: {
                normal: {
                    opacity: 0.8,
                    color: '#00940b',
                    width: 1
                }
            }
         },
     ]
    return {
        tooltip: { //弹框指示器
            trigger: 'axis',
            axisPointer: {
                type: 'cross'
            },
            formatter: function(params, ticket, callback) {
               let html =""; 
               for(let i=0;i<params.length;i++) {
                   //对成交量的数据进行格式化
                   if(params[i].seriesName == "Volumn") {
                        params[i].data =  forMatNum(params[i].data);
                   }
                   if(params[i].componentSubType == "candlestick") {
                        let time = params[i].name;
                        let datas = params[i].data;
                        let percentNumb = (datas[11].replace("%",""))/100;
                        let className = setQuterColor(percentNumb,0,colorType);
                        html += `<div style="width:100%;margin-bottom:4px;"> <span style="display:inline-block;border-radius:10px;width:10px;height:10px;background-color:${params[i].color};"></span>
                                <span class="padding-left:4px;display:inline-block;width:100%;font-size:14px;text-align:center;">${time}</span></br>`;
                        html += "开盘价:"+datas[1] +"</br>"+ "收盘价:"+datas[2] +"</br>" + "最低价:"+datas[3] +"</br>"  +"最高价:"+datas[4] + "</br>";
                        html += `<span style='color:${className}'>涨跌幅:${datas[11]}</span></div>`;
                   }
                   else{
                        html += `<div>
                            <span style="display:inline-block;border-radius:10px;width:10px;height:10px;background-color:${params[i].color};"></span>
                            <span style="padding-left: 2px;">${params[i].seriesName}</span>
                            <span style="padding-left: 4px;">${params[i].data}</span>
                        </div>`        
                   }
               }
               return html
            }    
        },
        legend: { //图例控件,点击图例控制哪些系列不显示
            icon: 'rect', 
            type:'scroll',
            itemWidth: 14,
            itemHeight: 2,
            left: 0,
            top: '0.6%',  
            data: ['K线周期图表','Volumn'],
            animation:true,
            textStyle: {
                fontSize: 12,
                color: setChartBgColor(bgColorType).lineColor
            },
            pageIconColor:setChartBgColor(bgColorType).lineColor
        },
        axisPointer: {
            show: true
        },
        color: [ma5Color, ma10Color, ma20Color, ma30Color, ma60Color],
        grid: [{
            id: 'gd1',
            left: '0%',
            right: '1%',
            height: '40%', //主K线的高度,
            top: '11%'
        }, {
            left: '0%',
            right: '1%',
            top: '54%',
            height: '18%' //交易量图的高度
        }, {
            left: '0%',
            right: '1%',
            top: '77%', //MACD 指标
            height: '20%'
        }],
        xAxis: [ //==== x轴
            { //主图
                type: 'category',
                data: data.times,
                scale: true,
                boundaryGap: false,
                axisLine: {
                    onZero: false,
                    lineStyle:{
                        color:setChartBgColor(bgColorType).lightColor,
                    }
                },
                axisLabel: { //label文字设置
                    show: false
                },
                splitLine: {
                    show: false,
                    lineStyle: {
                        color: '#3a3a3e'
                    }
                },
                splitNumber: 20,
                min: 'dataMin',
                max: 'dataMax'
            }, { //交易量图
                type: 'category',
                gridIndex: 1,
                data: data.times,
                axisLabel: { //label文字设置
                    color: '#9b9da9',
                    fontSize: 10
                },
                axisLine: {
                    lineStyle:{
                        color:setChartBgColor(bgColorType).lightColor,
                    }
                },
            }, { //幅图
                type: 'category',
                gridIndex: 2,
                data: data.times,
                axisLabel: {
                    show: false
                },
                axisLine: {
                    lineStyle:{
                        color:setChartBgColor(bgColorType).lightColor,
                    }
                },
            }
        ],
        yAxis: [ //y轴
            { //==主图
                scale: true,
                z:4,
                axisLabel: { //label文字设置
                    color: '#c7c7c7',
                    inside: true, //label文字朝内对齐
                },
                splitLine: { //分割线设置
                    show: false,
                    lineStyle: { 
                        color:  setChartBgColor(bgColorType).heavyColor
                    }
                },
                axisLine: {
                    lineStyle:{
                        color:setChartBgColor(bgColorType).lightColor,
                    }
                },
            }, { //交易图
                gridIndex: 1, splitNumber: 3, z:4,
                axisLine: {
                    onZero: false,
                    lineStyle:{
                        color:setChartBgColor(bgColorType).lightColor,
                    }
                },
                axisTick: {
                    show: false
                },
                splitLine: {
                    show: false
                },
                axisLabel: { //label文字设置
                    color: '#c7c7c7',
                    inside: true, //label文字朝内对齐 
                    fontSize: 8
                },
            }, { //幅图
                z:4, gridIndex: 2,splitNumber: 4,
                axisLine: {
                    onZero: false,
                    lineStyle:{
                        color:setChartBgColor(bgColorType).lightColor,
                    }
                },
                axisTick: {
                    show: false
                },
                splitLine: {
                    show: false
                },
                axisLabel: { //MACDY轴坐标
                    show: false,
                    color: '#c7c7c7',
                    inside: true, //label文字朝内对齐 
                    fontSize: 8
                },
            }
        ],
        dataZoom: [{
                type: 'slider',
                xAxisIndex: [0, 1, 2], //控件联动
                start: 100,
                end: 80,
                throttle: 10,
                top: '94%',
                height: '6%',
                borderColor: '#696969',
                textStyle: {
                    color: '#dcdcdc'
                },
                handleSize: '90%', //滑块图标
                handleIcon: 'M10.7,11.9v-1.3H9.3v1.3c-4.9,0.3-8.8,4.4-8.8,9.4c0,5,3.9,9.1,8.8,9.4v1.3h1.3v-1.3c4.9-0.3,8.8-4.4,8.8-9.4C19.5,16.3,15.6,12.2,10.7,11.9z M13.3,24.4H6.7V23h6.6V24.4z M13.3,19.6H6.7v-1.4h6.6V19.6z',
                dataBackground: {
                    lineStyle: {
                        color: '#fff'
                    }, //数据边界线样式
                    areaStyle: {
                        color: '#696969'
                    } //数据域填充样式
                }
            },
            // 		{
            // 			type: 'inside',
            // 			xAxisIndex: [0,1,2],//控件联动
            // 		},
        ],
        animation: false, //禁止动画效果
        backgroundColor: setChartBgColor(bgColorType).bgColor,
        blendMode: 'source-over',
        series: series,    
    }
}

//=================================================五日K线 
var get_Five_data = function(data) {
    var priceArr = new Array();
	var avgPrice = new Array();
    var vol = new Array();
    var times = new Array();
    for(let i=0;i<data.length;i++) {
        let v = data[i];
        times.push(v[0]);
        priceArr.push(v[1]);
		avgPrice.push(v[2]);
		vol.push(v[3]); 
    }
    return {
        priceArr: priceArr,
		avgPrice: avgPrice,
		vol: vol,
		times: times  
    }
}
function initFiveOption(data, closePrice, colorType, bgColorType) {
    var m_datas = get_Five_data(data); 
    return {
        tooltip: { //弹框指示器
			trigger: 'axis',
			axisPointer: {
				type: 'cross'
			},
			formatter: function(params, ticket, callback) {
				var i = params[0].dataIndex;
                var color;
                color =  `style="color:${setQuterColor(m_datas.priceArr[i], closePrice, colorType)}"`;
				var html = '<div class="commColor" style="width:100px;"><div>当前价 <span  '+color+' >' + m_datas.priceArr[i] + '</span></div>';
				html += '<div>均价 <span  '+color+' >' + m_datas.avgPrice[i] + '</span></div>';
				html += '<div>涨幅 <span  '+color+' >' + ratioCalculate(m_datas.priceArr[i],closePrice)+ '%</span></div>';
				html += '<div>成交量 <span  '+color+' >' + forMatNum(m_datas.vol[i]) + '</span></div></div>'
				return html;
			}
        },
        axisPointer: {
			show: true
		},
        color: [ma5Color, ma10Color],
        grid: [{
                id: 'gd1',
                left: '10',
                right: '10',
                height: '60%', //主K线的高度,
                top: '5%'
            },
            {
                id: 'gd2',
                left: '10',
                right: '10',
                height: '60%', //主K线的高度,
                top: '5%'
            }, {
                id: 'gd3',
                left: '10',
                right: '10',
                top: '68%',
                height: '25%' //交易量图的高度
            }
        ],
        xAxis: [ //==== x轴
			{ //主图 
				gridIndex: 0,
				data: m_datas.times,
				axisLabel: { //label文字设置
					show: false
				},
				splitLine: {
					show: false,
                },
                axisTick: {
                    show: false
                },
                axisLine:{
                    lineStyle:{
                        color:setChartBgColor(bgColorType).lightColor,
                    }
                } 
			},
			{
				show:false,
				gridIndex: 1,
				data: m_datas.times,
				axisLabel: { //label文字设置
					show: false
				},
				splitLine: {
					show: false,
                },
                axisTick: {
                    show: false
                },
			}, { //交易量图
				splitNumber: 2,
				type: 'category',
				gridIndex: 2,
				data: m_datas.times,
				axisLabel: { //label文字设置
					color: '#9b9da9',
                    fontSize: 10,
                    interval: 73
                },
                axisLine:{
                    lineStyle:{
                        color:setChartBgColor(bgColorType).lightColor,
                    }
                } 
			}
        ],
        yAxis: [ //y轴
			{
                axisTick: {
                    show: false
                },
                axisLine: {
                    show: false
                },
				gridIndex: 0,
				scale: true, 
                splitNumber: 3,
                axisLabel: { //label文字设置 
                    inside: true, //label文字朝内对齐 
                    interval: 100000,
                    showMinLabel: true,
                    showMaxLabel: true,
					//fontWeight:'bold',
					color:function(val){ 
                        return setQuterColor(val,closePrice,colorType)
					}
				},z:4,splitLine: { //分割线设置
					show: false,
					lineStyle: {
						color:  setChartBgColor(bgColorType).heavyColor
					}
				},  
			}, { 
				scale: true,  gridIndex: 1, splitNumber: 3,  
                position: 'right', z:4,
                axisLabel: { //label文字设置
                    showMinLabel: true,
                    showMaxLabel: true,
					color:function(val){ 
                        return setQuterColor(val,closePrice,colorType)
					},
					inside: true, //label文字朝内对齐 
					//fontWeight:'bold',
					formatter:function(val){
						var resul=ratioCalculate(val,closePrice);
						return  Number(resul).toFixed(2)+' %'}
				},
				splitLine: { //分割线设置
					show: false,
					lineStyle: {
						color: setChartBgColor(bgColorType).heavyColor
					}
                },
                axisTick: {
                    show: false
                },
                axisLine: {
                    show: false
                },
				axisPointer:{show:true,
					label:{
						formatter:function(params){ //计算右边Y轴对应的当前价的涨幅比例
							return  ratioCalculate(params.value,closePrice)+'%';
						}
					}
				}
			} 
			, { //交易图
				gridIndex: 2,z:4,
				splitNumber: 3,
				axisLine: {
                    onZero: false,
                    lineStyle:{
                        color:setChartBgColor(bgColorType).lightColor,
                    }
				},
				axisTick: {
					show: false
				},
				splitLine: {
					show: false
				},
                axisLabel: { //label文字设置
					color: setChartBgColor(bgColorType).mediumColor,
					inside: true, //label文字朝内对齐 
					fontSize: 8
				},
			}
        ],
        //animation:false,//禁止动画效果
		backgroundColor: setChartBgColor(bgColorType).bgColor,
		blendMode: 'source-over',
		series: [{
				name: '当前价',
				type: 'line',
				data: m_datas.priceArr,
				smooth: true,
				symbol: "circle", //中时有小圆点 
				lineStyle: {
					normal: {
						opacity: 1,
						color: setChartBgColor(bgColorType).lineColor,
						width: 1
					}
				},
				areaStyle: {
					normal: {
						color: new echarts.graphic.LinearGradient(0, 0, 0, 1, [{
							offset: 0,
							color: 'rgba(0, 136, 212, 0.7)'
						}, {
							offset: 0.8,
							color: 'rgba(0, 136, 212, 0.02)'
						}], false),
						shadowColor: 'rgba(0, 0, 0, 0.1)',
						shadowBlur: 10
					}
				}
			},
			{
				name: '均价',
				type: 'line',
				data: m_datas.avgPrice,
				smooth: true,
				symbol: "circle",
				lineStyle: { //标线的样式
					normal: {
						opacity: 1,
						color: '#f1a233',
						width: 1
					}
				}
			},{  
				type: 'line', 
				data: m_datas.priceArr,
				smooth: true,
				symbol: "none",
				gridIndex: 1,
				xAxisIndex: 1,
				yAxisIndex: 1,
				lineStyle: { //标线的样式 
					normal: { 
						width: 0
					}
				}
			},
			{
				name: 'Volumn',
				type: 'bar',
				gridIndex: 2,
				xAxisIndex: 2,
				yAxisIndex: 2,
				data: m_datas.vol,
				barWidth: '60%',
				itemStyle: {
					normal: {
						color: function(params) {
                            return setQuterColor(m_datas.priceArr[params.dataIndex],m_datas.priceArr[params.dataIndex-1],colorType);
						},
					}
				}
			}
		]
    }
}

export  {initMOption,initFiveOption,initKOption};
