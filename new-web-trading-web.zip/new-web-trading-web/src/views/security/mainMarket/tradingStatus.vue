 <!--交易状况-->
<template>
  <div class="tranding-status contentBg">
    <main-title :title="$t('security.mainMarket.orderStatus')">
      <el-popover placement="left" width="100" ref="popover" trigger="click" >
        <div class="btn-wrap">
          <span class="btn mediumColor" style="cursor:pointer;" @click="exportExcel">{{$t('security.mainMarket.export')}}</span>
          <span class="btn mediumColor" style="cursor:pointer;display:block;margin-top:10px;" @click="printTrad">{{$t('security.mainMarket.print')}}</span>
        </div>
        <span slot="reference" class="icons"><i class="iconfont icon-more lightColor"></i></span>
      </el-popover>
    </main-title>
    <popover :title="$t('security.mainMarket.tradDetail')" @close="closeDetailWrap" :showPopover="showDetail" >
      <div class="tradDetail-wrap">
        <div class="expain-wrap activeFontColor" @click="openHelpCenter">
          {{$t('security.mainMarket.tradExplain')}}
        </div>
        <ul class="info-wrap">
          <li class="info-item">
            <span class="text mediumColor">{{$t('security.mainMarket.account')}}</span>
            <span class="val heavyColor">02-0071828-33</span>
          </li>
          <li class="info-item">
            <span class="text mediumColor">{{$t('security.mainMarket.tradId')}}</span>
            <span class="val heavyColor">80044</span>
          </li>
          <li class="info-item">
            <span class="text mediumColor">
              {{$t('security.mainMarket.tradStatus')}}
              <span class="tip">
                <i class="iconfont icon-detail"></i>
                <el-popover placement="right" width="220" trigger="click">
                  <div class="list">
                    <span class="icon lightColor">*</span>
                    <span class="text mediumColor">{{$t('security.mainMarket.explain1')}}</span>
                  </div>
                  <div class="list">
                    <span class="icon lightColor">#</span>
                    <span class="text mediumColor">{{$t('security.mainMarket.explain2')}}</span>
                  </div>
                  <div class="list">
                    <span class="icon lightColor">@</span>
                    <span class="text mediumColor">{{$t('security.mainMarket.explain3')}}</span>
                  </div>
                  <span slot="reference" class="txt lightColor">{{$t('security.mainMarket.detail')}}</span>
                </el-popover>
              </span>
            </span>
            <span class="val heavyColor">完全成交</span>
          </li>
          <li class="info-item">
            <span class="text mediumColor">{{$t('security.mainMarket.buys')}}/{{$t('security.mainMarket.sells')}}</span>
            <span class="val heavyColor">買入</span>
          </li>
          <li class="info-item">
            <span class="text mediumColor">{{$t('security.mainMarket.tradType')}}</span>
            <span class="val heavyColor">限價盤</span>
          </li>
          <li class="info-item">
            <span class="text mediumColor">{{$t('security.mainMarket.market')}}</span>
            <span class="val heavyColor">港股</span>
          </li>
          <li class="info-item">
            <span class="text mediumColor">{{$t('security.mainMarket.stock')}}</span>
            <span class="val heavyColor">00665 海通國際</span>
          </li>
          <li class="info-item">
            <span class="text mediumColor">{{$t('security.mainMarket.tradPrice')}}</span>
            <span class="val heavyColor">HKD 2.600</span>
          </li>
          <li class="info-item">
            <span class="text mediumColor">{{$t('security.mainMarket.condition')}}</span>
            <span class="val heavyColor">不適用</span>
          </li>
          <li class="info-item">
            <span class="text mediumColor">{{$t('security.mainMarket.orignNum')}}</span>
            <span class="val heavyColor">3000</span>
          </li>
          <li class="info-item">
            <span class="text mediumColor">
              {{$t('security.mainMarket.changeNum')}}
              <span class="tip">
                <i class="iconfont icon-detail"></i>
                <el-popover placement="right" width="220" trigger="click">
                  <div class="list">
                    <span class="icon mediumColor">{{$t('security.mainMarket.chejiaojiage')}}</span>
                    <span class="text heavyColor">HKD 2.60</span>
                  </div>
                  <div class="list">
                    <span class="icon mediumColor">{{$t('security.mainMarket.sellTotalNum')}}</span>
                    <span class="text heavyColor">3,000</span>
                  </div>
                  <div class="list">
                    <span class="icon mediumColor">{{$t('security.mainMarket.jiaoyiduishou')}}</span>
                    <span class="text heavyColor">不通用</span>
                  </div>
                  <span slot="reference" class="txt lightColor">{{$t('security.mainMarket.detail')}}</span>
                </el-popover>
              </span>
            </span>
            <span class="val heavyColor">0</span>
          </li>
          <li class="info-item">
            <span class="text mediumColor">{{$t('security.mainMarket.sellTotalNum')}}</span>
            <span class="val heavyColor">3,000</span>
          </li>
          <li class="info-item">
            <span class="text mediumColor">{{$t('security.mainMarket.noComplateNum')}}</span>
            <span class="val heavyColor">0</span>
          </li>
          <li class="info-item">
            <span class="text mediumColor">{{$t('security.mainMarket.expired')}}</span>
            <span class="val heavyColor">即日</span>
          </li>
          <li class="info-item">
            <span class="text mediumColor">{{$t('security.mainMarket.refusReson')}}</span>
            <span class="val heavyColor">-</span>
          </li>
          <li class="info-item">
            <span class="text mediumColor">{{$t('security.mainMarket.aon')}}</span>
            <span class="val heavyColor">否</span>
          </li>
          <li class="info-item">
            <span class="text mediumColor">{{$t('security.mainMarket.channel')}}</span>
            <span class="val heavyColor">網上交易</span>
          </li>
        </ul>
      </div>
    </popover>
    <popover :title="isType=='cancel'?$t('security.mainMarket.cancelTradTip'):$t('security.mainMarket.changeTip')" 
              @close="closeEditorWrap" :showPopover="showEditor" :isFirst="firstStep">
      <div class="editor-wrap" v-if="firstStep">
        <div class="expain-wrap activeFontColor">
          <p class="explian-item" @click="openHelpCenter">{{$t('security.mainMarket.tradExplain')}}</p>
          <p class="explian-item" @click="openHelpCenter">{{$t('security.mainMarket.confirmChange')}}</p>
        </div>
        <ul class="info-wrap">
          <li class="info-item">
            <span class="text mediumColor">{{$t('security.mainMarket.account')}}</span>
            <span class="val heavyColor">02-0071828-33</span>
          </li>
          <li class="info-item">
            <span class="text mediumColor">{{$t('security.mainMarket.tradId')}}</span>
            <span class="val heavyColor">80044</span>
          </li>
          <li class="info-item">
            <span class="text mediumColor">
              {{$t('security.mainMarket.tradStatus')}}
               <span class="tip">
                <i class="iconfont icon-detail"></i>
                <el-popover placement="right" width="220" trigger="click">
                  <div class="list">
                    <span class="icon lightColor">*</span>
                    <span class="text mediumColor">{{$t('security.mainMarket.explain1')}}</span>
                  </div>
                  <div class="list">
                    <span class="icon lightColor">#</span>
                    <span class="text mediumColor">{{$t('security.mainMarket.explain2')}}</span>
                  </div>
                  <div class="list">
                    <span class="icon lightColor">@</span>
                    <span class="text mediumColor">{{$t('security.mainMarket.explain3')}}</span>
                  </div>
                  <span slot="reference" class="txt lightColor">{{$t('security.mainMarket.detail')}}</span>
                </el-popover>
              </span>
            </span>
            <span class="val heavyColor">挂盘中</span>
          </li>
          <li class="info-item">
            <span class="text mediumColor">{{$t('security.mainMarket.buys')}}/{{$t('security.mainMarket.sells')}}</span>
            <span class="val heavyColor">買入</span>
          </li>
          <li class="info-item">
            <span class="text mediumColor">{{$t('security.mainMarket.tradType')}}</span>
            <span class="val heavyColor">限價盤</span>
          </li>
          <li class="info-item">
            <span class="text mediumColor">{{$t('security.mainMarket.market')}}</span>
            <span class="val heavyColor">港股</span>
          </li>
          <li class="info-item">
            <span class="text mediumColor">{{$t('security.mainMarket.stock')}}</span>
            <span class="val heavyColor">00665 海通國際</span>
          </li>
          <li class="info-item">
            <span class="text mediumColor">{{$t('security.mainMarket.tradPrice')}}</span>
            <span class="val heavyColor">HKD 2.600</span>
          </li>
          <li class="info-item">
            <span class="text mediumColor">{{$t('security.mainMarket.condition')}}</span>
            <span class="val heavyColor">不適用</span>
          </li>
          <li class="info-item">
            <span class="text mediumColor">{{$t('security.mainMarket.orignNum')}}</span>
            <span class="val heavyColor">3000</span>
          </li>
          <li class="info-item">
            <span class="text mediumColor">{{$t('security.mainMarket.changeNum')}}</span>
            <span class="val heavyColor">0</span>
          </li>
          <li class="info-item">
            <span class="text mediumColor">{{$t('security.mainMarket.sellTotalNum')}}</span>
            <span class="val heavyColor">3,000</span>
          </li>
          <li class="info-item">
            <span class="text mediumColor">{{$t('security.mainMarket.noComplateNum')}}</span>
            <span class="val heavyColor">0</span>
          </li>
          <li class="info-item">
            <span class="text mediumColor">{{$t('security.mainMarket.expired')}}</span>
            <span class="val heavyColor">即日</span>
          </li>
          <li class="info-item">
            <span class="text mediumColor">{{$t('security.mainMarket.aon')}}</span>
            <span class="val heavyColor">否</span>
          </li>
          <li class="info-item" v-if="isType=='editor'">
            <span class="text mediumColor">{{$t('security.mainMarket.chufaPrice')}}</span>
            <span class="val heavyColor">不通用</span>
          </li>
          <li class="info-item" v-if="isType=='editor'">
            <span class="text mediumColor">{{$t('security.mainMarket.condition')}}</span>
            <span class="val heavyColor">不通用</span>
          </li>
        </ul>
        <ul class="editor-pannel" v-if="isType=='editor'">
          <li class="editor-item">
            <span class="text mediumColor">{{$t('security.mainMarket.targePrice')}}</span>
            <span class="set">
              <el-input-number size="mini" v-model="price" @change="handleChange1" :step="0.01" :min="0"></el-input-number>
            </span>
          </li>
          <li class="editor-item">
            <span class="text mediumColor">{{$t('security.mainMarket.lastTradNum')}}</span>
            <span class="set">
              <el-input-number size="mini" v-model="num" @change="handleChange2" :step="100" :min="0"></el-input-number>
            </span>
          </li>
          <li class="editor-item">
            <span class="text mediumColor">{{$t('security.mainMarket.password')}}</span>
            <span class="set">
              <el-input size="small" type="password" v-model="password" :placeholder="$t('security.mainMarket.placeholder')"></el-input>
            </span>
          </li>
        </ul>
        <div class="btn-wrap">
          <el-button type="primary" @click="confirmEditor">{{$t('security.mainMarket.confirm')}}</el-button>
        </div>
      </div>
      <div class="second-wrap" v-else>
        <div class="layout-wrap">
          <div class="success-wrap">
            <span class="ico"><i class="iconfont icon-status_success activeFontColor"></i></span>
            <span class="text activeFontColor">{{$t('myInquiry.accoutSummary.zhishi1')}}</span>
          </div>
          <div class="success-info heavyColor">{{$t('myInquiry.accoutSummary.zhishi2')}}</div>
        </div>
      </div>
    </popover>
    <div class="content-wrap">
      <div class="market-wrap">
        <conditionChoose :conditionArr="conditionArr" @btnChoose="btnChoose" />
      </div>
      <div class="table-wrap">
        <el-table
           ref="multipleTable"
          :data="tableData"
          style="width: 100%"
          fixed
          :row-class-name="tableRowClass"  
          :header-cell-style="headeRowClass"
        >
          <!--固定列会让元素自动加上hover class-->
          <el-table-column
            fixed
            width="60"
            :label="$t('security.mainMarket.action')"
          >
            <template slot-scope="scope">
              <span class="num heavyColor">
                <span class="small-btn small-btn-blue" @click="openEditorWrap('editor',scope.row)">{{$t('security.mainMarket.amd')}}</span>
              </span>
              <span class="num heavyColor">
                <span class="small-btn small-btn-light" @click="openEditorWrap('cancel',scope.row)">{{$t('security.mainMarket.del')}}</span>
              </span>
            </template>
          </el-table-column>
          <el-table-column
            width="80"
            prop="ordNo"
            :label="$t('security.mainMarket.ordNo')"
          >
          </el-table-column>
          <el-table-column
            prop="stock"
            :label="$t('security.mainMarket.stock')"
           >
          </el-table-column>
          <el-table-column
            prop="status"
            :label="$t('security.mainMarket.status')"
          >
            <template slot-scope="scope">
              <span class="num waiting activeFontColor" v-show="scope.row.status == 'waiting'"  @click="openDetailWrap(scope.row)">等待成交</span>
              <span class="num refuse lightColor" v-show="scope.row.status == 'refuse'" @click="openDetailWrap(scope.row)">已拒绝</span>
            </template>
          </el-table-column>
          <el-table-column
            prop="sells"
            width="60"
            :label="$t('security.mainMarket.buy')+'/'+$t('security.mainMarket.sell')"
          >
            <template slot-scope="scope">
              <span class="num buy activeFontColor" v-show="scope.row.sells == 'buy'">{{$t('security.mainMarket.buys')}}</span>
              <span class="num sell" v-show="scope.row.sells == 'sell'">{{$t('security.mainMarket.sells')}}</span>
            </template>
          </el-table-column>
          <el-table-column
            prop="price"
             align="right"
            :label="$t('security.mainMarket.prc')"
          >
            <template slot-scope="scope">
              <span class="num heavyColor">HKD3.33</span>
              <span class="num clearfix">
                <i class="btn iconfont icon-add contentAllBorder lightColor"></i>
                <i class="btn iconfont icon-reduce contentAllBorder lightColor"></i>
              </span>
            </template>
          </el-table-column>
          <el-table-column
            prop="sellNum"
            align="right"
          >
            <template  slot="header">
              <span class="block">{{$t('security.mainMarket.nums')}}/</span>
              <span class="block">{{$t('security.mainMarket.sellNum')}}</span>
            </template>
            <template slot-scope="scope">
              <span class="num clearfix heavyColor">
                <span class="num ">{{scope.row.sellNum.qty}}</span> 
                <span class="num">{{scope.row.sellNum.trdQty}}</span>
              </span>
            </template>
          </el-table-column>
        </el-table>    
        <div class="explain lightColor">{{$t('security.mainMarket.explain')}}</div>
        <div class="pagination-wrap">
          <el-pagination 
            @current-change="handleCurrentChange" 
            :current-page.sync="curPage" 
            :page-size="1" 
            :hide-on-single-page=true 
            layout="prev, pager, next, jumper" 
            :total="tradArr.length">
          </el-pagination>
        </div>
        <noContent v-show="false" :content="$t('security.mainMarket.noRecords')" height="260px" width="120" />
      </div>
    </div>
  </div>
</template>

<script>
import mainTitle from '@/components/mainTitle';
import noContent from '@/components/noContent';
import conditionChoose from '@/components/conditionChoose'
import popover from "@/components/popover"
import { mapGetters } from 'vuex'
export default {
  components: {
    mainTitle,
    noContent,
    conditionChoose,
    popover
  },
  data() {
    return {
      conditionArr: [],
      curPage: 1, //当前页
      tradArr: [1],
      showDetail: false,//交易详情弹窗
      showEditor: false,//取消和更改弹窗
      isType: 'cancel',//取消或者更改 editor
      price: 2.61,
      num: 300,
      password: "",
      firstStep: true,
      tableData:[
        {
          ordNo:"00004",
          stock:"665海通国际",
          status:"waiting",
          sells:"buy",
          price:"HKD3.33",
          sellNum: {
            qty:"5000", 
            trdQty:"1000"
          },
        }
      ],
    };
  },
  computed: {
    ...mapGetters(['getLang','getBgColor'])
  },
  watch: {
    getLang: {
      handler: function (o, n) {
        this.conditionArr = [
          {
            title: this.$t('security.mainMarket.status'),
            dataArr: [
              {
                name: this.$t('security.mainMarket.all'),
                code: "all"
              },
              {
                name: this.$t('security.mainMarket.completed'),
                code: ""
              },
              {
                name: this.$t('security.mainMarket.queuing'),
                code: ""
              },
              {
                name: this.$t('security.mainMarket.canceled'),
                code: ""
              }
            ]
          }
        ]
      },
      immediate: true
    }
  },
  methods: {
     tableRowClass() {
      return 'tableRowClass'
    },  
    headeRowClass({row, column, rowIndex, columnIndex}) {
       //表头的背景颜色
      if(rowIndex==0){
          if(this.getBgColor == 'bg-anhei') {
            return 'background:rgb(51,51,51)';
          }else{
            return 'background:rgb(255,255,255)';
          }
      }
    },
    //确认修改和取消
    confirmEditor() {
      this.firstStep = false;
    },
    handleChange1(val) {
      console.log(val)
    },
    handleChange2(val) {
      console.log(val)
    },
    //跳转到帮助中心
    openHelpCenter() {
      let link = this.$router.resolve({ path: '/helpCenter' });
      window.open(link.href, '_blank');
    },
    handleCurrentChange(val) {
      console.log(val)
    },
    closeEditorWrap() {
      this.showEditor = false;
    },
    openEditorWrap(type) {
      this.isType = type;
      this.showEditor = true;
      this.firstStep = true;
    },
    openDetailWrap() {
      this.showDetail = true;
    },
    closeDetailWrap() {
      this.showDetail = false;
    },
    btnChoose(resultArr) {
      console.log(resultArr)
    },
    exportExcel() {
      this.$refs.popover.doClose();
    },
    printTrad() {
      //关闭弹窗
      this.$refs.popover.doClose();
    }
  },
  mounted() {
      this.$nextTick(() => {
        //更新表格数据的时候执行一下，不然固定列的时候会出现高度不同
        this.$refs.multipleTable.doLayout();
      })
  },
}

</script>
<style lang='scss' scoped>
.tranding-status {
  width: 100%;
  min-height: 420px;
  margin-bottom: 24px;
  .icons {
    height: 100%;
    text-align: right;
    display: inline-block;
    float: right;
    cursor: pointer;
  }
  .tradDetail-wrap,
  .editor-wrap {
    padding: 0 24px;
    .expain-wrap {
      padding: 6px 0;
      font-family: SourceHanSansCN-Medium;
      font-size: 14px;
      line-height: 18px;
      cursor: pointer;
      text-decoration: underline;
    }
    .info-wrap {
      padding-bottom: 12px;
      .info-item {
        padding: 2px 0;
        display: flex;
        flex-wrap: wrap;
        .text {
          font-family: SourceHanSansCN-Regular;
          font-size: 16px;
          flex: 0 0 160px;
        }
        .tip {
          i {
            font-size: 14px;
            color: #9b9b9b;
          }
          .txt {
            font-family: SourceHanSansCN-Medium;
            font-size: 12px;
            text-decoration: underline;
            cursor: pointer;
          }
        }
        .val {
          font-family: SourceHanSansCN-Regular;
          font-size: 16px;
          flex: 1;
          text-align: right;
          padding-left: 10px;
        }
      }
    }
  }
  .editor-wrap {
    padding: 0;
    .expain-wrap {
      padding: 0 24px 12px 24px;
      .explian-item {
        padding-top: 6px;
        font-family: SourceHanSansCN-Medium;
        font-size: 14px;
        line-height: 18px;
        cursor: pointer;
        text-decoration: underline;
      }
    }
    .info-wrap {
      padding: 0 24px 12px 24px;
    }
    .editor-pannel {
      border-top: 1px solid rgba(51, 51, 51, 0.25);
      padding: 12px 24px 0 24px;
      .editor-item {
        padding: 4px 0 6px 0;
        display: flex;
        flex-wrap: wrap;
        .text {
          font-family: SourceHanSansCN-Regular;
          font-size: 16px;
          flex: 0 0 180px;
          padding-right: 10px;
        }
        .set {
          flex: 1;
          text-align: right;
        }
      }
    }
    .btn-wrap {
      padding: 24px;
      text-align: right;
    }
  }
  .second-wrap {
    .layout-wrap {
      width: 100%;
      height: 100%;
      padding: 24px;
      .success-wrap {
        text-align: center;
        span {
          display: block;
        }
        .ico {
          padding: 24px 0;
          i {
            font-size: 58px;
          }
        }
        .text {
          font-family: SourceHanSansCN-Medium;
          font-size: 18px;
        }
      }
      .success-info {
        padding: 6px 0;
        font-family: SourceHanSansCN-Regular;
        font-size: 14px;
        line-height: 16px;
        text-align: center;
      }
    }
  }
  .content-wrap {
    padding: 0 24px;
    .market-wrap {
      padding: 12px 0;
    }
    >>> .el-scrollbar__wrap{
      overflow-x: auto;
    }
    .table-wrap {
        .num {
          display: block;
          font-family: Avenir-Book;
          font-size: 16px;
          padding: 2px 0;
          &.waiting {
            text-decoration: underline;
            cursor: pointer;
          }
          &.refuse {
            text-decoration: underline;
            cursor: pointer;
          }
          &.buy {
            text-align: center;
            font-size: 14px;
            background: rgba(0, 61, 165, 0.1);
            border-radius: 6px;
            width: 40px;
            display: inline-block;
          }
          &.sell {
            text-align: center;
            font-size: 14px;
            color: #fb6130;
            background: rgba(251, 97, 48, 0.1);
            border-radius: 6px;
            width: 40px;
            display: inline-block;
          }
          .btn {
            font-size: 12px;
            width: 18px;
            height: 18px;
            text-align: center;
            line-height: 18px;
            display: inline-block;
            cursor: pointer;
          }
        }
      }
      .explain {
        padding: 12px 0;
        font-family: SourceHanSansCN-Regular;
        font-size: 14px;
      }
      .pagination-wrap {
        text-align: right;
        .el-pagination {
          padding: 6px 5px 12px 5px;
        }
      }
    }
}
.list {
  width: 100%;
  display: flex;
  flex-wrap: wrap;
  font-family: SourceHanSansCN-Regular;
  font-size: 14px;
  padding-bottom: 4px;
  .icon {
    width: auto;
  }
  .text {
    flex: 1;
    text-align: right;
  }
}
.block{
  text-align: right;
  height: 16px;
  line-height: 16px;
}
@media screen and (max-width: 768px) {
  .tranding-status{
    margin-bottom: 12px;
  }
  .tranding-status .content-wrap {
    padding: 0 12px;
  }
}
</style>