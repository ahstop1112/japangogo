 <!--行情图表-->
<template>
  <div class="market-chart contentBg">
    <div class="top-wraps contentBorder">
        <span class="top-nav lightColor" :class="btnIndex == 0?'activeColor':''" @click="btnChoose(0)">{{$t('security.mainMarket.chart')}}</span>
        <span class="top-nav lightColor" :class="btnIndex == 1?'activeColor':''" @click="btnChoose(1)">{{$t('security.mainMarket.date')}}</span>
        <span class="search-wrap">
            <span class="right-input">
                <searchBox :curMarket="curMarket" @handleSelect="handleSelect"/>
            </span>
        </span>
    </div>    
    <div class="content-wrap">
        <div class="base-data">
            <div class="stock-title heavyColor">
                <span class="code">{{detailData[0] || "-"}}</span>
                <span class="name">{{detailData[1] || "-"}}</span>
                <span class="status" v-if="curMarket == 'hkTrading'">[V]</span>    
            </div>
            <div class="trading-status mediumColor clearfix">
                <div class="fl">
                    <span class="time lightColor">
                        {{$t('security.mainMarket.updateTime')}}: {{updateTime}}
                    </span>
                     <el-popover
                        placement="right-start"
                        trigger="hover"
                        >
                        <div class="wrap" style="width:200px;">
                            <p class="mediumColor">
                                <a style="color:#003da5" class="link activeTagColor" target="_blank" :href="$t('security.mainMarket.alink1')"> {{$t('security.mainMarket.linkName1')}}</a> {{$t('security.mainMarket.aExplain1')}}
                            </p>
                            <p  class="mediumColor" style="margin-top: 6px;">
                                <a style="color:#003da5" class="link activeTagColor" target="_blank"  :href="$t('security.mainMarket.alink2')">{{$t('security.mainMarket.linkName2')}}</a>
                            </p>
                        </div>
                        <i slot="reference" style="cursor:pointer;font-size:14px;color:#9b9b9b;" class="iconfont icon-detail"></i>   
                    </el-popover>
                </div>
                <div class="fr">
                    <span class="status" >{{tradStatus()}}</span>
                    <span class="collection" @click="addOptions" :title="isCollect?$t('security.mainMarket.removeUseStock'):$t('security.mainMarket.addUseStock')">
                        <i :class="isCollect?'active':''" class="iconfont icon-follow"></i>
                    </span>   
                </div>
            </div>
            <div class="first-wrap">
                <div class="price-wrap">
                    <div class="price" >
                        <span 
                            :class="calcUpDownColor(detailData[3])"
                            :style="{'font-size': getDevice == 'mobile'?'26px':''}"
                        >{{detailData[2]?Number(detailData[2]).toFixed(2) : "-"}}</span>
                        <i class="iconfont" :class="calcUpDownIcon(detailData[3])"></i>
                    </div>
                    <div class="wrap">
                        <span class="num" 
                             :class="calcUpDownColor(detailData[3])"> 
                            {{detailData[3]?detailData[3]>=0?'+'+Number(detailData[3]).toFixed(2):Number(detailData[3]).toFixed(2):"-"}}
                        </span>
                        <span class="rate" 
                            :class="calcUpDownColor(detailData[4])">
                            {{detailData[4]?detailData[4]>=0?'+'+(detailData[4]*100).toFixed(2):(detailData[4]*100).toFixed(2):"-"}}%
                        </span>
                    </div>
                </div>
                <ul class="base-wrap">
                    <li class="index-item" v-for="item in baseItem1">
                        <span class="name mediumColor">{{item.name}}</span>
                        <span class="val heavyColor">{{item.val}}</span>
                    </li>
                </ul>
            </div>
            <ul class="base-wrap">
                <li class="index-item" v-for="item in baseItem2">
                    <span class="name mediumColor">{{item.name}}</span>
                    <span class="val heavyColor" :class="item.val.length>7?'smallFont':''">{{item.val}}</span>
                </li>
            </ul>
            <div class="third-wrap" >
                <div class="chart-wrap" v-show="btnIndex == 0">
                    <div class="kline-type contentLightColor">
                        <span class="type-item lightColor"  :class="kTypeIndex == 0?'activeColor':''" @click="chooseklineType(0)">{{$t('security.mainMarket.minK')}}</span>
                        <span class="type-item lightColor" :class="kTypeIndex == 1?'activeColor':''" @click="chooseklineType(1)">{{$t('security.mainMarket.fiveDate')}}</span>
                        <span class="type-item lightColor" :class="kTypeIndex == 2?'activeColor':''" @click="chooseklineType(2)">{{$t('security.mainMarket.dateK')}}</span>
                        <span class="type-item lightColor" :class="kTypeIndex == 3?'activeColor':''" @click="chooseklineType(3)">{{$t('security.mainMarket.weekK')}}</span>
                        <span class="type-item lightColor" :class="kTypeIndex == 4?'activeColor':''" @click="chooseklineType(4)">{{$t('security.mainMarket.monK')}}</span>
                    </div>
                    <div class="kIndex-wrap clearfix" v-show="kTypeIndex != 0 && kTypeIndex != 1">
                        <div class="fl">
                            <span class="kIndex-item lightColor" :class="kMAIndex == 1?'activeFontColor':''" @click="choosekMA(1)">MA</span>
                            <span class="kIndex-item lightColor" :class="kMAIndex == 2?'activeFontColor':''" @click="choosekMA(2)">BOLL</span>
                        </div>
                        <div class="fl" style="margin-left: 5%">
                            <span class="kIndex-item lightColor" :class="kOtherIndex == 1?'activeFontColor':''" @click="choosekOther(1)">MACD</span>
                            <span class="kIndex-item lightColor" :class="kOtherIndex == 2?'activeFontColor':''" @click="choosekOther(2)">KDJ</span>
                            <span class="kIndex-item lightColor" :class="kOtherIndex == 3?'activeFontColor':''" @click="choosekOther(3)">RSI</span>
                        </div>
                        <div class="fr">
                            <span class="kIndex-item lightColor" :class="kfuquanIndex == 0?'activeFontColor':''" @click="choosekfuquan(0,'F')">{{$t('security.mainMarket.AdjFwd')}}</span>
                            <span class="kIndex-item lightColor" :class="kfuquanIndex == 1?'activeFontColor':''" @click="choosekfuquan(1,'N')">{{$t('security.mainMarket.Actual')}}</span>
                            <span class="kIndex-item lightColor" :class="kfuquanIndex == 2?'activeFontColor':''" @click="choosekfuquan(2,'B')">{{$t('security.mainMarket.AdjBwd')}}</span>
                        </div>
                    </div>
                    <div class="main-wrap">
                        <div class="kline-wrap">
                            <div class="main-kline" ref="mainLline"></div>
                        </div>
                    </div>    
                </div>
                <div class="data-wrap" v-show="btnIndex == 1">
                    <ul class="base-wrap paddingBottom">
                         <li class="index-item" v-for="item in detailItem1">
                            <span class="name mediumColor">{{item.name}}</span>
                            <span class="val heavyColor">{{item.val}}</span>
                        </li>
                    </ul>   
                    <ul class="base-wrap special-wrap contentTopBorder">
                        <li class="index-item" v-for="item in detailItem2">
                            <span class="name mediumColor">{{item.name}}</span>
                            <span class="val heavyColor">{{item.val}}</span>
                        </li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
  </div>
</template>

<script>
import echarts from"echarts"
import {initMOption,initFiveOption,initKOption} from "./marketChart/kline.js";
import {MarketData} from "./marketChart/mixins.js"
import { mapGetters } from 'vuex'
import { getFiveTs, getTimeSharing, getHistoryQuot, saveOptionStock, getIdcMacd, getIdcKdj, getIdcBoll, getIdcRsi } from "@/api/security"
import searchBox from '@/components/searchBox'
import { _getIsTradingDay, _calTradyTime } from '@/utils/security'
import { setQuterColor } from "@/utils/mixinsQuterColor"
//获取技术指标的数据函数
//import { _getIdcMacd, _getIdcKdj,  _getIdcBoll, _getIdcRsi} from './marketChart/stockTechnicalData';
export default {
  data () {
    return {
        btnIndex: 0,
        isCollect: false,
        kTypeIndex:0,
        kfuquanIndex:1,  //复权索引
        kMAIndex:1,  //ma boll指标索引
        kOtherIndex:1,//macd kdj rsi技术指标索引
        kChart:null,
        timer:null,
        baseTime: null,//查询基础信息的定时器
        tradTime: null,//查询分时数据的定时器
        minDataArr: [],//保存分时数据
        minPreClose:"",//昨收价格
        curMarket:"",//当前市场
        sotckCode:'',//选中的股票代码
        fuquan: 'N',
        baseLegend: ['K线周期图表', 'Volumn','MA5', 'MA10','MA20','MA30','MA60'],
        techLegend: [],
        MADataArr:[],//保存ma的数据
    }
  },
  components: {
    searchBox
  },
  mixins:[MarketData, setQuterColor],
  computed: {
    ...mapGetters(['getLang','getFixedSide', 'getBgColor','getDevice']),
  },
  watch: {
    getFixedSide() {
      let transitionWrap = document.getElementById("appRight");
      transitionWrap.addEventListener('transitionend',  this.resizeChart)
    },
    //监听用户改变涨跌幅颜色
    getQuterType() {
       this.echartReload();
    },
    //切换主题颜色
    getBgColor() {
        this.echartReload();
    }
  },
  methods: {  
    getMAdata(data) {
        let arr5 = [];//MA5
        let arr10 = [];//MA10
        let arr20 = [];//MA20
        let arr30 = [];//MA30
        let arr60 = [];//MA60
        for(let i=0;i<data.length;i++) {
            arr5.push(Number(data[i][7]).toFixed(2));
            arr10.push(Number(data[i][8]).toFixed(2));
            arr20.push(Number(data[i][9]).toFixed(2));
            arr30.push(Number(data[i][10]).toFixed(2));
            arr60.push(Number(data[i][11]).toFixed(2));
        }
        this.MADataArr = [arr5,arr10,arr20,arr30,arr60];
    },  
    choosekMA(type) {
        this.kMAIndex = type;
        this.changeMATech();
    }, 
    changeMATech() {
        let index =  this.kMAIndex;
        let type = '';
        this.kTypeIndex == 2?type = 'D':this.kTypeIndex == 3?type = 'W':type = 'M';
        let that = this;
        let totalSeries = ['MA5', 'MA10','MA20','MA30','MA60','Upper','Avg','Lower'];
        //加载ma数据
        if(this.kMAIndex == 1) {
            this.baseLegend = ['K线周期图表', 'Volumn','MA5', 'MA10','MA20','MA30','MA60'];
            let series =[];
            let totalArr = ['MA5', 'MA10','MA20','MA30','MA60'];
            let dataObj = {
                'MA5': this.MADataArr[0],
                'MA10':this.MADataArr[1],
                'MA20':this.MADataArr[2],
                'MA30':this.MADataArr[3],
                'MA60':this.MADataArr[4],
            }
            let seriesArr = that.getSeriesArr(totalSeries, totalArr , dataObj);
            let options = {
                legend: { 
                    data: this.baseLegend.concat( this.techLegend )
                },
                series: seriesArr
            }
            this.kChart.setOption( options );   
        }
        //加载BOLL线
        else if(this.kMAIndex == 2){
            this.baseLegend = ['K线周期图表', 'Volumn', 'Upper','Avg','Lower'];
            let type = '';
            this.kTypeIndex == 2?type = 'D':this.kTypeIndex == 3?type = 'W':type = 'M';
            let that = this;
            let params = {
                "params": {
                    "adjust": this.fuquan,
                    "assetId": this.sotckCode,
                    "count": 250,  //条数
                    "type": type
                },
                "tester":"ibester",
            }
             getIdcBoll(   
                params
            ).then(res => {
                let datas = res.result.data;
                let upperArr = datas.map(n => n[1]);
                let avgArr = datas.map(n => n[2]);
                let lowerArr = datas.map(n => n[3]);
                let curArr = ['Upper','Avg','Lower'];
                let dataObj = {
                    'Upper': upperArr,
                    'Avg': avgArr,
                    'Lower': lowerArr
                }
                let seriesArr = that.getSeriesArr(totalSeries, curArr, dataObj);
                let options = {
                    legend: { 
                        data: this.baseLegend.concat( this.techLegend )
                    },
                    series: seriesArr
                }
                that.kChart.setOption( options );  
            })
        }
    },
    calcUpDownIcon(val) {
        if(val > 0 ) {
            return this.getQuterType == 1?'icon-jiantoushangsheng greenUpColor':'icon-jiantoushangsheng redUpColor'
        }
        else if(val < 0) {
            return this.getQuterType == 1?'icon-jiantouxiajiang greenDownColor':'icon-jiantouxiajiang redDownColor'
        }
        else{
            return 'grayColor'
        }
    },
    echartReload() {
        //分时数据
        if(this.kTypeIndex == 0) {
            this._getTimeSharingData();
        }else if(this.kTypeIndex == 1) {
            //五日线
            this._getFiveKLineData();
        }else{
            this._getHistoryQuot();
        }
    }, 
    //股票交易狀態  
    tradStatus() {
        let stockStatus = {
            0:  this.$t('security.mainMarket.Normal'),
            1:  this.$t('security.mainMarket.LimitUp'),
            2:  this.$t('security.mainMarket.LimitDown'),
            3:  this.$t('security.mainMarket.Suspend'),
            4:  this.$t('security.mainMarket.Delisted'),
            5:  this.$t('security.mainMarket.IPOPeriod'),
            6:  this.$t('security.mainMarket.Unopened'),
            7:  this.$t('security.mainMarket.Trading'),
            8:  this.$t('security.mainMarket.Closed'),
            9:  this.$t('security.mainMarket.AuctionSession'),
            10: this.$t('security.mainMarket.LunchBreak'),
            11: this.$t('security.mainMarket.MarkerClosed'),
        }
        let status = '--';
        for(let key in stockStatus) {
            if(key == this.detailData[25]) {
                status = stockStatus[key];
                break;
            }
        }
        return status;
    },
    handleSelect(item) {
        //查询结果保存到vuex
        this.$store.commit('changeCurStock',item);
    },
    choosekOther(index) {
        this.kOtherIndex = index;
        this.changeIndexTech();
    },
    getSeriesArr(totalArr, curArr, dataObj) {
        let seriesArr = [];
        for(let i=0;i<totalArr.length;i++) {
            if(curArr.indexOf(totalArr[i]) != -1) {
                let index = curArr.indexOf(totalArr[i]);
                seriesArr.push(
                    {
                        name: totalArr[i],
                        data: dataObj[curArr[index]]
                    }
                )
            }else{
                seriesArr.push(
                    {
                        name: totalArr[i],
                        data:[] 
                    }
                )
            }    
        }
        return seriesArr;
    },
    changeIndexTech() {
        let index =  this.kOtherIndex;
        let type = '';
        this.kTypeIndex == 2?type = 'D':this.kTypeIndex == 3?type = 'W':type = 'M';
        let that = this;
        let params = {
            "params": {
                "adjust": this.fuquan,
                "assetId": this.sotckCode,
                "count": 250,  //条数
                "type": type
            },
            "tester":"ibester",
        }
        let totalArr = ['MACD','DIF','DEA','K','D','J','Rsi1','Rsi2', 'Rsi3'];
        let baseLegend = this.baseLegend;
        //MACD线
        if(index == 1) {
            getIdcMacd(
                params
            ).then(res => {
                let datas = res.result.data;
                let arr1 = datas.map(n => n[3]);
                let arr2 = datas.map(n => n[1]);
                let arr3 = datas.map(n => n[2]);
                this.techLegend = ['MACD','DIF','DEA'];
                let dataObj = {
                    'MACD': arr1,
                    'DIF': arr2,
                    'DEA': arr3
                }
                let seriesArr = that.getSeriesArr(totalArr, this.techLegend , dataObj);
                let options = {
                    legend: { 
                        data: this.baseLegend.concat( this.techLegend )
                    },
                    series: seriesArr
                }
                that.kChart.setOption( options );   
            }).catch(error => {
                //console.log(error)
            })
        }
        else if(index == 2) {
            getIdcKdj(   
                params
            ).then(res => {
                let datas = res.result.data;
                let kArr = datas.map(n => n[1]);
                let dArr = datas.map(n => n[2]);
                let jArr = datas.map(n => n[3]);
                this.techLegend = ['K','D','J'];
                let dataObj = {
                    'K': kArr,
                    'D': dArr,
                    'J': jArr
                }
                let seriesArr = that.getSeriesArr(totalArr, this.techLegend, dataObj);
                let options = {
                    legend: { 
                        data: baseLegend.concat(this.techLegend)
                    },
                    series: seriesArr
                }
                that.kChart.setOption( options );  
            })
        }
        else if(index == 3){
            getIdcRsi(   
                params
            ).then(res => {
                let datas = res.result.data;
                let rsi1Arr = datas.map(n => n[1]);
                let rsi2Arr = datas.map(n => n[2]);
                let rsi3Arr = datas.map(n => n[3]);
                this.techLegend = ['Rsi1','Rsi2','Rsi3'];
                let dataObj = {
                    'Rsi1': rsi1Arr,
                    'Rsi2': rsi2Arr,
                    'Rsi3': rsi3Arr
                }
                let seriesArr = that.getSeriesArr(totalArr, this.techLegend, dataObj);
                let options = {
                    legend: { 
                        data: baseLegend.concat(this.techLegend)
                    },
                    series: seriesArr
                }
                that.kChart.setOption( options );  
            })
        }
    },
    choosekfuquan(index, type) {
      this.kfuquanIndex = index;
      this.fuquan = type;  
      this._getHistoryQuot();
    },
    chooseklineType(index) {
        this.kTypeIndex = index;
        let type = "";
        if(index == 0){
            type = "mKline";
        }else if(index == 1) {
             type = "kFiveline";
        }else{
           type = "kline";
        }
        this.changeLineChart(type)
    },  
    btnChoose(index) {
        this.btnIndex = index;
        if(index == 0) {
            this.resizeChart();  
        }
    },
    addOptions() {
        this.isCollect = !this.isCollect;
        let operatingType ='';
        let that = this;
        this.isCollect ? operatingType ='addData': operatingType ='delData';
        let params = {
             "params": {
                "sessionId":"b2d59448cfdc43928e614d313b9b7255453387",
                "operatingType": operatingType,
                "assetIds": [this.sotckCode],
             }
        }
        saveOptionStock(
            params
        ).then(res => {
            let curMarket = this.$route.name;  
            let types = ""
            curMarket == 'hkTrading'? types = 'HK':curMarket == 'A-shareTrading'?types = 'SH,SZ':types = 'US';
            let assetIds = (JSON.parse(res.result.assetIds))[0].data;
            let curAssetIds = [];
            //过滤掉没有用的assetIds
            for(let i=0;i<assetIds.length;i++) {
                let assetType = assetIds[i].substring(assetIds[i].length-2,assetIds[i].length);
                if(types.indexOf(assetType) != -1) {
                    curAssetIds.push( assetIds[i]);
                }
            }
            //派发更新自选股的指令
            this.$store.commit('changeUpdateSelfStock', curAssetIds);
        }).catch(error => {
            //console.log(error)
        })
    },
    //五日K线数据
    _getFiveKLineData() {
        let that = this;
        if(!this.sotckCode || this.sotckCode == '') {
            return;
        }
        let params = {
            "params": {
                "assetId": this.sotckCode
            },
            "tester":"ibester"
        }
        getFiveTs(
            params
        ).then(res => {
           let datas = res.result.data;
           let dataArr = [];
           for(let i=0;i<datas.length;i++) {
               datas[i][0] = that._forMatTime(datas[i][0]);
               dataArr.push(datas[i]);
           }
           this.kChart.setOption(initFiveOption(dataArr,res.result.preClose, this.getQuterType, this.getBgColor)); //数据和上次收盘价格
        }).catch(error => {
            //console.log(error)
        })
    },
    //分时数据
    _getTimeSharingData() {
        let that = this;
        if(!this.sotckCode || this.sotckCode == "" ) {
            return;
        }
        let params = {
            "params": {
                "assetId": this.sotckCode
            },
            "tester":"ibester"
        }
        getTimeSharing(
            params
        ).then(res => {
            let datas = res.result.data;
            let dataArr = [];
            for(let i=0;i<datas.length;i++) {
                datas[i][0] = that._forMatTime(datas[i][0], true);
                dataArr.push(datas[i]);
            }
            this.minDataArr = dataArr;
            this.minPreClose = res.result.preClose;
            let types = ''
            this.curMarket == 'hkTrading'? types = 'hk':this.curMarket == 'A-shareTrading'?types = 'hs':types = 'us';
            this.kChart.setOption(initMOption(types, dataArr, this.minPreClose, this.getQuterType, this.getBgColor));
        }).catch(error => {
            //console.log(error)
        })
    },
    initChart() {
        if(this.kChart) {
           this.kChart.dispose();
        }
        this.kChart = echarts.init(this.$refs.mainLline); 
    },
    changeLineChart(type) {
        this.initChart();
        //分时图
        if(type == 'mKline') {  
            this._getTimeSharingData();
        }
        //5日
        else if(type == 'kFiveline') {
            this._getFiveKLineData();
        }
        else{
            this._getHistoryQuot();
        }
    },
    _forMatTime(time,isHs) {
        if(!time) {
            return;    
        }
        var time = new Date(time);
        var m = time.getMonth() + 1;  //月
        m < 10?m = '0' + m:m;
        var d = time.getDate();  //日
        d < 10?d = '0' + d:d;
        var h = time.getHours();  //时
        h < 10?h = '0' + h:h;
        var mm = time.getMinutes();  //分
        mm < 10?mm = '0' + mm:mm;
        if(isHs) {
            return h.toString()+mm.toString();
        }
        return m+"-"+d;
    },
    resizeChart() {
        if(this.timer) {
          clearTimeout(this.timer)
        }
        this.timer = setTimeout( () => {
           this.kChart.resize();
        }, 150)
    },
    //查询日K 周k 月K
    _getHistoryQuot() {
        if(!this.sotckCode || this.sotckCode == '') {
            return;
        }
        let type = '';
        let that = this;
        this.kTypeIndex == 2?type = 'D':this.kTypeIndex == 3?type = 'W':type = 'M';
        let params = {
            "params": {
                "adjust": this.fuquan,
                "assetId": this.sotckCode,
                "count": 250,  //条数
                "type": type
            },
            "tester":"ibester",
        }
        getHistoryQuot(
            params
        ).then(res => {
            let datas = res.result.data;
            let dataArr = [];
            for(let i=0;i<datas.length;i++) {
                datas[i][0] = that.forMatDate(datas[i][0], true);
                dataArr.push(datas[i]);
            }
           this.kChart.setOption(initKOption(dataArr, this.getQuterType, this.getBgColor)); 
           this.getMAdata(dataArr);
           //更新当前股票技术指标
           this.changeIndexTech();
           this.changeMATech();
        }).catch(error => {
            //console.log(error)
        })
    },
    //是否打开定时器
    openIntervalQuery() {
        //每分钟监听一次,看是否需要调用查询接口,只有图形在日K并且在交易时间段的时候才去定时请求相关数据
        this.tradTime = setInterval(() => {
            //分时按钮页面
            if(this.kTypeIndex == 0){
                _calTradyTime(this.curMarket, this._getTimeSharingData);
            }
            //5日线按钮页面
            else if(this.kTypeIndex == 1){
                _calTradyTime(this.curMarket, this._getFiveKLineData);
            }
        }, 60000)
        //监听基础信息的数据
        this.baseTime = setInterval(() => {
            _calTradyTime(this.curMarket, this._getChartData);
        }, 5000)
    }
  },
  mounted(){
     this.$nextTick( () => {
         this.curMarket = this.$route.name;  
         window.addEventListener('resize', this.resizeChart);
         this.initChart();
         //this._getChartData();
         //是交易日才去调用定时器
         let isTradeDay = _getIsTradingDay(this.curMarket);
         isTradeDay.then( res=>{
             if(res) {
                this.openIntervalQuery();
             }
         })
     })
  },
  beforeDestroy() {
    window.removeEventListener('resize', this.resizeChart);   
    try{
        let transitionWrap = document.getElementById("appRight");
        transitionWrap.removeEventListener('transitionend',  this.resizeChart) ;
    }catch(err) {
        //console.log(err)
    }
    if (this.kChart) {
      this.kChart.dispose();
      this.kChart = null;
    }
    clearInterval(this.tradTime);
    clearInterval(this.baseTime);
  },
}

</script>
<style lang='scss' scoped>
    .market-chart{
        width: 100%;
        min-height: 600px;
        margin-bottom: 24px;
        .top-wraps{
            width: 100%;
            height: 40px;
            padding: 0 24px;
            cursor: pointer;
            display: flex;
            align-items: center;
            .top-nav{
                font-family: SourceHanSansCN-Regular;
                font-size: 18px;
                line-height: 40px;
                height: 40px;
                margin-right: 24px;
            }
            .search-wrap{
                flex: 1;
                text-align: right;
                .right-input{
                    width: 130px;
                    display: inline-block;
                }
            }   
        }
        .content-wrap{
            padding: 0 24px;
            .base-data{
                .stock-title{
                    padding-top: 12px;
                    font-size: 20px;
                    .code{
                        font-family: Avenir-Medium;
                        margin-right: 12px;
                    }
                    .name{
                        font-family: SourceHanSansCN-Medium;
                    }
                }
                .trading-status{
                    padding-top: 8px;    
                    font-size: 14px;
                    .status{
                        margin-right: 12px;
                    }
                    .collection {
                        padding: 0 6px;
                        i{
                            cursor: pointer;
                            color: #CACACA;
                            background-color: #fff;
                            border-radius: 3px;
                            &.active{
                                color:#ED8B00;
                            }
                        }
                    }   
                }    
                .base-wrap{
                    flex: 1;
                    display: flex;
                    flex-wrap: wrap;
                    .index-item{
                        width: 33.33%;
                        display: flex;
                        padding: 6px;
                        .name{
                            line-height: 16px;
                            flex: 0 0 70px;
                            font-family: SourceHanSansCN-Normal;
                            font-size: 1rem;
                        }   
                        .val{
                            flex:1;
                            line-height: 16px;
                            text-align: right;
                            font-family: Avenir-Book;
                            font-size: 1rem;
                            &.smallFont{
                                font-size: 14px;
                            }
                        }
                    }
                }
                .third-wrap{
                    .chart-wrap{
                        width: 100%;
                        margin-top: 6px;
                        .kline-type{
                            width: 100%;
                            display: flex;
                            height: 36px;
                            line-height: 36px;
                        }
                        .kIndex-wrap{
                            width: 100%;
                            text-align: center;
                            .kIndex-item{
                                display: inline-block;
                                font-size: 12px;
                                cursor: pointer;
                                padding: 0 2px;
                            }
                            .textCenter{
                                display: inline-block;
                            }
                        }
                        .type-item{
                            flex:1;
                            font-family: SourceHanSansCN-Regular;
                            font-size: 18px;
                            text-align: center;
                            cursor: pointer;
                        }
                    }    
                    .main-wrap{
                        width: 100%;
                        display: flex;
                        .kline-wrap{
                            flex:1;
                            .main-kline{
                                width: 100%;
                                height: 340px;
                            }
                        }
                    }
                }
                .first-wrap{
                    width: 100%;
                    display: flex;
                    align-items: flex-end;
                    .price-wrap{
                        flex: 0 0 33.33%;
                        min-width: 116px;
                        .price{
                            font-family: Avenir-Medium;
                            font-size: 36px;
                            padding-bottom: 6px;
                            display: flex;
                            align-items: center;
                            i{
                                font-size: 30px;
                            }
                        }
                        .wrap{
                            display: flex;
                            font-size: 14px;
                            .num{
                                padding-right: 10px;
                            }
                            .rate{
                                flex: 1;
                            }
                        }
                    }
                    .index-item{
                        width: 50%;
                        display: flex;
                        padding: 6px;
                        .name{
                            flex: 0 0 40px;
                        }
                    }
                }
                .chart-wrap{
                    width: 100%;
                }
                .special-wrap{
                    padding-top: 10px;
                }
            }  
        }
    }
    .paddingBottom{
        padding-bottom: 10px;
    }
    @media screen and (max-width: 768px){
      .market-chart{
          margin-bottom: 12px;
      }
     .market-chart .content-wrap{
        padding: 0 ;
     }   
     .market-chart .content-wrap .base-data .base-wrap .index-item{
         width: 50%;
     }
     .market-chart .top-wraps{
         padding: 0 12px;
     }
     .market-chart .top-wraps .top-nav{
         margin-right: 12px;
     }
   }
</style>