 <!--自选股-->
<template>
  <div class="selfSelect-stock contentBg">
    <main-title :title="$t('security.mainMarket.watchlists')" @click.native="toggleSelStockPannel">
      <span class="icons" v-if="getDevice == 'mobile'">
        <i class="el-submenu__icon-arrow lightColor el-icon-arrow-right" :class="isShowStockPannel?'openArrow':''"></i>
      </span>
    </main-title>  
    <div class="table-wrap" ref="tableWrap">
      <el-scrollbar style="height:100%;">
        <div class="padding-wrap" ref="paddingWrap">
          <el-table 
            ref="table"
            :row-class-name="tableRowClass"  
            :header-cell-style="headeRowClass"
            v-show="tableData.length" 
            :data="tableData" 
            fixed 
            :key="keyIndex"
            @row-click='changeStockInfo'
          style="width: 100%">
            <el-table-column :label="$t('security.mainMarket.stock')" prop="stockName">
              <template slot-scope="scope">
                <div class="name heavyColor">{{scope.row.stockName}}</div>
                <div class="code lightColor">{{scope.row.stockCode}}</div>
              </template>
            </el-table-column>
            <el-table-column prop="price" align="right" :key="1" sortable :sort-method="sortVal1" :label="$t('security.mainMarket.prc')">
              <template slot-scope="scope">
                <span :class="calcUpDownColor(scope.row.upDownRate)">{{scope.row.price}}</span>
              </template>
            </el-table-column>
            <el-table-column prop="upDownVal" align="right" sortable width="100" :key="keyIndex"  :sort-method="isRate?sortVal3:sortVal2" :label="isRate?$t('security.mainMarket.prcentChg'):$t('security.mainMarket.chg')">
              <template slot-scope="scope">
                <span  v-if="isRate" @click.stop="toggleRateVal(false)" :style="{'font-size': scope.row.upDownRate.length>8?'12px':''}" class="upDownVal" :class="calcUpDownColor(scope.row.upDownRate,'bg')">{{scope.row.upDownRate}}%</span>
                <span v-else @click.stop="toggleRateVal(true)" :style="{'font-size': scope.row.upDownVal.length>9?'12px':''}" class="upDownVal" :class="calcUpDownColor(scope.row.upDownVal,'bg')">{{scope.row.upDownVal}}</span>
              </template>
            </el-table-column>
          </el-table>
          <noContent height="500px" :content="$t('security.mainMarket.noRecords')" v-show="!tableData.length" />
        </div>
      </el-scrollbar>
    </div>
  </div>
</template>

<script>
import mainTitle from '@/components/mainTitle';
import noContent from '@/components/noContent';
import { mapGetters } from 'vuex'
import { getOptionStock, getQuot } from "@/api/security"
import { _getIsTradingDay, _calTradyTime } from '@/utils/security'
import { setQuterColor } from "@/utils/mixinsQuterColor"
export default {
  components: {
    mainTitle,
    noContent
  },
  computed: {
    ...mapGetters(['getDevice','getUpdateSelfStock', 'getBgColor']),
  },
  mixins:[ setQuterColor ],
  data() {
    return {
      isRate: true,//是否显示涨跌幅，还是涨跌额
      isShowStockPannel: false,
      tableData: [],
      curMarket:'',
      tradTime:null,
      isFirst:false,
      keyIndex:0,
      totalData:[],//用来临时保存自选股的数据，解决闪烁的bug
    };
  },
  watch: {
    getDevice: {
      handler: function (to, from) {
        this.$nextTick( () => {
          if(to != 'mobile') {
            this.$refs.tableWrap.style.height = '985px'
          }else{
            this.calcHeight();
          }
        })
      },
      immediate: true
    },
    getUpdateSelfStock(val) {
      //更新数据
      this._getQuot(val);
    }
  },  
  methods: {
    tableRowClass() {
      return 'tableRowClass'
    },  
    headeRowClass({row, column, rowIndex, columnIndex}) {
       //表头的背景颜色
      if(rowIndex==0){
          if(this.getBgColor == 'bg-anhei') {
            return 'background:rgb(51,51,51)';
          }else{
            return 'background:rgb(255,255,255)';
          }
      }
    },
    changeStockInfo(row) {
      //滚动条回到顶部
      document.documentElement.scrollTop = 0;
      document.body.scrollTop = 0;
      let value = row.stockCode.substring(0,row.stockCode.length-3)+" "+row.stockName;
      let obj = {
        assetId: row.stockCode,
        secType: row.secType,
        value: value
      }
      this.$store.commit('changeCurStock',obj);
    },
    toggleSelStockPannel() {
      //该按钮只在移动端有用
      if(this.getDevice != 'mobile') {
        return;
      }
      this.isShowStockPannel = !this.isShowStockPannel;
      this.calcHeight();
    },
    toggleRateVal(isRate) {
      this.isRate = isRate;
      //解决切换不同列闪烁的BUG
      this.keyIndex = Math.random();
      //切换的时候清除排序
      this.$refs.table.clearSort();
    },
    sortVal1(a, b) {
      return a.price - b.price;
    },
    sortVal2(a, b) {
      return a.upDownVal - b.upDownVal;
    },
    sortVal3(a, b) {
      return a.upDownRate - b.upDownRate;
    },
    calcHeight() {
      let element = this.$refs.tableWrap;
      let targetHeight = 0;
      element.style.transition = "none"; 
      if(this.isShowStockPannel) {
          targetHeight = this.$refs.paddingWrap.offsetHeight;   
       }else{
          targetHeight = 0;
       }
       element.style.height = targetHeight+"px";
       element.style.transition = "height "+ "0.3s";
    },
    _getOptionStock() {
      let that = this;
      let params = {
        "params": {
          "sessionId":"b2d59448cfdc43928e614d313b9b7255453387"
        }
      }
      getOptionStock(
          params
      ).then(res => {
          let curMarket = this.curMarket;
          let types = ""
          curMarket == 'hkTrading'? types = 'HK':curMarket == 'A-shareTrading'?types = 'SH,SZ':types = 'US';
          let assetIds = (JSON.parse(res.result.assetIds))[0].data;
          let curAssetIds = [];
          //过滤掉没有用的assetIds
          for(let i=0;i<assetIds.length;i++) {
            let assetType = assetIds[i].substring(assetIds[i].length-2,assetIds[i].length);
            if(types.indexOf(assetType) != -1) {
              curAssetIds.push( assetIds[i]);
            }
          }
          //派发更新自选股的指令
          this.$store.commit('changeUpdateSelfStock', curAssetIds);
          this.isFirst = true;
      }).catch(error => {
          //console.log(error)
      }) 
    },
    //根据数据的条数归类，每20条放在一个新数组中
    _calRequestTime(dataArr) {
      if(!dataArr.length){
        return;
      } 
      //当数据条数大于20，每隔20条发一次请求
      let len = Math.ceil(dataArr.length/20 );
      let orgArr = [];
      for(let i=0;i<len;i++) {
        let calArr = [].concat(dataArr);
        let objArr = calArr.splice(i*20, 20);
        orgArr.push(objArr);
      }
      return orgArr;
    },
    _getQuot(curAssetIds) {
        if(!curAssetIds.length) {
           //初始化加载第一项数据
          if(this.isFirst) {
            this.$store.commit('changeCurStock',{});
          }
          this.isFirst = false;
          return;
        }
        //市场为美股或者A股的时候，当自选股的数量大于20条的时候就每20条发一次请求
        if(this.curMarket == 'US') {
          this._requestData(0,[curAssetIds]);
        }else{
          let orgArr = this._calRequestTime(curAssetIds);
          this._requestData(0,orgArr);
        }
    },
    _requestData(num,curAssetIds) {
      if(num >curAssetIds.length-1 ) {
        //只有数据全部请求完成之后，才赋值给表格渲染，这样可以解决页面闪烁的BUG
        this.tableData = JSON.parse(JSON.stringify(this.totalData));
        this.totalData = [];
        return;
      } 
      let that = this;
      let curParams =  {
          "params": {
              "fields": "0|1|2|9|10|118",
              "assetIds": curAssetIds[num],
          },
          "tester": "ibester"
      }
      getQuot(
          curParams
      ).then(res => {
          that.$nextTick( () => {
            let stockArr = res.result.data;
            let tableArr = [];
            for(let i=0;i<stockArr.length;i++) {
              let obj =  {
                stockName: stockArr[i][1] || "-",
                stockCode: stockArr[i][0] || "-",
                price: Number(stockArr[i][2]).toFixed(2) || "-",
                upDownVal: Number(stockArr[i][3]).toFixed(2) || "-",
                upDownRate:  (Number(stockArr[i][4])*100).toFixed(2) || "-",
                secType: stockArr[i][5] || "-",
              }
              tableArr.push(obj);
            }
           
            if(num == 0) {
              let fistItem ={
                  assetId: stockArr[0][0],
                  secType: stockArr[0][5]
              }
              //初始化加载第一项数据
              if(this.isFirst) {
                this.isFirst = false;
                that.$store.commit('changeCurStock',fistItem);
              }
              that.totalData = tableArr;
            }else{
              that.totalData = that.totalData.concat(tableArr);
            }
            //递归调用
            that._requestData(num+1, curAssetIds);
          })
      }).catch(error => {
          //console.log(error)
      })
    },
    openIntervalQuery() {
       //每分钟监听一次,看是否需要调用查询接口,只有图形在日K并且在交易时间段的时候才去定时请求相关数据
      this.tradTime = setInterval(() => {
          //分时按钮页面
        _calTradyTime(this.curMarket, this._getQuot, this.getUpdateSelfStock);
      }, 5000)
    }
  },
  beforeDestroy() {
    clearInterval(this.tradTime);
  },
  created() {
    this._getOptionStock();
  },
  mounted() {
    //是交易日才去调用定时器
    this.curMarket = this.$route.name;  
    this.$nextTick( () => {
      let isTradeDay = _getIsTradingDay(this.curMarket);
      isTradeDay.then( res=>{
          if(res) {
            this.openIntervalQuery();
          }
      })
    })  
  },
}

</script>
<style lang='scss' scoped>
.selfSelect-stock {
  width: 100%;
  .icons{
    position: relative;
    float: right;
    width: 40px;
    height: 100%;
    display: inline-block;
    text-align: right;
    .el-submenu__icon-arrow{
      right: 0;
      font-size: 16px;
      font-weight: bold;
      &.openArrow{
        transform: rotate(90deg);
      }
    }
  }
  .table-wrap {
    width: 100%;
    height: 985px; //985
    .padding-wrap {
      width: 100%;
      height: 100%;
      padding: 0 24px 12px 24px;
    }
    >>> .el-table__row {
      cursor: pointer;
    }
    .el-table__row .name {
      font-family: SFUIText-Medium;
      font-size: 16px;
      line-height: 22px;
    }
    .el-table__row .code {
      font-family: SFUIText-Medium;
      font-size: 12px;
    }
    .el-table__row .upDownVal {
      width: 80px;
      height: 28px;
      line-height: 28px;
      color: #fff;
      display: inline-block;
      font-size: 14px;
      text-align: center;
      overflow: hidden;
      vertical-align: middle;
      border-radius: 2px;
      user-select: none;
    }
  }
}
@media screen and (max-width: 768px) {
  .selfSelect-stock .table-wrap .padding-wrap {
    padding: 0 12px 12px 12px;
  }
  .selfSelect-stock .table-wrap{
    height: 0;
  }
}
</style>