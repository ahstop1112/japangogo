<template>
  <div class="prospectus">
    <div class="top">
      <div class="top-box">
        <img src="@/assets/img/1@3x.png" alt="" />
        <span>08512 凯富善集团控股有限公司 - 申请认购的香港招股股份数目</span>
      </div>
    </div>
    <span class="title">08512 凯富善集团控股有限公司 - 申请认购的香港招股股份数目</span>
    <div class="box">
      <div class="content">
        <table width="100%">
          <thead>
            <tr>
              <th width="20%">{{$t('security.ipoSubscriptions.prospectusForm.number')}}</th>
              <th>{{$t('security.ipoSubscriptions.prospectusForm.amount')}}</th>
            </tr>
          </thead>
          <tbody>
            <tr v-for="(item,index) in list" :key="index">
              <td>{{item.amount}}</td>
              <td>{{item.money}}</td>
            </tr>
          </tbody>
        </table>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  data() {
    return {
      list: [
        { amount: '1,000', money: '$54,522.65' },
        { amount: '1,000', money: '$54,522.65' },
      ]
    };
  },
  created() {

  },
  methods: {

  }
};
</script>

<style lang="scss" scoped>
.prospectus {
  .top {
    display: flex;
    align-items: center;
    margin-bottom: 24px;
    padding: 16px 0;
    height: 100%;
    background: #003da5;
    box-shadow: 6px 0 6px 0 rgba(162, 140, 133, 0.3);
    @media screen and(max-width: 1080px) {
      padding: 12px 24px;
    }
    @media screen and(max-width:768px) {
      padding: 12px 12px;
    }
    .top-box {
      display: flex;
      align-items: center;
      margin: 0 auto;
      width: 1000px;
      img {
        margin-right: 25px;
        width: 95px;
        height: 32px;
      }
      span {
        padding-left: 25px;
        font-family: SourceHanSansCN-Medium;
        font-size: 18px;
        color: #ffffff;
        line-height: 25px;
        border-left: 1px #fff solid;
      }
    }
  }
  .title {
    display: block;
    font-family: SourceHanSansCN-Medium;
    font-size: 18px;
    color: #003da5;
    line-height: 18px;
    text-align: center;
    @media screen and(max-width:768px) {
      padding: 0 12px;
    }
  }
  .box {
    margin: 53px auto 80px;
    width: 1000px;
    @media screen and(max-width: 1080px) {
      padding: 0 24px;
      width: 100%;
    }
    @media screen and(max-width:768px) {
      padding: 0 12px;
    }
    .content {
      width: 100%;
      font-family: SourceHanSansCN-Regular;
      font-size: 1rem;
      color: rgba(51, 51, 51, 0.75);
      table,
      th,
      td {
        border: 1px solid #979797;
      }
      table {
        border-collapse: collapse;
      }
      td {
        text-align: center;
        font-family: Avenir-Book;
      }
      th:nth-child(2) {
        text-align: left;
        padding-left: 50px;
      }
      tr td:last-child {
        text-align: left;
        padding-left: 50px;
      }
    }
  }
}
</style>