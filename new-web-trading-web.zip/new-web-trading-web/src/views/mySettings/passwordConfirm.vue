<!--密码确认(我的设定)-->
<template>
  <div class="passwordConfirm contentBg">
    <popover :title="$t('mySettings.passwordConfirm.passwordConfirm')" @close="closePopover" :showPopover = "showPopover">
      <div class="second-wrap"> 
          <div class="success-wrap">
            <span class="icons"><i class="iconfont icon-status_success activeFontColor"></i></span>
            <span class="text activeFontColor">{{$t('mySettings.passwordConfirm.changeSuccess')}}</span>
        </div>
      </div>
    </popover>  
    <div class="baseInfo-wrap contentBorder">
      <p class="info-item">
        <span class="txt mediumColor">{{$t('mySettings.passwordConfirm.state')}}</span>
        <span class="val heavyColor">{{$t('mySettings.passwordConfirm.started')}}</span>
      </p>
      <p class="info-item">
        <span class="txt mediumColor">{{$t('mySettings.passwordConfirm.editor')}}</span>
        <span class="val heavyColor">{{$t('mySettings.passwordConfirm.adapt')}}</span>
      </p>
    </div>
    <div class="setting-wrap" :class="isOpen?'':'contentBorder'">
      <div class="title heavyColor">
        <span class="txt mediumColor">{{$t('mySettings.passwordConfirm.loginName')}}</span>
        <span class="val heavyColor"> 0071828 (Client 0071828)</span>
      </div>
      <div class="progress">
        <el-radio v-model="isOpen" :label="true">{{$t('mySettings.passwordConfirm.startedInfo')}}</el-radio>
      </div>
      <div class="progress">
        <el-radio v-model="isOpen" :label="false" >{{$t('mySettings.passwordConfirm.cancelInfo')}}</el-radio>
        <p v-show="!isOpen" class="tip lightColor">{{$t('mySettings.passwordConfirm.cancelTip')}}</p>
      </div>
    </div>
    <div v-show="!isOpen" class="explain-wrap contentBorder">
      <div class="explain-title heavyColor">{{$t('mySettings.passwordConfirm.cancelTitle')}}</div>
      <div class="explain-item mediumColor">{{$t('mySettings.passwordConfirm.cancelExpian1')}}</div>
      <div class="explain-item mediumColor">{{$t('mySettings.passwordConfirm.cancelExpian2')}}</div>
    </div>
    <div v-show="!isOpen" class="password-wrap">
      <div class="tip lightColor">{{$t('mySettings.passwordConfirm.tip')}}</div>
      <div class="password-input">
        <span class="txt mediumColor">{{$t('mySettings.passwordConfirm.password')}}</span>
        <span class="val">
           <el-input v-model="password" :placeholder="$t('mySettings.passwordConfirm.inputPassword')"></el-input>
        </span>
      </div>
    </div>
    <div class="btn-wrap">
        <el-button type="primary" @click="openPopover">{{$t('mySettings.passwordConfirm.confirm')}}</el-button>
    </div>
  </div>
</template>

<script>
import popover from "@/components/popover"
export default {
  data () {
    return {
      isOpen: false,
      password: "",
      showPopover: false,
    };
  },
  components: {
    popover
  },
  methods: {
    openPopover() {
      this.showPopover = true;
    },
       //隐藏弹窗
    closePopover() {
      this.showPopover = false;
    }
  },
  mounted(){},

}

</script>
<style lang='scss' scoped>
  .passwordConfirm{
    padding: 24px;
    .baseInfo-wrap{
      width: 100%;
      padding-bottom: 12px;
      .info-item{
        padding-bottom: 12px;
        .txt{
          font-family: SourceHanSansCN-Regular;
          font-size: 16px;
          line-height: 20px;
          padding-right: 12px;
        }
        .val{
          font-family: SourceHanSansCN-Regular;
          font-size: 16px;
          line-height: 16px;
        }
      }
    }
    .setting-wrap{
      padding: 24px 0;
      .title{
        font-family: SourceHanSansCN-Medium;
        font-size: 18px;
        .txt{
          padding-right: 12px;
        }
      }
      .progress{
        padding: 12px 0 6px 0;
        .tip{
          font-family: SourceHanSansCN-Regular;
          font-size: 14px;
          line-height: 16px;
          padding-top: 6px;
          text-indent: 24px;
        }
      }
    }
    .explain-wrap{
      padding: 24px 0;
      .explain-title{
        font-family: SourceHanSansCN-Medium;
        font-size: 18px;
        padding-bottom: 12px;
      }
      .explain-item{
        padding-top: 12px;
        font-family: SourceHanSansCN-Regular;
        font-size: 16px;
        line-height: 20px;
      }
    }
    .password-wrap{
       padding: 24px 0;
       .tip{
          font-family: SourceHanSansCN-Regular;
          font-size: 14px;
          line-height: 16px;
       }
       .password-input{
         display: flex;
         align-items: center;
         padding-top: 24px;
         .txt{
           flex: 0 0 80px;
         }
         .val{
           max-width: 240px;
         }
       }
    }
    .btn-wrap{
      padding: 24px 0 12px 0;
      text-align: right;
    }
    .second-wrap{
      width: 100%;
      height: 100%;    
      padding: 24px;
      .success-wrap{
        text-align: center;
        span{
            display: block;
        }
        .icons{
            padding: 24px 0;
            i{
                font-size: 58px;
            }
        }
        .text{
            font-family: SourceHanSansCN-Medium;
            font-size: 18px;
        }
      }
    }
  }
   @media screen and (max-width: 768px){
     .passwordConfirm{
       padding: 12px;
     }
   }
</style>