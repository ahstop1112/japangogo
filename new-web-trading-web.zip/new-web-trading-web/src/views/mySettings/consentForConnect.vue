<!--中华通北向交易同意书(我的设定)-->
<template>
  <div class="consentForConnect contentBg">
    <div class="top">
      <div class="top-box">
        <img src="@/assets/img/1@3x.png" alt="" />
        <span>{{$t('mySettings.consentForConnnect.title')}}</span>
      </div>
    </div>
    <div class="box" v-if="infoShow == 0">
      <h4 class="title activeFontColor">{{$t('mySettings.consentForConnnect.title1')}}</h4>
      <div class="content mediumColor">
        <p>
          {{$t('mySettings.consentForConnnect.content1')}}
        </p>
        <p class="txt activeFontColor">
          {{$t('mySettings.consentForConnnect.content2')}}
        </p>
        <p>
          {{$t('mySettings.consentForConnnect.content3')}}
        </p>
        <p style="text-indent:2em;">
          {{$t('mySettings.consentForConnnect.content4')}}
        </p>
        <p style="text-indent:2em;">
          {{$t('mySettings.consentForConnnect.content5')}}
        </p>
        <p>
          {{$t('mySettings.consentForConnnect.content6')}}
        </p>
        <p style="text-indent:2em;">
          {{$t('mySettings.consentForConnnect.content7')}}
        </p>
        <p style="text-indent:2em;">
          {{$t('mySettings.consentForConnnect.content8')}}
        </p>
        <p style="text-indent:2em;">
          {{$t('mySettings.consentForConnnect.content9')}}
        </p>
        <p style="text-indent:2em;">
          {{$t('mySettings.consentForConnnect.content10')}}
        </p>
        <p>
          {{$t('mySettings.consentForConnnect.content11')}}
        </p>
        <p class="txt activeFontColor">
          {{$t('mySettings.consentForConnnect.content12')}}
        </p>
        <p>
          {{$t('mySettings.consentForConnnect.content13')}}
        </p>
        <p class="txt activeFontColor">
          {{$t('mySettings.consentForConnnect.content14')}}
        </p>
        <p> {{$t('mySettings.consentForConnnect.content15')}}</p>
        <el-form ref="form" :model="form">
          <el-form-item prop="radio1">
            <el-radio-group v-model="form.radio1">
              <el-radio :label="1"> {{$t('mySettings.consentForConnnect.content16')}}</el-radio>
              <el-radio :label="2"> {{$t('mySettings.consentForConnnect.content17')}}</el-radio>
            </el-radio-group>
          </el-form-item>
          <el-form-item prop="radio2">
            <el-radio-group v-model="form.radio2" :disabled="form.radio1==1">
              <el-radio :label="3" style="padding-left:25px"> {{$t('mySettings.consentForConnnect.content18')}}</el-radio>
              <el-radio :label="4" style="padding-left:25px"> {{$t('mySettings.consentForConnnect.content19')}}
                <template>
                  <el-form-item prop="input">
                    <el-input v-model="form.input" :disabled="form.radio1==1||form.radio2==3" :placeholder="$t('mySettings.consentForConnnect.ipt')"></el-input>
                  </el-form-item>
                </template>
              </el-radio>
            </el-radio-group>
          </el-form-item>
        </el-form>
        <p>
          {{$t('mySettings.consentForConnnect.content20')}}
        </p>
      </div>
      <div class="btn">
        <el-button plain @click="close" class="cancel">{{$t('mySettings.consentForConnnect.cancel')}}</el-button>
        <el-button :disabled="form.radio1!==1&&form.radio1!==2||form.radio1==2&&form.radio2!==3&&form.radio2!==4||form.radio2==4&&btnState == false" type="primary" @click="confirm('form')">{{$t('mySettings.consentForConnnect.confirm')}}</el-button>
      </div>
      <div class="ck">
        <el-checkbox v-model="checked"> {{$t('mySettings.consentForConnnect.prompt')}}</el-checkbox>
      </div>
    </div>
    <!-- 成功信息 -->
    <div class="success" v-else-if="infoShow == 1">
      <div class="imgs">
        <i class="iconfont icon-status_success activeFontColor"></i>
      </div>
      <div class="info activeFontColor">
        <p>{{$t('mySettings.consentForConnnect.content21')}}</p>
      </div>
      <el-button class="btn" type="primary" @click="isClose">{{$t('mySettings.consentForConnnect.content23')}}</el-button>
    </div>
    <!-- 失败信息 -->
    <div class="success" v-else>
      <div class="imgs img"><img src="@/assets/img/icon_pass@3x.png" alt="" /></div>
      <div class="info failure">
        <p>{{$t('mySettings.consentForConnnect.content22')}}</p>
      </div>
      <el-button class="btn" @click="isClose" type="primary">{{$t('mySettings.consentForConnnect.cancel')}}</el-button>
    </div>
    <!-- 底部组件 -->
    <bottombar :isShow="false" :class="[infoShow == 1 ? 'bottom' : '']"></bottombar>
  </div>
</template>

<script>
import bottombar from '@/layout/bottombar'
import { localGet, localSet } from '@/utils/mylocal.js'
import { loadThemColor } from '@/utils/loadTheme'
export default {
  components: {
    bottombar
  },
  computed: {
    btnState() {
      return (
        this.form.input !== ''
      )
    }
  },
  created() {
    let configColor = localStorage.getItem('bgColor') || 'bg-Blue';
    loadThemColor(configColor);
  },
  data() {
    return {
      checked: false, // 登陸提醒
      infoShow: 0, // 当前显示的页面
      form: {
        radio1: '',
        radio2: '',
        input: '',
      },
    };
  },
  methods: {
    confirm(form) {
      this.$refs.form.validate(val => {
        if (val) {
          // 跳转成功页面
          this.infoShow = 1
          // 保存不提示选中状态
          localSet('checked1', this.checked)
        }
      })

    },
    // 关闭当前页
    close() {
      window.close()
      // 保存不提示选中状态
      localSet('checked1', this.checked)
    },
    // 关闭当前页
    isClose() {
      window.close()
    }
  },
  mounted() { },

}

</script>
<style lang='scss' scoped>
.consentForConnect {
  width: 100%;
  min-height: 100%;
  .top {
    display: flex;
    align-items: center;
    margin-bottom: 40px;
    height: 64px;
    background: #003da5;
    box-shadow: 6px 0 6px 0 rgba(162, 140, 133, 0.3);
    @media screen and(max-width: 1080px) {
      padding: 0 24px;
    }
    @media screen and(max-width: 768px) {
      padding: 0 12px;
    }
    .top-box {
      display: flex;
      align-items: center;
      margin: 0 auto;
      width: 1000px;
      img {
        margin-right: 25px;
        width: 95px;
        height: 32px;
      }
      span {
        padding-left: 25px;
        font-family: SourceHanSansCN-Medium;
        font-size: 18px;
        color: #ffffff;
        line-height: 25px;
        border-left: 1px #fff solid;
      }
    }
  }

  .box {
    position: relative;
    margin: 0px auto;
    width: 1000px;
    @media screen and (max-width: 1080px) {
      padding: 0 24px;
      width: 100%;
    }
    @media screen and(max-width: 768px) {
      padding: 0 12px;
      width: 100%;
    }
    .title {
      font-family: SourceHanSansCN-Medium;
      font-size: 20px;
      line-height: 25px;
      text-align: center;
    }
    .content {
      padding: 20px 0;
      width: 100%;
      height: 100%;
      font-family: SourceHanSansCN-Regular;
      font-size: 1rem;
      .el-form-item {
        margin-bottom: 0px;
      }
      p {
        padding: 10px 0;
      }
      .txt {
        font-family: SourceHanSansCN-Medium;
      }
      .el-radio {
        margin-right: 12px;
        line-height: 30px;
        >>> .el-radio__label {
          text-overflow: ellipsis;
          white-space: normal;
          line-height: 20px;
          display: inline-block;
          vertical-align: text-top;
          margin-top: -3px;
          margin-bottom: 15px;
        }
      }
    }
    .btn {
      text-align: center;
      .el-button {
        margin: 50px 20px 20px 0px;
        width: 120px;
        height: 40px;
        font-family: SourceHanSansCN-Bold;
        font-size: 1rem;
        color: #ffffff;
        line-height: 14px;
        &:nth-child(2) {
          margin-right: 0px;
        }
      }
      // .btnBg {
      //   background: #003da5;
      // }
      .cancel {
        color: #003da5;
      }
    }

    .ck {
      margin-bottom: 80px;
      text-align: center;
      >>> .el-checkbox__label {
        font-family: SourceHanSansCN-Regular;
        font-size: 1rem;
        color: #333333;
        line-height: 16px;
      }
    }
  }

  .success {
    margin: 125px auto 0;
    width: 826px;
    min-height: calc(100vh - 265px);
    @media screen and (max-width: 850px) {
      padding: 0 24px;
      width: 100%;
    }
    @media screen and (max-width: 375px) {
      padding: 0 12px;
      width: 100%;
    }
    .imgs {
      float: left;
      margin-right: 24px;
      width: 58px;
      height: 58px;
      i{
        font-size: 58px;
      }
      img {
        width: 58px;
        height: 58px;
      }
    }
    .img {
      width: 53px;
      height: 60px;
    }

    .info {
      margin-left: 80px;
      font-family: SourceHanSansCN-Medium;
      font-size: 24px;
      line-height: 30px;
      font-weight: 550;
    }
    .failure {
      color: #e6400b;
    }
    .btn {
      display: block;
      margin: 112px auto;
      width: 120px;
      height: 40px;
      font-family: SourceHanSansCN-Bold;
      font-size: 1rem;
      color: #ffffff;
      text-align: center;
      line-height: 16px;
    }
  }
  .bottom {
    position: fixed;
    left: 0;
    bottom: 0;
  }
}
</style>