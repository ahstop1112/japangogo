<!-- 个人问卷 -->
<template>
  <div class="personalQuestionnaire-wrap contentBg mediumColor">
    <div class="top">
      <div class="top-box">
        <img src="@/assets/img/1@3x.png" alt="" />
        <span>{{$t('mySettings.investProfile.personalQuestionnaire.questionnaire')}}</span>
      </div>
    </div>
    <div class="box" v-if="!isShowSuccess">
      <h4 class="title activeFontColor">{{$t('mySettings.investProfile.personalQuestionnaire.title')}}</h4>
      <div class="content">
        <!-- 第一部分 -->
        <el-form :model="oneForm" :show-message="false" :label-position="labelPosition" :rules="rules" ref="oneForm" label-width="100px" class="ruleForm">
          <p class="main heavyColor">{{$t('mySettings.investProfile.personalQuestionnaire.name')}}Client 0233221 {{$t('mySettings.investProfile.personalQuestionnaire.account')}}02-0233221-33</p>
          <p>{{$t('mySettings.investProfile.personalQuestionnaire.content')}}</p>
          <p><span>{{$t('mySettings.investProfile.personalQuestionnaire.important')}}</span>{{$t('mySettings.investProfile.personalQuestionnaire.info')}}</p>
          <p class="main heavyColor">{{$t('mySettings.investProfile.personalQuestionnaire.oneContent')}}</p>
          <p>{{$t('mySettings.investProfile.personalQuestionnaire.oneInfo')}}</p>
          <el-form-item :label="$t('mySettings.investProfile.personalQuestionnaire.one')" prop="radio">
            <el-radio-group v-model="oneForm.radio">
              <el-radio :label="item.id" :key="item.id" v-for="item in list[0].options">{{item.name}}</el-radio>
            </el-radio-group>
          </el-form-item>
          <el-form-item :label="$t('mySettings.investProfile.personalQuestionnaire.two')" prop="radio1">
            <el-radio-group v-model="oneForm.radio1">
              <el-radio :label="item.id" :key="item.id" v-for="item in list[1].options">{{item.name}}</el-radio>
            </el-radio-group>
          </el-form-item>
          <el-form-item :label="$t('mySettings.investProfile.personalQuestionnaire.three')" prop="radio2">
            <el-radio-group v-model="oneForm.radio2">
              <el-radio :label="item.id" :key="index" v-for="(item,index) in list[2].options" @change="getId(item.id)">{{item.name}}</el-radio>
            </el-radio-group>
          </el-form-item>
          <el-form-item :label="$t('mySettings.investProfile.personalQuestionnaire.four')" prop="radio3" :rules="oneForm.radio2!==1?rules.radio3:[{ required: false}]">
            <el-radio-group v-model="oneForm.radio3">
              <el-radio :label="item.id" :key="index" v-for="(item,index) in list[3].options" :disabled="oneForm.radio2==1||index>=2&&oneForm.radio2==2">{{item.name}}</el-radio>
            </el-radio-group>
          </el-form-item>
          <el-form-item :label="$t('mySettings.investProfile.personalQuestionnaire.five')" prop="radio4">
            <el-radio-group v-model="oneForm.radio4">
              <el-radio :label="item.id" :key="item.id" v-for="item in list[4].options">{{item.name}}</el-radio>
            </el-radio-group>
          </el-form-item>
          <el-form-item :label="$t('mySettings.investProfile.personalQuestionnaire.six')" prop="radio5">
            <el-radio-group v-model="oneForm.radio5">
              <el-radio :label="item.id" :key="item.id" v-for="item in list[5].options">{{item.name}}</el-radio>
            </el-radio-group>
          </el-form-item>
          <el-form-item :label="$t('mySettings.investProfile.personalQuestionnaire.seven')" prop="radio6">
            <el-radio-group v-model="oneForm.radio6">
              <el-radio :label="item.id" :key="item.id" v-for="item in list[6].options">{{item.name}}</el-radio>
            </el-radio-group>
          </el-form-item>
          <el-form-item :label="$t('mySettings.investProfile.personalQuestionnaire.eight')" prop="radio7">
            <el-radio-group v-model="oneForm.radio7">
              <el-radio :label="item.id" :key="item.id" v-for="item in list[7].options">{{item.name}}</el-radio>
            </el-radio-group>
          </el-form-item>
          <el-form-item :label="$t('mySettings.investProfile.personalQuestionnaire.nine')" prop="radio8">
            <el-radio-group v-model="oneForm.radio8">
              <el-radio :label="item.id" :key="item.id" v-for="item in list[8].options">{{item.name}}</el-radio>
            </el-radio-group>
          </el-form-item>
          <el-form-item :label="$t('mySettings.investProfile.personalQuestionnaire.ten')" prop="radio9">
            <el-radio-group v-model="oneForm.radio9">
              <el-radio :label="item.id" :key="item.id" v-for="item in list[9].options">{{item.name}}</el-radio>
            </el-radio-group>
          </el-form-item>
          <el-form-item :label="$t('mySettings.investProfile.personalQuestionnaire.eleven')" prop="radio10">
            <el-radio-group v-model="oneForm.radio10">
              <el-radio :label="item.id" :key="item.id" v-for="item in list[10].options">{{item.name}}</el-radio>
            </el-radio-group>
          </el-form-item>
          <el-form-item prop="amount" :label="$t('mySettings.investProfile.personalQuestionnaire.twelve')">
            {{$t('mySettings.investProfile.personalQuestionnaire.twelve1')}}<el-input onkeyup="this.value=this.value.replace(/[^\d]/g,'').replace(/^0{1,}/g,'')" onafterpaste="this.value=this.value.replace(/[^\d]/g,'').replace(/^0{1,}/g,'')" style="width:200px" v-model="oneForm.amount"></el-input>
          </el-form-item>
          <el-form-item :label="$t('mySettings.investProfile.personalQuestionnaire.thirteen')" prop="radio11">
            <table width="100%">
              <thead>
                <tr>
                  <th></th>
                  <th>{{$t('mySettings.investProfile.personalQuestionnaire.thirteen2')}}</th>
                  <th>{{$t('mySettings.investProfile.personalQuestionnaire.thirteen3')}}</th>
                  <th>{{$t('mySettings.investProfile.personalQuestionnaire.thirteen4')}}</th>
                  <th>{{$t('mySettings.investProfile.personalQuestionnaire.thirteen5')}}</th>
                </tr>
              </thead>
              <tbody>
                <tr v-for="(item) in experience" :key="item.id">
                  <td class="contentAllBorder" style="text-align: left;padding-left:15px">{{item.information}}</td>
                  <td class="contentAllBorder">{{item.no}}</td>
                  <td class="contentAllBorder">{{item.limited}}</td>
                  <td class="contentAllBorder">{{item.good}}</td>
                  <td class="contentAllBorder">{{item.rich}}</td>
                </tr>
                <tr v-for="(item,index) in product" :key="index">
                  <td class="contentAllBorder" style="text-align: left; padding-left:15px">{{item.information}}
                  </td>
                  <td class="contentAllBorder">
                    <el-radio v-model="oneForm.radio11[index]" label="12">{{item.no}}</el-radio>
                  </td>
                  <td class="contentAllBorder">
                    <el-radio v-model="oneForm.radio11[index]" label="13">{{item.limited}}</el-radio>
                  </td>
                  <td class="contentAllBorder">
                    <el-radio v-model="oneForm.radio11[index]" label="14">{{item.good}}</el-radio>
                  </td>
                  <td class="contentAllBorder">
                    <el-radio v-model="oneForm.radio11[index]" label="15">{{item.rich}}</el-radio>
                  </td>
                </tr>
              </tbody>
            </table>
          </el-form-item>
        </el-form>
        <!-- 第二部分 -->
        <el-form :model="twoForm" :show-message='false' :label-position="labelPosition" :rules="rules2" ref="twoForm" label-width="100px" class="ruleForm">
          <p class="main heavyColor">{{$t('mySettings.investProfile.personalQuestionnaire.note')}}</p>
          <p>{{$t('mySettings.investProfile.personalQuestionnaire.note1')}}</p>
          <p>{{$t('mySettings.investProfile.personalQuestionnaire.note2')}}</p>
          <p class="main heavyColor">{{$t('mySettings.investProfile.personalQuestionnaire.twoContent')}}</p>
          <p>{{$t('mySettings.investProfile.personalQuestionnaire.twoInfo')}}</p>
          <el-form-item :label="$t('mySettings.investProfile.personalQuestionnaire.one1')" prop="radio12" :rules="twoForm.radio13==''&&twoForm.checked==false&&twoForm.checkList.length==0&&twoForm.radio18==''&&twoForm.radio19==''?rules2.radio12:[{ required: true}]">
            <el-radio-group v-model="twoForm.radio12">
              <el-radio :label="item.id" :key="item.id" v-for="item in list[11].options">{{item.name}}</el-radio>
            </el-radio-group>
          </el-form-item>
          <el-form-item :label="$t('mySettings.investProfile.personalQuestionnaire.two1')" prop="checkList" :rules="twoForm.radio12==''&&twoForm.radio13==''&&twoForm.radio18==''&&twoForm.radio19==''||twoForm.checked==true?rules2.checkList:[{ required: true}]">
            <el-checkbox-group v-model="twoForm.checkList" @change="handleCheckedCitiesChange">
              <el-checkbox :label="1">{{$t('mySettings.investProfile.personalQuestionnaire.two2')}}</el-checkbox>
              <el-checkbox :label="2">{{$t('mySettings.investProfile.personalQuestionnaire.two3')}}</el-checkbox>
              <el-checkbox :label="3">{{$t('mySettings.investProfile.personalQuestionnaire.two4')}}</el-checkbox>
              <el-checkbox :label="4" style="display: inline-block;">{{$t('mySettings.investProfile.personalQuestionnaire.two5')}}
              </el-checkbox>
              <el-form-item prop="input" :rules="twoForm.checkList.includes(4)?[{ required: true}]:rules2.input" style="display: inline-block;margin-bottom: 0;">
                <el-input v-model="twoForm.input" style="width:300px" :disabled="!(twoForm.checkList.includes(4))||twoForm.checkList.includes(1)&&twoForm.checkList.includes(2)&&twoForm.checkList.includes(3)&&!(twoForm.checkList.includes(1)&&twoForm.checkList.includes(2)&&twoForm.checkList.includes(3)&&twoForm.checkList.includes(4))">
                </el-input>
              </el-form-item>
            </el-checkbox-group>
            <el-checkbox v-model="twoForm.checked" @change="handleCheckAllChange">{{$t('mySettings.investProfile.personalQuestionnaire.two6')}}</el-checkbox>
          </el-form-item>
          <el-form-item :label="$t('mySettings.investProfile.personalQuestionnaire.three1')" prop="radio13" :rules="twoForm.radio12==''&&twoForm.checkList.length==0&&twoForm.radio18==''&&twoForm.radio19==''||twoForm.checked==true?rules2.radio13:[{ required: true}]">
            <el-radio-group v-model="twoForm.radio13" :disabled="twoForm.checked==true">
              <el-radio :label="1">{{$t('mySettings.investProfile.personalQuestionnaire.three2')}}
              </el-radio>
              <div class="indicate">
                <div class="left">
                  <el-form-item :label="$t('mySettings.investProfile.personalQuestionnaire.three3')" prop="nameFinancialInstitution" :rules="twoForm.radio13==''||twoForm.radio13==2?rules2.nameFinancialInstitution:[{ required: true}]">
                    <el-input :disabled="twoForm.radio13!==1||twoForm.checked==true" v-model="twoForm.nameFinancialInstitution"></el-input>
                  </el-form-item>
                </div>
                <div class="right">
                  <el-form-item :label="$t('mySettings.investProfile.personalQuestionnaire.three4')" prop="transactionAmount" :rules="twoForm.radio13==''||twoForm.radio13==2?rules2.transactionAmount:[{ required: true}]">
                    <el-input :disabled="twoForm.radio13!==1||twoForm.checked==true" v-model="twoForm.transactionAmount" onkeyup="this.value=this.value.replace(/[^\d]/g,'').replace(/^0{1,}/g,'')" onafterpaste="this.value=this.value.replace(/[^\d]/g,'').replace(/^0{1,}/g,'')"></el-input>
                  </el-form-item>
                </div>
              </div>
              <el-radio :label="2">{{$t('mySettings.investProfile.personalQuestionnaire.three5')}}</el-radio>
            </el-radio-group>
          </el-form-item>
          <el-form-item :label="$t('mySettings.investProfile.personalQuestionnaire.four1')" prop="radio18" :rules="twoForm.radio12==''&&twoForm.checkList.length==0&&twoForm.radio13==''&&twoForm.radio19==''?rules2.radio18:[{ required: true}]">
            <el-radio-group v-model="twoForm.radio18" @change="empty">
              <el-radio :label="1">{{$t('mySettings.investProfile.personalQuestionnaire.four2')}}
              </el-radio>
              <div class="indicate">
                <div class="left">
                  <el-form-item :label="$t('mySettings.investProfile.personalQuestionnaire.four3')" prop="date1" :rules="twoForm.radio18==''||twoForm.radio18==2||twoForm.radio18==3?rules2.date1:[{ required: true}]">
                    <el-date-picker :disabled="twoForm.radio18!==1" v-model="twoForm.date1" type="date" :editable="false">
                    </el-date-picker>
                    <i class="iconfont icon-date heavyColor"></i>
                    <a class="activeTagColor" :href="$t('mySettings.investProfile.jiaoyuLink')" target="_blank">{{$t('mySettings.investProfile.personalQuestionnaire.four5')}}</a>
                  </el-form-item>
                </div>
                <div class="right">
                  <el-form :model="form" :show-message="twoForm.radio18==1?true:false" :label-position="labelPosition" :rules="rules2" ref="form" label-width="100px" class="ruleForm">
                    <el-form-item :label="$t('mySettings.investProfile.personalQuestionnaire.four4')" prop="code">
                      <el-input :maxlength="8" :minlength="8" :disabled="twoForm.radio18!==1" v-model="form.code" onkeyup="this.value=this.value.replace(/[^\d]/g,'')" onafterpaste="this.value=this.value.replace(/[^\d]/g,'')"></el-input>
                    </el-form-item>
                  </el-form>
                </div>
              </div>
              <el-radio :label="2">{{$t('mySettings.investProfile.personalQuestionnaire.four6')}}
              </el-radio>
              <div class="indicate">
                <div class="left">
                  <el-form-item :label="$t('mySettings.investProfile.personalQuestionnaire.four7')" prop="institutionName" :rules="twoForm.radio18==''||twoForm.radio18==1||twoForm.radio18==3?rules2.institutionName:[{ required: true}]">
                    <el-input :disabled="twoForm.radio18!==2" v-model="twoForm.institutionName"></el-input>
                  </el-form-item>
                  <el-form-item :label="$t('mySettings.investProfile.personalQuestionnaire.four3')" prop="date2" :editable="false" :rules="twoForm.radio18==''||twoForm.radio18==1||twoForm.radio18==3?rules2.date2:[{ required: true}]">
                    <el-date-picker :disabled="twoForm.radio18!==2" v-model="twoForm.date2" type="date">
                    </el-date-picker> <span>（例：1970-01-01）</span>
                    <i class="iconfont icon-date heavyColor"></i>
                  </el-form-item>
                </div>
                <div class="right">
                  <el-form-item :label="$t('mySettings.investProfile.personalQuestionnaire.four8')" prop="courseName" :rules="twoForm.radio18==''||twoForm.radio18==1||twoForm.radio18==3?rules2.courseName:[{ required: true}]">
                    <el-input :disabled="twoForm.radio18!==2" v-model="twoForm.courseName"></el-input>
                  </el-form-item>
                </div>
              </div>
              <el-radio :label="3">{{$t('mySettings.investProfile.personalQuestionnaire.three5')}}</el-radio>
            </el-radio-group>
          </el-form-item>
          <el-form-item :label="$t('mySettings.investProfile.personalQuestionnaire.five1')" prop="radio19" :rules="twoForm.radio12==''&&twoForm.checked==false&&twoForm.checkList.length==0&&twoForm.radio13==''&&twoForm.radio18==''?rules2.radio19:[{ required: true}]">
            <el-radio-group v-model="twoForm.radio19">
              <el-radio :label="1">{{$t('mySettings.investProfile.personalQuestionnaire.three2')}}
              </el-radio>
              <div class="indicate">
                <div class="left">
                  <el-form-item :label="$t('mySettings.investProfile.personalQuestionnaire.five2')" prop="companyName" :rules="twoForm.radio19==''||twoForm.radio19==2?rules2.companyName:[{ required: true}]">
                    <el-input :disabled="twoForm.radio19!==1" v-model="twoForm.companyName"></el-input>
                  </el-form-item>
                  <el-form-item :label="$t('mySettings.investProfile.personalQuestionnaire.five4')" prop="work" :rules="twoForm.radio19==''||twoForm.radio19==2?rules2.work:[{ required: true}]">
                    <el-input :disabled="twoForm.radio19!==1" v-model="twoForm.work"></el-input>
                  </el-form-item>
                </div>
                <div class="right">
                  <el-form-item :label="$t('mySettings.investProfile.personalQuestionnaire.five3')" prop="departmentName" :rules="twoForm.radio19==''||twoForm.radio19==2?rules2.departmentName:[{ required: true}]">
                    <el-input :disabled="twoForm.radio19!==1" :style="{'width': '@media screen and (max-width: 768px)'?'280px':'300px'}" v-model="twoForm.departmentName"></el-input>
                  </el-form-item>
                  <el-form-item :label="$t('mySettings.investProfile.personalQuestionnaire.five5')" prop="dateRange">
                    <timeSelector :disabled="twoForm.radio19!==1" :isShow="false" :clearable="false" :range-separator="$t('myInquiry.myReport.to')" :start-placeholder="$t('myInquiry.myReport.start')" :end-placeholder="$t('myInquiry.myReport.end')" @change="time"></timeSelector>
                  </el-form-item>
                </div>
              </div>
              <el-radio :label="2">{{$t('mySettings.investProfile.personalQuestionnaire.three5')}}</el-radio>
            </el-radio-group>
          </el-form-item>
          <p class="txt">{{$t('mySettings.investProfile.personalQuestionnaire.prompt')}}</p>
        </el-form>
        <div class="btn">
          <el-button type="primary" @click="submitForm('oneForm','form','twoForm')">{{$t('mySettings.investProfile.personalQuestionnaire.submit')}}</el-button>
        </div>
      </div>
    </div>

    <!-- 提交成功 -->
    <div class="success " v-if="isShowSuccess">
      <div class="content">
        <div class="imgs">
          <i class="iconfont icon-status_success activeFontColor"></i>
        </div>
        <div class="info activeFontColor">
          <p>{{$t('mySettings.investProfile.prompt')}}</p>
        </div>
      </div>
      <el-button class="btn" type="primary" @click="close">{{$t('mySettings.consentForConnnect.content23')}}</el-button>
    </div>
    <!-- 底部组件 -->
    <bottombar :isShow="false" :class="[isShowSuccess == true ? 'bottom' : '']"></bottombar>
  </div>
</template>

<script>
import bottombar from '@/layout/bottombar'
import timeSelector from '@/components/timeSelector'
import { loadThemColor } from '@/utils/loadTheme'
export default {
  components: {
    bottombar,
    timeSelector
  },
  data() {
    return {
      isShowSuccess: false,
      labelPosition: 'top',
      form: {
        code: '', // 第四题验证码
      },
      // 表单1
      oneForm: {
        radio: '',
        radio1: '',
        radio2: '',
        radio3: '',
        radio4: '',
        radio5: '',
        radio6: '',
        radio7: '',
        radio8: '',
        radio9: '',
        radio10: '',
        amount: '',
        radio11: ['12', '12', '12', '12', '12', '12', '12', '12', '12', '12', '12', '12', '12'],
      },
      // 表单2
      twoForm: {
        radio12: '', // 第一题
        checkList: [], // 第二题
        radio13: '', // 第三题
        radio18: '', // 第四题
        radio19: '', // 第五题
        checked: false, // 第二题第5项
        input: '', // 第二题第4项输入框
        nameFinancialInstitution: '', // 第三题金融机构名称
        transactionAmount: '', // 第三题总交易金额
        date1: '', // 第四题日期
        institutionName: '', // 第四题机构名称
        courseName: '', // 第四题课程名称
        date2: '', // 第四题日期
        companyName: '', //  第五题公司名称
        departmentName: '', // 第五题部门名称
        work: '', // 第五题工作性质
        dateRange: '', // 第五题任职期限
      },
      // 校验
      rules: {
        radio: [
          { required: true }
        ],
        radio1: [
          { required: true }
        ],
        radio2: [
          { required: true }
        ],
        radio3: [
          { required: true }
        ],
        radio4: [
          { required: true }
        ],
        radio5: [
          { required: true }
        ],
        radio6: [
          { required: true }
        ],
        radio7: [
          { required: true }
        ],
        radio8: [
          { required: true }
        ],
        radio9: [
          { required: true }
        ],
        radio10: [
          { required: true }
        ],
        radio11: [
          { type: 'array', required: true }
        ],
        amount: [
          { required: true }
        ],
      },
      rules2: {
        // 表单2第1题
        radio12: [
          { required: false },
        ],
        // 表单2第2题
        checkList: [
          { type: 'array', required: false },
        ],
        input: [
          { required: false },
        ],
        // 表单2第3题
        radio13: [
          { required: false },
        ],
        // 表单2第3题金融机构名称
        nameFinancialInstitution: [
          { required: false },
        ],
        // 表单2第3题总交易金额
        transactionAmount: [
          { required: false },
        ],
        // 表单2第4题
        radio18: [
          { required: false },
        ],
        // 表单2第4题日期
        date1: [
          { required: false },
        ],
        // 表单2第4题验证码
        code: [
          { required: false, message: this.$t('mySettings.investProfile.digital'), trigger: "blur" },
          { min: 8, max: 8, message: this.$t('mySettings.investProfile.digital'), trigger: 'blur' }
        ],
        // 表单2第4题机构名称
        institutionName: [
          { required: false },
        ],
        // 表单2第4题课程名称
        courseName: [
          { required: false },
        ],
        // 表单2第4题日期2
        date2: [
          { required: false },
        ],
        // 表单2第5题
        radio19: [
          { required: false },
        ],
        // 表单2第5题公司名称
        companyName: [
          { required: false },
        ],
        // 表单2第5题部门名称
        departmentName: [
          { required: false },
        ],
        // 表单2第5题工作性质
        work: [
          { required: false },
        ],
        // 表单2第5题任职年限
        dateRange: [
          { required: false },
        ],
      },
      list: [
        {
          id: 1,
          options: [
            {
              id: 1,
              name: this.$t('mySettings.investProfile.personalQuestionnaire.oneA')
            },
            {
              id: 2,
              name: this.$t('mySettings.investProfile.personalQuestionnaire.oneB')
            },
            {
              id: 3,
              name: this.$t('mySettings.investProfile.personalQuestionnaire.oneC')
            },
            {
              id: 4,
              name: this.$t('mySettings.investProfile.personalQuestionnaire.oneD')
            },
          ]
        },
        {
          id: 2,
          options: [
            {
              id: 1,
              name: this.$t('mySettings.investProfile.personalQuestionnaire.twoA')
            },
            {
              id: 2,
              name: this.$t('mySettings.investProfile.personalQuestionnaire.twoB')
            },
            {
              id: 3,
              name: this.$t('mySettings.investProfile.personalQuestionnaire.twoC')
            },
          ]
        },
        {
          id: 3,
          options: [
            {
              id: 1,
              name: this.$t('mySettings.investProfile.personalQuestionnaire.threeA')
            },
            {
              id: 2,
              name: this.$t('mySettings.investProfile.personalQuestionnaire.threeB')
            },
            {
              id: 3,
              name: this.$t('mySettings.investProfile.personalQuestionnaire.threeC')
            },
            {
              id: 4,
              name: this.$t('mySettings.investProfile.personalQuestionnaire.threeD')
            },
          ]
        },
        {
          id: 4,
          options: [
            {
              id: 1,

              name: this.$t('mySettings.investProfile.personalQuestionnaire.fourA')
            },
            {
              id: 2,

              name: this.$t('mySettings.investProfile.personalQuestionnaire.fourB')
            },
            {
              id: 3,

              name: this.$t('mySettings.investProfile.personalQuestionnaire.fourC')
            },
            {
              id: 4,

              name: this.$t('mySettings.investProfile.personalQuestionnaire.fourD')
            },
          ]
        },
        {
          id: 5,
          options: [
            {
              id: 1,
              name: this.$t('mySettings.investProfile.personalQuestionnaire.fiveA')
            },
            {
              id: 2,
              name: this.$t('mySettings.investProfile.personalQuestionnaire.fiveB')
            },
            {
              id: 3,
              name: this.$t('mySettings.investProfile.personalQuestionnaire.fiveC')
            },
            {
              id: 4,
              name: this.$t('mySettings.investProfile.personalQuestionnaire.fiveD')
            },
          ]
        },
        {
          id: 6,
          options: [
            {
              id: 1,
              name: this.$t('mySettings.investProfile.personalQuestionnaire.sixA')
            },
            {
              id: 2,
              name: this.$t('mySettings.investProfile.personalQuestionnaire.sixB')
            },
            {
              id: 3,
              name: this.$t('mySettings.investProfile.personalQuestionnaire.sixC')
            },
            {
              id: 4,
              name: this.$t('mySettings.investProfile.personalQuestionnaire.sixD')
            },
          ]
        },
        {
          id: 7,
          options: [
            {
              id: 1,
              name: this.$t('mySettings.investProfile.personalQuestionnaire.sevenA')
            },
            {
              id: 2,
              name: this.$t('mySettings.investProfile.personalQuestionnaire.sevenB')
            },
            {
              id: 3,
              name: this.$t('mySettings.investProfile.personalQuestionnaire.sevenC')
            },
            {
              id: 4,
              name: this.$t('mySettings.investProfile.personalQuestionnaire.sevenD')
            },
          ]
        },
        {
          id: 8,
          options: [
            {
              id: 1,
              name: this.$t('mySettings.investProfile.personalQuestionnaire.eightA')
            },
            {
              id: 2,
              name: this.$t('mySettings.investProfile.personalQuestionnaire.eightB')
            },
            {
              id: 3,
              name: this.$t('mySettings.investProfile.personalQuestionnaire.eightC')
            },
            {
              id: 4,
              name: this.$t('mySettings.investProfile.personalQuestionnaire.eightD')
            },
          ]
        },
        {
          id: 9,
          options: [
            {
              id: 1,
              name: this.$t('mySettings.investProfile.personalQuestionnaire.nineA')
            },
            {
              id: 2,
              name: this.$t('mySettings.investProfile.personalQuestionnaire.nineB')
            },
            {
              id: 3,
              name: this.$t('mySettings.investProfile.personalQuestionnaire.nineC')
            },
            {
              id: 4,
              name: this.$t('mySettings.investProfile.personalQuestionnaire.nineD')
            },
          ]
        },
        {
          id: 10,
          options: [
            {
              id: 1,
              name: this.$t('mySettings.investProfile.personalQuestionnaire.tenA')
            },
            {
              id: 2,
              name: this.$t('mySettings.investProfile.personalQuestionnaire.tenB')
            },
            {
              id: 3,
              name: this.$t('mySettings.investProfile.personalQuestionnaire.tenC')
            },
            {
              id: 4,
              name: this.$t('mySettings.investProfile.personalQuestionnaire.tenD')
            },
          ]
        },
        {
          id: 11,
          options: [
            {
              id: 1,
              name: this.$t('mySettings.investProfile.personalQuestionnaire.elevenA')
            },
            {
              id: 2,
              name: this.$t('mySettings.investProfile.personalQuestionnaire.elevenB')
            },
            {
              id: 3,
              name: this.$t('mySettings.investProfile.personalQuestionnaire.elevenC')
            },
            {
              id: 4,
              name: this.$t('mySettings.investProfile.personalQuestionnaire.elevenD')
            },
            {
              id: 5,
              name: this.$t('mySettings.investProfile.personalQuestionnaire.elevenE')
            },
          ]
        },
        {
          id: 12,
          options: [
            {
              id: 1,
              name: this.$t('mySettings.investProfile.personalQuestionnaire.one2')
            },
            {
              id: 2,
              name: this.$t('mySettings.investProfile.personalQuestionnaire.one3')
            },
            {
              id: 3,
              name: this.$t('mySettings.investProfile.personalQuestionnaire.one4')
            },
            {
              id: 4,
              name: this.$t('mySettings.investProfile.personalQuestionnaire.one5')
            },
          ]
        },
      ],
      experience: [
        { information: this.$t('mySettings.investProfile.personalQuestionnaire.thirteen1'), no: '0', limited: '1', good: '2-3', rich: '>3' },
        { information: this.$t('mySettings.investProfile.personalQuestionnaire.thirteen6'), no: '', limited: '', good: '', rich: '' },
      ],
      product: [
        { information: this.$t('mySettings.investProfile.personalQuestionnaire.thirteen7'), no: '0', limited: '1', good: '5', rich: '8' },
        { information: this.$t('mySettings.investProfile.personalQuestionnaire.thirteen8'), no: '0', limited: '1', good: '5', rich: '8' },
        { information: this.$t('mySettings.investProfile.personalQuestionnaire.thirteen9'), no: '0', limited: '1', good: '5', rich: '8' },
        { information: this.$t('mySettings.investProfile.personalQuestionnaire.thirteen10'), no: '0', limited: '1', good: '5', rich: '8' },
        { information: this.$t('mySettings.investProfile.personalQuestionnaire.thirteen11'), no: '0', limited: '1', good: '5', rich: '8' },
        { information: this.$t('mySettings.investProfile.personalQuestionnaire.thirteen12'), no: '0', limited: '1', good: '5', rich: '8' },
        { information: this.$t('mySettings.investProfile.personalQuestionnaire.thirteen13'), no: '0', limited: '1', good: '5', rich: '8' },
        { information: this.$t('mySettings.investProfile.personalQuestionnaire.thirteen14'), no: '0', limited: '1', good: '5', rich: '8' },
        { information: this.$t('mySettings.investProfile.personalQuestionnaire.thirteen15'), no: '0', limited: '1', good: '5', rich: '8' },
        { information: this.$t('mySettings.investProfile.personalQuestionnaire.thirteen16'), no: '0', limited: '1', good: '5', rich: '8' },
        { information: this.$t('mySettings.investProfile.personalQuestionnaire.thirteen17'), no: '0', limited: '1', good: '5', rich: '8' },
        { information: this.$t('mySettings.investProfile.personalQuestionnaire.thirteen18'), no: '0', limited: '1', good: '5', rich: '8' },
        { information: this.$t('mySettings.investProfile.personalQuestionnaire.thirteen19'), no: '0', limited: '1', good: '5', rich: '8' },
      ]
    };
  },
  created() {
    let configColor = localStorage.getItem('bgColor') || 'bg-Blue';
    loadThemColor(configColor);
  },
  methods: {
    submitForm(oneForm, form, twoForm) {
      this.$refs[oneForm].validate(val => {
        if (val) {
          this.$refs[twoForm].validate(val => {
            if (val) {
              if ((this.oneForm.radio11[0] != '12'
                || this.oneForm.radio11[1] != '12'
                || this.oneForm.radio11[3] != '12'
                || this.oneForm.radio11[4] != '12')
                && !this.twoForm.checkList.includes(1)) {
                this.$notify({
                  message: this.$t("mySettings.investProfile.prompt1"),
                  duration: 3000
                });
                return
              }
              if (!(this.oneForm.radio11[0] != '12'
                || this.oneForm.radio11[1] != '12'
                || this.oneForm.radio11[3] != '12'
                || this.oneForm.radio11[4] != '12')
                && this.twoForm.checkList.includes(1)) {
                this.$notify({
                  message: this.$t("mySettings.investProfile.prompt1"),
                  duration: 3000
                });
                return
              }
              if ((this.oneForm.radio11[2] != '12'
                || this.oneForm.radio11[6] != '12')
                && !this.twoForm.checkList.includes(2)) {
                this.$notify({
                  message: this.$t("mySettings.investProfile.prompt1"),
                  duration: 3000
                });
                return
              }
              if (!(this.oneForm.radio11[2] != '12'
                || this.oneForm.radio11[6] != '12')
                && this.twoForm.checkList.includes(2)) {
                this.$notify({
                  message: this.$t("mySettings.investProfile.prompt1"),
                  duration: 3000
                });
                return
              }
              if (this.oneForm.radio11[10] != '12'
                && !this.twoForm.checkList.includes(3)) {
                this.$notify({
                  message: this.$t("mySettings.investProfile.prompt1"),
                  duration: 3000
                });
                return
              }
              if (this.oneForm.radio11[10] == '12'
                && this.twoForm.checkList.includes(3)) {
                this.$notify({
                  message: this.$t("mySettings.investProfile.prompt1"),
                  duration: 3000
                });
                return
              }
              if (this.twoForm.radio13 == 1
                && !(this.oneForm.radio11[0] != '12'
                  || this.oneForm.radio11[1] != '12'
                  || this.oneForm.radio11[2] != '12'
                  || this.oneForm.radio11[3] != '12'
                  || this.oneForm.radio11[4] != '12'
                  || this.oneForm.radio11[6] != '12'
                  || this.oneForm.radio11[11] != '12')) {
                this.$notify({
                  message: this.$t("mySettings.investProfile.prompt1"),
                  duration: 3000
                });
                return
              }
              this.isShowSuccess = true;
            } else {
              this.$notify({
                message: this.$t("mySettings.investProfile.answer"),
                duration: 3000
              });
            }
          });
        } else {
          this.$notify({
            message: this.$t("mySettings.investProfile.answer"),
            duration: 3000
          });
        }
      });
    },
    empty() {
      if (this.twoForm.radio18 != 1) {
        this.form.code = ''
      }
    },
    close() {
      window.close()
    },
    time(t) {
      console.log(t);
    },
    getId(id) {
      if (id == 1) {
        this.$notify({
          message: this.$t("mySettings.investProfile.conservative"),
          duration: 3000,
        })
      }
    },
    handleCheckAllChange(val) {
      if (val) {
        this.twoForm.checkList = [];
        this.twoForm.input = ''
      }
    },
    handleCheckedCitiesChange(value) {
      if (value) {
        this.twoForm.checked = false;
      }
    }
  },
  mounted() {
  }
}

</script>
<style lang='scss' scoped>
.personalQuestionnaire-wrap {
  font-family: SourceHanSansCN-Regular;
  font-size: 1rem;
  min-height: 100%;
  .top {
    display: flex;
    align-items: center;
    margin-bottom: 40px;
    height: 64px;
    background: #003da5;
    box-shadow: 6px 0 6px 0 rgba(162, 140, 133, 0.3);
    @media screen and(max-width: 1080px) {
      padding: 0 24px;
    }
    @media screen and(max-width: 768px) {
      padding: 0 12px;
    }
    .top-box {
      display: flex;
      align-items: center;
      margin: 0 auto;
      width: 1000px;
      img {
        margin-right: 25px;
        width: 95px;
        height: 32px;
      }
      span {
        padding-left: 25px;
        font-family: SourceHanSansCN-Medium;
        font-size: 18px;
        color: #ffffff;
        line-height: 25px;
        border-left: 1px #fff solid;
      }
    }
  }

  .box {
    margin: 0px auto;
    width: 1000px;
    @media screen and (max-width: 1080px) {
      padding: 0 24px;
      width: 100%;
    }
    @media screen and(max-width: 768px) {
      padding: 0 12px;
      width: 100%;
    }
    .title {
      padding: 0 24px;
      font-family: SourceHanSansCN-Medium;
      font-size: 20px;
      text-align: center;
      @media screen and(max-width: 768px) {
        padding: 0 12px;
      }
    }
    .content {
      width: 100%;
      .main {
        font-family: SourceHanSansCN-Medium;
        line-height: 50px;
      }
      p {
        margin: 10px 0;
      }
      .ruleForm {
        >>> .time-slelector {
          display: flex;
          position: relative;
          .el-date-editor {
            .el-input__inner {
              padding-left: 4px;
              width: 132px;
            }
          }
          .icon-date {
            position: absolute;
            top: -1px;
            left: 105px;
            font-size: 18px;
          }
          .icon-date1 {
            position: absolute;
            top: -1px;
            left: -26px;
            font-size: 18px;
          }
        }
        .el-form-item {
          position: relative;
          margin-bottom: 15px;
          .icon-date {
            position: absolute;
            top: 0px;
            left: 254px;
            font-size: 18px;
          }
          >>> .el-form-item__label {
            font-family: SourceHanSansCN-Regular;
            font-size: 1rem;
            font-weight: 500;
            line-height: 25px;
          }
          >>> .el-form-item__content {
            font-size: 1rem;
          }
          >>> .el-input__prefix {
            .el-input__icon {
              display: none;
            }
          }

          >>> .el-input__suffix {
            top: 1px;
            right: 0px;
            width: 35px;
            height: 35px;
            line-height: 35px;
            .el-input__icon {
              position: absolute;
              top: -1px;
              left: -40px;
            }
          }
        }
        .indicate {
          display: flex;
          @media screen and (max-width: 768px) {
            flex-wrap: wrap;
          }
          .left {
            flex: 0 0 300px;
            padding-left: 20px;
            a {
              display: inline-block;
              line-height: 20px;
            }
          }
          .right {
            flex: 0 0 300px;
            margin-left: 50px;
            @media screen and (max-width: 768px) {
              margin-left: 0px;
              padding-left: 20px;
            }
            .wa {
              width: 300px;
            }
          }
        }
        .el-radio {
          display: block;
          margin-right: 12px;
          line-height: 30px;
          >>> .el-radio__label {
            margin-top: -3px;
            margin-bottom: 15px;
            text-overflow: ellipsis;
            white-space: normal;
            line-height: 20px;
            display: inline-block;
            vertical-align: text-top;
          }
        }
        table {
          border-collapse: collapse;
        }
        td {
          text-align: center;
          vertical-align: bottom;
        }

        .txt {
          text-align: center;
        }
        .el-checkbox {
          display: block;
          margin-bottom: 0px;
          margin-right: 12px;
          >>> .el-checkbox__label {
            display: inline-grid;
            white-space: pre-line;
            overflow: hidden;
            font-family: SourceHanSansCN-Regular;
            font-size: 1rem;
            color: rgba(51, 51, 51, 0.75);
          }
        }
      }
    }
    .btn {
      text-align: center;
      .el-button {
        margin: 50px 0px;
        width: 120px;
        height: 40px;
        font-family: SourceHanSansCN-Bold;
        font-size: 1rem;
        color: #ffffff;
        line-height: 14px;
      }
    }
  }
  .success {
    margin: 125px auto 0;
    width: 826px;
    @media screen and (max-width: 850px) {
      padding: 0 24px;
      width: 100%;
    }
    .content {
      display: flex;
      align-items: center;
      justify-content: center;
      .imgs {
        width: 58px;
        height: 58px;
        margin-right: 24px;
        i{
          font-size: 58px;
        }
      }
      .info {
        font-family: SourceHanSansCN-Medium;
        font-size: 24px;
        line-height: 30px;
        font-weight: 550;
      }
    }

    .btn {
      display: block;
      margin: 112px auto;
      width: 120px;
      height: 40px;
      font-family: SourceHanSansCN-Bold;
      font-size: 1rem;
      color: #ffffff;
    }
  }

  .bottom {
    position: fixed;
    left: 0;
    bottom: 0;
  }
}
</style>