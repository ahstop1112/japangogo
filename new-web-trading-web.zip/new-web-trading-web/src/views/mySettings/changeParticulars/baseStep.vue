<template>
  <div class="baseStep contentBg">
    <ul class="base-form">
      <li class="form-item">
        <span class="txt mediumColor">{{$t('mySettings.changeParticulars.shoutiPhone')}}</span>
        <span class="val">   
          <el-input class="country-input" v-model="baseInfo.country" :placeholder="$t('mySettings.changeParticulars.guojiahaoma')"></el-input>
          <el-input class="tel-input" v-model="baseInfo.telphone" :placeholder="$t('mySettings.changeParticulars.dianhuahaoma')"></el-input>
        </span>  
      </li>
      <li class="form-item">
        <span class="txt mediumColor">{{$t('mySettings.changeParticulars.youbian')}}</span>
        <span class="val">   
          <el-input v-model="baseInfo.postcode" :placeholder="$t('mySettings.changeParticulars.tianxieyoubian')"></el-input>
        </span>  
      </li>
      <li class="form-item">
        <span class="txt mediumColor">{{$t('mySettings.changeParticulars.dizhi')}}</span>
        <span class="val">   
          <el-input v-model="baseInfo.address" :placeholder="$t('mySettings.changeParticulars.tianxiedizhi')"></el-input>
        </span>  
      </li>
      <li class="form-item">
        <span class="txt mediumColor">{{$t('mySettings.changeParticulars.email')}}</span>
        <span class="val">   
          <el-input v-model="baseInfo.email" :placeholder="$t('mySettings.changeParticulars.inputEmail')"></el-input>
        </span>  
      </li>
      <li class="form-item">
        <span class="title heavyColor">{{$t('mySettings.changeParticulars.shouquhukou')}}</span>
      </li>
      <li class="form-item">
        <span class="txt mediumColor">{{$t('mySettings.changeParticulars.shouqufangshi')}}</span>
        <span class="val">   
          <el-radio-group v-model="baseInfo.getType">
            <el-radio :label="1">{{$t('mySettings.changeParticulars.dianzijiedan')}}</el-radio>
            <el-radio :label="2">{{$t('mySettings.changeParticulars.youjijiedan')}}</el-radio>
          </el-radio-group>
        </span>  
      </li>
      <li class="form-item">
        <span class="txt mediumColor">{{$t('mySettings.changeParticulars.jiedanyuyan')}}</span>
        <span class="val">   
          <el-radio-group v-model="baseInfo.lang">
            <el-radio :label="1">{{$t('mySettings.changeParticulars.en')}}</el-radio>
            <el-radio :label="2">{{$t('mySettings.changeParticulars.cn')}}</el-radio>
            <el-radio :label="3">{{$t('mySettings.changeParticulars.hk')}}</el-radio>
          </el-radio-group>
        </span>  
      </li>
      <li class="form-item">
        <span class="txt mediumColor">{{$t('mySettings.changeParticulars.email')}}</span>
        <span class="val">   
          <el-input v-model="baseInfo.recEmail" :placeholder="$t('mySettings.changeParticulars.inputEmail')"></el-input>
        </span>  
      </li>
    </ul>
    <div class="editor-more">
      <span class="more activeFontColor" @click="emitEvent('detail')">{{$t('mySettings.changeParticulars.editorMore')}}</span>
    </div>
    <div class="explain-wrap mediumColor">
      {{$t('mySettings.changeParticulars.explain')}}
    </div>
    <div class="btn-wrap">
      <el-button type="primary" @click="emitEvent('next')">{{$t('mySettings.changeParticulars.next')}}</el-button>
    </div>
  </div>
</template>

<script>
export default {
  data () {
    return {
      baseInfo: {
        country:"",
        telphone:"",
        postcode:"",
        email:"",
        getType: 1,
        lang: 3,
        recEmail:"",
      }
    };
  },
  methods: {
    emitEvent(type) {
      this.$emit('emitEvent', type);
    }
  },
  mounted(){},

}

</script>
<style lang='scss' scoped>
  .baseStep{
    padding: 24px;
    .base-form{
      .form-item{
        display: flex;
        align-items: center;
        padding: 10px 0;
        .title{
          font-family: SourceHanSansCN-Medium;
          font-size: 18px;
          line-height: 18px;
          padding: 12px 0;
        }
        .txt{
          width: 90px;
          padding-right: 10px;
          font-family: SourceHanSansCN-Regular;
          font-size: 16px;
          line-height: 20px;
        }
        .val{
          flex: 1;
          display: flex;
          .country-input{
              flex: 0 0 40%;
          }
          .country-input >>> input{
            border-top-right-radius:0;
            border-bottom-right-radius:0;
            border-right: none;
          }
          .tel-input{
            flex: 1;
          }
          .tel-input >>>  input{
            border-top-left-radius:0;
            border-bottom-left-radius:0;
          } 
        }
      }
    }
    .editor-more{
      padding: 12px 0;
      .more{
        font-family: SourceHanSansCN-Medium;
        font-size: 16px;
        text-decoration: underline;
        cursor: pointer;
      }
    }
    .explain-wrap{
      font-family: SourceHanSansCN-Regular;
      font-size: 16px;
      line-height: 20px;
    }
    .btn-wrap{
      padding: 24px 0;
      text-align: right;
    }
  }
  .el-radio{
    line-height: 24px;
  }
   @media screen and (max-width: 768px){
     .baseStep{
       padding: 12px;
     }
   }
</style>