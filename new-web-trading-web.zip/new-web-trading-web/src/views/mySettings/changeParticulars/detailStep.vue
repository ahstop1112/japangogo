<template>
  <div class="detailStep contentBg">
     <ul class="detail-form">
       <li class="form-item">
          <span class="title heavyColor">{{$t('mySettings.changeParticulars.dianhuahaoma')}}</span>
        </li>
        <li class="form-item">
          <span class="txt mediumColor">{{$t('mySettings.changeParticulars.zhuzhaidianhua')}}</span>
          <span class="val">   
            <el-input class="country-input" v-model="detailInfo.homePhone.country" :placeholder="$t('mySettings.changeParticulars.guojiahaoma')"></el-input>
            <el-input class="tel-input" v-model="detailInfo.homePhone.telphone" :placeholder="$t('mySettings.changeParticulars.dianhuahaoma')"></el-input>
          </span>  
        </li>
        <li class="form-item">
          <span class="txt mediumColor">{{$t('mySettings.changeParticulars.bangongdianhua')}}</span>
          <span class="val">   
            <el-input class="country-input" v-model="detailInfo.officePhone.country" :placeholder="$t('mySettings.changeParticulars.guojiahaoma')"></el-input>
            <el-input class="tel-input" v-model="detailInfo.officePhone.telphone" :placeholder="$t('mySettings.changeParticulars.dianhuahaoma')"></el-input>
          </span>  
        </li>
        <li class="form-item">
          <span class="txt mediumColor">{{$t('mySettings.changeParticulars.chuanzhenhaoma')}}</span>
          <span class="val">   
            <el-input class="country-input" v-model="detailInfo.faxPhone.country" :placeholder="$t('mySettings.changeParticulars.guojiahaoma')"></el-input>
            <el-input class="tel-input" v-model="detailInfo.faxPhone.telphone" :placeholder="$t('mySettings.changeParticulars.dianhuahaoma')"></el-input>
          </span>  
        </li>
        <li class="form-item">
          <span class="title heavyColor">{{$t('mySettings.changeParticulars.jiaoyuchengdu')}}</span>
        </li>
        <li class="form-item">
          <span class="txt mediumColor">{{$t('mySettings.changeParticulars.jiaoyu')}}</span> 
          <span class="val">   
             <el-select class="select" v-model="detailInfo.education" :placeholder="$t('mySettings.changeParticulars.choose')">
                <el-option :label="item" v-for="item in educaitionLevel"  :value="item" :key="item"></el-option>
             </el-select>
          </span>  
        </li>
        <li class="form-item">
          <span class="txt mediumColor">{{$t('mySettings.changeParticulars.zhiye')}}</span>
          <span class="val">   
             <el-select class="select" v-model="detailInfo.job"  :placeholder="$t('mySettings.changeParticulars.choose')">
                <el-option :label="item" v-for="item in occupation"  :value="item" :key="item"></el-option>
             </el-select>
          </span>  
        </li>
        <li class="form-item">
          <span class="txt mediumColor">{{$t('mySettings.changeParticulars.guzhuming')}}</span>
          <span class="val">   
             <el-input class="tel-input" v-model="detailInfo.corporateName" :placeholder="$t('mySettings.changeParticulars.tianxieguzhu')"></el-input>
          </span>  
        </li>
        <li class="form-item">
          <span class="txt mediumColor">{{$t('mySettings.changeParticulars.congyenianfen')}}</span>
          <span class="val">   
            <el-input class="tel-input" v-model="detailInfo.workYear" :placeholder="$t('mySettings.changeParticulars.qingtianxie')"></el-input>
          </span>  
        </li>
        <li class="form-item">
          <span class="txt mediumColor">{{$t('mySettings.changeParticulars.zhiwei')}}</span>
          <span class="val">   
             <el-input class="tel-input" v-model="detailInfo.position" :placeholder="$t('mySettings.changeParticulars.tianxiezhiwei')"></el-input>
          </span>  
        </li>
        <li class="form-item">
          <span class="title heavyColor">{{$t('mySettings.changeParticulars.caiwuziliao')}}</span>
        </li>
        <li class="form-item">
          <span class="txt mediumColor">{{$t('mySettings.changeParticulars.zhuwu')}}</span>
          <span class="val"> 
            <el-select class="select" v-model="detailInfo.house" :placeholder="$t('mySettings.changeParticulars.choose')">
                <el-option  :label="item" v-for="item in house"  :value="item" :key="item"></el-option>
             </el-select>
          </span>  
        </li>
        <li class="form-noWrap">
          <span class="noWrap-txt mediumColor">{{$t('mySettings.changeParticulars.caifulaiyuan')}}</span>
          <span class="noWrap-val">   
            <el-checkbox-group v-model="detailInfo.sourcesIncome">
              <el-checkbox :label="item" v-for="item in SourcesOfWealth" :key="item"></el-checkbox>
            </el-checkbox-group>
            <el-input class="tel-input" 
                v-if="detailInfo.sourcesIncome.indexOf(SourcesOfWealth[SourcesOfWealth.length-1]) != -1"
                v-model="detailInfo.sourcesIncomeExplain" 
                :placeholder="$t('mySettings.changeParticulars.laiyuanqita')">
            </el-input>
          </span>  
        </li>
        <li class="form-noWrap">
          <span class="noWrap-txt mediumColor">{{$t('mySettings.changeParticulars.caifuzhuanyi')}}</span>
          <span class="noWrap-val">    
            <el-checkbox-group v-model="detailInfo.transferType">
              <el-checkbox :label="item" v-for="item in SourcesOfRoute" :key="item"></el-checkbox>
            </el-checkbox-group>
             <el-input class="tel-input" 
                v-if="detailInfo.transferType.indexOf(SourcesOfRoute[SourcesOfRoute.length-1]) != -1"
                v-model="detailInfo.transferTypeExplain" 
                :placeholder="$t('mySettings.changeParticulars.laiyuanqita')">
              </el-input>
          </span>  
        </li>
        <li class="form-noWrap">
          <span class="noWrap-txt mediumColor">{{$t('mySettings.changeParticulars.caifulaiyuandi')}}</span>
          <span class="noWrap-val">   
            <el-checkbox-group v-model="detailInfo.transferCity">
              <el-checkbox :label="item" v-for="item in SourcesOfCity" :key="item"></el-checkbox>
            </el-checkbox-group>
             <el-input class="tel-input" 
                v-if="detailInfo.transferCity.indexOf(SourcesOfCity[SourcesOfCity.length-1]) != -1"
                v-model="detailInfo.transferCityExplain" 
                :placeholder="$t('mySettings.changeParticulars.laiyuanqita')">
              </el-input>
          </span>  
        </li>
        <li class="form-item">
          <span class="txt mediumColor">{{$t('mySettings.changeParticulars.zongshouru')}}</span>
          <span class="val">   
            <el-select class="select" v-model="detailInfo.annualIncome" :placeholder="$t('mySettings.changeParticulars.choose')">
                <el-option  label="≤ HK$ 72,000"  value="chengxuyuan1"></el-option>
                <el-option  label="HK$ 72,001 - HK$ 200,000"  value="chengxuyuan2"></el-option>
                <el-option  label="HK$ 200,001 - HK$ 499,999"  value="chengxuyuan3"></el-option>
                <el-option  label="HK$ 500,000 - HK$ 999,999"  value="chengxuyuan4"></el-option>
                <el-option  label="HK$ 1,000,000 - HK$ 2,999,999"  value="chengxuyuan5"></el-option>
                <el-option  label="HK$ 3,000,000"  value="chengxuyuan6"></el-option>
             </el-select>
          </span>  
        </li>
        <li class="form-item">
          <span class="txt mediumColor">{{$t('mySettings.changeParticulars.jingzichan')}}</span>
          <span class="val">   
            <el-select class="select" v-model="detailInfo.iquidAssets" :placeholder="$t('mySettings.changeParticulars.choose')">
                <el-option  label="≤ HK$ 1,000,000"  value="chengxuyuan1"></el-option>
                <el-option  label="HK$ 1,000,001 - HK$ 5,000,000"  value="chengxuyuan2"></el-option>
                <el-option  label="HK$ 5,000,001 - HK$ 8,000,000"  value="chengxuyuan3"></el-option>
                <el-option  label="HK$ 8,000,001 - HK$ 29,999,999"  value="chengxuyuan4"></el-option>
                <el-option  label="HK$ 30,000,000"  value="chengxuyuan5"></el-option>
             </el-select>
          </span>  
        </li>
        <li class="form-item">
          <span class="title heavyColor">{{$t('mySettings.changeParticulars.touzimudi')}}</span>
        </li>
        <li class="form-noWrap">
          <span class="noWrap-txt mediumColor">{{$t('mySettings.changeParticulars.touzijingyan')}}</span>
          <span class="noWrap-val">
            <el-checkbox-group v-model="detailInfo.investExperience">
              <el-checkbox  :label="item" v-for="item in InvestExperience" :key="item"></el-checkbox>
            </el-checkbox-group>
          </span>  
        </li>
        <li class="form-item">
          <span class="txt mediumColor">{{$t('mySettings.changeParticulars.touzinianfen')}}</span>
          <span class="val">   
            <el-select class="select" v-model="detailInfo.investYear" :placeholder="$t('mySettings.changeParticulars.choose')">
                <el-option v-for="item in InvestYear"  :label="item"  :value="item" :key="item"></el-option>
             </el-select>
          </span>  
        </li>
         <li class="form-noWrap">
          <span class="noWrap-txt mediumColor">{{$t('mySettings.changeParticulars.touzimudi')}}</span>
          <span class="noWrap-val">   
            <el-checkbox-group v-model="detailInfo.investPurpose"> 
              <el-checkbox  :label="item" v-for="item in InvestPurpose" :key="item"></el-checkbox>
            </el-checkbox-group>
            <el-input class="tel-input" 
                v-if="detailInfo.investPurpose.indexOf(InvestPurpose[InvestPurpose.length-1]) != -1"
                v-model="detailInfo.investPurposeExplain" 
                :placeholder="$t('mySettings.changeParticulars.laiyuanqita')">
            </el-input>
          </span>  
        </li>
     </ul> 
    <div class="explain-wrap mediumColor">
        {{$t('mySettings.changeParticulars.explain')}}
    </div>
    <div class="btn-wrap">
      <el-button @click="emitEvent('back')">{{$t('mySettings.changeParticulars.back')}}</el-button>
      <el-button @click="emitEvent('next')" type="primary">{{$t('mySettings.changeParticulars.next')}}</el-button>
    </div>
  </div>
</template>

<script>
export default {
  data () {
    return {
      detailInfo: {
        homePhone: {
          country:"",
          telphone:""
        },
        officePhone: {
          country:"",
          telphone:""
        },
        faxPhone: {
          country:"",
          telphone:""
        },
        education:"",
        job:"",
        corporateName:"",
        workYear:"",
        position:"",
        house:"",
        sourcesIncome: [],
        sourcesIncomeExplain: "",
        transferType:[],
        transferTypeExplain:"",
        transferCity:[],
        transferCityExplain:"",
        annualIncome:"",
        iquidAssets:"",
        investExperience:[],
        investYear:"",
        investPurpose:[],
        investPurposeExplain:"",
      }
    };
  },
  computed: { //detail data from lang
    educaitionLevel() {
      return this.$t('mySettings.changeParticulars.educaitionLevel').split("/");
    },
    occupation() {
      return this.$t('mySettings.changeParticulars.occupation').split("|");
    },
    house() {
      return this.$t('mySettings.changeParticulars.house').split("/");
    },
    SourcesOfWealth() {
      return this.$t('mySettings.changeParticulars.laiyuanxuanze').split("|");
    },
    SourcesOfRoute() {
      return this.$t('mySettings.changeParticulars.zhuanyixuanze').split("|");
    },
    SourcesOfCity() {
      return this.$t('mySettings.changeParticulars.laiyuandixuanze').split("|");
    },
    InvestExperience() {
      return this.$t('mySettings.changeParticulars.touzijinyanxuanze').split("|");
    },
    InvestYear() {
      return this.$t('mySettings.changeParticulars.touzinianfenxuanze').split("|");
    },
    InvestPurpose() {
      return this.$t('mySettings.changeParticulars.touzimudixuanze').split("|");
    },
  },
  methods: {
    emitEvent(type) {
      this.$emit('emitEvent',type);
    },
  },
  mounted(){},

}

</script>
<style lang='scss' scoped>
  .detailStep{
    padding: 24px;
    .detail-form{
      .form-item{
        display: flex;
        align-items: center;
        padding: 10px 0;
        .title{
          font-family: SourceHanSansCN-Medium;
          font-size: 18px;
          line-height: 18px;
          padding: 12px 0;
        }
        .txt{
          width: 90px;
          padding-right: 10px;
          font-family: SourceHanSansCN-Regular;
          font-size: 16px;
          line-height: 20px;
        }
        .val{
          flex: 1;
          display: flex;
          .select{
            width: 100%;
          }
          .country-input{
              flex: 0 0 40%;
          }
          .country-input >>> input{
            border-top-right-radius:0;
            border-bottom-right-radius:0;
            border-right: none;
          }
          .tel-input{
            flex: 1;
          }
          .tel-input >>>  input{
            border-top-left-radius:0;
            border-bottom-left-radius:0;
          } 
        }
      }
      .form-noWrap{
        padding: 10px 0;
        .noWrap-txt{
          display: block;
          font-family: SourceHanSansCN-Regular;
          font-size: 16px;
          line-height: 20px;
          padding: 12px 0;
        }
        .noWrap-val{
          width: 100%;
          display: block;
          padding-left: 90px;
        }
      }  
    }
    .explain-wrap{
      padding: 48px 0 12px 0;
      font-family: SourceHanSansCN-Regular;
      font-size: 16px;
      line-height: 20px;
    }
    .btn-wrap{
      padding: 24px 0;
      text-align: right;
    }
  }
   @media screen and (max-width: 768px){
     .detailStep{
        padding: 12px;
     }
     .detailStep .explain-wrap{
        padding: 24px 0 12px 0;
     }
     .detailStep .detail-form .form-item .title{
       padding: 6px 0;
     }
     .detailStep .detail-form .form-noWrap .noWrap-txt{
       padding: 6px 0;
     }
   }
</style>