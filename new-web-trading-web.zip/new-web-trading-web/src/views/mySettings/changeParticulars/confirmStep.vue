<template>
  <div class="confirmStep">
    <div class="confirm-title heavyColor">{{$t('mySettings.changeParticulars.cofirmInfo')}}</div>
    <div class="confirm-content contentBg">
      <ul class="confirm-form">
        <li class="confirm-item">
          <span class="text mediumColor">{{$t('mySettings.changeParticulars.shoutiPhone')}}</span>
          <span class="val heavyColor">（+86）18898652786</span>
        </li>
        <li class="confirm-item">
          <span class="text mediumColor">{{$t('mySettings.changeParticulars.youbian')}}</span>
          <span class="val heavyColor"></span>
        </li>
        <li class="confirm-item">
          <span class="text mediumColor">{{$t('mySettings.changeParticulars.dizhi')}}</span>
          <span class="val heavyColor">深圳市福田区车公庙</span>
        </li>
        <li class="confirm-item">
          <span class="text mediumColor">{{$t('mySettings.changeParticulars.email')}}</span>
          <span class="val heavyColor"></span>
        </li>
        <li class="confirm-item">
          <span class="title heavyColor">{{$t('mySettings.changeParticulars.shouquhukou')}}</span>
        </li>
        <li class="confirm-item">
          <span class="text mediumColor">{{$t('mySettings.changeParticulars.shouqufangshi')}}</span>
          <span class="val heavyColor"></span>
        </li>
        <li class="confirm-item">
          <span class="text mediumColor">{{$t('mySettings.changeParticulars.jiedanyuyan')}}</span>
          <span class="val heavyColor"></span>
        </li>
        <li class="confirm-item">
          <span class="text mediumColor">{{$t('mySettings.changeParticulars.email')}}</span>
          <span class="val heavyColor" ></span>
        </li>
        <li class="confirm-item">
          <span class="title heavyColor">{{$t('mySettings.changeParticulars.dianhuahaoma')}}</span>
        </li>
        <li class="confirm-item">
          <span class="text mediumColor">{{$t('mySettings.changeParticulars.zhuzhaidianhua')}}</span>
          <span class="val heavyColor"></span>
        </li>
        <li class="confirm-item">
          <span class="text mediumColor">{{$t('mySettings.changeParticulars.bangongdianhua')}}</span>
          <span class="val heavyColor"></span>
        </li>
        <li class="confirm-item">
          <span class="text mediumColor">{{$t('mySettings.changeParticulars.chuanzhenhaoma')}}</span>
          <span class="val heavyColor"></span>
        </li>
        <li class="confirm-item">
          <span class="title heavyColor">{{$t('mySettings.changeParticulars.jiaoyuchengdu')}}</span>
        </li>
        <li class="confirm-item">
          <span class="text mediumColor">{{$t('mySettings.changeParticulars.jiaoyu')}}</span>
          <span class="val heavyColor"></span>
        </li>
        <li class="confirm-item">
          <span class="text mediumColor">{{$t('mySettings.changeParticulars.zhiye')}}</span>
          <span class="val heavyColor"></span>
        </li>
        <li class="confirm-item">
          <span class="text mediumColor">{{$t('mySettings.changeParticulars.guzhuming')}}</span>
          <span class="val heavyColor"></span>
        </li>
        <li class="confirm-item">
          <span class="text mediumColor">{{$t('mySettings.changeParticulars.congyenianfen')}}</span>
          <span class="val heavyColor"></span>
        </li>
         <li class="confirm-item">
          <span class="text mediumColor">{{$t('mySettings.changeParticulars.zhiwei')}}</span>
          <span class="val heavyColor"></span>
        </li>
         <li class="confirm-item">
          <span class="title heavyColor">{{$t('mySettings.changeParticulars.caiwuziliao')}}</span>
        </li>
        <li class="confirm-item">
          <span class="text mediumColor">{{$t('mySettings.changeParticulars.zhuwu')}}</span>
          <span class="val heavyColor"></span>
        </li>
        <li class="confirm-item">
          <span class="text mediumColor">{{$t('mySettings.changeParticulars.caifulaiyuan')}}</span>
          <span class="val heavyColor"></span>
        </li>
        <li class="confirm-item">
          <span class="text mediumColor">{{$t('mySettings.changeParticulars.caifuzhuanyi')}}</span>
          <span class="val heavyColor"></span>
        </li>
        <li class="confirm-item">
          <span class="text mediumColor">{{$t('mySettings.changeParticulars.caifulaiyuandi')}}</span>
          <span class="val heavyColor"></span>
        </li>
        <li class="confirm-item">
          <span class="text mediumColor">{{$t('mySettings.changeParticulars.zongshouru')}}</span>
          <span class="val heavyColor"></span>
        </li>
        <li class="confirm-item">
          <span class="text mediumColor">{{$t('mySettings.changeParticulars.jingzichan')}}</span>
          <span class="val heavyColor"></span>
        </li>
         <li class="confirm-item">
          <span class="title heavyColor">{{$t('mySettings.changeParticulars.touzimudi')}}</span>
        </li>
        <li class="confirm-item">
          <span class="text mediumColor">{{$t('mySettings.changeParticulars.touzijingyan')}}</span>
          <span class="val heavyColor"></span>
        </li>
        <li class="confirm-item">
          <span class="text mediumColor">{{$t('mySettings.changeParticulars.touzinianfen')}}</span>
          <span class="val heavyColor"></span>
        </li>
        <li class="confirm-item">
          <span class="text mediumColor">{{$t('mySettings.changeParticulars.touzimudi')}}</span>
          <span class="val heavyColor"></span>
        </li>
      </ul>
      <div class="btn-wrap">
        <el-button @click="backPrevStep">{{$t('mySettings.changeParticulars.back')}}</el-button>
        <el-button @click="goToNextStep" type="primary">{{$t('mySettings.changeParticulars.confirm')}}</el-button>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  data () {
    return {

    };
  },
  props:{
    backState:""
  },
  methods: {
    backPrevStep() {
      this.$emit('backPrevStep',this.backState);
    },
    goToNextStep() {
      this.$router.push({
        path: "/twoFaLogin",
        query: {
          source:"changeParticulars"
        }
      })
    }
  },
  mounted(){

  },
}
</script>
<style lang='scss' scoped>
  .confirmStep{
    width: 100%;
    height: 100%;
    .confirm-title{
      padding-bottom: 12px;
      font-family: SourceHanSansCN-Regular;
      font-size: 20px;
    }
    .confirm-content{ 
      width: 100%;
      padding: 24px;
      .confirm-form{
        .confirm-item{
          display: flex;
          align-items: center;
          padding: 12px 0;
          .title{
            font-family: SourceHanSansCN-Medium;
            font-size: 18px;
            line-height: 18px;
            padding: 12px 0;
          }
          .text{
            padding-right: 10px;
            font-family: SourceHanSansCN-Regular;
            font-size: 16px;
            line-height: 20px;
          }
          .val{
            font-family: SourceHanSansCN-Regular;
            font-size: 16px;
            line-height: 18px;
          }
        }
      }
      .btn-wrap{
        padding: 24px 24px 24px 0;
        text-align: right;
      }
    }
  }
  @media screen and (max-width: 768px){
     .confirmStep .confirm-content{
       padding: 12px;
     }
     .confirmStep .confirm-content .btn-wrap{
        padding: 24px 12px 24px 0;
        text-align: right;
      }
      .confirmStep .confirm-content .confirm-form .confirm-item{
        align-items:normal;
      }
      .confirmStep .confirm-content .confirm-form .confirm-item .title{
        padding: 5px 0;
      }
   }
</style>