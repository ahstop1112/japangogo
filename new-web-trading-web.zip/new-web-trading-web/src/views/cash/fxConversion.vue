<!--货币兑换-->
<template>
  <div class="fundTransfer-wrap">
    <pageNav :routerArr="routerArr"/>
    <div class="content-wrap">
      <keep-alive>
         <router-view />
      </keep-alive>
    </div>
  </div>
</template>
<script>
import pageNav from "@/components/pageNav"
import { mapGetters } from 'vuex'

export default {
  computed: {
    ...mapGetters(['getLang'])
  },
  watch: {
    getLang: {
      handler:function(o,n){
        this.routerArr = [
          {
            name: this.$t('cash.fxConversion.zhishi'),
            path:"fxConversionWrap"
          },
          {
            name: this.$t('cash.fxConversion.jiecunTotal'),
            path:"currencyBalance"
          }
        ]
      },
      immediate: true
    }  
  },
  data () {
    return {
        routerArr: []
    };
  },
 components: {
    pageNav
  },
  methods: {},
  mounted(){},
}

</script>
<style lang='scss' scoped>
  .fundTransfer-wrap{
    width: 100%;
    .content-wrap{
      margin-top: 24px;
    }
  }
   @media screen and (max-width: 768px){
     .fundTransfer-wrap .router-wrap .router-item{
       padding-left: 12px;
     }
     .fundTransfer-wrap .content-wrap{
       margin-top: 12px;
     }
   }
</style>