<!-- 资金提取 -->
<template>
  <div class="fundTransfer-wrap" v-if="userData.onlineWthdrAllw===true">
    <!-- 弹出框 -->
    <popover :title="$t('cash.fundWithdrawal.tiquTitle')" @close="closePopover" :showPopover="showPopover">
      <div class="exchange-main" v-if="firstStep">
        <div class="exchange-Info contentBorder">
          <div class="exchange-explain">
            <p class="explain-item lightColor">
              {{$t('cash.fundWithdrawal.tiquTip')}}
            </p>
          </div>
          <ul class="exchange-base">
            <li class="exchange-base-item">
              <span class="text mediumColor">{{$t('cash.fundWithdrawal.zhishi')}}</span>
              <span class="num heavyColor">提取HKD</span>
            </li>
            <li class="exchange-base-item">
              <span class="text mediumColor">{{$t('cash.fundWithdrawal.zhizhangzhanghu')}}</span>
              <span class="num heavyColor">02-0071828-33 (香港,中國A股,美國及場外市場)</span>
            </li>
            <li class="exchange-base-item">
              <span class="text mediumColor">{{$t('cash.fundWithdrawal.ruzhangzhanghu')}}</span>
              <span class="num heavyColor">The Hong Kong & Shanghai Banking Corp. Co. Ltd.</span>
            </li>
            <li class="exchange-base-item">
              <span class="text mediumColor">{{$t('cash.fundWithdrawal.tiquMoney')}}</span>
              <span class="num heavyColor">HKD 6,847.50</span>
            </li>
          </ul>
        </div>
        <div class="password-wrap">
          <span class="txt mediumColor">{{$t('cash.fundWithdrawal.password')}}</span>
          <span class="password">
            <el-input v-model="password" type="password"></el-input>
          </span>
        </div>
        <div class="confirm-btn">
          <el-button @click="changeExchangeInfo">{{$t('cash.fundWithdrawal.change')}}</el-button>
          <el-button type="primary" @click="goNextStep">{{$t('cash.fundWithdrawal.cofirm')}}</el-button>
        </div>
      </div>
      <div class="success-wrap" v-else>
        <ul class="success-content">
          <li class="success-icon">
            <i class="iconfont icon-status_success activeFontColor"></i>
          </li>
          <li class="success-text activeFontColor">
            {{$t('cash.fundWithdrawal.confirmSuccess')}}
          </li>
          <li class="success-num heavyColor">
            {{$t('cash.fundWithdrawal.bianhao')}}：MP800052167
          </li>
        </ul>
        <div class="confirm-btn">
          <el-button>{{$t('cash.fundWithdrawal.ticunjilu')}}</el-button>
          <el-button class="btn" type="primary">{{$t('cash.fundWithdrawal.print')}}</el-button>
        </div>
      </div>
    </popover>
    <!-- 账户 -->
    <div class="exchange-wrap" v-show="btnIndex == 0">
      <el-row class="exchange-content" :gutter="12">
        <!-- 提款存入账户 -->
        <el-col :xs="24" :sm="24" :md="12" :lg="12" :xl="12">
          <div class="content-left contentBg">
            <div class="form-wrap">
              <div class="form-title heavyColor">{{$t('cash.fundWithdrawal.tikuanzhanghu')}}</div>
              <ul class="form-content">
                <li class="form-item">
                  <span class="form-text mediumColor">{{$t('cash.fundWithdrawal.koukuanzhanghu')}}</span>
                  <span class="form-val heavyColor">
                    <el-select class="market" v-model="deductionsAccount">
                      <el-option v-for="item in deductions" :key="item.value" :label="item.label" :value="item.value" style="width:100%">
                      </el-option>
                    </el-select>
                  </span>
                </li>
                <li class="form-item">
                  <span class="form-text mediumColor">{{$t('cash.fundWithdrawal.market')}}</span>
                  <span class="form-val heavyColor">
                    <el-select class="market" v-model="deductionsMarket">
                      <el-option v-for="item in market" :key="item.value" :label="item.label" :value="item.value">
                      </el-option>
                    </el-select>
                  </span>
                </li>
                <li class="form-item">
                  <span class="form-text mediumColor">{{$t('cash.fundWithdrawal.tiquMoney')}}</span>
                  <span class="form-val heavyColor">
                    <el-input :placeholder="$t('cash.fundWithdrawal.tiquPlaceholder')" v-model="extractVal" class="input-with-select">
                    </el-input>
                  </span>
                </li>
              </ul>
            </div>
            <div class="form-wrap">
              <div class="form-title heavyColor">{{$t('cash.fundWithdrawal.cunruzhanghu')}}</div>
              <ul class="form-content">
                <li class="form-item">
                  <span class="form-text mediumColor">{{$t('cash.fundWithdrawal.bankZhanghu')}}</span>
                  <span class="form-val heavyColor">
                    <el-select class="market" v-model="depositAccount">
                      <el-option v-for="item in deposit" :key="item.value" :label="item.label" :value="item.value">
                      </el-option>
                    </el-select>
                  </span>
                </li>
              </ul>
            </div>
            <div class="query-wrap">
              <el-button type="primary" @click="openQueryInfo">{{$t('cash.fundWithdrawal.nextStep')}}</el-button>
            </div>
          </div>
        </el-col>
        <!-- 注意事项 -->
        <el-col :xs="24" :sm="24" :md="12" :lg="12" :xl="12">
          <div class="content-right">
            <div class="disclaimer-title heavyColor">
              {{$t('cash.fundWithdrawal.zhuyi')}}
            </div>
            <div class="disclaimer-wrap">
              <p class="disclaimer-item mediumColor">
                {{$t('cash.fundWithdrawal.zhuyiExplain1')}}
              </p>
              <p class="disclaimer-item mediumColor">
                {{$t('cash.fundWithdrawal.zhuyiExplain2')}}
              </p>
              <p class="disclaimer-item mediumColor">
                {{$t('cash.fundWithdrawal.zhuyiExplain3')}}
              </p>
              <p class="disclaimer-item mediumColor">
                {{$t('cash.fundWithdrawal.zhuyiExplain4')}}
              </p>
              <p class="disclaimer-item mediumColor">
                {{$t('cash.fundWithdrawal.zhuyiExplain5')}}
              </p>
            </div>
          </div>
        </el-col>
      </el-row>
      <div></div>
    </div>
  </div>
  <div class="investProfile-wrap" v-else>
    <span class="text">{{$t('cash.fundTransfer.formCheck3')}}</span>
  </div>
</template>

<script>
import { mapGetters } from 'vuex'
import popover from '@/components/popover'
export default {
  computed: {
    ...mapGetters(['getLang'])
  },
  components: {
    popover
  },
  watch: {
    getLang: {
      handler: function (o, n) {
        this.$nextTick(() => {
          this.market = [
            {
              value: 'mainMarket',
              label: this.$t("cash.fundWithdrawal.zhengquanMarket1")
            },
            {
              value: 'bSotckMarket',
              label: this.$t("cash.fundWithdrawal.zhengquanMarket2")
            },
            {
              value: 'otherMarket',
              label: this.$t("cash.fundWithdrawal.zhengquanMarket3")
            }
          ]
        })
      },
      immediate: true
    }
  },
  data() {
    return {
      btnIndex: 0,
      showPopover: false, //是否显示弹出
      firstStep: true, //是否显示第一步
      market: [],
      deductions: [
        {
          value: '02-0071828-33 (香港,中國A股,美國及場外市場)',
          label: '02-0071828-33 (香港,中國A股,美國及場外市場)'
        },
        {
          value: '02-0071828-34(香港,中國A股,美國及場外市場)',
          label: '02-0071828-34(香港,中國A股,美國及場外市場)'
        },
        {
          value: '02-0071828-35(香港,中國A股,美國及場外市場)',
          label: '02-0071828-35(香港,中國A股,美國及場外市場)'
        }
      ],
      deposit: [
        {
          value: 'The Hong Kong & Shanghai Banking Corp. Co. Ltd.',
          label: 'The Hong Kong & Shanghai Banking Corp. Co. Ltd.'
        },
        {
          value: 'The Hong Kong & Shanghai Banking Corp. Co. Ltd',
          label: 'The Hong Kong & Shanghai Banking Corp. Co. Ltd '
        },
        {
          value: 'The Hong Kong & Shanghai Banking Corp. Co. ',
          label: 'The Hong Kong & Shanghai Banking Corp. Co. '
        }
      ],
      extractVal: '',
      // buyVal: '',
      deductionsAccount: '02-0071828-33 (香港,中國A股,美國及場外市場)',
      deductionsMarket: 'mainMarket',
      depositAccount: 'The Hong Kong & Shanghai Banking Corp. Co. Ltd.',
      password: '',
      userData: ''
    }
  },
  methods: {
    goNextStep() {
      this.firstStep = false
    },
    changeExchangeInfo() {
      this.showPopover = false
    },
    //打开弹窗
    openQueryInfo() {
      let reg = /^\d*[.]?\d{1,2}$/;
      if (this.extractVal == "") {
        this.$notify({
          message: this.$t("cash.fundWithdrawal.formCheck1"),
          duration: 3000,
        })
        return;
      }
      else if (!reg.test(this.extractVal)) {
        this.$notify({
          message: this.$t("cash.fundWithdrawal.formCheck2"),
          duration: 3000,
        })
        return;
      } else if (Number(this.extractVal) < 1) {
        this.$notify({
          message: this.$t("cash.fundWithdrawal.formCheck3"),
          duration: 3000,
        })
        return;
      }
      this.showPopover = true
      this.firstStep = true
    },
    //隐藏弹窗
    closePopover() {
      this.showPopover = false
    },
    chooseItem(index) {
      this.btnIndex = index
    }
  },
  created() {
    this.userData = JSON.parse(sessionStorage.getItem("userData"));
  },
  mounted() {
  }
}
</script>
<style lang="scss" scoped>
.fundTransfer-wrap {
  width: 100%;
  .exchange-main .exchange-Info {
    padding: 12px 24px 48px 24px;
    width: 100%;
    .exchange-base {
      .exchange-base-item {
        display: flex;
        padding-top: 10px;
        .text {
          flex: 0 0 140px;
          font-family: SourceHanSansCN-Regular;
          font-size: 16px;
        }
        .num {
          flex: 1;
          text-align: right;
          font-family: Avenir-Book;
          font-size: 16px;
        }
      }
    }
    .exchange-explain {
      margin-bottom: 12px;
      .explain-item {
        margin-top: 12px;
        font-family: SourceHanSansCN-Regular;
        font-size: 14px;
        line-height: 16px;
      }
    }
  }
  .exchange-main .password-wrap {
    display: flex;
    padding: 24px;
    .txt {
      padding-right: 48px;
      font-family: SourceHanSansCN-Regular;
      font-size: 16px;
      line-height: 36px;
    }
    .password {
      flex: 1;
    }
  }
  .exchange-main .confirm-btn {
    padding: 0 24px 12px 0;
    text-align: right;
  }
  .success-wrap {
    padding: 24px;
    .success-content {
      padding: 24px 0;
      .success-icon {
        padding-bottom: 12px;
        text-align: center;
        i {
          font-size: 58px;
        }
      }
      .success-text {
        padding: 12px 0;
        text-align: center;
        font-family: SourceHanSansCN-Medium;
        font-size: 18px;
        font-weight: 550;
      }
      .success-num {
        font-family: SourceHanSansCN-Regular;
        font-size: 14px;
        text-align: center;
      }
    }
    .confirm-btn {
      padding: 24px 0 48px 0;
      text-align: center;
      button {
        margin: 0 12px 12px 0;
        font-weight: 600;
      }
    }
  }

  .exchange-wrap {
    width: 100%;
    .exchange-content {
      width: 100%;
      .content-left {
        padding: 24px;
        .form-wrap {
          width: 100%;
          .form-title {
            font-family: SourceHanSansCN-Medium;
            font-size: 20px;
          }
          .form-content {
            padding-bottom: 30px;
            .form-item {
              display: flex;
              align-items: center;
              padding: 12px 0;
              .form-text {
                flex: 0 0 120px;
                line-height: 18px;
                font-family: SourceHanSansCN-Regular;
                font-size: 16px;
              }
              .form-val {
                flex: 1;
                font-family: Avenir-Book;
                font-size: 16px;
                .input-with-select {
                  >>> .el-input__inner {
                    border-right: 1px solid rgba(51, 51, 51, 0.25);
                  }
                }
                .market {
                  width: 100%;
                }
              }
            }
          }
        }
        .query-wrap {
          padding: 12px 0;
          text-align: right;
        }
      }
      .content-right {
        padding: 24px;
        .disclaimer-title {
          margin-bottom: 24px;
          font-family: SourceHanSansCN-Medium;
          font-size: 16px;
        }
        .disclaimer-wrap {
          .disclaimer-item {
            margin-top: 12px;
            font-family: SourceHanSansCN-Regular;
            font-size: 16px;
            line-height: 20px;
          }
        }
      }
    }
  }
}
.investProfile-wrap {
  padding-top: 150px;
  text-align: center;
  .text {
    font-family: SourceHanSansCN-Regular;
    font-size: 16px;
    color: #333333;
  }
}
@media screen and (max-width: 768px) {
  .el-col {
    padding: 0 !important;
  }
  .fundTransfer-wrap .btn-item {
    margin-left: 12px;
  }
  .fundTransfer-wrap .market-choose .market-info .market-item {
    margin-right: 12px;
  }
  .fundTransfer-wrap .exchange-wrap .exchange-content {
    margin: 0 !important;
  }
  .fundTransfer-wrap .exchange-wrap .exchange-content .content-left {
    padding: 12px;
  }
  .fundTransfer-wrap .exchange-wrap .exchange-content .content-right {
    padding: 12px;
    margin-top: 12px;
  }
  .fundTransfer-wrap
    .exchange-wrap
    .exchange-content
    .content-left
    .form-wrap
    .form-content
    .form-item
    .form-text {
    flex: 0 0 80px;
  }
}
</style>
