<template>
  <!-- 缴费灵 -->
  <div class="pps">
    <div class="top">
      <img src="@/assets/1@3x.png" alt="" />
      <span>繳費靈</span>
    </div>
    <div class="box">
      <h4>傳入現金戶口</h4>
      <el-select v-model="value" placeholder="02-012-26147-30">
        <el-option v-for="item in options" :key="item.value" :label="item.label" :value="item.value">
        </el-option>
      </el-select>
      <h4>轉賬金額</h4>
      <el-input v-model="input" placeholder="请输入金额" class="ipt">
        <template slot="suffix">HKD</template>
      </el-input>
      <div class="btn">
        <el-button plain>返回資金存入主頁</el-button>
        <el-button type="primary">確定</el-button>
      </div>
      <p>
        <strong>注意：</strong>使用「繳費靈」服務時，有關Internet Explorer
        6.0(IE6)的設定要求，詳情請 <a href="javascript:;">按此</a>。
      </p>
    </div>

    <!-- 底部组件 -->
    <bottombar :isShow="false"></bottombar>
  </div>
</template>

<script>
import bottombar from '@/layout/bottombar'
export default {
  components: {
    bottombar
  },
  data() {
    return {
      input: '',
      options: [
        {
          value: '选项1',
          label: '02-012-26147-30'
        },
        {
          value: '选项2',
          label: '02-012-26147-30'
        }
      ],
      value: ''
    }
  }
}
</script>

<style lang="scss" scoped>
.pps {
  .top {
    display: flex;
    align-items: center;
    margin-bottom: 60px;
    padding-left: 236px;
    height: 64px;
    background: #003da5;
    box-shadow: 6px 0 6px 0 rgba(162, 140, 133, 0.3);
    @media screen and (max-width: 768px) {
      justify-content: center;
      padding-left: 0px;
    }
    img {
      margin-right: 25px;
      width: 95px;
      height: 32px;
    }
    span {
      padding-left: 25px;
      font-family: SourceHanSansCN-Medium;
      font-size: 18px;
      color: #ffffff;
      letter-spacing: 0;
      line-height: 25px;
      border-left: 1px #fff solid;
    }
  }
  .box {
    margin: 60px auto 0;
    width: 480px;
    @media screen and (max-width: 768px) {
      padding: 0 12px;
    }
    h4 {
      font-family: SourceHanSansCN-Medium;
      font-size: 16px;
      color: #333333;
      letter-spacing: 0;
      line-height: 16px;
    }
    .el-select {
      width: 100%;
      >>> .el-input--suffix {
        font-size: 16px;
      }
    }
    .ipt {
      font-weight: 550;
      >>> .el-input__suffix {
        margin-right: 5px;
        border-left: none;
        color: #333333;
        font-size: 16px;
      }
    }

    .btn {
      margin: 36px 0;
      text-align: right;
      font-family: SourceHanSansCN-Bold;
      .el-button {
        font-weight: 550;
      }
    }
    p {
      font-family: SourceHanSansCN-Regular;
      font-size: 16px;
      color: rgba(51, 51, 51, 0.75);
      letter-spacing: 0;
      line-height: 20px;
    }
    a {
      font-family: SourceHanSansCN-Medium;
      font-size: 16px;
      color: #4191ff;
      letter-spacing: 0;
      border-bottom: 1px solid #4191ff;
      line-height: 20px;
      font-weight: 550;
    }
  }
  .bottom-wrap {
    position: fixed;
    bottom: 0px;
  }
}
</style>
