<template>
  <!-- 账户资料 -->
  <div class="account contentBg">
    <p class="heavyColor">中國工商銀行(亞洲)賬戶名稱*：</p>
    <p class="heavyColor">HAITONG INTL SECURITIES CO LTD - CHEN BOMIN</p>
    <p class="heavyColor">中國工商銀行(亞洲)賬戶號碼：</p>
    <p class="heavyColor">上午11時30分至下午2時</p>
    <p class="heavyColor">關聯賬戶：</p>
    <p class="heavyColor">02-0099899-33</p>
    <p class="text mediumColor">
      *為確保資金能成功存入至
      閣下於中國工商銀行(亞洲)的指定境外匯款子賬戶，客戶於存款或匯款到該賬戶時於收款人名稱前務必填上「HAITONG
      INTL SECURITIES CO LTD -」,否則中國工商銀行(亞洲)會拒絕接受該筆款項。
    </p>
  </div>
</template>

<script>
export default {

}
</script>

<style lang="scss" scoped>
.account {
  padding: 24px;
  width: 100%;
  height: 100%;
  p {
    font-family: SourceHanSansCN-Medium;
    font-size: 16px;
    letter-spacing: 0;
    line-height: 30px;
    font-weight: 550;
  }
  .text {
    margin-top: 15px;
    font-family: SourceHanSansCN-Regular;
    font-size: 14px;
    line-height: 16px;
    font-weight: 500;
  }
}
@media screen and (max-width: 768px) {
  .account {
    padding: 12px;
  }
}
</style>