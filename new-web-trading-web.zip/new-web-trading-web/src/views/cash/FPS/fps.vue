<template>
  <!-- 转数快页面 -->
  <div class="fps">
    <!-- 弹出框 -->
    <popover :title="$t('cash.ePayment.fpsConfiguration.head')" @close="closePopover" :showPopover="showPopover">
      <div class="exchange-main">
        <div class="success-wrap contentBorder">
          <ul class="success-content">
            <li class="success-icon">
              <i class="iconfont icon-status_success activeFontColor"></i>
            </li>
            <li class="success-text activeFontColor">
              {{$t('cash.ePayment.fpsConfiguration.instructions')}}
            </li>
            <li class="success-num heavyColor">
              {{$t('cash.ePayment.fpsConfiguration.record')}}
            </li>
          </ul>
        </div>
        <div class="exchange-Info">
          <ul class="exchange-base">
            <li class="exchange-base-item">
              <span class="text mediumColor">{{$t('cash.ePayment.fpsConfiguration.ReferenceCode')}}</span>
              <span class="num heavyColor">{{$t('cash.ePayment.fpsConfiguration.digital1')}}</span>
            </li>
            <li class="exchange-base-item">
              <span class="text mediumColor">{{$t('cash.ePayment.fpsConfiguration.fpsCode')}}</span>
              <span class="num heavyColor">{{$t('cash.ePayment.fpsConfiguration.digital')}}</span>
            </li>
            <li class="exchange-base-item">
              <span class="text mediumColor">{{$t('cash.ePayment.fpsConfiguration.AfterFour')}}</span>
              <span class="num heavyColor">1234</span>
            </li>
            <li class="exchange-base-item">
              <span class="text mediumColor">{{$t('cash.ePayment.fpsConfiguration.account')}}</span>
              <span class="num heavyColor">02-0071828-33</span>
            </li>
            <li class="exchange-base-item">
              <span class="text mediumColor">{{$t('cash.ePayment.fpsConfiguration.market')}}</span>
              <span class="num heavyColor">香港,中國A股,美國及場外市場</span>
            </li>
            <li class="exchange-base-item">
              <span class="text mediumColor">{{$t('cash.ePayment.fpsConfiguration.currency')}}</span>
              <span class="num heavyColor">港幣</span>
            </li>
            <li class="exchange-base-item">
              <span class="text mediumColor">{{$t('cash.ePayment.fpsConfiguration.amount')}}</span>
              <span class="num heavyColor">1.00</span>
            </li>
          </ul>
        </div>
        <div class="confirm-btn">
          <el-button plain @click="changeExchangeInfo">{{$t('cash.ePayment.fpsConfiguration.wanCheng')}}</el-button>
          <el-button type="primary">{{$t('cash.ePayment.fpsConfiguration.print')}}</el-button>
        </div>
      </div>
    </popover>
    <el-row class="content" :gutter="12">
      <el-col :xs="24" :sm="24" :md="12" :lg="12" :xl="12">
        <div class="left contentBg" v-if="isShow">
          <div class="title heavyColor">{{$t('cash.ePayment.fpsConfiguration.title')}}</div>
          <br />
          <ul class="form-content">
            <li class="form-item">
              <span class="form-text mediumColor">{{$t('cash.ePayment.fpsConfiguration.fpsCode')}}</span>
              <span class="form-val heavyColor">{{$t('cash.ePayment.fpsConfiguration.digital')}}</span>
            </li>
            <li class="form-item">
              <span class="form-text lh mediumColor">{{$t('cash.ePayment.fpsConfiguration.collection')}}</span>
              <span class="form-val heavyColor">{{$t('cash.ePayment.fpsConfiguration.chinaBank')}}</span>
            </li>
            <li class="form-item">
              <span class="form-text mediumColor">{{$t('cash.ePayment.fpsConfiguration.payee')}}</span>
              <span class="form-val heavyColor">{{$t('cash.ePayment.fpsConfiguration.name')}}</span>
            </li>
          </ul>
          <a class="activeTagColor" href="http://htisec.com/sites/all/themes/hitong/files/FPSFundTransferGuide.pdf" target="_blank">{{$t('cash.ePayment.fpsConfiguration.guide')}}</a>

          <div class="btn">
            <el-button plain @click="$router.push('/cash/ePayment')">{{$t('cash.ePayment.fpsConfiguration.return')}}</el-button>
            <el-button type="primary" @click="isShow=false">{{$t('cash.ePayment.fpsConfiguration.nextStep')}}</el-button>
          </div>
        </div>
        <div class="content-left contentBg" v-else>
          <div class="form-wrap">
            <div class="form-title heavyColor">{{$t('cash.ePayment.fpsConfiguration.notice')}}</div>
            <ul class="form-content">
              <li class="form-item">
                <span class="form-text mediumColor">{{$t('cash.ePayment.fpsConfiguration.fpsCode')}}</span>
                <span class="form-val heavyColor">{{$t('cash.ePayment.fpsConfiguration.digital')}}</span>
              </li>
              <li class="form-item">
                <span class="form-text lh mediumColor">{{$t('cash.ePayment.fpsConfiguration.AfterFour')}}</span>
                <span class="form-val">
                  <el-input :placeholder="$t('cash.ePayment.fpsConfiguration.check')" v-model="accountVal" class="input-with-select">
                  </el-input>
                </span>
              </li>
              <li class="form-item">
                <span class="form-text mediumColor">{{$t('cash.ePayment.fpsConfiguration.account')}}</span>
                <span class="form-val">
                  <el-select class="market" v-model="depositAccount" placeholder="请选择">
                    <el-option v-for="item in deposit" :key="item.value" :label="item.label" :value="item.value" style="width:100%">
                    </el-option>
                  </el-select>
                </span>
              </li>
              <li class="form-item">
                <span class="form-text mediumColor">{{$t('cash.ePayment.fpsConfiguration.market')}}</span>
                <span class="form-val">
                  <el-select class="market" v-model="deductionsAccount" placeholder="请选择">
                    <el-option v-for="item in deductions" :key="item.value" :label="item.label" :value="item.value" style="width:100%">
                    </el-option>
                  </el-select>
                </span>
              </li>
              <li class="form-item">
                <span class="form-text mediumColor">{{$t('cash.ePayment.fpsConfiguration.currency')}}</span>
                <span class="form-val">
                  <el-select class="market" v-model="deductionsMarket" placeholder="请选择">
                    <el-option v-for="item in market" :key="item.value" :label="item.label" :value="item.value">
                    </el-option>
                  </el-select>
                </span>
              </li>
              <li class="form-item">
                <span class="form-text mediumColor">{{$t('cash.ePayment.fpsConfiguration.amount')}}</span>
                <span class="form-val">
                  <el-input placeholder="請輸入您的存入金額，最多輸入2位小數" v-model="depositVal" class="input-with-select">
                  </el-input>
                </span>
              </li>
            </ul>
          </div>
          <div class="query-wrap">
            <el-button  plain @click="isShow = true">{{$t('cash.ePayment.fpsConfiguration.return1')}}</el-button>
            <el-button type="primary" @click="openQueryInfo">{{$t('cash.ePayment.fpsConfiguration.queren')}}</el-button>
          </div>
        </div>
      </el-col>

      <!-- 注意事项 -->
      <el-col :xs="24" :sm="24" :md="12" :lg="12" :xl="12">
        <div class="content-right">
          <div class="matters-title heavyColor">
            {{$t('cash.ePayment.fpsConfiguration.attention')}}
          </div>
          <div class="matters-wrap">
            <p class="matters-item mediumColor">
              {{$t('cash.ePayment.fpsConfiguration.content')}}
            </p>
          </div>
        </div>
      </el-col>
    </el-row>
    <div></div>

  </div>
</template>

<script>
import popover from '@/components/popover'

export default {
  components: {
    popover
  },
  data() {
    return {
      isShow: true,
      showPopover: false, //是否显示弹出
      market: [
        {
          value: '港幣',
          label: '港幣'
        },
        {
          value: '人民幣',
          label: '人民幣'
        }
      ],
      deductions: [
        {
          value: '香港，中國A股，美國及場外市場',
          label: '香港，中國A股，美國及場外市場'
        },
        {
          value: '中國B股市場',
          label: '中國B股市場'
        },
        {
          value: '其它市場',
          label: '其它市場'
        }
      ],
      deposit: [
        {
          value: '00-11-22-33-44',
          label: '00-11-22-33-44'
        }
      ],
      // 存入金额
      depositVal: '',
      // 账户后四位，
      accountVal: '',
      deductionsAccount: '香港，中國A股，美國及場外市場',
      deductionsMarket: '港幣',
      depositAccount: '00-11-22-33-44',
    }
  },
  methods: {
    //隐藏弹窗
    changeExchangeInfo() {
      this.showPopover = false
    },
    //打开弹窗
    openQueryInfo() {
      let reg = /^\d*[.]?\d{1,2}$/;
      if (this.depositVal == "") {
        this.$notify({
          message: this.$t("cash.ePayment.fpsConfiguration.formCheck1"),
          duration: 3000,
        })
        return;
      }
      else if (!reg.test(this.depositVal)) {
        this.$notify({
          message: this.$t("cash.ePayment.fpsConfiguration.formCheck2"),
          duration: 3000,
        })
        return;
      } else if (Number(this.depositVal) < 1) {
        this.$notify({
          message: this.$t("cash.ePayment.fpsConfiguration.formCheck3"),
          duration: 3000,
        })
        return;
      }


      let regs = /^\d{4}$/;
      if (this.accountVal == "") {
        this.$notify({
          message: this.$t("cash.ePayment.fpsConfiguration.formCheck4"),
          duration: 3000,
        })
        return;
      }
      else if (!regs.test(this.accountVal)) {
        this.$notify({
          message: this.$t("cash.ePayment.fpsConfiguration.formCheck5"),
          duration: 3000,
        })
        return;
      }
      this.showPopover = true
    },
    //隐藏弹窗
    closePopover() {

      this.showPopover = false
    },
  },
}
</script>

<style  lang="scss" scoped>
.fps {
  width: 100%;
  .exchange-main .exchange-Info {
    padding: 12px 24px 30px 24px;
    width: 100%;
    .exchange-base {
      .exchange-base-item {
        display: flex;
        padding-top: 10px;
        .text {
          flex: 0 0 160px;
          font-family: SourceHanSansCN-Regular;
          font-size: 16px;
        }
        .num {
          flex: 1;
          text-align: right;
          font-family: Avenir-Book;
          font-size: 16px;
        }
      }
    }
  }

  .exchange-main .confirm-btn {
    padding: 0 0 30px 0;
    text-align: center;
    .el-button {
      font-weight: 600;
      width: 120px;
    }
  }

  .success-wrap {
    padding-top: 60px;
    .success-content {
      padding-bottom: 10px;
      .success-icon {
        text-align: center;
        padding-bottom: 8px;
        i {
          font-size: 58px;
        }
      }
      .success-text {
        padding: 12px 0;
        text-align: center;
        font-family: SourceHanSansCN-Medium;
        font-size: 18px;
        font-weight: 550;
      }
      .success-num {
        font-family: SourceHanSansCN-Regular;
        font-size: 14px;
        text-align: center;
      }
    }
    .confirm-btn {
      padding: 24px 0 48px 0;
      text-align: center;
      button {
        margin-right: 12px;
        font-weight: 600;
      }
    }
  }
  .content {
    width: 100%;
    margin-left: 0px !important;
    .left {
      padding: 24px;
      .title {
        width: 100%;
        font-family: SourceHanSansCN-Medium;
        font-size: 20px;
        font-weight: 600;
      }
      .form-content {
        padding-bottom: 30px;
        .form-item {
          display: flex;
          margin-top: 12px;
          height: 36px;
          line-height: 25px;
          .form-text {
            flex: 0 0 180px;
            font-family: SourceHanSansCN-Regular;
            font-size: 16px;
          }
          .form-val {
            flex: 1;
            font-family: Avenir-Book;
            font-size: 16px;
          }
        }
      }
      a {
        font-family: SourceHanSansCN-Medium;
        font-size: 16px;
        line-height: 16px;
      }

      .btn {
        padding: 30px 0 12px 0;
        text-align: right;
        .el-button {
          font-weight: 600;
        }
      }
    }
    .content-left {
      padding: 24px;
      .form-wrap {
        width: 100%;
        .form-title {
          font-family: SourceHanSansCN-Medium;
          font-size: 20px;
        }
        .form-content {
          padding-bottom: 30px;
          .form-item {
            display: flex;
            margin-top: 12px;
            height: 36px;
            line-height: 36px;
            .lh {
              line-height: 19px;
            }
            .form-text {
              flex: 0 0 180px;
              font-family: SourceHanSansCN-Regular;
              font-size: 16px;
            }
            .form-val {
              flex: 1;
              font-family: Avenir-Book;
              font-size: 16px;
              .market {
                width: 100%;
              }
            }
          }
        }
      }
      .query-wrap {
        padding: 12px 0;
        text-align: right;
        .el-button {
          font-weight: 600;
        }
      }
    }
    .content-right {
      padding: 24px;
      .matters-title {
        margin-bottom: 24px;
        font-family: SourceHanSansCN-Medium;
        font-size: 16px;
      }
      .matters-wrap {
        .matters-item {
          margin-top: 12px;
          font-family: SourceHanSansCN-Regular;
          font-size: 16px;
          line-height: 20px;
        }
      }
    }
  }
}
@media screen and (max-width: 768px) {
  .el-col {
    padding: 0 !important;
  }
  .fps .content .left,
  .fps .content .content-left,
  .fps .content .content-right {
    padding: 12px;
  }
  .fps .content .left .form-content .form-item .form-text {
    flex: 0 0 140px;
  }
}
</style>