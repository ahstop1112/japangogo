<!--
 * @Author: your name
 * @Date: 2020-11-02 16:44:17
 * @LastEditTime: 2021-01-27 11:50:06
 * @LastEditors: your name
 * @Description: In User Settings Edit
 * @FilePath: \new-web-trading\src\views\cash\remittanceServices.vue
-->
<!--汇款服务-->
<template>
  <div class="remittanceServices-wrap">
    <pageNav :routerArr="routerArr" />
    <div class="content-wrap">
      <keep-alive>
        <router-view />
      </keep-alive>
    </div>
  </div>
</template>
<script>
import pageNav from "@/components/pageNav"
import { mapGetters } from 'vuex'
export default {
  computed: {
    ...mapGetters(['getLang'])
  },
  components: {
    pageNav
  },
  watch: {
    getLang: {
      handler: function (o, n) {
        //如果是英文版则跳转到首页
        if (o == 'en_US') {
          this.$router.push('/');
          this.$store.commit('changeIsJumpRouter', true);
        }
        this.routerArr = [
          {
            name: this.$t('cash.remittanceServices.nav1'),
            path: "accountInformation"
          },
          {
            name: this.$t('cash.remittanceServices.nav2'),
            path: "applicationInformation"
          }
        ]
      },
      immediate: true
    }
  },
  data() {
    return {
      routerArr: []
    };
  },
  methods: {},
  mounted() { },
}

</script>
<style lang='scss' scoped>
.remittanceServices-wrap {
  width: 100%;
  .content-wrap {
    margin-top: 24px;
  }
}
@media screen and (max-width: 768px) {
  .remittanceServices-wrap .router-wrap .router-item {
    padding-left: 12px;
  }
  .remittanceServices-wrap .content-wrap {
    margin-top: 12px;
  }
}
</style>