<template>
  <!-- 中国银行电子转账服务页面 -->
  <div class="chinaBank">
    <div class="top">
      <img src="@/assets/1@3x.png" alt="" />
      <span>電子轉賬服務</span>
    </div>
    <div class="box">
      <h4 class="text">提取現金戶口：</h4>
      <span>中銀集團智達銀行服務</span>
      <h4>傳入現金戶口</h4>
      <el-select v-model="value" placeholder="02-012-26147-30">
        <el-option v-for="item in options" :key="item.value" :label="item.label" :value="item.value">
        </el-option>
      </el-select>
      <h4>轉賬金額</h4>
      <el-input v-model="input" placeholder="请输入金额" class="ipt">
        <template slot="suffix">HKD</template>
      </el-input>
      <div class="btn">
        <el-button type="primary">確定</el-button>
      </div>
      <p>
        <strong>注意：</strong>首次使用中銀集團智達銀行服務之客戶，請於轉賬前先
        <a href="javascript:;">按此</a>到中銀集團網頁內的《額度管理》把閣下之繳付賬單撥款限額提高。
      </p>
    </div>
    <!-- 底部组件 -->
    <bottombar :isShow="false"></bottombar>
  </div>
</template>

<script>
import bottombar from '@/layout/bottombar'
export default {
  components: {
    bottombar
  },
  data() {
    return {
      input: '',
      options: [
        {
          value: '选项1',
          label: '02-012-26147-30'
        },
        {
          value: '选项2',
          label: '02-012-26147-30'
        }
      ],
      value: ''
    }
  }
}
</script>

<style lang="scss" scoped>
.chinaBank {
  .top {
    display: flex;
    align-items: center;
    margin-bottom: 60px;
    padding-left: 236px;
    height: 64px;
    background: #003da5;
    box-shadow: 6px 0 6px 0 rgba(162, 140, 133, 0.3);
    @media screen and (max-width: 768px) {
      padding-left: 0px;
      justify-content: center;
    }
    img {
      margin-right: 25px;
      width: 95px;
      height: 32px;
    }
    span {
      padding-left: 25px;
      font-family: SourceHanSansCN-Medium;
      font-size: 18px;
      color: #ffffff;
      letter-spacing: 0;
      line-height: 25px;
      border-left: 1px #fff solid;
    }
  }
  .box {
    margin: 60px auto 0;
    width: 480px;
    @media screen and (max-width: 768px) {
      padding: 0 12px;
    }
    .text {
      display: inline-block;
      margin-bottom: 0;
    }
    h4 {
      font-family: SourceHanSansCN-Medium;
      font-size: 16px;
      color: #333333;
      letter-spacing: 0;
      line-height: 16px;
    }
    .el-select {
      width: 100%;
      >>> .el-input--suffix {
        font-size: 16px;
      }
    }
    .ipt {
      font-weight: 550;
      >>> .el-input__suffix {
        margin-right: 5px;
        border-left: none;
        color: #333333;
        font-size: 16px;
      }
    }

    .btn {
      margin: 36px 0;
      text-align: right;
      font-family: SourceHanSansCN-Bold;
      .el-button {
        font-weight: 550;
        width: 120px;
        height: 40px;
      }
    }
    p {
      font-family: SourceHanSansCN-Regular;
      font-size: 16px;
      color: rgba(51, 51, 51, 0.75);
      letter-spacing: 0;
      line-height: 20px;
    }
    a {
      font-family: SourceHanSansCN-Medium;
      font-size: 16px;
      color: #4191ff;
      letter-spacing: 0;
      border-bottom: 1px solid #4191ff;
      line-height: 20px;
      font-weight: 550;
    }
  }

  .bottom-wrap {
    position: fixed;
    bottom: 0px;
  }
}
</style>
