<template>
  <!-- 中国银行电子转账服务页面 -->
  <div class="chinaBank">
    <div class="top">
      <img src="@/assets/img/1@3x.png" alt="" />
      <span>電子轉賬服務</span>
    </div>
    <div class="box">
      <h4 class="text">提取現金戶口：</h4>
      <span>中銀集團智達銀行服務</span>
      <h4>傳入現金戶口</h4>
      <el-select v-model="value" placeholder="02-012-26147-30">
        <el-option v-for="item in options" :key="item.value" :label="item.label" :value="item.value">
        </el-option>
      </el-select>
      <h4>轉賬金額</h4>
      <el-input v-model="input" placeholder="请输入金额" class="ipt">
        <template slot="suffix">HKD</template>
      </el-input>
      <div class="btn">
        <el-button type="primary">確定</el-button>
      </div>
      <p>
        <strong>注意：</strong>首次使用中銀集團智達銀行服務之客戶，請於轉賬前先
        <a href="javascript:;">按此</a>到中銀集團網頁內的《額度管理》把閣下之繳付賬單撥款限額提高。
      </p>
    </div>
    <!-- 底部组件 -->
    <bottombar :isShow="false"></bottombar>
  </div>
</template>

<script>
import bottombar from '@/layout/bottombar'
export default {
  components: {
    bottombar
  },
  data() {
    return {
      input: '',
      options: [
        {
          value: '选项1',
          label: '02-012-26147-30'
        },
        {
          value: '选项2',
          label: '02-012-26147-30'
        }
      ],
      value: ''
    }
  }
}
</script>