<template>
  <!-- 保安提示弹窗 -->
  <div class="prompt">
    <div class="top">
      <div class="top-box">
        <img src="@/assets/1@3x.png" alt="" />
        <span>{{ $t('prompt.title') }}</span>
      </div>
    </div>
    <h4 class="title">{{ $t('prompt.title') }}</h4>
    <div class="box">
      <div class="content">
        <el-scrollbar wrap-class="scrollbar-wrapper" style="height: 100%;">
          <p>
            {{ $t('prompt.content1') }}
          </p>
          <p>
            {{ $t('prompt.content2') }}
          </p>
          <p>
            {{ $t('prompt.content3') }}
          </p>
          <p>
            {{ $t('prompt.content4') }}
          </p>
          <p>
            {{ $t('prompt.content5') }}
          </p>
          <p>
            {{ $t('prompt.content6') }}
          </p>
          <p>
            {{ $t('prompt.content7') }}
          </p>
          <p>
            {{ $t('prompt.content8') }}
          </p>
          <p>
            {{ $t('prompt.content9') }}
          </p>
          <p>
            {{ $t('prompt.content10') }}
          </p>
          <p>
            {{ $t('prompt.content11') }}
          </p>
          <p>
            {{ $t('prompt.content12') }}
          </p>
          <p>
            {{ $t('prompt.content13') }}
          </p>
          <p>
            {{ $t('prompt.content14') }}
          </p>
          <p>
            {{ $t('prompt.content15') }}
          </p>
          <p>
            {{ $t('prompt.content16') }}
          </p>
          <p>
            {{ $t('prompt.content17') }}
          </p>
          <p>
            {{ $t('prompt.content18') }}
          </p>
          <p>
            {{ $t('prompt.content19') }}
          </p>
          <p>
            {{ $t('prompt.content20') }}
          </p>
        </el-scrollbar>
      </div>
      <div class="ck">
        <el-checkbox v-model="checked"> {{ $t('prompt.chek') }}</el-checkbox>
      </div>
    </div>

    <div class="btn">
      <el-button type="primary" @click="close">{{
        $t('prompt.Close')
      }}</el-button>
    </div>
  </div>
</template>

<script>
import { localSet } from '@/utils/mylocal.js'
export default {
  data() {
    return {
      checked: false
    }
  },
  methods: {
    // 关闭当前页
    close() {
      window.close()
      // 保存不提示选中状态
      localSet('checked', this.checked)
    }
  }
}
</script>

<style lang="scss" scoped>
.prompt {
  .top {
    display: flex;
    align-items: center;
    padding: 16px 0;
    height: 100%;
    background: #003da5;
    box-shadow: 6px 0 6px 0 rgba(162, 140, 133, 0.3);
    @media screen and(max-width: 1080px) {
      padding: 12px 24px;
    }
    @media screen and(max-width: 768px) {
      padding: 12px 12px;
    }
    .top-box {
      display: flex;
      align-items: center;
      margin: 0 auto;
      width: 1000px;
      img {
        margin-right: 25px;
        width: 95px;
        height: 32px;
      }
      span {
        padding-left: 25px;
        font-family: SourceHanSansCN-Medium;
        font-size: 18px;
        color: #ffffff;
        line-height: 25px;
        border-left: 1px #fff solid;
      }
    }
  }
  .title {
    padding: 0 24px;
    font-family: SourceHanSansCN-Medium;
    font-size: 18px;
    color: #003da5;
    letter-spacing: 0;
    line-height: 18px;
    text-align: center;
    @media screen and(max-width: 768px) {
      padding: 0 12px;
    }
  }
  .box {
    position: relative;
    margin: 40px auto 0px;
    width: 1000px;
    @media screen and (max-width: 1080px) {
      padding: 0 24px;
      width: 100%;
    }
    @media screen and (max-width: 768px) {
      padding: 0 12px;
      width: 100%;
    }
    .content {
      overflow: auto;
      padding: 20px;
      width: 100%;
      height: 600px;
      border: 1px solid rgba(0, 61, 165, 0.1);
      font-family: SourceHanSansCN-Regular;
      font-size: 16px;
      color: rgba(51, 51, 51, 0.75);
      letter-spacing: 0;
      line-height: 30px;
    }
    .ck {
      position: absolute;
      bottom: -40px;
      left: 0px;
      margin-top: 15px;
      @media screen and (max-width: 1080px) {
        padding: 0 24px;
      }
      >>> .el-checkbox__label {
        font-family: SourceHanSansCN-Regular;
        font-size: 16px;
        color: #333333;
        letter-spacing: 0;
        line-height: 16px;
      }
    }
  }

  .btn {
    text-align: center;
  }
  .el-button {
    margin: 50px 0px;
    text-align: center;
    width: 120px;
    height: 40px;
    font-family: SourceHanSansCN-Bold;
    font-size: 16px;
    color: #ffffff;
    letter-spacing: 0;
    line-height: 14px;
  }
}
</style>
