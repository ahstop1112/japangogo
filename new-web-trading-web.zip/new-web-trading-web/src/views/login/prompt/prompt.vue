<template>
  <!-- 保安提示弹窗 -->
  <div class="prompt">
    <div class="top">
      <div class="top-box">
        <img src="@/assets/img/1@3x.png" alt="" />
        <span>{{ $t('prompt.title') }}</span>
      </div>
    </div>
    <h4 class="title">{{ $t('prompt.title') }}</h4>
    <div class="box">
      <div class="content">
        <el-scrollbar wrap-class="scrollbar-wrapper" style="height: 100%;">
          <span v-html="$t('prompt.content')" />
        </el-scrollbar>
      </div>
      <div class="ck">
        <el-checkbox v-model="checked"> {{ $t('prompt.chek') }}</el-checkbox>
      </div>
    </div>

    <div class="btn">
      <el-button type="primary" @click="close">{{
        $t('prompt.Close')
      }}</el-button>
    </div>
  </div>
</template>

<script>
import { localSet } from '@/utils/mylocal.js'
import prompt from './prompt.scss'

export default {
  data() {
    return {
      checked: false
    }
  },
  methods: {
    // 关闭当前页
    close() {
      window.close()
      // 保存不提示选中状态
      localSet('checked', this.checked)
    }
  }
}
</script>