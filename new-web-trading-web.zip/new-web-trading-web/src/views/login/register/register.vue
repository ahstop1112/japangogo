<template>
  <!-- 流动保安编码注册页面 -->
  <div class="register">
    <div class="top">
      <div class="top-box">
        <img src="@/assets/1@3x.png" alt="" />
        <span>{{ $t('register.addDialog.title') }}</span>
      </div>
    </div>
    <!-- 表单 -->
    <div class="box" v-if="isSuccess == true">
      <el-form :model="form" :rules="rules" ref="form" class="form" :inline="false">
        <h4>{{ $t('register.registerCode.name') }}</h4>
        <el-form-item prop="loginId">
          <el-input :placeholder="$t('register.registerCode.promptName')" v-model="form.loginId" clearable>
            <i slot="prefix" class="iconfont icon-login_username"></i>
          </el-input>
        </el-form-item>
        <h4>{{ $t('register.registerCode.password') }}</h4>
        <el-form-item prop="password">
          <el-input :type="show?'text':'password'" :placeholder="$t('register.registerCode.promptPassword')" v-model="form.password" clearable>
            <i slot="prefix" class="iconfont icon-login_password"></i>
            <i v-if="form.password!==''" slot="suffix" @click="show=!show" style="cursor:pointer; font-size: 40px;" :class="show?'iconfont icon-header_eye_show':'iconfont icon-header_eye_hide'"></i>
          </el-input>
        </el-form-item>
        <h4>{{ $t('register.registerCode.phone') }}</h4>
        <el-form-item prop="mobileNumber">
          <el-input :placeholder="$t('register.registerCode.promptPhone')" v-model="form.mobileNumber" clearable>
            <i slot="prefix" class="iconfont icon-login_phone"></i>
          </el-input>
        </el-form-item>
        <h4>{{ $t('register.registerCode.email') }}</h4>
        <el-form-item prop="emailAddress">
          <el-input :placeholder="$t('register.registerCode.promptEmail')" v-model="form.emailAddress" clearable>
            <i slot="prefix" class="iconfont icon-login_email"></i>
          </el-input>
        </el-form-item>
        <!-- 协议条款 -->
        <el-form-item prop="isPass">
          <el-checkbox v-model="form.isPass">
            {{ $t('register.registerCode.agree') }}
            <a href="http://www.htisec.com/zh-hk/software_token_tips" target="_blank">{{ $t('register.registerCode.terms') }}</a>
          </el-checkbox>
        </el-form-item>
        <div class="btn">
          <el-button :class="{ btnBg: btnState }" class="fr" type="primary" @click="toSuccess(form)" :disabled="btnState == false" :loading="loading">{{ $t('twoFaLogin.phoneLogin.btn2') }}</el-button>
        </div>
      </el-form>
    </div>

    <!-- 注册成功 -->
    <div class="success" v-else>
      <div class="imgs"><img src="@/assets/icon_pass@2x.png" alt="" /></div>
      <div class="info">
        <p>{{ $t('register.success.content1') }}</p>
        <p>{{ $t('register.success.content2') }}</p>
        <p>{{ $t('register.success.content3') }}</p>
      </div>
      <el-button class="btn" type="primary" @click="$router.push('/login')">{{
        $t('twoFaLogin.phoneLogin.btn2')
      }}</el-button>
    </div>
    <!-- 底部组件 -->
    <bottombar></bottombar>
  </div>
</template>

<script>
import bottombar from '@/layout/bottombar'
import { mobileOtpEnrollmentApi } from '@/api/register'
import { login1FaApi } from '@/api/login'
import errTables from '@/utils/errTables'
export default {
  components: {
    bottombar
  },
  computed: {
    btnState() {
      return (
        this.form.loginId !== '' &&
        this.form.password !== '' &&
        this.form.mobileNumber !== '' &&
        this.form.emailAddress !== '' &&
        this.form.isPass == true
      )
    }
  },
  data() {
    return {
      loading: false,
      show: false,
      isSuccess: true,
      form: {
        loginId: '',
        password: '',
        mobileNumber: '',
        emailAddress: '',
        isPass: true
      },
      //  校验规则
      rules: {
        loginId: [
          {
            required: true,
            message: this.$t('login.information1'),
            trigger: 'blur'
          }
        ],
        password: [
          {
            required: true,
            message: this.$t('login.information2'),
            trigger: 'blur'
          }
        ],
        mobileNumber: [
          {
            required: true,
            message: this.$t('twoFaLogin.phoneLogin.check'),
            trigger: 'blur'
          },
          {
            validator: (rule, value, callback) => {
              // let reg = /^(0|86|17951)?(13[0-9]|15[012356789]|166|17[3678]|18[0-9]|14[57])[0-9]{8}$/
              let reg = /^\d{8,11}$/
              if (reg.test(value)) {
                callback()
              } else {
                callback(new Error(this.$t('twoFaLogin.phoneLogin.check1')))
              }
            },
            trigger: 'change'
          }
        ],
        emailAddress: [
          {
            required: true,
            message: this.$t('register.registerCode.check'),
            trigger: 'blur'
          },
          {
            validator: (rule, value, callback) => {
              let reg = /\w+([-+.]\w+)*@\w+([-.]\w+)*\.\w+([-.]\w+)*/
              if (reg.test(value)) {
                callback()
              } else {
                callback(new Error(this.$t('register.registerCode.check1')))
              }
            },
            trigger: 'change'
          }
        ],
        isPass: [
          { required: true, message: this.$t('register.registerCode.terms1'), trigger: 'blur' },
          {
            validator: (rule, value, callback) => {
              if (value) {
                callback()
              } else {
                callback(new Error(this.$t('register.registerCode.terms1')))
              }
            },
            trigger: 'change'
          }
        ]
      }
    }
  },
  created() {
    let _self = this;
    window.document.onkeydown = function (e) {
      let key = window.event.keyCode;
      if (key == 13 || key == 100) {
        _self.toSuccess();
      }
    }
  },
  mounted() { },
  methods: {
    toSuccess(form) {
      // 全局效验
      this.$refs.form.validate(val => {
        if (val) {
          // 将加载状态设置为 true
          this.loading = true
          login1FaApi({
            loginId: this.form.loginId,
            password: this.form.password,
          }).then(res => {
            // 将加载状态设置为 false
            this.loading = false
            if (res.data.errorCode) {
              this.$notify({
                message: this.$t(errTables[res.data.errorCode]),
                duration: 3000
              });
            } else {
              sessionStorage.setItem('entitySequence', res.data.entitySequence)
              mobileOtpEnrollmentApi({
                loginId: this.form.loginId,
                mobileNumber: this.form.mobileNumber,
                emailAddress: this.form.emailAddress,
                entitySequence: sessionStorage.getItem("entitySequence")
              }).then(res => {
                if (res.data.errorCode) {
                  this.$notify({
                    message: this.$t(errTables[res.data.errorCode]),
                    duration: 3000
                  });
                } else {
                  // 跳转页面
                  this.isSuccess = false
                }
              }).catch(error => {
                console.log(error);
              })
            }
          }).catch(error => {
            console.log(error);
          })
        } else {
          // 将加载状态设置为 false
          this.loading = false
        }
      })
    }
  }
}
</script>

<style lang="scss" scoped>
.register {
  overflow: auto;
  width: 100%;
  height: 100%;
  .top {
    display: flex;
    align-items: center;
    height: 64px;
    background: #003da5;
    box-shadow: 6px 0 6px 0 rgba(162, 140, 133, 0.3);
    .top-box {
      display: flex;
      margin: 0 auto;
      align-items: center;
      width: 30%;
      @media screen and (max-width: 1000px) {
        margin-left: 180px;
        width: auto;
      }
      @media screen and (max-width: 768px) {
        margin-left: 70px;
        width: auto;
      }
      @media screen and (max-width: 375px) {
        margin: 0 12px;
        width: auto;
      }
      img {
        margin-right: 25px;
        width: 95px;
        height: 32px;
      }
      span {
        padding-left: 25px;
        font-family: SourceHanSansCN-Medium;
        font-size: 18px;
        color: #ffffff;
        line-height: 25px;
        border-left: 1px #fff solid;
      }
    }
  }
  .box {
    margin: 60px auto 0;
    width: 30%;
    min-height: calc(100vh - 238px);
    @media screen and(min-width:768px) and (max-width: 1000px) {
      min-height: calc(100vh - 238px);
      padding: 0px 180px;
      width: auto;
    }
    @media screen and(min-width:375px) and (max-width: 768px) {
      min-height: calc(100vh - 238px);
      overflow: auto;
      padding: 0px 70px;
      width: auto;
    }
    @media screen and(max-width: 375px) {
      min-height: calc(100vh - 238px);

      overflow: auto;
      padding: 0px 12px;
      width: auto;
    }
    .form {
      h4 {
        margin: 0px 0px 10px 0px;
      }
      .el-input {
        position: relative;
        font-family: SourceHanSansCN-Regular;
        font-size: 16px;
        color: rgba(51, 51, 51, 0.5);
        line-height: 16px;
        >>> .el-input__inner {
          padding-left: 48px;
          height: 40px;
        }
        >>> .el-input__clear {
          font-size: 20px;
        }
        >>> .el-input__prefix {
          top: -4px;
        }
        >>> .el-input__suffix {
          padding: 0px 60px 0 0;
          // right: 60px;
          border-left: none;
        }
        .icon-header_eye_hide,
        .icon-header_eye_show {
          position: absolute;
          top: 1.3px;
          right: -2px;
        }
        .icon-login_username,
        .icon-login_password,
        .icon-login_phone,
        .icon-login_email {
          margin-left: 8px;
          font-size: 24px;
          color: #003da5;
          line-height: 48px;
        }
      }

      .btn {
        height: 120px;
        .el-button {
          margin: 60px 0 56px 0;
          width: 120px;
          height: 40px;
          background: #bdbdbd;
          border: #003da5;
          font-family: SourceHanSansCN-Bold;
          font-size: 16px;
          color: #ffffff;
          letter-spacing: 0;
          text-align: center;
          line-height: 16px;
        }
        .btnBg {
          background: #003da5;
        }
      }
      .el-checkbox {
        margin-bottom: 0px;
        .el-checkbox__label {
          font-family: SourceHanSansCN-Regular;
          font-size: 16px;
          color: #333333;
          letter-spacing: 0;
          line-height: 16px;
        }
      }

      a {
        display: inline-block;
        font-family: SourceHanSansCN-Medium;
        color: #4191ff;
        letter-spacing: 0;
        border-bottom: 1px solid #4191ff;
        font-size: 16px;
        line-height: 20px;
      }
    }
  }

  .success {
    margin: 125px auto 0;
    width: 826px;
    min-height: calc(100vh - 303px);
    @media screen and (max-width: 850px) {
      padding: 0 24px;
      width: 100%;
      min-height: calc(100vh - 238px);
    }
    @media screen and (max-width: 375px) {
      padding: 0 12px;
      width: 100%;
      min-height: calc(100vh - 238px);
    }
    img {
      float: left;
      margin-right: 24px;
      width: 58px;
      height: 58px;
      .imgs {
        width: 58px;
        height: 58px;
      }
    }
    .info {
      margin-left: 80px;
      font-family: SourceHanSansCN-Medium;
      font-size: 24px;
      color: #003da5;
      line-height: 30px;
      font-weight: 550;
    }
    .btn {
      display: block;
      margin: 112px auto;
      width: 120px;
      height: 40px;
      font-family: SourceHanSansCN-Bold;
      font-size: 16px;
      color: #ffffff;
      text-align: center;
      line-height: 16px;
    }
  }
  .bottom-wrap {
    width: 100%;
  }
}
</style>
