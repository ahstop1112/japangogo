
<template>
  <!-- 用户密码登陆页 -->
  <div class="login">
    <div class="img">
      <img src="@/assets/login_HT_logo Copy@3x.png" alt="" />
    </div>
    <div class="imgs">
      <a v-if="lang == 'en_US'" href="http://www.htisec.com/en-us/account-opening"><img src="@/assets/开设户口_EN@2x.png" alt="" /></a>
      <a v-else-if="lang == 'zh_TW'" href="http://www.htisec.com/zh-hk/account-opening"><img src="@/assets/login_开设户口@3x.png" alt="" /></a>
      <a v-else href="http://www.htisec.com/zh-cn/account-opening"><img src="@/assets/开设户口_SC@2x.png" alt="" /></a>
    </div>
    <div class="box">
      <div class="box-top">
        <div class="box-left">
          <div class="logo">
            <img src="@/assets/login_HT_logo@3x.png" alt="" />
          </div>
          <span class="text" :class="[lang == 'en_US' ? 'txt' : '']">
            {{ $t("login.system") }}
          </span>
          <div class="left-bg">
            <img src="@/assets/login_HT_logo_bg@3x.png" alt="" />
          </div>
        </div>
        <div class="box-right">
          <div class="box-title">
            <span>{{ $t("login.customer") }}</span>
          </div>
          <!-- 表单 -->
          <el-form :model="form" :rules="rules" ref="form" class="form" :inline="true">
            <el-form-item prop="loginId">
              <el-input :placeholder="$t('login.name')" v-model="form.loginId" clearable>
                <i slot="prefix" class="iconfont icon-login_username"></i>
              </el-input>
            </el-form-item>
            <el-form-item prop="password">
              <el-input :type="show?'text':'password'" :placeholder="$t('login.password')" v-model="form.password" clearable>
                <i slot="prefix" class="iconfont icon-login_password"></i>
                <i v-if="form.password!==''" slot="suffix" @click="show=!show" style="cursor:pointer; font-size: 40px;" :class="show?'iconfont icon-header_eye_show':'iconfont icon-header_eye_hide'"></i>
              </el-input>
            </el-form-item>
            <!-- 忘记密码 -->
            <a class="ft-pw fr" href="javascript:;">{{$t("login.ForgetPassword")}}</a>
            <el-form-item>
              <el-button class="btn" type="primary" @click="toLogin('form')" :loading="loading">
                {{ $t("login.btn") }}
              </el-button>
            </el-form-item>
          </el-form>
          <!-- 编码注册 -->
          <div class="coding">
            <a href="javascript:;" @click="$router.push('/register')">{{ $t("login.Register") }}&nbsp
            </a>
            <a href="javascript:;" @click="$router.push('/cancelRegister')" :class="{ hidden: lang == 'en_US' }">&nbsp{{ $t("login.Unregister") }}&nbsp
            </a>
            <a href="javascript:;">&nbsp;{{ $t("login.Activation") }}</a>
          </div>
          <!-- 交易示范 -->
          <div class="trading" v-if="!(lang == 'en_US')">
            <span>請
              <a href="http://gb.htisec.com/gb/www.htisec.com/chi/cs/demo/sec_trade/index_new.html" target="_blank">按此</a>
              以收看 “網上證券交易服務示範”</span>
          </div>
        </div>
      </div>
      <div class="box-bottom">
        <span>
          {{ $t("login.Caution") }}
        </span>
      </div>
    </div>
    <div class="login-bottom">
      <div class="text">
        <span>
          {{ $t("login.kefu") }}
        </span>
      </div>
      <div class="text1">
        <span>
          {{ $t("login.company") }}
        </span>
      </div>
    </div>
    <!-- 保留密码弹窗 -->
    <popover :title="$t('mySettings.changePassword.changePassword')" @close="closePopover" :showPopover="showPopover">
      <div class="left-wrap">
        <div class="explain-wrap">
          <div class="explain-content">{{$t('login.prompt1')}}</div>
        </div>
        <div class="button-wrap">
          <el-button type="primary" @click="$router.push('/changePd')">{{$t('mySettings.changePassword.changePassword')}}</el-button>
          <el-button v-if="userData.newSubCode=='GRACECNT'&& userData.allowKeepPassword == true" type="primary" @click="keepPasswd">{{$t('login.keep')}}</el-button>
        </div>
      </div>
    </popover>
    <!-- 注册otp弹框 -->
    <addDialog ref="addDialog"></addDialog>
    <!-- 注册otp弹框 -->
    <addDialogs ref="addDialogs"></addDialogs>
  </div>
</template>

<script>
import * as event from "@/utils/EventEmitter.js"
import { localGet, localSet } from '@/utils/mylocal.js'
import { login1FaApi } from '@/api/login'
import { keepPasswordApi } from '@/api/layout'
import errTables from '@/utils/errTables'
import popover from "@/components/popover"
import addDialog from './addDialog'
import addDialogs from './addDialogs'
export default {
  components: {
    popover,
    addDialog,
    addDialogs
  },
  data() {
    return {
      showPopover: false, //是否显示弹出更改密码
      loading: false,
      show: false,
      userData: '',
      form: {
        loginId: "0273376A",
        password: "00000000"
      },
      // 切换语言的值
      lang: "",
      //  校验规则
      rules: {
        loginId: [
          {
            required: true,
            message: this.$t("login.information1"),
            trigger: "blur"
          }
        ],
        password: [
          {
            required: true,
            message: this.$t("login.information2"),
            trigger: "blur"
          }
        ],

      },

    };
  },
  created() {
    let _self = this;
    window.document.onkeydown = function (e) {
      let key = window.event.keyCode;
      if (key == 13 || key == 100) {
        _self.toLogin();
      }
    }
    // 判断token是否存在
    if (localGet('token')) {
      // 存在，跳入首页
      this.$router.push('/')
    }
  },
  mounted() {
    event.addListener("langChange", this.onCommand);
    this.lang = localGet("lang") || "zh_TW";
    localStorage.setItem('hasInterceptors', 'false');
  },
  methods: {
    //关闭弹窗按钮
    closePopover() {
      this.showPopover = false
    },
    // 登录按钮点击事件
    toLogin(form) {
      // 登录全局效验
      this.$refs.form.validate(val => {
        if (val) {
          // 将加载状态设置为 true
          this.loading = true
          // 如果校验成功，发送登陆请求
          login1FaApi({
            loginId: this.form.loginId,
            password: this.form.password,
            lang: this.lang
          }).then(res => {
            sessionStorage.setItem('userData', JSON.stringify(res.data))
            this.userData = JSON.parse(sessionStorage.getItem("userData"));
            // this.$store.commit('saveUserInfo', user_data);
            // 将加载状态设置为 false
            this.loading = false
            // 校验登录状态提示信息
            if (res.data.returnStatus == "NORMAL") {
              // 1FA账号直接跳转
              if (res.data.authOptions.length == 0) {
                // 登录成功后存储token
                sessionStorage.setItem('token', res.headers['token'])
                // 跳转到风险披露声明页
                this.$router.push('/risk')
              } else {
                sessionStorage.setItem('authenticationType', res.data.authenticationType)
                if (res.data.authOptions[0].enrollmentStatus == 'Y' && res.data.mobilieRequired == false) {
                  // 跳转填写验证码页面
                  this.$router.push({
                    name: 'code',
                    // params: {
                    //   val
                    // }
                  })
                } else if (res.data.authOptions[0].enrollmentStatus == 'NA' || res.data.authOptions[0].enrollmentStatus == 'Y' && res.data.mobilieRequired == true) {
                  // 跳转2FA登录验证页面
                  this.$router.push("/twoFaLogin");
                } else if (res.data.authOptions[0].enrollmentStatus == 'N' && res.data.mobilieRequired == false) {
                  // 打开注册OTP弹窗
                  this.$refs.addDialog.isShow = true
                } else if (res.data.authOptions[0].enrollmentStatus == 'N' && res.data.mobilieRequired == true) {
                  // 打开注册OTP弹窗
                  this.$refs.addDialogs.isShow = true
                }
              }
            } else if (res.data.returnStatus == "WARRNING") {
              if (res.data.authOptions.length == 0) {
                // 登录成功后存储token
                sessionStorage.setItem('token', res.headers['token'])
              }
              if (res.data.newSubCode == 'ISSUED' || res.data.newSubCode == 'CHGPASS') {
                this.$notify({
                  message: this.$t(errTables[res.data.newSubCode]),
                  duration: 3000
                });
                // 跳转强制更改密码页面
                this.$router.push("/changePd");
              } else if (res.data.newSubCode == 'GRACECNT') {
                this.showPopover = true
              } else if (res.data.newSubCode == 'GRACECNT' && res.data.allowKeepPassword == true) {
                this.showPopover = true
              }
            } else {
              this.$notify({
                message: this.$t(errTables[res.data.errorCode]),
                duration: 3000
              });
            }
          }).catch(error => {
            console.log(error);
          });
        } else {
          // 将加载状态设置为 false
          this.loading = false
        }
      });
    },
    onCommand(lang) {
      this.lang = lang;
    },
    keepPasswd() {
      keepPasswordApi({}).then(res => {
        if (res.data.returnStatus == "NORMAL") {
          this.showPopover = false
          this.$router.push('/risk')
        } else {
          this.$notify({
            message: this.$t(errTables[res.data.errorCode]),
            duration: 3000
          });
        }
      })
    }
  }
};
</script>

<style lang="scss" scoped>
.login {
  position: relative;
  overflow: auto;
  width: 100%;
  height: 100%;
  .img {
    position: absolute;
    top: 0px;
    right: 0px;
    width: 815px;
    height: 844px;
    z-index: -99;
    img {
      width: 100%;
      height: 100%;
    }
  }
  .imgs {
    position: absolute;
    right: 30px;
    top: 20px;
    width: 160px;
    height: 80px;
    img {
      width: 100%;
      height: 100%;
    }
  }
  .box {
    width: 880px;
    margin: 150px auto 150px;
    min-height: calc(100vh - 371px);
    .box-top {
      display: flex;
      .box-left {
        position: relative;
        width: 400px;
        height: 520px;
        background: #003da5;
        z-index: 0;
        .logo {
          margin: 50px auto 20px;
          width: 280px;
          height: 96px;
          img {
            width: 100%;
            height: 100%;
          }
        }
        .text {
          display: block;
          text-align: center;
          font-family: SourceHanSansCN-Heavy;
          font-size: 30px;
          color: #ffffff;
          letter-spacing: 4.5px;
          line-height: 20px;
        }
        .txt {
          font-family: Avenir-Heavy;
          letter-spacing: 0px;
          font-size: 20px;
        }
        .left-bg {
          position: absolute;
          left: 0;
          bottom: -4px;
          z-index: -10;
          img {
            width: 100%;
            height: 100%;
          }
        }
      }
      .box-right {
        padding: 24px 35px 0px;
        width: 480px;
        height: 520px;
        background: #ffffff;
        .box-title {
          width: 100%;
          height: 48px;
          border-bottom: 1px solid rgba(51, 51, 51, 0.25);
          span {
            display: inline-block;
            height: 47px;
            border-bottom: 2px solid #003da5;
            font-family: SourceHanSansCN-Medium;
            font-size: 20px;
            color: #003da5;
            line-height: 47px;
            font-weight: 550;
          }
        }
        .form {
          margin-top: 40px;
          >>> .el-form-item__content {
            width: 100%;
          }
          .el-form-item {
            margin-right: 0px;
            .el-input {
              position: relative;
              width: 410px;
              font-family: SourceHanSansCN-Medium;
              font-size: 18px;
              color: rgba(51, 51, 51, 0.75);
              >>> .el-input__inner {
                padding-left: 48px;
                height: 48px;
              }
              >>> .el-input__clear {
                font-size: 20px;
              }
              >>> .el-input__suffix {
                padding: 5px 60px 0 0;
                border-left: none;
              }
              .icon-header_eye_hide,
              .icon-header_eye_show {
                position: absolute;
                top: 6.4px;
                right: -3px;
              }
              .icon-login_username,
              .icon-login_password {
                padding-left: 8px;
                font-size: 24px;
                color: #003da5;
                line-height: 48px;
              }
            }
          }
          .btn {
            margin-top: 12px;
            width: 410px;
            font-size: 16px;
          }
          .ft-pw {
            font-size: 14px;
            color: #003da5;
            letter-spacing: 1px;
          }
        }
        .coding {
          display: flex;
          flex-wrap: wrap;
          width: 100%;
          font-family: SourceHanSansCN-Regular;
          font-size: 14px;
          color: #003da5;
          letter-spacing: 1px;
          line-height: 15px;
          a {
            padding: 2px 0;
            border-right: 1px solid rgba(51, 51, 51, 0.25);
            &:nth-child(3n) {
              border-right: none;
            }
          }
          .hidden {
            border-right: none;
          }
        }
        .trading {
          margin-top: 120px;
          font-family: SourceHanSansCN-Regular;
          text-align: center;
          font-size: 14px;
          color: rgba(51, 51, 51, 0.75);
          a {
            color: #4191ff;
            border-bottom: 1px solid #4191ff;
          }
        }
      }
    }
    .box-bottom {
      padding: 6px 0px 8px 10px;
      width: 100%;
      color: #333333;
      background: rgba(183, 191, 16, 0.25);
      font-size: 12px;
      font-family: SourceHanSansCN-Regular;
    }
  }
  .login-bottom {
    // position: fixed;
    // bottom: 0px;
    width: 100%;
    .text {
      padding: 8px 20px;
      text-align: left;
      width: 100%;
      font-size: 12px;
      color: #1a1a1a;
      font-family: PingFangSC-Regular;
      background: rgba(183, 191, 16, 0.25);
    }
    .text1 {
      padding: 10px 40px;
      width: 100%;
      font-family: SourceHanSansCN-Regular;
      background: #00244c;
      font-size: 14px;
      color: #ffffff;
      text-align: left;
    }
  }
  .left-wrap {
    padding: 12px;
    background: #fff;
    .password-form {
      >>> .el-form-item__label {
        font-family: SourceHanSansCN-Regular;
        font-size: 16px;
        color: rgba(51, 51, 51, 0.75);
      }
      >>> .el-input__suffix {
        border-left: none;
      }
      >>> .el-input__inner {
        width: 220px;
      }
    }
    .btn-wrap {
      padding: 36px 0;
      text-align: right;
    }
    .button-wrap {
      padding: 36px 0;
      text-align: center;
    }
  }
  .explain-wrap {
    font-family: SourceHanSansCN-Regular;
    font-size: 16px;
    color: rgba(51, 51, 51, 0.75);
    line-height: 20px;
    .explain-title {
      font-family: SourceHanSansCN-Medium;
      font-size: 16px;
      color: #333333;
      padding: 12px 0;
    }
  }
  .second-wrap {
    width: 100%;
    height: 100%;
    padding: 24px;
    .success-wrap {
      text-align: center;
      span {
        display: block;
      }
      .icons {
        padding: 24px 0;
        i {
          font-size: 58px;
          color: #003da5;
        }
      }
      .text {
        font-family: SourceHanSansCN-Medium;
        font-size: 18px;
        color: #003da5;
      }
    }
  }
}
@media screen and (max-height: 940px) {
  .login .box {
      box-shadow: 10px 20px 24px 0 rgba(0, 0, 0, 0.1);
  }
}
@media screen and (max-width: 768px) {
  .login {
    width: 100%;
    min-height: 100%;
  }
  .login .img {
    display: none;
  }
  .login .imgs {
    display: none;
  }
  .login .box {
    width: 100%;
    margin: 0;
    box-shadow: none;
    min-height: calc(100vh - 118px);
  }
  .login .box .box-top {
    flex-wrap: wrap;
  }
  .login .box .box-top .box-left {
    width: 100%;
    height: 241px;
    overflow: hidden;
  }
  .login .box .box-top .box-left .logo {
    margin: 48px auto 20px;
    width: 280px;
    height: 96px;
  }
  .login .box .box-top .box-left .left-bg {
    position: absolute;
    left: 0;
    top: 0;
    bottom: -100px;
    z-index: -10;
  }
  .login .box .box-top .box-left .left-bg img {
    width: 400px;
    height: auto;
  }
  .login .box .box-top .box-right {
    padding: 24px 12px 0px;
    width: 100%;
    height: 100%;
  }
  .login .box .box-top .box-right .box-title {
    width: 100%;
  }
  .login .box .box-top .box-right .form {
    width: 100%;
  }
  .login .box .box-top .box-right .form .el-form-item {
    width: 100%;
  }
  .login
    .box
    .box-top
    .box-right
    .form
    .el-form-item
    .el-form-item__content
    .el-input {
    width: 100%;
  }
  .login .box .box-top .box-right .form .btn {
    width: 100%;
  }
  .login .box .box-top .box-right .coding {
    width: 100%;
    justify-content: center;
    letter-spacing: 0px;
  }
  .login .box .box-top .box-right .coding .hidden {
    border-right: 1px solid rgba(51, 51, 51, 0.25);
  }
  .login .box .box-top .box-right .trading {
    display: none;
  }
  .login .box .box-bottom {
    margin: 50px 0 30px;
  }
  .login .login-bottom .text {
    padding: 12px;
  }
  .login .login-bottom .text1 {
    padding: 12px;
  }
  // .login .login-bottom {
  //   position: static;
  // }
}

// @media screen and (min-width: 375px) and(max-width: 540px) {
//   .login .box .box-top .box-left .left-bg img {
//     width: 70%;
//     height: auto;
//   }
// }
// @media screen and (max-width: 375px) {
//   .login .box .box-top .box-left .left-bg img {
//     width: 400px;
//     height: auto;
//   }
// }
</style>
