<template>
  <!-- 用户密码登陆页 -->
  <div class="login">
    <div class="imgs">
      <a v-if="lang == 'en_US'" href="http://www.htisec.com/en-us/account-opening"><img src="@/assets/img/开设户口_EN@2x.png" alt="" /></a>
      <a v-else-if="lang == 'zh_TW'" href="http://www.htisec.com/zh-hk/account-opening"><img src="@/assets/img/login_开设户口@3x.png" alt="" /></a>
      <a v-else href="http://www.htisec.com/zh-cn/account-opening"><img src="@/assets/img/开设户口_SC@2x.png" alt="" /></a>
    </div>
    <div class="box">
      <div class="box-top">
        <div class="box-left">
          <div class="logo">
            <img src="@/assets/img/login_HT_logo@3x.png" alt="" />
          </div>
          <span class="text" :class="[lang == 'en_US' ? 'txt' : '']">
            {{ $t("login.system") }}
          </span>
        </div>
        <div class="box-right">
          <div class="box-title">
            <span>{{ $t("login.customer") }}</span>
          </div>
          <!-- 表单 -->
          <el-form :model="form" :rules="rules" ref="form" class="form" :inline="true">
            <el-form-item prop="loginId">
              <el-input :placeholder="$t('login.name')" v-model="form.loginId" clearable>
                <i slot="prefix" class="iconfont icon-login_username"></i>
              </el-input>
            </el-form-item>
            <el-form-item prop="password">
              <el-input :type="show?'text':'password'" :placeholder="$t('login.password')" v-model="form.password" clearable>
                <i slot="prefix" class="iconfont icon-login_password"></i>
                <i v-if="form.password!==''" slot="suffix" @click="show=!show" :class="show?'iconfont icon-header_eye_show':'iconfont icon-header_eye_hide'"></i>
              </el-input>
            </el-form-item>
            <!-- 忘记密码 -->
            <a class="ft-pw fr" href="javascript:;">{{$t("login.ForgetPassword")}}</a>
            <el-form-item>
              <el-button class="btn" type="primary" @click="toLogin('form')" :loading="loading">
                {{ $t("login.btn") }}
              </el-button>
            </el-form-item>
          </el-form>
          <!-- 编码注册 -->
          <div class="coding">
            <a href="javascript:;" @click="$router.push('/register')">{{ $t("login.Register") }}&nbsp;
            </a>
            <a href="javascript:;" @click="$router.push('/cancelRegister')" :class="{ hidden: lang == 'en_US' }">&nbsp;{{ $t("login.Unregister") }}&nbsp;
            </a>
            <a href="javascript:;">&nbsp;{{ $t("login.Activation") }}</a>
          </div>
          <!-- 交易示范 -->
          <div class="trading" v-if="!(lang == 'en_US')">
            <span>請
              <a href="http://gb.htisec.com/gb/www.htisec.com/chi/cs/demo/sec_trade/index_new.html" target="_blank">按此</a>
              以收看 “網上證券交易服務示範”</span>
          </div>
        </div>
      </div>
      <div class="box-bottom">
        <span>
          {{ $t("login.Caution") }}
        </span>
      </div>
    </div>
    <div class="login-bottom">
      <div class="text">
        <span>
          {{ $t("login.kefu") }}
        </span>
      </div>
      <div class="text1">
        <span>
          {{ $t("login.company") }}
        </span>
      </div>
    </div>
    <!-- 保留密码弹窗 -->
    <popover :title="$t('mySettings.changePassword.changePassword')" @close="closePopover" :showPopover="showPopover">
      <div class="left-wrap">
        <div class="explain-wrap">
          <div class="explain-content">{{$t('login.prompt1')}}</div>
        </div>
        <div class="button-wrap">
          <el-button type="primary" @click="$router.push('/changePd')">{{$t('mySettings.changePassword.changePassword')}}</el-button>
          <el-button v-if="userData.newSubCode=='GRACECNT'&& userData.allowKeepPassword == true" type="primary" @click="keepPasswd">{{$t('login.keep')}}</el-button>
        </div>
      </div>
    </popover>
    <!-- 注册otp弹框 -->
    <addDialog ref="addDialog"></addDialog>
    <!-- 注册otp弹框 -->
    <addDialogs ref="addDialogs"></addDialogs>
  </div>
</template>

<script>
import * as event from "@/utils/EventEmitter.js"
import { localGet, localSet } from '@/utils/mylocal.js'
import { login1FaApi } from '@/api/login'
import { keepPasswordApi } from '@/api/layout'
import errTables from '@/utils/errTables'
import popover from "@/components/popover"
import addDialog from './addDialog'
import addDialogs from './addDialogs'
import login from './login.scss'

export default {
  components: {
    popover,
    addDialog,
    addDialogs
  },
  data() {
    return {
      showPopover: false, //是否显示弹出更改密码
      loading: false,
      show: false,
      userData: '',
      form: {
        loginId: "0273376A",
        password: "00000000"
      },
      // 切换语言的值
      lang: "",
      //  校验规则
      rules: {
        loginId: [
          {
            required: true,
            message: this.$t("login.information1"),
            trigger: "blur"
          }
        ],
        password: [
          {
            required: true,
            message: this.$t("login.information2"),
            trigger: "blur"
          }
        ],

      },

    };
  },
  created() {
    let _self = this;
    window.document.onkeydown = function (e) {
      let key = window.event.keyCode;
      if (key == 13 || key == 100) {
        _self.toLogin();
      }
    }
    // 判断token是否存在
    if (localGet('token')) {
      // 存在，跳入首页
      this.$router.push('/')
    }
  },
  mounted() {
    event.addListener("langChange", this.onCommand);
    this.lang = localGet("lang") || "zh_TW";
    localStorage.setItem('hasInterceptors', 'false');
  },
  methods: {
    //关闭弹窗按钮
    closePopover() {
      this.showPopover = false
    },
    // 登录按钮点击事件
    toLogin(form) {
      // 登录全局效验
      this.$refs.form.validate(val => {
        if (val) {
          // 将加载状态设置为 true
          this.loading = true
          // 如果校验成功，发送登陆请求
          login1FaApi({
            loginId: this.form.loginId,
            password: this.form.password,
            lang: this.lang
          }).then(res => {
            sessionStorage.setItem('userData', JSON.stringify(res.data))
            this.userData = JSON.parse(sessionStorage.getItem("userData"));
            // this.$store.commit('saveUserInfo', user_data);
            // 将加载状态设置为 false
            this.loading = false
            // 校验登录状态提示信息
            if (res.data.returnStatus == "NORMAL") {
              // 1FA账号直接跳转
              if (res.data.authOptions.length == 0) {
                // 登录成功后存储token
                sessionStorage.setItem('token', res.headers['token'])
                // 跳转到风险披露声明页
                this.$router.push('/risk')
              } else {
                sessionStorage.setItem('authenticationType', res.data.authenticationType)
                if (res.data.authOptions[0].enrollmentStatus == 'Y' && res.data.mobilieRequired == false) {
                  // 跳转填写验证码页面
                  this.$router.push({
                    name: 'code',
                    // params: {
                    //   val
                    // }
                  })
                } else if (res.data.authOptions[0].enrollmentStatus == 'NA' || res.data.authOptions[0].enrollmentStatus == 'Y' && res.data.mobilieRequired == true) {
                  // 跳转2FA登录验证页面
                  this.$router.push("/twoFaLogin");
                } else if (res.data.authOptions[0].enrollmentStatus == 'N' && res.data.mobilieRequired == false) {
                  // 打开注册OTP弹窗
                  this.$refs.addDialog.isShow = true
                } else if (res.data.authOptions[0].enrollmentStatus == 'N' && res.data.mobilieRequired == true) {
                  // 打开注册OTP弹窗
                  this.$refs.addDialogs.isShow = true
                }
              }
            } else if (res.data.returnStatus == "WARRNING") {
              if (res.data.authOptions.length == 0) {
                // 登录成功后存储token
                sessionStorage.setItem('token', res.headers['token'])
              }
              if (res.data.newSubCode == 'ISSUED' || res.data.newSubCode == 'CHGPASS') {
                this.$notify({
                  message: this.$t(errTables[res.data.newSubCode]),
                  duration: 3000
                });
                // 跳转强制更改密码页面
                this.$router.push("/changePd");
              } else if (res.data.newSubCode == 'GRACECNT') {
                this.showPopover = true
              } else if (res.data.newSubCode == 'GRACECNT' && res.data.allowKeepPassword == true) {
                this.showPopover = true
              }
            } else {
              this.$notify({
                message: this.$t(errTables[res.data.errorCode]),
                duration: 3000
              });
            }
          }).catch(error => {
            console.log(error);
          });
        } else {
          // 将加载状态设置为 false
          this.loading = false
        }
      });
    },
    onCommand(lang) {
      this.lang = lang;
    },
    keepPasswd() {
      keepPasswordApi({}).then(res => {
        if (res.data.returnStatus == "NORMAL") {
          this.showPopover = false
          this.$router.push('/risk')
        } else {
          this.$notify({
            message: this.$t(errTables[res.data.errorCode]),
            duration: 3000
          });
        }
      })
    }
  }
};
</script>


