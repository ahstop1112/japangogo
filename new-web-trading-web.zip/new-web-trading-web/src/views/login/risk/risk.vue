<template>
  <!-- 风险披露声明页面 -->
  <div class="risk">
    <div class="top">
      <img src="@/assets/login_HT_logo_blue@3x.png" alt="" />
    </div>
    <div class="box">
      <div class="content">
        <el-scrollbar wrap-class="scrollbar-wrapper" style="height: 100%;">
          <span v-html="$t('risk.content1')"></span>
          <span v-html="$t('risk.content2')" class="center"></span>
        </el-scrollbar>
      </div>
    </div>

    <div class="btn">
      <el-button type="primary" @click="toHome">{{
        $t('twoFaLogin.phoneLogin.btn2')
      }}</el-button>
    </div>
  </div>
</template>

<script>
import { localGet } from '@/utils/mylocal'
export default {
  data() {
    return {
      userData: ''
    }
  },
  created() {
    let _self = this;
    window.document.onkeydown = function (e) {
      let key = window.event.keyCode;
      if (key == 13 || key == 100) {
        _self.toHome();
      }
    }
    this.userData = JSON.parse(sessionStorage.getItem("userData"));
  },
  methods: {
    toHome() {
      this.$router.push('/')
      // 获取保安提示弹窗的不提示选中状态
      const checked = localGet('checked')
      // 获取北向交易声明弹窗的不提示选中状态
      const checked1 = localGet('checked1')
      // if (this.$store.state.user_data.hasOwnProperty('02-0233221-33') && !checked) {
      //   // 新窗口打开保安提示
      //   let prompt = this.$router.resolve({ path: "/prompt" });
      //   window.open(prompt.href, "_blank");
      // } else if (this.$store.state.user_data.hasOwnProperty('02-0273376-33') && !checked) {
      //   // 新窗口打开保安提示
      //   let prompt = this.$router.resolve({ path: "/prompt" });
      //   window.open(prompt.href, "_blank");
      // }



      if (!checked) {
        // 新窗口打开保安提示
        let prompt = this.$router.resolve({ path: "/prompt" });
        window.open(prompt.href, "_blank");
      }
      if (this.userData.nbTrdEcnsntAllw == true) {
        if (!checked1) {
          // 新窗口打开北向交易声明弹窗
          let prompt = this.$router.resolve({ path: "/mySettings/consentForConnect" });
          window.open(prompt.href, "_blank");
        }
      }
    }
  }
}
</script>

<style lang="scss" scoped>
.risk {
  a {
    font-family: SourceHanSansCN-Medium;
    font-size: 16px;
    color: #4191ff;
    letter-spacing: 0;
    line-height: 12px;
    border-bottom: 1px solid #4191ff;
  }
  .top {
    margin: 64px 0 23px;
    text-align: center;
    img {
      width: 280px;
      height: 96px;
    }
  }
  .box {
    margin: 0 auto;
    width: 1000px;
    @media screen and (max-width: 1000px) {
      padding: 0 24px;
      width: 100%;
    }
    @media screen and (max-width: 768px) {
      padding: 0 12px;
      width: 100%;
    }
    .content {
      padding: 20px;
      word-wrap: break-word;
      word-break: normal;
      width: 100%;
      height: 600px;
      border: 1px solid rgba(0, 61, 165, 0.1);
      font-family: SourceHanSansCN-Regular;
      font-size: 16px;
      color: rgba(51, 51, 51, 0.75);
      letter-spacing: 0;
      line-height: 20px;
      .center {
        display: block;
        text-align: center;
      }
    }
  }
  .btn {
    text-align: center;
  }
  .el-button {
    margin: 40px 0;
    width: 120px;
    height: 40px;
    font-family: SourceHanSansCN-Bold;
    font-size: 16px;
    color: #ffffff;
    letter-spacing: 0;
    text-align: center;
    line-height: 16px;
  }
}
</style>
