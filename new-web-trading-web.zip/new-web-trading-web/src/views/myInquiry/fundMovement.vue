
<!--资金记录(我的查询)-->
<template>
  <div class="fundMovement-wrap">
    <pageNav :routerArr="routerArr" />
    <div class="content-wrap">
      <keep-alive>
        <router-view />
      </keep-alive>
    </div>
  </div>
</template>

<script>
import pageNav from "@/components/pageNav"
import { mapGetters } from 'vuex'
export default {
  data() {
    return {
      routerArr: []
    };
  },
  computed: {
    ...mapGetters(['getLang'])
  },
  components: {
    pageNav
  },
  watch: {
    getLang: {
      handler: function (o, n) {
        this.routerArr = [
          {
            name: this.$t('myInquiry.fundMovement.currencyExchangeRecord.title'),
            path: "exchange"
          },
          {
            name: this.$t('myInquiry.fundMovement.escrowRecords.title'),
            path: "escrow"
          }
        ]
        const userData = JSON.parse(sessionStorage.getItem("userData"));
        if (userData.primeBrokerageFunds.length !== 0) {
          this.routerArr.splice(0, 1)
          return
        }
        // else {
        //   for (let i = 0; i < userData.accountProfiles.length; i++) {
        //     if (userData.accountProfiles[i].entityRole == "TPA" || userData.accountProfiles[i].entityRole == "AP") {
        //       this.routerArr.splice(0, 1)
        //     }
        //     return
        //   }
        //   return
        // }

      },
      immediate: true
    }
  },
  methods: {},
  mounted() { },

}

</script>
<style lang='scss' scoped>
.fundMovement-wrap {
  width: 100%;
  .content-wrap {
    margin-top: 24px;
  }
}
@media screen and (max-width: 768px) {
  .fundMovement-wrap .router-wrap .router-item {
    padding-left: 12px;
  }
  .fundMovement-wrap .content-wrap {
    margin-top: 12px;
  }
}
</style>