<!--公司行动-->
<template>
  <div class="companyAction-wrap">
    <popover :title="$t('myInquiry.tradeHistory.companyAction.xiugai')" @close="closePopover" :showPopover="showPopover">
      <div class="first-wrap" v-if="firstStep">
        <ul class="base-info">
          <li class="info-item">
            <span class="txt mediumColor">{{$t('myInquiry.tradeHistory.companyAction.cankaobianhao')}}</span>
            <span class="val heavyColor">CA07499550</span>
          </li>
          <li class="info-item">
            <span class="txt mediumColor">{{$t('myInquiry.tradeHistory.companyAction.guxi')}}</span>
            <span class="val heavyColor">港元2.1354</span>
          </li>
          <li class="info-item">
            <span class="txt mediumColor">{{$t('myInquiry.tradeHistory.companyAction.xingujia')}}</span>
            <span class="val heavyColor">港元 5.68</span>
          </li>
        </ul>
        <div class="explain-wrap mediumColor">
          <div class="explain-item">{{$t('myInquiry.tradeHistory.companyAction.jieshi1')}}</div>
          <div class="explain-title">{{$t('myInquiry.tradeHistory.companyAction.jieshi2')}}</div>
          <div class="explain-item1 heavyColor">{{$t('myInquiry.tradeHistory.companyAction.jieshi3')}}：1,000</div>
        </div>
        <div class="check-wrap">
          <div class="checkbox-info">
            <el-radio-group v-model="radio">
              <el-radio :label="1">{{$t('myInquiry.tradeHistory.companyAction.xianjin')}}</el-radio>
              <el-radio :label="2">{{$t('myInquiry.tradeHistory.companyAction.xingu')}}</el-radio>
              <el-radio :label="3">{{$t('myInquiry.tradeHistory.companyAction.bufenxianjin')}}</el-radio>
            </el-radio-group>
          </div>
          <div class="checkbox-other contentLightColor" v-if="radio == 1 || radio == 3">
            <div class="detail-item" v-if="radio == 3">
              <span class="text heavyColor">{{$t('myInquiry.tradeHistory.companyAction.xuanze1')}}</span>
              <span class="set">
                <el-input-number size="mini" v-model="num1" @change="handleChange1" :step="100" :min="0"></el-input-number>
              </span>
            </div>
            <el-radio-group v-model="radio1">
              <el-radio :label="1">{{$t('myInquiry.tradeHistory.companyAction.ganyuan')}}</el-radio>
              <el-radio :label="2">{{$t('myInquiry.tradeHistory.companyAction.renmingbi')}}</el-radio>
              <el-radio :label="3">{{$t('myInquiry.tradeHistory.companyAction.meiyuan')}}</el-radio>
            </el-radio-group>
            <div class="detail-item" v-if="radio == 3">
              <span class="text heavyColor">{{$t('myInquiry.tradeHistory.companyAction.xuanze2')}}</span>
              <span class="set">
                <el-input-number size="mini" v-model="num2" @change="handleChange2" :step="100" :min="0"></el-input-number>
              </span>
            </div>
          </div>
        </div>
        <div class="confirm-btn">
          <el-button type="primary" @click="goToSuccess">{{$t('myInquiry.tradeHistory.companyAction.cofirm')}}</el-button>
        </div>
      </div>
      <div class="second-wrap" v-else>
        <div class="layout-wrap">
          <div class="success-wrap">
            <span class="icons"><i class="iconfont icon-status_success activeFontColor"></i></span>
            <span class="text activeFontColor">{{$t('myInquiry.tradeHistory.companyAction.xingdongtijiao')}}</span>
          </div>
        </div>
      </div>
    </popover>
    <div class="content-wrap contentBg">
      <div class="conditions">
        <conditionChoose :conditionArr="conditionArr" @btnChoose="btnChoose" />
      </div>
      <div class="conditions-info">
        <span class="exchange-text mediumColor">{{$t('myInquiry.tradeHistory.companyAction.gupiaobianhao')}} </span>
        <div class="date-wrap">
          <span class="conditions-btn heavyColor" :class="stockIndex == 0?'active':''" @click="stockIndex = 0">{{$t('myInquiry.tradeHistory.companyAction.all')}}</span>
          <span class="conditions-btn heavyColor" :class="stockIndex == 1?'active':''" @click="stockIndex = 1">{{$t('myInquiry.tradeHistory.companyAction.zhidinggupiao')}}</span>
          <div class="input-wrap">
            <el-input class="ipt" v-model="input" placeholder="AAPL  APPLE COMP INC">
            </el-input>
            <span class="icons contentLeftBorder" :title="$t('myInquiry.tradeHistory.companyAction.sousuo')">
              <img src="@/assets/search.png" />
            </span>
          </div>
        </div>
      </div>
      <div class="table-wrap">
        <div class="table-layout">
          <el-table :data="tableData" :row-class-name="tableRowClass" :header-cell-style="headeRowClass" style="width: 100%">
            <el-table-column :label="$t('myInquiry.tradeHistory.companyAction.market')" prop="market" width="80">
              <template slot-scope="scope">
                <span class="icons" style="vertical-align:middle;"><img width="18" src="@/assets/flag_HK@2x.png" /></span>
                <span class="text">{{scope.row.market}}</span>
              </template>
            </el-table-column>
            <el-table-column prop="stock" :label="$t('myInquiry.tradeHistory.companyAction.gupiao')">
            </el-table-column>
            <el-table-column prop="description" :label="$t('myInquiry.tradeHistory.companyAction.xingdong')">
            </el-table-column>
            <el-table-column prop="numberId" :label="$t('myInquiry.tradeHistory.companyAction.cankao')">
            </el-table-column>
            <el-table-column prop="tradeType" :label="$t('myInquiry.tradeHistory.companyAction.qudao')">
            </el-table-column>
            <el-table-column prop="type" :label="$t('myInquiry.tradeHistory.companyAction.leixing')">
            </el-table-column>
            <el-table-column prop="endDate" :label="$t('myInquiry.tradeHistory.companyAction.jiezhiriqi')">
            </el-table-column>
            <el-table-column prop="state" :label="$t('myInquiry.tradeHistory.companyAction.zhuangtai')">
            </el-table-column>
            <el-table-column fixed="right" align="right" width="80" :label="$t('myInquiry.tradeHistory.companyAction.caozuo')">
              <template slot-scope="scope">
                <span class="small-btn small-btn-blue" @click="openPopover" :class="{notClick:userData.allowTrade == false}">{{$t('myInquiry.tradeHistory.companyAction.editor')}}</span>
              </template>
            </el-table-column>
          </el-table>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import conditionChoose from '@/components/conditionChoose'
import popover from "@/components/popover"
import { mapGetters } from 'vuex'
export default {
  data() {
    return {
      conditionArr: [],
      stockIndex: 1,
      input: "",
      showPopover: false,
      radio: 1,
      radio1: 1,
      num1: "3000",
      num2: "3000",
      firstStep: true, //是否显示第一步
      tableData: [
        {
          market: "港股",
          stock: "00351 亞洲能源物流",
          description: "-",
          numberId: "CA07499550",
          tradeType: "網上交易",
          type: "股票股息",
          endDate: "2018-08-18",
          state: "已啟動",
        },
        {
          market: "港股",
          stock: "00352 凱富善集團控股有限公司",
          description: "-",
          numberId: "CA07499550",
          tradeType: "網上交易",
          type: "股票股息",
          endDate: "2018-08-18",
          state: "已啟動",
        }
      ],
      userData: ''
    };
  },
  watch: {
    getLang: {
      handler: function (o, n) {
        this.conditionArr = [
          {
            title: this.$t('myInquiry.tradeHistory.companyAction.market'),
            dataArr: [
              {
                name: this.$t('myInquiry.tradeHistory.companyAction.all'),
                code: "allMarket"
              },
              {
                name: this.$t('myInquiry.tradeHistory.companyAction.hkStock'),
                code: ""
              },
              {
                name: this.$t('myInquiry.tradeHistory.companyAction.hugutong'),
                code: ""
              },
              {
                name: this.$t('myInquiry.tradeHistory.companyAction.gangutong'),
                code: ""
              }
            ]
          },
          {
            title: this.$t('myInquiry.tradeHistory.companyAction.zhuangtai'),
            dataArr: [
              {
                name: this.$t('myInquiry.tradeHistory.companyAction.all'),
                code: "allMarket"
              },
              {
                name: this.$t('myInquiry.tradeHistory.companyAction.yiqidong'),
                code: ""
              },
              {
                name: this.$t('myInquiry.tradeHistory.companyAction.yijiezhi'),
                code: ""
              },
              {
                name: this.$t('myInquiry.tradeHistory.companyAction.yishouquan'),
                code: ""
              },
              {
                name: this.$t('myInquiry.tradeHistory.companyAction.yipaifa'),
                code: ""
              },
              {
                name: this.$t('myInquiry.tradeHistory.companyAction.yiwancheng'),
                code: ""
              }
            ]
          },
          {
            title: this.$t('myInquiry.tradeHistory.companyAction.leixing'),
            dataArr: [
              {
                name: this.$t('myInquiry.tradeHistory.companyAction.all'),
                code: "allMarket"
              },
              {
                name: this.$t('myInquiry.tradeHistory.companyAction.xianjinguxi'),
                code: ""
              },
              {
                name: this.$t('myInquiry.tradeHistory.companyAction.gupiaoguxi'),
                code: ""
              }
            ]
          }
        ]
      },
      immediate: true
    }
  },
  components: {
    conditionChoose,
    popover
  },
  computed: {
    ...mapGetters(['getLang', 'getBgColor'])
  },
  methods: {
    tableRowClass() {
      return 'tableRowClass'
    },
    headeRowClass({ row, column, rowIndex, columnIndex }) {
      //表头的背景颜色
      if (rowIndex == 0) {
        if (this.getBgColor == 'bg-anhei') {
          return 'background:rgb(51,51,51)';
        } else {
          return 'background:rgb(255,255,255)';
        }
      }
    },
    handleChange1(val) {
      console.log(val)
    },
    handleChange2(val) {
      console.log(val)
    },
    goToSuccess() {
      this.firstStep = false;
    },
    openPopover() {
      if (this.userData.allowTrade !== false) {
        this.firstStep = true;
        this.showPopover = true;
      }
    },
    //隐藏弹窗
    closePopover() {
      this.showPopover = false;
    },
    btnChoose(dataArr) {
      console.log(dataArr)
    }
  },
  created() {
    this.userData = JSON.parse(sessionStorage.getItem("userData"));
  },
  mounted() { },

}

</script>
<style lang='scss' scoped>
.companyAction-wrap {
  width: 100%;
  .first-wrap {
    width: 100%;
    .base-info {
      padding: 24px 24px 12px 24px;
      .info-item {
        padding: 4px 0;
        display: flex;
        flex-wrap: wrap;
        align-content: flex-start;
        .txt {
          font-family: SourceHanSansCN-Regular;
          font-size: 16px;
          flex: 0 0 100px;
          line-height: 20px;
        }
        .val {
          flex: 1;
          font-family: Avenir-Book;
          font-size: 16px;
          text-align: right;
          line-height: 18px;
        }
      }
    }
    .explain-wrap {
      padding: 0 24px 12px 24px;
      font-family: SourceHanSansCN-Regular;
      font-size: 14px;
      .explain-item {
        line-height: 16px;
      }
      .explain-title {
        padding: 6px 0;
        font-size: 16px;
      }
      .explain-item1 {
        font-family: SourceHanSansCN-Regular;
        font-size: 16px;
        line-height: 16px;
      }
    }
    .check-wrap {
      padding: 12px 24px 24px 24px;
      .checkbox-info {
      }
      .checkbox-other {
        padding: 12px 6px 4px 6px;
        margin-top: 12px;
        .detail-item {
          display: flex;
          padding: 6px 0;
          .text {
            flex: 1;
            padding-right: 6px;
            font-size: 14px;
          }
          .set {
            height: 36px;
          }
        }
      }
    }
    .confirm-btn {
      padding: 0 24px 24px 24px;
      text-align: right;
    }
  }
  .second-wrap {
    .layout-wrap {
      width: 100%;
      height: 100%;
      padding: 24px;
      .success-wrap {
        text-align: center;
        span {
          display: block;
        }
        .icons {
          padding: 24px 0;
          i {
            font-size: 58px;
          }
        }
        .text {
          font-family: SourceHanSansCN-Medium;
          font-size: 18px;
        }
      }
    }
  }
  .content-wrap {
    width: 100%;
    padding: 24px;
    .conditions-info {
      display: flex;
      width: 100%;
      padding: 12px 0;
      flex-wrap: wrap;
      align-items: center;
      .exchange-text {
        font-family: SourceHanSansCN-Regular;
        font-size: 16px;
        flex: 0 0 80px;
      }
      .date-wrap {
        flex: 1;
        display: flex;
        flex-wrap: wrap;
        align-items: center;
        padding-left: 6px;
        .conditions-btn {
          display: inline-block;
          font-size: 16px;
          height: 24px;
          line-height: 24px;
          cursor: pointer;
          padding: 0 6px;
          margin-right: 4px;
          white-space: nowrap;
          &.active {
            color: #fff;
            font-family: SourceHanSansCN-Medium;
            background: #003da5;
            border-radius: 4px;
          }
        }
        .input-wrap {
          position: relative;
          padding-left: 12px;
          .icons {
            width: 36px;
            cursor: pointer;
            text-align: center;
            display: inline-block;
            height: 36px;
            line-height: 32px;
            position: absolute;
            right: 0;
            top: 0;
            img {
              display: inline-block;
              width: 24px;
              height: 24px;
              vertical-align: middle;
            }
            img:hover {
              opacity: 0.8;
            }
          }
        }
      }
    }
    .table-wrap {
      padding: 24px 0;
      .notClick {
        background: grey;
        cursor: not-allowed;
      }
    }
  }
}
@media screen and (max-width: 768px) {
  .companyAction-wrap .content-wrap {
    padding: 12px 12px 48px 12px;
  }
  .companyAction-wrap .content-wrap .table-wrap {
    padding: 12px 0;
  }
  .companyAction-wrap .content-wrap .conditions-info {
    align-items: normal;
  }
  .companyAction-wrap .content-wrap .conditions-info .date-wrap .input-wrap {
    margin-top: 12px;
    padding-left: 0;
  }
}
.el-radio-group {
  line-height: 24px;
}
</style>