<!--新股认购-->
<template>
  <div class="ipoSubsciption-wrap">
    <popover :title="$t('myInquiry.tradeHistory.ipoSub.cancelIPO')" @close="closePopover" :showPopover="showPopover">
      <div class="first-wrap" v-if="firstStep">
        <ul class="base-info">
          <li class="info-item">
            <span class="txt mediumColor">{{$t('myInquiry.tradeHistory.ipoSub.stockName')}}</span>
            <span class="val heavyColor">凯富善集团控股有限公司</span>
          </li>
          <li class="info-item">
            <span class="txt mediumColor">{{$t('myInquiry.tradeHistory.ipoSub.stockCode')}}</span>
            <span class="val heavyColor">08512</span>
          </li>
          <li class="info-item">
            <span class="txt mediumColor">{{$t('myInquiry.tradeHistory.ipoSub.zhaogujia')}}</span>
            <span class="val heavyColor">$0.36</span>
          </li>
          <li class="info-item">
            <span class="txt mediumColor">{{$t('myInquiry.tradeHistory.ipoSub.shengoushuliang')}}</span>
            <span class="val heavyColor">10,000</span>
          </li>
          <li class="info-item">
            <span class="txt mediumColor">{{$t('myInquiry.tradeHistory.ipoSub.shouxufei')}}</span>
            <span class="val heavyColor">$100</span>
          </li>
          <li class="info-item">
            <span class="txt mediumColor">{{$t('myInquiry.tradeHistory.ipoSub.shengoujine')}}</span>
            <span class="val heavyColor">$3,636.28</span>
          </li>
          <li class="info-item" v-if="isRongzi">
            <span class="txt mediumColor">{{$t('myInquiry.tradeHistory.ipoSub.rongzibili')}}</span>
            <span class="val heavyColor">90%</span>
          </li>
          <li class="info-item" v-if="isRongzi">
            <span class="txt mediumColor">{{$t('myInquiry.tradeHistory.ipoSub.cankaolilv')}}</span>
            <span class="val heavyColor">4.48%</span>
          </li>
          <li class="info-item">
            <span class="txt mediumColor">{{$t('myInquiry.tradeHistory.ipoSub.jiaoyijine')}}</span>
            <span class="val heavyColor">$463.63</span>
          </li>
          <li class="info-item">
            <span class="txt mediumColor">{{$t('myInquiry.tradeHistory.ipoSub.tishi')}}</span>
            <span class="val heavyColor">电邮地址</span>
          </li>
          <li class="info-item">
            <span class="txt mediumColor">{{$t('myInquiry.tradeHistory.ipoSub.zhishibianhao')}}</span>
            <span class="val heavyColor">1726502</span>
          </li>
          <li class="info-item">
            <span class="txt mediumColor">{{$t('myInquiry.tradeHistory.ipoSub.zhishizhuangkuang')}}</span>
            <span class="val heavyColor">已收到</span>
          </li>
        </ul>
        <div class="avg-wrap contentTopBorder">
          <span class="txt mediumColor">{{$t('myInquiry.tradeHistory.ipoSub.password')}}</span>
          <span class="val">
            <el-input v-model="password" :placeholder="$t('myInquiry.tradeHistory.ipoSub.tip')"></el-input>
          </span>
        </div>
        <div class="confirm-btn">
          <el-button type="primary" @click="goToSuccess">{{$t('myInquiry.tradeHistory.ipoSub.cofirm')}}</el-button>
        </div>
      </div>
      <div class="second-wrap" v-else>
        <div class="layout-wrap">
          <div class="success-wrap">
            <span class="icons"><i class="iconfont icon-status_success activeFontColor"></i></span>
            <span class="text activeFontColor">{{$t('myInquiry.tradeHistory.ipoSub.submitSuccess')}}</span>
          </div>
        </div>
      </div>
    </popover>
    <div class="table-wrap contentBg">
      <el-table :data="tableData" :row-class-name="tableRowClass" :header-cell-style="headeRowClass" style="width: 100%">
        <el-table-column prop="ipoId" :label="$t('myInquiry.tradeHistory.ipoSub.subscriptionId')">
        </el-table-column>
        <el-table-column prop="stockCode" :label="$t('myInquiry.tradeHistory.ipoSub.stockNum')">
        </el-table-column>
        <el-table-column prop="sellPrice" align="right" :label="$t('myInquiry.tradeHistory.ipoSub.biddingPrice')">
        </el-table-column>
        <el-table-column prop="buyNum" align="right" :label="$t('myInquiry.tradeHistory.ipoSub.subscriptionNum')">
        </el-table-column>
        <el-table-column prop="moenyType" align="center" :label="$t('myInquiry.tradeHistory.ipoSub.subscriptionType')">
        </el-table-column>
        <el-table-column prop="buyMoney" align="right" :label="$t('myInquiry.tradeHistory.ipoSub.subscriptionMoney')">
        </el-table-column>
        <el-table-column prop="servicePrice" align="right" :label="$t('myInquiry.tradeHistory.ipoSub.serviceCharge')">
        </el-table-column>
        <el-table-column prop="financing" align="right" :label="$t('myInquiry.tradeHistory.ipoSub.financingRatio')">
        </el-table-column>
        <el-table-column prop="rate" align="right" :label="$t('myInquiry.tradeHistory.ipoSub.rate')">
        </el-table-column>
        <el-table-column prop="costPrice" align="right" :label="$t('myInquiry.tradeHistory.ipoSub.tradeCost')">
        </el-table-column>
        <el-table-column prop="stockNum" align="right" :label="$t('myInquiry.tradeHistory.ipoSub.stockNum')">
        </el-table-column>
        <el-table-column prop="tradeType" align="center" :label="$t('myInquiry.tradeHistory.ipoSub.tradeChannel')">
        </el-table-column>
        <el-table-column prop="state" align="center" :label="$t('myInquiry.tradeHistory.ipoSub.state')">
        </el-table-column>
        <el-table-column fixed="right" align="right" width="70" :label="$t('myInquiry.tradeHistory.ipoSub.action')">
          <template slot-scope="scope">
            <span class="small-btn small-btn-blue" @click="openPopover(scope.row)" :class="{notClick:userData.allowTrade == false}">{{$t('myInquiry.tradeHistory.ipoSub.cancel')}}</span>
          </template>
        </el-table-column>
      </el-table>
    </div>
  </div>
</template>

<script>
import popover from "@/components/popover"
import { mapGetters } from 'vuex'
export default {
  data() {
    return {
      firstStep: true, //是否显示第一步
      showPopover: false,
      password: "",
      isRongzi: false,
      tableData: [
        {
          ipoId: "1736502",
          stockCode: "00351 亞洲能源物流",
          sellPrice: "0.36",
          buyNum: "10000",
          moenyType: "现金",
          buyMoney: "3636.28",
          servicePrice: "100.00",
          financing: "-",
          rate: "-",
          costPrice: "3.736.28",
          stockNum: "-",
          tradeType: "網上交易",
          state: "巳拒絶"
        },
        {
          ipoId: "1736501",
          stockCode: "00352 凱富善集團控股有限公司",
          sellPrice: "0.36",
          buyNum: "10000",
          moenyType: "融资",
          buyMoney: "3636.28",
          servicePrice: "100.00",
          financing: "90%",
          rate: "4.48%",
          costPrice: "$463.63",
          stockNum: "-",
          tradeType: "網上交易",
          state: "巳收到"
        }
      ],
      userData: ''

    };
  },
  components: {
    popover
  },
  computed: {
    ...mapGetters(['getBgColor'])
  },
  methods: {
    tableRowClass() {
      return 'tableRowClass'
    },
    headeRowClass({ row, column, rowIndex, columnIndex }) {
      //表头的背景颜色
      if (rowIndex == 0) {
        if (this.getBgColor == 'bg-anhei') {
          return 'background:rgb(51,51,51)';
        } else {
          return 'background:rgb(255,255,255)';
        }
      }
    },
    goToSuccess() {
      this.firstStep = false;
    },
    openPopover(val) {
      if (val.moenyType == '融资') {
        this.isRongzi = true;
      } else {
        this.isRongzi = false;
      }
      if (this.userData.allowTrade !== false) {
        this.firstStep = true;
        this.showPopover = true;
      }
    },
    //隐藏弹窗
    closePopover() {
      this.showPopover = false;
    },
  },
  created() {
    this.userData = JSON.parse(sessionStorage.getItem("userData"));
  },
  mounted() { },

}

</script>
<style lang='scss' scoped>
.table-wrap {
  padding: 24px;
  .notClick {
    background: grey;
    cursor: not-allowed;
  }
}
.first-wrap {
  width: 100%;
  .base-info {
    padding: 24px 24px 12px 24px;
    .info-item {
      padding: 4px 0;
      display: flex;
      flex-wrap: wrap;
      align-content: flex-start;
      .txt {
        font-family: SourceHanSansCN-Regular;
        font-size: 1rem;
        flex: 0 0 100px;
        line-height: 20px;
      }
      .val {
        flex: 1;
        font-family: Avenir-Book;
        font-size: 1rem;
        text-align: right;
        line-height: 18px;
      }
    }
  }
  .avg-wrap {
    width: 100%;
    padding: 24px;
    display: flex;
    align-items: center;
    .txt {
      flex: 0 0 80px;
      font-family: SourceHanSansCN-Regular;
      font-size: 1rem;
    }
    .val {
      flex: 1;
    }
  }
  .confirm-btn {
    padding: 0 24px 24px 24px;
    text-align: right;
  }
}
.second-wrap {
  .layout-wrap {
    width: 100%;
    height: 100%;
    padding: 24px;
    .success-wrap {
      text-align: center;
      span {
        display: block;
      }
      .icons {
        padding: 24px 0;
        i {
          font-size: 58px;
        }
      }
      .text {
        font-family: SourceHanSansCN-Medium;
        font-size: 18px;
      }
    }
  }
}
@media screen and (max-width: 768px) {
  .table-wrap {
    padding: 12px;
  }
}
</style>