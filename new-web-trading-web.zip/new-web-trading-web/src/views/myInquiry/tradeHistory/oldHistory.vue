<!--历史记录-->
<template>
  <div class="oldHistory-wrap">
    <div class="content-wrap contentBg">
        <div class="conditions">
            <conditionChoose :conditionArr="conditionArr" @btnChoose ="btnChoose"/>
        </div>
        <div class="conditions-info">
          <span class="exchange-text mediumColor">{{$t('myInquiry.tradeHistory.stockNum')}}</span>
          <div class="date-wrap">
            <span class="conditions-btn heavyColor" :class="stockIndex == 0?'active':''" @click="stockIndex = 0">{{$t('myInquiry.tradeHistory.all')}}</span>
            <span class="conditions-btn heavyColor" :class="stockIndex == 1?'active':''" @click="stockIndex = 1">{{$t('myInquiry.tradeHistory.specifyStock')}}</span>
            <div class="input-wrap">
              <el-input class="ipt" v-model="input" placeholder="AAPL  APPLE COMP INC">
              </el-input>
              <span class="icons contentLeftBorder">
                 <img src="@/assets/search.png" />
              </span>
            </div>
          </div>
        </div>
        <div class="conditions-info">
            <span class="exchange-text mediumColor">{{$t('myInquiry.tradeHistory.tradeDate')}}</span>
            <div class="date-wrap">
              <div class="date-picker">
                <timeSelector :range-separator="$t('myInquiry.tradeHistory.zhi')" 
                                                                 :start-placeholder="$t('myInquiry.tradeHistory.startDate')" 
                                                                 :end-placeholder="$t('myInquiry.tradeHistory.endDate')" @change="time">
                </timeSelector>
              </div>
            </div>
        </div>
        <div class="other-conditions">
            <span class="conditions-btn heavyColor" :class="btnIndex ==0?'active':''" @click="btnClick(0)">{{$t('myInquiry.tradeHistory.Summary')}}</span>
            <span class="conditions-btn heavyColor" :class="btnIndex ==1?'active':''" @click="btnClick(1)">{{$t('myInquiry.tradeHistory.detailed')}}</span>
            <span class="tip">{{$t('myInquiry.tradeHistory.recordTime')}} 2019-06-25 14:58:48</span>
        </div>
        <div class="table-wrap">
              <div class="table-layout" v-show="tableData.length">
                    <el-table
                      :data="tableData"
                      :row-class-name="tableRowClass"  
                      :header-cell-style="headeRowClass"
                      style="width: 100%">
                          <el-table-column
                              :key="item.prop"
                              v-for="item in colData"
                              :label="item.label"
                              :prop="item.prop"
                              :width="item.width"    
                              :align="item.align" 
                          >
                          </el-table-column>
                  </el-table>  
              </div>
              <div class="noResult" v-show="!tableData.length">
                  <noContent :content="$t('myInquiry.tradeHistory.noResult')" height="260px"/>
              </div>  
          </div>
    </div>  
    <div class="explain-wrap">
          <p class="explain-title heavyColor">{{$t('myInquiry.tradeHistory.remarks')}}</p>
          <p class="explain-item mediumColor">{{$t('myInquiry.tradeHistory.remark1')}}</p>
          <p class="explain-item mediumColor">{{$t('myInquiry.tradeHistory.remark2')}}</p>
          <p class="explain-item mediumColor">{{$t('myInquiry.tradeHistory.remark3')}}</p>
          <p class="explain-item mediumColor">{{$t('myInquiry.tradeHistory.remark4')}}
              <span class="explain-btn activeFontColor">{{$t('myInquiry.tradeHistory.remarkBtn1')}}</span>
              <span class="explain-btn activeFontColor">{{$t('myInquiry.tradeHistory.remarkBtn2')}}</span>
              。
          </p>
      </div>
  </div>
</template>

<script>
import conditionChoose from '@/components/conditionChoose'
import noContent from '@/components/noContent'
import {mapGetters} from 'vuex'
import timeSelector from '@/components/timeSelector'
export default {
  data () {
    return {
      conditionArr:[],
      btnIndex: 0,
      monthIndex:0,
      stockIndex: 1,
      value: '',
      input: '',
      colData: [],//列数据
      tableData: [ //表格数据
        {
          tradDate: "2018-12-17",
          endDate: "2018-12-28",
          market: "香港、中國A股、美國及場外市場",
          stockCode: "00665 海通国际 ",
          tradType: "买入",
          sellNum: "5000",
          currency: "HKD",
          avagPrice: "2.541",      
          price: "25,410.00",        
        },
        {
          tradDate: "2018-12-17",
          endDate: "2018-12-28",
          market: "香港、中國A股、美國及場外市場",
          stockCode: "AAPL  APPLE COMP INC",
          tradType: "卖出",
          sellNum: "500",
          currency: "USD",
          avagPrice: "147.541",      
          price: "14,754.10",       
        }
      ],
    };
  },
  watch: {
    getLang: {
      handler:function(o,n){
        this.conditionArr = [
            {
                title: this.$t('cash.fxConversion.market'),
                dataArr: [
                    {
                        name: this.$t('cash.fxConversion.allMarket'),
                        code: "allMarket"      
                    },
                    {
                        name: this.$t('cash.fxConversion.hkAUSAsotck'),
                        code: ""      
                    },
                    {
                        name: this.$t('cash.fxConversion.cnBStock'),
                        code: ""      
                    },
                    {
                        name: this.$t('cash.fxConversion.otherMarket'),
                        code: ""      
                    }
                ]
            },
            {
              title: this.$t('myInquiry.tradeHistory.tradeType'),
              dataArr: [
                  {
                      name: this.$t('myInquiry.tradeHistory.all'),
                      code: ""    
                  },
                  {
                      name:  this.$t('myInquiry.tradeHistory.buy'),
                      code: ""    
                  },
                  {
                      name: this.$t('myInquiry.tradeHistory.sell'),
                      code: ""    
                  }
              ]
            },
        ]
        this.changeCol(this.btnIndex);
      },
      immediate: true
    }
  },
  components: {
    conditionChoose,
    noContent,
    timeSelector
  },
  computed: {
    ...mapGetters(['getLang', 'getBgColor'])
  },
  methods: {
     tableRowClass() {
      return 'tableRowClass'
    },  
    headeRowClass({row, column, rowIndex, columnIndex}) {
       //表头的背景颜色
      if(rowIndex==0){
          if(this.getBgColor == 'bg-anhei') {
            return 'background:rgb(51,51,51)';
          }else{
            return 'background:rgb(255,255,255)';
          }
      }
    },
     changeCol(type) {
        if(type == 0) {
          this.colData = [ //表格列
              {
                  prop: 'tradDate',
                  label: this.$t('myInquiry.tradeHistory.tradeDate'),
                  width: 120,
                  align: 'left'              
              },
              {
                  prop: 'endDate',
                  width: 140,
                  label: this.$t('myInquiry.tradeHistory.settlementDate'),
                  align: 'left'              
              },
              {
                  prop: 'market',
                  label: this.$t('myInquiry.tradeHistory.market'),
                  align: 'left'              
              },
              {
                  prop: 'stockCode',
                  label: this.$t('myInquiry.tradeHistory.stock'),
                  align: 'left'              
              },
              {
                  prop: 'tradType',
                  label: this.$t('myInquiry.tradeHistory.tradeClasify'),
                  width: 80,
                  align: 'left'        
              },
              {
                  prop: 'sellNum',
                  label: this.$t('myInquiry.tradeHistory.tradeNum'),
                  align: 'right'         
              },
              {
                  prop: 'currency',
                  label: this.$t('myInquiry.tradeHistory.currency'),
                  width: 80,
                  align: 'center'         
              },
              {
                  prop: 'avagPrice',
                  label: this.$t('myInquiry.tradeHistory.avagPrice'),
                  align: 'right'            
              },
              {
                  prop: 'price',
                  label: this.$t('myInquiry.tradeHistory.money'),
                  align: 'right'      
              },
          ]
      }else{
          this.colData = [ //表格列
              {
                  prop: 'tradDate',
                  label: this.$t('myInquiry.tradeHistory.tradeDate'),
                  width: 120,
                  align: 'left'              
              },
              {
                  prop: 'endDate',
                  label:  this.$t('myInquiry.tradeHistory.settlementDate'),
                  width: 140,
                  align: 'left'              
              },
              {
                  prop: 'market',
                  label: this.$t('myInquiry.tradeHistory.market'),
                  align: 'left'              
              },
              {
                  prop: 'stockCode',
                  label: this.$t('myInquiry.tradeHistory.stock'),
                  align: 'left'              
              },
              {
                  prop: 'tradType',
                  label: this.$t('myInquiry.tradeHistory.tradeClasify'),
                  width: 80,
                  align: 'left'        
              },
              {
                  prop: 'sellNum',
                  label: this.$t('myInquiry.tradeHistory.tradeNum'),
                  align: 'right'         
              },
              {
                  prop: 'currency',
                  label: this.$t('myInquiry.tradeHistory.currency'),
                  width: 80,
                  align: 'center'         
              },
              {
                  prop: 'costPrice',
                  label: this.$t('myInquiry.tradeHistory.tradePrice'),
                  align: 'right'            
              },
              {
                  prop: 'price',
                  label: this.$t('myInquiry.tradeHistory.money'),
                  align: 'right'      
              },
              {
                  prop: 'channel',
                  label: this.$t('myInquiry.tradeHistory.channel'),
                  align: 'center'      
              },
              {
                  prop: 'numId',
                  label: this.$t('myInquiry.tradeHistory.numId'),
                  align: 'right'      
              },
          ]
      }     
    },
    btnClick(index) {
      this.btnIndex = index;
      this.changeCol(index);
      if(index == 1) {
          this.tableData = [];
      }else{
          this. tableData = [ //表格数据
              {
                  tradDate: "2018-12-17",
                  endDate: "2018-12-28",
                  market: "香港、中國A股、美國及場外市場",
                  stockCode: "00665 海通国际 ",
                  tradType: "买入",
                  sellNum: "5000",
                  currency: "HKD",
                  avagPrice: "2.541",      
                  price: "25,410.00",        
              },
              {
                  tradDate: "2018-12-18",
                  endDate: "2018-12-28",
                  market: "香港、中國A股、美國及場外市場",
                  stockCode: "AAPL  APPLE COMP INC",
                  tradType: "卖出",
                  sellNum: "500",
                  currency: "USD",
                  avagPrice: "147.541",      
                  price: "14,754.10",       
              }
          ]
      }
    },
    btnChoose(resultArr) {
        console.log(resultArr)
    },
    time(t) {
      console.log(t);
    }
  },
  mounted(){},

}

</script>
<style lang='scss' scoped>
.oldHistory-wrap{
      .content-wrap{
          padding: 24px 24px 72px 24px;
          .conditions-info{
            display: flex;
            width: 100%;
            padding: 12px 0;
            flex-wrap: wrap;
            align-items: center;
            .date-wrap{
              flex: 1;
              display: flex;
              flex-wrap: wrap;
              align-items: center;
              padding-left: 6px;
              .conditions-btn{
                display: inline-block;
                font-size: 16px;
                height: 24px;
                line-height: 24px;
                cursor: pointer;
                padding: 0 6px;
                margin-right: 4px;
                white-space: nowrap;
                &.active{
                  color: #fff;
                  font-family: SourceHanSansCN-Medium;
                  background: #003DA5;
                  border-radius: 4px; 
                }
              }
              .input-wrap{
                position: relative;
                padding-left: 12px;
                .icons{
                  width: 36px;
                  cursor: pointer;
                  text-align: center;
                  display: inline-block;
                  height: 36px;
                  line-height: 32px;
                  position: absolute;
                  right: 0;
                  top: 0;
                  img{
                    display: inline-block;
                    width: 24px;
                    height: 24px;
                    vertical-align:middle;
                  }
                  img:hover{
                      opacity: 0.8;
                  }
                }
              }
            }
            .exchange-text {
              font-family: SourceHanSansCN-Regular;
              font-size: 16px;
              flex: 0 0 80px;
            }
            .el-date-editor {
              width: 240px !important;
              >>> .el-input__icon {
                display: none;
              }
              >>> .el-range-separator {
                line-height: 28px;
                width: 15%;
              }
            }
             
          }
          .other-conditions{
              margin: 24px 0 12px 0;
              .conditions-btn{
                  display: inline-block;
                  font-family: SourceHanSansCN-Regular;
                  font-size: 16px;
                  height: 24px;
                  line-height: 24px;
                  cursor: pointer;
                  padding: 0 6px;
                  margin-right: 4px;
                  white-space:nowrap;
                  &.active{
                      color: #fff;
                      font-family: SourceHanSansCN-Medium;
                      background: #003DA5;
                      border-radius: 4px;
                  }
              }
              .tip{
                  font-family: SourceHanSansCN-Regular;
                  font-size: 12px;
                  color: #333333;
                  line-height: 14px;
              }
          }
      }
      .explain-wrap{
          .explain-title{
              padding: 24px 0;
              font-family: SourceHanSansCN-Medium;
              font-size: 16px;
          }
          .explain-item{
              font-family: SourceHanSansCN-Regular;
              font-size: 16px;
              line-height: 20px;
              padding: 6px 0;
              .explain-btn{
                  margin: 0 4px;
                  text-decoration: underline;
                  cursor: pointer;
              }
          }
      }
  }
 @media screen and (max-width: 768px){
     .oldHistory-wrap .content-wrap{
          padding: 12px 12px 48px 12px;
     }
     .oldHistory-wrap .explain-wrap .explain-title{
         padding: 12px 0;
     }
     .oldHistory-wrap .content-wrap .conditions-info{
       align-items: normal;
     }
     .oldHistory-wrap .content-wrap .conditions-info .date-wrap .input-wrap{
       margin-top: 12px;
       padding-left: 0;
     }
     .oldHistory-wrap .content-wrap .other-conditions{
       margin: 0 0 12px 0;
     }
   }
</style>