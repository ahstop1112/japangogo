<!-- 证券提存(我的查询)-->
<template>
  <div class="stockMovement">
    <div class="stockMovement-wrap contentBg">
      <div class="conditions">
        <conditionChoose :conditionArr="conditionArr" @btnChoose="btnChoose" />
      </div>
      <div class="stockMovement-choose" style="flex-wrap: nowrap;">
        <span class="stockMovement-text mediumColor">{{$t('myInquiry.stockMovement.date1')}}</span>
        <div class="date-picker">
          <timeSelector :range-separator="$t('myInquiry.myReport.to')" :start-placeholder="$t('myInquiry.myReport.start')" :end-placeholder="$t('myInquiry.myReport.end')" @change="time"></timeSelector>
        </div>
      </div>
      <div class="stockMovement-choose">
        <div class="choose-wrap">
          <conditionChoose :conditionArr="conditionArr1" @btnChoose="btnChoose" />
        </div>
        <div class="input-wrap">
          <el-input class="ipt" v-model="input" placeholder="海通国际">
          </el-input>
          <span class="icon contentLeftBorder">
             <img src="@/assets/search.png" />
          </span>
        </div>

      </div>
      <div class="text heavyColor">{{$t('myInquiry.stockMovement.record')}} 2019-06-25 14:58:48</div>
      <div class="stockMovement-detail">
        <el-table 
          :data="tableData" 
          :row-class-name="tableRowClass"  
          :header-cell-style="headeRowClass"
        style="width: 100%">
          <el-table-column prop="date" width="110" :label="$t('myInquiry.stockMovement.date2')">
          </el-table-column>
          <el-table-column prop="booked" align="left" width="110" :label="$t('myInquiry.stockMovement.date3')">
          </el-table-column>
          <el-table-column prop="coding" align="left" width="130" :label="$t('myInquiry.stockMovement.code1')">
          </el-table-column>
          <el-table-column prop="query" align="left" min-width="50" :label="$t('myInquiry.stockMovement.query')">
          </el-table-column>
          <el-table-column prop="market" align="left" min-width="130" :label="$t('myInquiry.stockMovement.market')">
          </el-table-column>
          <el-table-column prop="instructions" align="left" min-width="150" :label="$t('myInquiry.stockMovement.instructions')">
          </el-table-column>
          <el-table-column prop="code" align="left" min-width="70" :label="$t('myInquiry.stockMovement.code2')">
          </el-table-column>
          <el-table-column prop="number" align="left" min-width="50" :label="$t('myInquiry.stockMovement.number')">
          </el-table-column>
          <el-table-column prop="currency" align="left" min-width="50" :label="$t('myInquiry.stockMovement.currency')">
          </el-table-column>
          <el-table-column prop="amount" align="right" :label="$t('myInquiry.stockMovement.amount')">
          </el-table-column>
        </el-table>
      </div>
    </div>
    <div class="content">
      <div class="title heavyColor">{{$t('myInquiry.stockMovement.note')}}</div>
      <p class="mediumColor">{{$t('myInquiry.stockMovement.content')}}</p>
      <p class="mediumColor">{{$t('myInquiry.stockMovement.content1')}}</p>
    </div>
  </div>

</template>

<script>
import conditionChoose from '@/components/conditionChoose'
import { mapGetters } from 'vuex'
import timeSelector from '@/components/timeSelector'
export default {

  data() {
    return {
      input: '',
      conditionArr: [],
      conditionArr1: [],
      tableData: [
        {
          date: "2018-06-23",
          booked: "2018-06-23",
          coding: "OS800062455",
          query: "资金",
          market: "香港，中國A股、美國及場外市場",
          instructions: "Interest Due (2018/11/01-2018/11/30)",
          code: "-",
          number: "100",
          currency: "USD",
          amount: "-261.54",
        },
        {
          date: "2018-06-23",
          booked: "2018-06-23",
          coding: "OS800062455",
          query: "资金",
          market: "香港，中國A股、美國及場外市場",
          instructions: "Interest Due (2018/11/01-2018/11/30)",
          code: "-",
          number: "100",
          currency: "USD",
          amount: "-261.54",
        }
      ],
    };
  },
  watch: {
    getLang: {
      handler: function (o, n) {
        this.conditionArr = [
          {
            title: this.$t('cash.fxConversion.market'),
            dataArr: [
              {
                name: this.$t('cash.fxConversion.allMarket'),
                code: "allMarket"
              },
              {
                name: this.$t('cash.fxConversion.hkAUSAsotck'),
                code: ""
              },
              {
                name: this.$t('cash.fxConversion.cnBStock'),
                code: ""
              },
              {
                name: this.$t('cash.fxConversion.otherMarket'),
                code: ""
              }
            ]
          },
          {
            title: this.$t('myInquiry.stockMovement.project'),
            dataArr: [
              {
                name: this.$t('myInquiry.stockMovement.allMarket'),
                code: "allMarket"
              },
              {
                name: this.$t('myInquiry.stockMovement.securities'),
                code: ""
              },
              {
                name: this.$t('myInquiry.stockMovement.futures'),
                code: ""
              }
            ]
          }
        ],
          this.conditionArr1 = [
            {
              title: this.$t('myInquiry.stockMovement.code'),
              dataArr: [
                {
                  name: this.$t('myInquiry.stockMovement.allMarket'),
                  code: "allMarket"
                },
                {
                  name: this.$t('myInquiry.stockMovement.stock'),
                  code: ""
                },
              ]
            }
          ]
      },
      immediate: true
    }
  },
  components: {
    conditionChoose,
    timeSelector
  },
  computed: {
    ...mapGetters(['getLang', 'getBgColor'])
  },
  methods: {
     tableRowClass() {
      return 'tableRowClass'
    },  
    headeRowClass({row, column, rowIndex, columnIndex}) {
       //表头的背景颜色
      if(rowIndex==0){
          if(this.getBgColor == 'bg-anhei') {
            return 'background:rgb(51,51,51)';
          }else{
            return 'background:rgb(255,255,255)';
          }
      }
    },
    btnChoose(resultArr) {
      console.log(resultArr)
    },
    time(t) {
      console.log(t);
      // this.isShowtime = NaN // 当手动修改时间选择器的时候，清除快捷选择的样式
    }
  },
  mounted() { },

}

</script>
<style lang='scss' scoped>
.stockMovement {
  .stockMovement-wrap {
    padding: 24px;
    width: 100%;
    >>> .condition-wrap .conditons-item .conditons-content {
      padding-left: 0;
    }
    .stockMovement-choose {
      display: flex;
      flex-wrap: wrap;
      padding: 12px 0;
      width: 100%;
      .stockMovement-text {
        flex: 0 0 80px;
        font-family: SourceHanSansCN-Regular;
        font-size: 16px;
        line-height: 36px;
      }

      .choose-wrap {
        display: flex;
        flex-wrap: wrap;
        flex: 0 0 270px;
        >>> .conditons-title {
          line-height: 20px;
        }
      }
      .input-wrap {
        position: relative;
        @media screen and (max-width: 590px) {
          padding-left: 80px;
        }
        >>> .el-input__inner {
          padding-right: 50px !important;
        }
        .icon {
          position: absolute;
          right: 0;
          top: 0;
          display: inline-block;
          width: 36px;
          height: 36px;
          text-align: center;
          line-height: 32px;
          cursor: pointer;
          img{
            display: inline-block;
            width: 24px;
            height: 24px;
            vertical-align:middle;
          }
          img:hover{
              opacity: 0.8;
          }
        }
      }
    }

    .text {
      font-family: SourceHanSansCN-Regular;
      font-size: 12px;
    }

    .stockMovement-detail {
      overflow: auto;
      margin: 12px 0;
    }
  }
  .content {
    .title {
      margin: 15px 0;
      font-family: SourceHanSansCN-Medium;
      font-size: 16px;
    }
    p {
      font-family: SourceHanSansCN-Regular;
      font-size: 16px;
    }
  }
}
@media screen and (max-width: 768px) {
  .stockMovement .stockMovement-wrap {
    padding: 12px;
  }
}
</style>