
<!--交易记录(我的查询)-->
<template>
  <div class="tradeHistory-wrap">
    <pageNav :routerArr="routerArr" />
    <div class="content-wrap">
      <keep-alive>
        <router-view />
      </keep-alive>
    </div>
  </div>
</template>

<script>
import pageNav from "@/components/pageNav"
import { mapGetters } from 'vuex'
export default {
  data() {
    return {
      routerArr: []
    };
  },
  computed: {
    ...mapGetters(['getLang'])
  },
  components: {
    pageNav
  },
  watch: {
    getLang: {
      handler: function (o, n) {
        this.routerArr = [
          {
            name: this.$t('myInquiry.tradeHistory.title1'),
            path: "todayRecord"
          },
          {
            name: this.$t('myInquiry.tradeHistory.title2'),
            path: "oldHistory"
          },
          {
            name: this.$t('myInquiry.tradeHistory.title3'),
            path: "ipoSubscription"
          },
          {
            name: this.$t('myInquiry.tradeHistory.title4'),
            path: "companyAction"
          }
        ]
        const userData = JSON.parse(sessionStorage.getItem("userData"));
        if (userData.primeBrokerageFunds.length !== 0) {
          this.routerArr.splice(2, 2)
          return
        } 
      },
      immediate: true
    }
  },
  methods: {},
  created() { },
  mounted() { },

}

</script>
<style lang='scss' scoped>
.tradeHistory-wrap {
  width: 100%;
  .content-wrap {
    margin-top: 24px;
  }
}
@media screen and (max-width: 768px) {
  .tradeHistory-wrap .router-wrap .router-item a {
    font-size: 18px;
  }
  .tradeHistory-wrap .router-wrap .router-item {
    padding-left: 12px;
  }
  .tradeHistory-wrap .content-wrap {
    margin-top: 12px;
  }
}
</style>