<!-- 我的报表(我的查询)-->
<template>
  <div class="myReport-wrap contentBg">
    <div class="myReport-text">
      <span class="myReport-info mediumColor">{{$t('myInquiry.myReport.code')}}</span>
      <span class="myReport-item heavyColor">0335130AARCF</span>
    </div>
    <div class="myReport-text" style="flex-wrap: nowrap;">
      <span class="myReport-info mediumColor">{{$t('myInquiry.myReport.date')}}</span>
      <div class="date-picker">
        <timeSelector :range-separator="$t('myInquiry.myReport.to')" :start-placeholder="$t('myInquiry.myReport.start')" :end-placeholder="$t('myInquiry.myReport.end')" @change="time"></timeSelector>
      </div>
    </div>
    <div class="myReport-text" style="flex-wrap: nowrap;">
      <span class="myReport-info mediumColor">{{$t('myInquiry.myReport.name')}}</span>
      <div class="input-wrap">
        <el-input class="ipt" v-model="input">
        </el-input>
        <span class="icon contentLeftBorder">
           <img src="@/assets/search.png" />
        </span>
      </div>
    </div>
    <div class="report-detail">
      <el-table 
        :data="tableData" 
        :row-class-name="tableRowClass"  
        :header-cell-style="headeRowClass"
      style="width: 100%">
        <el-table-column prop="date" width="130" :label="$t('myInquiry.myReport.time')">
        </el-table-column>
        <el-table-column prop="file" align="left" min-width="180" :label="$t('myInquiry.myReport.file')">
        </el-table-column>
        <el-table-column :render-header="renderHeader" width="110" prop="download" align="left">
          <template slot-scope="scope">
            <span class="small-btn small-btn-blue" @click="download(scope.row)">{{$t('myInquiry.myReport.download')}}</span>
          </template>
        </el-table-column>

      </el-table>
    </div>
    <div class="block">
      <el-pagination background @size-change="handleSizeChange" @current-change="handleCurrentChange" :current-page.sync="currentPage" :page-size="100" layout="prev, pager, next, jumper" :total="1000">
      </el-pagination>
    </div>

  </div>
</template>

<script>
import timeSelector from '@/components/timeSelector'
import {mapGetters} from 'vuex'
export default {
  components: {
    timeSelector
  },
  data() {
    return {
      input: '',
      currentPage: 5, // 默认选择第五页
      tableData: [
        {
          date: "2018-06-23",
          file: "Account Current Position Report_20190404_SITPBFUNDC60.PDF",
        },
        {
          date: "2018-06-23",
          file: "Account Current Position Report_20190404_SITPBFUNDC60.PDF",
        }
      ],
    };
  },
  computed: {
    ...mapGetters([ 'getBgColor' ])
  },
  methods: {
    tableRowClass() {
      return 'tableRowClass'
    },  
    headeRowClass({row, column, rowIndex, columnIndex}) {
       //表头的背景颜色
      if(rowIndex==0){
          if(this.getBgColor == 'bg-anhei') {
            return 'background:rgb(51,51,51)';
          }else{
            return 'background:rgb(255,255,255)';
          }
      }
    },
    handleSizeChange(val) {
      console.log(`每页 ${val} 条`);
    },
    handleCurrentChange(val) {
      console.log(`当前页: ${val}`);
    },
    // 下载点击事件
    download(row) {
      console.log(row)
    },
    renderHeader() {
      return (
        <div>
          <span class="small-btn small-btn-blue" onclick={() => this.exportExcel()}>下載全部報告</span>
        </div>
      )
    },
    time(t) {
      console.log(t);
      // this.isShowtime = NaN // 当手动修改时间选择器的时候，清除快捷选择的样式
    }
  },
  mounted() { },

}

</script>
<style lang='scss' scoped>
.myReport-wrap {
  padding: 24px;
  width: 100%;
  .myReport-text {
    display: flex;
    flex-wrap: wrap;
    padding: 12px 0;
    .myReport-info {
      display: flex;
      align-items: center;
      font-family: SourceHanSansCN-Regular;
      font-size: 16px;
      flex: 0 0 100px;
      height: 36px;
      line-height: 20px;
      @media screen and (max-width: 768px) {
        flex: 0 0 80px;
      }
    }
    .myReport-item {
      font-family: SourceHanSansCN-Regular;
      font-size: 16px;
      line-height: 36px;
    }

    .input-wrap {
      position: relative;
      >>> .el-input__inner {
        padding-right: 50px !important;
      }
      .icon {
        display: inline-block;
        position: absolute;
        right: 0;
        top: 0;
        text-align: center;
        width: 36px;
        height: 36px;
        line-height: 32px;
        cursor: pointer;
        img{
          display: inline-block;
          width: 24px;
          height: 24px;
          vertical-align:middle;
        }
        img:hover{
            opacity: 0.8;
        }
      }
    }
  }
  .report-detail {
    overflow: auto;
    margin: 12px 0px;
    >>> th > .cell {
      font-family: SourceHanSansCN-Regular;
      font-size: 16px;
      color: rgba(51, 51, 51, 0.5);
    }
    >>> td > .cell {
      font-family: SourceHanSansCN-Regular;
      font-size: 16px;
      color: #333333;
    }
    .el-button--mini {
      padding: 5px;
    }
  }
  .block {
    overflow: auto;
    width: 100%;
    text-align: right;
    >>> .btn-prev,
    >>> .btn-next {
      background-color: #fff;
    }
    >>> .el-pager {
      li {
        min-width: 25px;
        margin: 0 5px;
        background-color: #fff;
        font-size: 15px;
        @media screen and (max-width: 768px) {
          min-width: 16px;
          height: 20px;
          line-height: 20px;
          vertical-align: 0;
        }
      }
    }
    >>> .el-input__inner {
      padding-right: 2px !important;
    }
  }
}
@media screen and (max-width: 768px) {
  .myReport-wrap {
    padding: 12px;
  }
}
</style>