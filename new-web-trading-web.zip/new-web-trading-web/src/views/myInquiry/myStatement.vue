<!-- 我的结单(我的查询)-->
<template>
  <div class="myStatement-wrap contentBg">
    <div class="conditions">
      <conditionChoose :conditionArr="conditionArr" @btnChoose="btnChoose" />
    </div>
    <div class="statement-type top" style="flex-wrap: nowrap;">
      <span class="statement-text mediumColor">{{$t('myInquiry.myStatement.date')}}</span>
      <div class="date-picker">
        <timeSelector :range-separator="$t('myInquiry.myReport.to')" :start-placeholder="$t('myInquiry.myReport.start')" :end-placeholder="$t('myInquiry.myReport.end')" @change="time"></timeSelector>
      </div>
    </div>
    <div class="statement-detail">
      <el-table :data="tableData" :row-class-name="tableRowClass" :header-cell-style="headeRowClass" style="width: 100%">
        <el-table-column prop="date" width="130" :label="$t('myInquiry.myStatement.time')">
        </el-table-column>
        <el-table-column prop="code" align="left" min-width="100" :label="$t('myInquiry.myStatement.file')">
        </el-table-column>
        <el-table-column prop="type" align="center" min-width="90" :label="$t('myInquiry.myStatement.type2')">
          <template slot-scope="scope">
            <i class="iconfont icon-bill" :style="{'color':scope.row.type=='月結單'?'#406EBC':'#FB6130'}"></i>
            <span style="margin-left: 5px">{{ scope.row.type }}</span>
          </template>
        </el-table-column>
        <el-table-column align="center" min-width="50">
          <template slot-scope="scope">
            <span class="small-btn small-btn-blue" @click="download(scope.row)">{{$t('myInquiry.myStatement.download')}}</span>
          </template>
        </el-table-column>

      </el-table>
    </div>
    <div class="block">
      <el-pagination background @size-change="handleSizeChange" @current-change="handleCurrentChange" :current-page.sync="currentPage" :page-size="100" layout="prev, pager, next, jumper" :total="1000">
      </el-pagination>
    </div>

  </div>
</template>

<script>
import conditionChoose from '@/components/conditionChoose'
import { mapGetters } from 'vuex'
import timeSelector from '@/components/timeSelector'
export default {
  components: {
    conditionChoose,
    timeSelector
  },
  computed: {
    ...mapGetters(['getLang', 'getBgColor'])
  },
  watch: {
    getLang: {
      handler: function (o, n) {
        this.conditionArr = [
          {
            title: this.$t('myInquiry.myStatement.type'),
            dataArr: [
              {
                name: this.$t('myInquiry.myStatement.all'),
                code: "allMarket"
              },
              {
                name: this.$t('myInquiry.myStatement.dayStatement'),
                code: ""
              },
              {
                name: this.$t('myInquiry.myStatement.monthlyStatement'),
                code: ""
              }
            ]
          }
        ]
      },
      immediate: true
    }
  },
  data() {
    return {
      currentPage: 5, // 默认选择第五页
      conditionArr: [],
      tableData: [
        {
          date: "2018-06-23",
          code: "02-0087618-33(网上保证金)",
          type: "月結單",
        },
        {
          date: "2018-06-23",
          code: "02-0087618-33(网上保证金)",
          type: "日結單",
        }
      ]
    };
  },
  methods: {
    tableRowClass() {
      return 'tableRowClass'
    },
    headeRowClass({ row, column, rowIndex, columnIndex }) {
      //表头的背景颜色
      if (rowIndex == 0) {
        if (this.getBgColor == 'bg-anhei') {
          return 'background:rgb(51,51,51)';
        } else {
          return 'background:rgb(255,255,255)';
        }
      }
    },
    btnChoose(resultArr) {
      console.log(resultArr)
    },
    handleSizeChange(val) {
      console.log(`每页 ${val} 条`);
    },
    handleCurrentChange(val) {
      console.log(`当前页: ${val}`);
    },
    // 下载点击事件
    download(row) {
      console.log(row)
    },
    time(t) {
      console.log(t);
      // this.isShowtime = NaN // 当手动修改时间选择器的时候，清除快捷选择的样式
    }
  },
  mounted() { },

}

</script>
<style lang='scss' scoped>
.myStatement-wrap {
  padding: 24px;
  width: 100%;
  >>> .condition-wrap .conditons-item .conditons-content {
    padding-left: 0;
  }
  .top {
    line-height: 36px;
  }
  .statement-type {
    display: flex;
    flex-wrap: wrap;
    padding: 12px 0;
    .statement-text {
      display: flex;
      flex: 0 0 80px;
      align-items: center;
      height: 36px;
      font-family: SourceHanSansCN-Regular;
      font-size: 16px;
      line-height: 20px;
    }
    >>> .time-slelector {
      position: relative;
      .icon-date {
        position: absolute;
        top: 0px;
        left: 133px;
        font-size: 18px;
      }
      .icon-wrap {
        position: relative;
        width: 100%;
        height: 100%;
        .icon-date1 {
          position: absolute;
          top: -10px;
          left: -27px;
          font-size: 18px;
          @media screen and (max-width: 474px) {
            position: absolute;
            top: -10px;
            left: -27px;
          }
        }
      }
      >>> .el-input__inner {
        padding-left: 10px;
      }

      >>> .el-input__prefix {
        .el-input__icon {
          display: none !important;
        }
      }
      >>> .el-input__icon {
        position: absolute;
        top: -1px;
        left: -24px;
      }
    }
  }
  .statement-detail {
    overflow: auto;
    margin: 12px 0;
    .el-button--mini {
      padding: 5px;
    }
  }
  .block {
    overflow: auto;
    width: 100%;
    text-align: right;
    >>> .btn-prev,
    >>> .btn-next {
      background-color: #fff;
    }
    >>> .el-pager {
      li {
        margin: 0 5px;
        min-width: 25px;
        background-color: #fff;
        font-size: 15px;
        @media screen and (max-width: 768px) {
          min-width: 16px;
          height: 20px;
          line-height: 20px;
          vertical-align: 0;
        }
      }
    }
    >>> .el-input__inner {
      padding-right: 2px !important;
    }
  }
}
@media screen and (max-width: 768px) {
  .myStatement-wrap {
    padding: 12px;
  }
}
</style>