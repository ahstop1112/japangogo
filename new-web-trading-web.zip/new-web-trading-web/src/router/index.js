import Vue from 'vue'
import Router from 'vue-router'
import Layout from '@/layout'
// import { localGet, localRemove } from '@/utils/mylocal.js'
import store from '@/store/state'
import NProgress from 'nprogress'
import 'nprogress/nprogress.css'

Vue.use(Router)

let router = new Router({
  mode: 'hash',
  routes: [
    {
      path: '*',
      redirect: '/login'
    },
    //主页
    {
      path: '/',
      component: Layout,
      children: [
        {
          path: '',
          component: () => import('@/views/home/index'),
          name: 'home',
          meta: {
            firstLevel: 0,
            accoutEnquire: { offOn: 'OFF,ON', type: 'C,M' }
          }
          //meta: { title: 'Dashboard', icon: 'dashboard', affix: true }
        }
      ]
    },
    //证券交易
    {
      path: '/security',
      component: Layout,
      children: [
        {
          path: 'mainMarket', //港A美股
          name: 'mainMarket',
          component: () => import('@/views/security/mainMarket'),
          meta: { firstLevel: 1, secondLevel: 0 },
          redirect: '/security/mainMarket/hkTrading', //点击交易记录默认选中第一个
          children: [
            {
              path: 'hkTrading', //港股交易
              name: 'hkTrading',
              component: () => import('@/views/security/mainMarket/index'),
              meta: {
                firstLevel: 1,
                secondLevel: 0,
                accoutEnquire: { offOn: 'ON', type: 'C,M' }
              }
            },
            {
              path: 'A-shareTrading', //A股交易
              name: 'A-shareTrading',
              component: () => import('@/views/security/mainMarket/index'),
              meta: {
                firstLevel: 1,
                secondLevel: 0,
                accoutEnquire: { offOn: 'ON', type: 'C,M' }
              }
            },
            {
              path: 'usTrading', //美股交易
              name: 'usTrading',
              component: () => import('@/views/security/mainMarket/index'),
              meta: {
                firstLevel: 1,
                secondLevel: 0,
                accoutEnquire: { offOn: 'ON', type: 'C,M' }
              }
            }
          ]
        },
        {
          path: 'otherMarket', //其它市场
          name: 'otherMarket',
          component: () => import('@/views/security/otherMarket'),
          meta: { firstLevel: 1, secondLevel: 1 },
          redirect: '/security/otherMarket/japan', //点击汇款默认选中第一个
          children: [
            {
              path: 'japan', // 日本东京
              component: () => import('@/views/security/otherMarket/japan'),
              name: 'japan',
              meta: {
                firstLevel: 1,
                secondLevel: 1,
                accoutEnquire: { offOn: 'OFF,ON', type: 'C,M' }
              }
            },
            {
              path: 'southKorea', // 南韩首尔
              component: () =>
                import('@/views/security/otherMarket/southKorea'),
              name: 'southKorea',
              meta: {
                firstLevel: 1,
                secondLevel: 1,
                accoutEnquire: { offOn: 'OFF,ON', type: 'C,M' }
              }
            },
            {
              path: 'china', // 中国台湾
              component: () => import('@/views/security/otherMarket/china'),
              name: 'china',
              meta: {
                firstLevel: 1,
                secondLevel: 1,
                accoutEnquire: { offOn: 'OFF,ON', type: 'C,M' }
              }
            }
          ]
        },
        {
          path: 'ipoSubscriptions', //新股认购
          name: 'ipoSubscriptions',
          component: () => import('@/views/security/ipoSubscriptions'),
          meta: {
            firstLevel: 1,
            secondLevel: 2,
            accoutEnquire: { offOn: 'ON', type: 'C,M', cies: false }
          }
        },
        {
          path: 'corporateAction', //公司行动
          name: 'corporateAction',
          component: () => import('@/views/security/corporateAction'),
          meta: {
            firstLevel: 1,
            secondLevel: 3,
            accoutEnquire: { offOn: 'OFF,ON', type: 'C,M' }
          }
        },
        {
          path: 'marginFinancingRatios', //按仓比率
          name: 'marginFinancingRatios',
          component: () => import('@/views/security/marginFinancingRatios'),
          meta: {
            firstLevel: 1,
            secondLevel: 4,
            accoutEnquire: { offOn: '', type: '' }
          }
        }
      ]
    },
    //资金管理
    {
      path: '/cash',
      component: Layout,
      children: [
        {
          path: 'fxConversion', //货币兑换
          component: () => import('@/views/cash/fxConversion'),
          name: 'fxConversion',
          meta: { firstLevel: 2, secondLevel: 0 },
          redirect: '/cash/fxConversion/fxConversionWrap', //点击交易记录默认选中第一个
          children: [
            {
              path: 'fxConversionWrap', //货币兑换指示
              component: () =>
                import('@/views/cash/fxConversion/fxConversionWrap'),
              name: 'fxConversionWrap',
              meta: {
                firstLevel: 2,
                secondLevel: 0,
                accoutEnquire: { offOn: 'ON', type: 'C,M', cies: false }
              }
            },
            {
              path: 'currencyBalance', //货币结存汇总表
              component: () =>
                import('@/views/cash/fxConversion/currencyBalance'),
              name: 'currencyBalance',
              meta: {
                firstLevel: 2,
                secondLevel: 0,
                accoutEnquire: { offOn: 'ON', type: 'C,M', cies: false }
              }
            }
          ]
        },
        {
          path: 'fundTransfer', //账户转账
          component: () => import('@/views/cash/fundTransfer'),
          name: 'fundTransfer',
          meta: {
            firstLevel: 2,
            secondLevel: 1,
            accoutEnquire: { offOn: '', type: '' }
          }
        },
        {
          path: 'fundWithdrawal', //资金提取
          component: () => import('@/views/cash/fundWithdrawal'),
          name: 'fundWithdrawal',
          meta: {
            firstLevel: 2,
            secondLevel: 2,
            accoutEnquire: { offOn: '', type: '' }
          }
        },
        {
          path: 'ePayment', //资金存入
          component: () => import('@/views/cash/ePayment'),
          name: 'ePayment',
          meta: {
            firstLevel: 2,
            secondLevel: 3,
            accoutEnquire: { offOn: '', type: '' }
          }
        },
        {
          path: 'remittanceServices', //汇款服务(英文版没有)
          component: () => import('@/views/cash/remittanceServices'),
          name: 'remittanceServices',
          meta: { firstLevel: 2, secondLevel: 4 },
          redirect: '/cash/remittanceServices/accountInformation', //点击汇款默认选中第一个
          children: [
            {
              path: 'accountInformation', //账户资料
              component: () =>
                import('@/views/cash/remittanceServices/accountInformation'),
              name: 'accountInformation',
              meta: {
                firstLevel: 2,
                secondLevel: 4,
                accoutEnquire: { offOn: '', type: '' }
              }
            },
            {
              path: 'applicationInformation', //申请咨询
              component: () =>
                import(
                  '@/views/cash/remittanceServices/applicationInformation'
                ),
              name: 'applicationInformation',
              meta: {
                firstLevel: 2,
                secondLevel: 4,
                accoutEnquire: { offOn: '', type: '' }
              }
            }
          ]
        },
        {
          path: 'eps',
          component: () => import('@/views/cash/eps/eps'),
          name: 'eps',
          meta: { firstLevel: 2, secondLevel: 3 }
        }, // 易辦事页面
        {
          path: 'fps',
          component: () => import('@/views/cash/fps/fps'),
          name: 'fps',
          meta: { firstLevel: 2, secondLevel: 3 }
        } // 转数快页面
      ]
    },

    //我的查询
    {
      path: '/myInquiry',
      component: Layout,
      meta: { roles: ['ENTERP'] } /* 配置每个页面对应的可访问角色权限信息 */,
      children: [
        {
          path: 'accoutSummary', //我的资产
          component: () => import('@/views/myInquiry/accoutSummary'),
          name: 'accoutSummary',
          meta: {
            firstLevel: 3,
            secondLevel: 0,
            accoutEnquire: { offOn: 'OFF,ON', type: 'C,M' }
          }
        },
        {
          path: 'tradeHistory', //交易记录
          component: () => import('@/views/myInquiry/tradeHistory'),
          name: 'tradeHistory',
          meta: { firstLevel: 3, secondLevel: 1 },
          redirect: '/myInquiry/tradeHistory/todayRecord', //点击交易记录默认选中第一个
          children: [
            {
              path: 'todayRecord', //今日记录
              component: () =>
                import('@/views/myInquiry/tradeHistory/todayRecord'),
              name: 'todayRecord',
              meta: {
                firstLevel: 3,
                secondLevel: 1,
                accoutEnquire: { offOn: 'OFF,ON', type: 'C,M,S' }
              }
            },
            {
              path: 'oldHistory', //历史记录
              component: () =>
                import('@/views/myInquiry/tradeHistory/oldHistory'),
              name: 'oldHistory',
              meta: {
                firstLevel: 3,
                secondLevel: 1,
                accoutEnquire: { offOn: 'OFF,ON', type: 'C,M,S' }
              }
            },
            {
              path: 'ipoSubscription', //新股认购
              component: () =>
                import('@/views/myInquiry/tradeHistory/ipoSubscription'),
              name: 'ipoSubscription',
              meta: {
                firstLevel: 3,
                secondLevel: 1,
                accoutEnquire: { offOn: 'OFF,ON', type: 'C,M,S' }
              }
            },
            {
              path: 'companyAction', //公司行动
              component: () =>
                import('@/views/myInquiry/tradeHistory/companyAction'),
              name: 'companyAction',
              meta: {
                firstLevel: 3,
                secondLevel: 1,
                accoutEnquire: { offOn: 'OFF,ON', type: 'C,M,S' }
              }
            }
          ]
        },
        {
          path: 'fundMovement', //资金记录
          component: () => import('@/views/myInquiry/fundMovement'),
          name: 'fundMovement',
          meta: { firstLevel: 3, secondLevel: 2 },
          redirect: to => {
            const userData = JSON.parse(sessionStorage.getItem('userData'))
            if (userData.primeBrokerageFunds.length !== 0) {
              return '/myInquiry/fundMovement/escrow'
            } else {
              return '/myInquiry/fundMovement/exchange'
            }
          },
          children: [
            {
              path: 'exchange', //兑换记录
              component: () =>
                import('@/views/myInquiry/moneyHistory/exchange'),
              name: 'exchange',
              meta: {
                firstLevel: 3,
                secondLevel: 2,
                accoutEnquire: { offOn: 'OFF,ON', type: 'C,M,S' }
              }
            },
            {
              path: 'escrow', //提存记录
              component: () => import('@/views/myInquiry/moneyHistory/escrow'),
              name: 'escrow',
              meta: {
                firstLevel: 3,
                secondLevel: 2,
                accoutEnquire: { offOn: 'OFF,ON', type: 'C,M,S' }
              }
            }
          ]
        },
        {
          path: 'stockMovement', //证券提存
          component: () => import('@/views/myInquiry/stockMovement'),
          name: 'stockMovement',
          meta: {
            firstLevel: 3,
            secondLevel: 3,
            accoutEnquire: { offOn: 'OFF,ON', type: 'C,M,S' }
          }
        },
        {
          path: 'myStatement', //我的结单
          component: () => import('@/views/myInquiry/myStatement'),
          name: 'myStatement',
          meta: {
            firstLevel: 3,
            secondLevel: 4,
            accoutEnquire: { offOn: 'OFF,ON', type: 'F,O,S,C,M,I' }
          }
        },
        {
          path: 'myReport', //我的报表
          component: () => import('@/views/myInquiry/myReport'),
          name: 'myReport',
          meta: {
            firstLevel: 3,
            secondLevel: 5,
            accoutEnquire: { offOn: '', type: '' }
          }
        }
      ]
    },
    //我的设定
    {
      path: '/mySettings',
      component: Layout,
      meta: { roles: ['ENTERP'] } /* 配置每个页面对应的可访问角色权限信息 */,
      children: [
        {
          path: 'changeParticulars', //个人资料
          component: () => import('@/views/mySettings/changeParticulars'),
          name: 'changeParticulars',
          meta: {
            firstLevel: 4,
            secondLevel: 0,
            accoutEnquire: { offOn: '', type: '' }
          }
        },
        {
          path: 'changePassword', //更改密码
          component: () => import('@/views/mySettings/changePassword'),
          name: 'changePassword',
          meta: {
            firstLevel: 4,
            secondLevel: 1,
            accoutEnquire: { offOn: '', type: '' }
          }
        },
        {
          path: 'passwordConfirm', //密码确认
          component: () => import('@/views/mySettings/passwordConfirm'),
          name: 'passwordConfirm',
          meta: {
            firstLevel: 4,
            secondLevel: 2,
            accoutEnquire: { offOn: '', type: '' }
          }
        },
        {
          path: 'marginApplication', //信贷额申请
          component: () => import('@/views/mySettings/marginApplication'),
          name: 'marginApplication',
          meta: {
            firstLevel: 4,
            secondLevel: 3,
            accoutEnquire: { offOn: 'OFF,ON', type: 'M' }
          }
        },
        {
          path: 'investProfile', //投资风险取向问卷
          component: () => import('@/views/mySettings/investProfile'),
          name: 'investProfile',
          meta: {
            firstLevel: 4,
            secondLevel: 4,
            accoutEnquire: { offOn: '', type: '' }
          }
        }
      ]
    },
    {
      path: '/404',
      component: () => import('@/views/error_404/404'),
      name: '404'
    }, // 404页面
    {
      path: '/500',
      component: () => import('@/views/error_500/500'),
      name: '500'
    }, // 500页面
    {
      path: '/pps',
      component: () => import('@/views/cash/pps/pps'),
      name: 'pps'
      // meta: { firstLevel: 2, secondLevel: 3 }
    }, // 易转数页面
    {
      path: '/newHelp',
      component: () => import('@/views/home/newHelp/newHelp'),
      name: 'newHelp',
      meta: { firstLevel: -2, title: 'help' }
    }, // 帮助中心
    {
      path: '/newContact',
      component: () => import('@/views/home/newContact/newContact'),
      meta: { firstLevel: -2, title: 'contact' }
    }, // 联系我们
    {
      path: '/moreNotice',
      component: () => import('@/views/home/moreNotice/moreNotice'),
      meta: { firstLevel: -2, title: 'notice' }
    }, // 更多通知
    {
      path: '/prospectus', // 招股章程
      component: () => import('@/views/security/ipoSubscriptions/prospectus'),
      name: 'prospectus'
    },
    {
      path: '/prospectusForm', // 申请股数一览表
      component: () =>
        import('@/views/security/ipoSubscriptions/prospectusForm'),
      name: 'prospectusForm'
    },
    {
      path: '/mySettings/consentForConnect', // 中华通北向交易同意书
      component: () => import('@/views/mySettings/consentForConnect'),
      name: 'consentForConnect',
      hidden: true
    },
    {
      path: '/mySettings/personalQuestionnaire', // 个人投资风险取向问卷
      component: () =>
        import(
          '@/views/mySettings/personalQuestionnaire/personalQuestionnaire'
        ),
      name: 'personalQuestionnaire'
    },
    {
      path: '/mySettings/companyQuestionnaire', // 公司投资风险取向问卷
      component: () =>
        import(
          '@/views/mySettings/personalQuestionnaire/companyQuestionnaire'
        ),
      name: 'companyQuestionnaire'
    },
    {
      path: '/helpCenter',
      component: () => import('@/views/home/newHelp/newHelp'),
      name: 'helpCenter',
      meta: { firstLevel: -2, title: 'help' }
    }, // 帮助中心
    {
      path: '/newNotice',
      component: () => import('@/views/home/newNotice/newNotice'),
      name: 'newNotice'
    }, // 通知页面
    {
      path: '/login',
      component: () => import('@/views/login/login'),
      name: 'login'
    }, // 登录页面
    {
      path: '/prompt',
      component: () => import('@/views/login/prompt/prompt'),
      hidden: true
    }, // 保安提示弹窗
    {
      path: '/twoFaLogin',
      component: () => import('@/views/login/twoFaLogin/twoFaLogin')
    }, // 2FA登录验证页面
    {
      path: '/code',
      component: () => import('@/views/login/code/code'),
      name: 'code'
    }, // 验证码填写页面
    {
      path: '/risk',
      component: () => import('@/views/login/risk/risk')
    }, // 风险披露声明页面
    {
      path: '/register',
      component: () => import('@/views/login/register/register')
    }, // 保安编码注册页面
    {
      path: '/cancelRegister',
      component: () => import('@/views/login/register/cancelRegister')
    }, // 取消保安编码注册页面
    {
      path: '/changePd',
      component: () => import('@/views/login/changePd')
    } //  强制更改密码页面
  ]
})

// 路由导航守卫
// 路由前置守卫
router.beforeEach((to, from, next) => {
  // if (!to.meta.roles.includes(store.role)) {
  //   // 提示信息
  //   alert('您无权访问')
  //   // 删除token
  //   sessionStorage.removeItem('token')
  //   // 跳转到登录页
  //   next('/login')
  // } else {
    NProgress.start()
    next()
  // }
  // if (
  //   to.path === '/login' ||
  //   to.path === '/twoFaLogin' ||
  //   to.path === '/code' ||
  //   to.path === '/register' ||
  //   to.path === '/cancelRegister' ||
  //   to.path === '/prompt' ||
  //   to.path === '/changePd' ||
  //   to.path === '/500' ||
  //   to.path === '/404'
  // ) {
  //   next()
  // } else {
  //   let token = sessionStorage.getItem('token')
  //   if (token === null || token === '') {
  //     // 如果没有取到值,跳转至登录页
  //     next('/login')
  //   } else {
  //     NProgress.start()
  //     next()
  //   }
  // }
})
// 路由后置守卫
router.afterEach((to, from) => {
  // 结束进度
  NProgress.done()
})

const originalReplace = Router.prototype.push
Router.prototype.push = function push (location) {
  return originalReplace.call(this, location).catch(err => err)
}

export default router
