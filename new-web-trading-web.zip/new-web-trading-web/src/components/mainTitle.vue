<!--功能模块的title-->
<template>
  <div class="title-wrap contentBorder">
      <span class="text activeFontColor">{{title}}</span>
      <slot></slot>
  </div>
</template>

<script>
export default {
  data () {
    return {
    };
  },
  props: {
      title: ""
  },
  methods: {},
  mounted(){},

}

</script>
<style lang='scss' scoped>
    .title-wrap{
        width: 100%;
        height: 40px;
        line-height: 40px;
        font-family: SourceHanSansCN-Medium;
        border-bottom: 1px solid rgba(51,51,51,0.25);
        padding: 0 24px;
        .text{
            font-size: 18px;
        }
    }
    @media screen and (max-width: 768px){
        .title-wrap{
          padding: 0 12px;
        }
      }
</style>