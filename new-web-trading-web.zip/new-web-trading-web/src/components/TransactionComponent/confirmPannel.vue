<!--确认组件-->
<template>
   <div class="confirm-wrap">
        <div class="no-balance messageBgColor" v-if="!isBalance && orderType =='buy'">
            <i class="iconfont icon-detail"></i>{{$t('security.mainMarket.noMoneyExplain')}}
        </div>
        <ul class="buy-info">
            <li class="info-item">
                <span class="txt mediumColor">{{$t('security.mainMarket.market')}}</span>
                <span class="val heavyColor">港股 </span>
            </li>
            <li class="info-item">
                <span class="txt mediumColor">{{$t('security.mainMarket.stock')}}</span>
                <span class="val heavyColor">00665 海通國際 </span>
            </li>
            <li class="info-item">
                <span class="txt mediumColor">{{$t('security.mainMarket.num')}}</span>
                <span class="val heavyColor">3,000</span>
            </li>
            <li class="info-item">
                <span class="txt mediumColor">{{$t('security.mainMarket.price')}}</span>
                <span class="val heavyColor">HKD 2.600</span>
            </li>
            <li class="info-item">
                <span class="txt mediumColor">{{$t('security.mainMarket.tiaojian')}}</span>
                <span class="val heavyColor">不適用</span>
            </li>
            <li class="info-item">
                <span class="txt mediumColor">{{$t('security.mainMarket.expired')}}</span>
                <span class="val heavyColor">即日 </span>
            </li>
            <li class="info-item">
                <span class="txt mediumColor">{{$t('security.mainMarket.aon1')}}</span>
                <span class="val heavyColor">否 </span>
            </li>
            <li class="info-item">
                <span class="txt mediumColor">{{$t('security.mainMarket.tradMoney')}}</span>
                <span class="val heavyColor">HKD 7,800.00</span>
            </li>
            <li class="info-item">
                <span class="txt mediumColor" style="flex: 0 0 210px;">
                    {{$t('security.mainMarket.costMoney')}}
                    <span class="tip">
                    <i class="iconfont icon-detail"></i>
                    <el-popover
                        placement="right"
                        :width="curMarket == 'usTrading'?360:220"
                        trigger="click"
                        >
                        <!--key -value得从后台取数据-->
                        <div class="list">
                        <span class="icon mediumColor">參考佣金</span>
                        <span class="text heavyColor">HKD  100.00</span>
                        </div>
                        <div class="list">
                        <span class="icon mediumColor">結算費</span>
                        <span class="text heavyColor">HKD 2.00</span>
                        </div>
                        <div class="list">
                        <span class="icon mediumColor">交易徵費</span>
                        <span class="text heavyColor">HKD  0.21</span>
                        </div>
                        <div class="list">
                        <span class="icon mediumColor">厘印費</span>
                        <span class="text heavyColor">HKD 8.00</span>
                        </div>
                        <div class="list">
                        <span class="icon mediumColor">交易費</span>
                        <span class="text heavyColor">HKD  0.39</span>
                        </div>
                        <div class="list">
                        <span class="icon mediumColor">合计</span>
                        <span class="text heavyColor">HKD 110.60</span>
                        </div>
                        <div class="explain lightColor" v-if="curMarket != 'usTrading'">
                        <p class="explain-item">{{$t('security.mainMarket.costExplain')}}</p>
                        </div>
                        <div class="explain lightColor" v-if="curMarket == 'usTrading'">
                        <p class="explain-item">{{$t('security.mainMarket.usExplain1')}}</p>
                        <p class="explain-item"  v-html="$t('security.mainMarket.usExplain2')"></p>
                        <p class="explain-item">{{$t('security.mainMarket.usExplain3')}}</p>
                        <p class="explain-item">{{$t('security.mainMarket.usExplain4')}}</p>
                        </div>
                        <span  slot="reference" class="txt lightColor">{{$t('security.mainMarket.detail')}}</span>
                    </el-popover>
                    </span>
                </span>
                <span class="val heavyColor">HKD 110.60</span>
            </li>
            <li class="info-item">
                <span class="txt mediumColor">{{$t('security.mainMarket.totalPrice')}}</span>
                <span class="val heavyColor">USD 7,910.60</span>
            </li>
            <li class="info-item" v-if="curMarket != 'hkTrading'">
                <span class="txt mediumColor">{{$t('security.mainMarket.duiyinzhi')}}</span>
                <span class="val heavyColor">HKD 72,169.23</span>
            </li>
        </ul>
        <div v-if="!isBalance && orderType =='buy'" class="no-balance-btn contentTopBorder">
            <el-button @click="goToRoute('/cash/fundTransfer')">{{$t('security.mainMarket.accountTrans')}}</el-button>
            <el-button @click="goToRoute('/cash/ePayment')" type="primary">{{$t('security.mainMarket.assetInput')}}</el-button>
        </div>
        <div class="password-wrap contentTopBorder" v-if="isBalance || orderType =='sell'">
            <div class="password-content">
            <span class="txt mediumColor">{{$t('security.mainMarket.password')}}</span>
            <span class="val">
                <el-input v-model="password"  type="password" :placeholder="$t('security.mainMarket.placeholder')"></el-input>
            </span>
            </div>
            <div class="confirm-btn">
                <el-button @click="backPrevStep">{{$t('mySettings.changeParticulars.back')}}</el-button>
                <el-button class="buy" v-if="orderType =='buy'" type="primary" @click="confirmBuy">{{$t('security.mainMarket.confirm')}}</el-button>
                <el-button class="sell" v-if="orderType =='sell'" type="warning" @click="confirmBuy">{{$t('security.mainMarket.confirm')}}</el-button>
            </div>
        </div>
    </div>
</template>

<script>
export default {
  props: {
    orderType: '',//买或者卖
    curMarket:"",//当前的市场 hkTrading usTrading A-shareTrading
  },  
  data () {
    return {
        isBalance: true,//true 足够的余额 false不足够
        password:"",
    };
  },
  methods: {
    goToRoute(path) {
        this.$router.push(path);
        this.$store.commit('changeIsJumpRouter', true);
    },
    //返回
    backPrevStep() {
        this.$emit('backNextStep',this.orderType);
    },  
    //提交买入
    confirmBuy() {
        this.$emit('goToLastStep',this.orderType);
    }
  },
  mounted(){

  }
}

</script>
<style lang='scss' scoped>
.confirm-wrap{
    .no-balance{
        padding: 4px 24px;
        font-family: SourceHanSansCN-Regular;
        font-size: 12px;
        color: #333333;
        line-height: 14px;
        i{
            color: #626262;
            font-size: 12px;
            margin-right: 4px;
        }
    }
    .buy-info{
        padding: 12px 24px;
        .info-item{
            padding: 2px 0;
            display: flex;
            flex-wrap: wrap;
            .txt{
                font-family: SourceHanSansCN-Regular;
                font-size: 16px;
                flex:0 0 120px;
            }
            .tip{
                i{
                font-size: 14px;
                color: #9B9B9B;
                }
                .txt {
                    font-family: SourceHanSansCN-Medium;
                    font-size: 12px;
                    text-decoration: underline;
                    cursor: pointer;
                }
            }
            .val{
                font-family: SourceHanSansCN-Regular;
                font-size: 16px;
                flex:1;
                text-align: right;
                padding-left: 10px;
            }
        }
    }
    .no-balance-btn{
        padding: 48px 24px 24px 24px;
        text-align: right;
    }
    .password-wrap{
        padding: 24px;
        .password-content{
            display: flex;
            align-items: center;
            .txt{
            flex: 0 0  80px;
            padding-right: 10px;
            font-family: SourceHanSansCN-Regular;
            font-size: 16px;
            }
            .val{
            flex: 1;
            }
        }
        .confirm-btn{
            padding-top: 24px;
            text-align: right;
        }
    }
}
.list {
    width: 100%;
    display: flex;
    flex-wrap: wrap;
    font-family: SourceHanSansCN-Regular;
    font-size: 14px;
    padding-bottom: 4px;
    .icon {
        width: auto;
    }
    .text {
        flex: 1;
        text-align: right;
    }
 }
.explain {
    padding-top: 6px;
    font-family: SourceHanSansCN-Normal;
    font-size: 12px;
    line-height: 18px;
}
</style>