<!--交易成功提示-->
<template>
  <div class="succes-wrap">
        <div class="layout-wrap">
            <div class="success-wrap">
                <span class="ico"><i class="iconfont icon-status_success activeFontColor" :class="orderType == 'sell'?'sellColor':''"></i></span>
                <span class="text activeFontColor" :class="orderType == 'sell'?'sellColor':''">{{$t('security.mainMarket.success')}}</span>
            </div>
            <div class="success-info activeFontColor" :class="orderType == 'sell'?'sellColor':''">{{$t('security.mainMarket.sucTip')}}： 80044</div>
        </div>
        <ul class="base-wrap contentTopBorder">
            <li class="info-item">
                <span class="txt mediumColor">{{$t('security.mainMarket.market')}}</span>
                <span class="val heavyColor">港股</span>
            </li>
            <li class="info-item">
                <span class="txt mediumColor">{{$t('security.mainMarket.stock')}}</span>
                <span class="val heavyColor">00665 海通國際</span>
            </li>
            <li class="info-item">
                <span class="txt mediumColor">{{$t('security.mainMarket.num')}}</span>
                <span class="val heavyColor">3,000</span>
            </li>
            <li class="info-item">
                <span class="txt mediumColor">{{$t('security.mainMarket.price')}}</span>
                <span class="val heavyColor">HKD 2.600</span>
            </li>
            <li class="info-item">
                <span class="txt mediumColor">{{$t('security.mainMarket.tradMoney')}}</span>
                <span class="val heavyColor">HKD 7,800.00</span>
            </li>
            <li class="info-item">
                <span class="txt mediumColor">{{$t('security.mainMarket.totalPrice')}}</span>
                <span class="val heavyColor">HKD 7,910.60</span>
            </li>
            <li class="info-item" v-if="curMarket != 'hkTrading'">
                <span class="txt mediumColor">{{$t('security.mainMarket.duiyinzhi')}}</span>
                <span class="val heavyColor">HKD 72,169.23</span>
            </li>
        </ul>
   </div>
</template>

<script>
export default {
  props: {
    orderType: '',//买或者卖
  }, 
  data () {
    return {
      curMarket:"hkTrading",//当前的市场 hkTrading usTrading A-shareTrading
    };
  },
  methods: {},
  mounted(){
    this.curMarket = this.$route.name;
  },
}

</script>
<style lang='scss' scoped>
 .succes-wrap{
        padding: 24px;
        .layout-wrap{
            width: 100%;
            height: 100%;    
            padding-bottom: 12px;
            .success-wrap{
                text-align: center;
                span{
                    display: block;
                }
                .ico{
                    padding: 24px 0;
                    i{
                        font-size: 58px;
                        &.sellColor{
                            color: #ED8B00 !important;
                        }
                    }
                }
                .text{
                    font-family: SourceHanSansCN-Medium;
                    font-size: 18px;
                    &.sellColor{
                        color: #ED8B00 !important;
                    }
                }
            }
            .success-info{
                padding: 6px 0;
                font-family: SourceHanSansCN-Regular;
                font-size: 14px;
                color: #333333;
                line-height: 16px;
                text-align: center;
                &.sellColor{
                    color: #ED8B00 !important;
                }
            }
        }
        .base-wrap{
            padding-top: 12px;
            padding-bottom: 46px;
            .info-item{
                padding: 2px 0;
                display: flex;
                flex-wrap: wrap;
                .txt{
                    font-family: SourceHanSansCN-Regular;
                    font-size: 1rem;
                    flex:0 0 120px;
                }
                .val{
                    font-family: SourceHanSansCN-Regular;
                    font-size: 1rem;
                    flex:1;
                    text-align: right;
                    padding-left: 10px;
                }
            }
        }
    }
</style>