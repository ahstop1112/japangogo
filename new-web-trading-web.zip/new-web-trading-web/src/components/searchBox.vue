<!--证券交易中的搜索框组件-->
<template>
  <div class="search-box">
    <el-autocomplete
        class="ipt"
        v-model="input"
        :fetch-suggestions="querySearchAsync"
        :placeholder="placeholderVal"
        @select="handleSelect"
        :trigger-on-focus= "false"
    ></el-autocomplete>
    <span class="icons contentLeftBorder">
        <img src="@/assets/img/search.png" />
    </span>
  </div>
</template>

<script>
import { getSearchAsset } from "@/api/security"
export default {
  props: {
      curMarket:'',//当前的市场 hkTrading A-shareTrading  usTrading
      isShowInput: false,//是否在输入框显示选中的结果
      placeholderVal: {
          type: String,
          default: '00665'
      },
      inInput:'',//传入的Input值
  },  
  watch: {
    inInput(val) {
        this.input = val;
    }
  },
  data () {
    return {
        input:"",
    };
  },
  methods: {
    querySearchAsync(queryString, cb) {
        if(queryString == "") {
            return;
        }
        let curMarket = this.curMarket;
        let mktCode = "";
        curMarket == 'hkTrading'?mktCode = 'HK':curMarket == 'A-shareTrading'?mktCode = 'SH':mktCode = 'US';
        let parmas = {
            "params": {
                key: queryString,
                mktCode: mktCode,
                limit:""
            }
        }
        getSearchAsset(
            parmas
        ).then(res => {
            let stocks = res.result;
            let result = stocks.map(item => {
                return {
                    assetId: item.assetId,
                    value: item.stkCode +" "+ item.stkName,
                    stkCode: item.stkCode,
                    secType: item.secType,//港股 类型   1-股票 2-债券 3-基金 4-涡轮 5-指数 6-牛熊证 0-其他 7-界内证 
                }    
            })
            cb(result);
        }).catch(error => {
            //console.log(error)
        })
    },
    handleSelect(item) {
        this.$emit('handleSelect', item);
        if(this.isShowInput) {
            this.input =  item.value;
            return;
        }
        this.input = "";
    },
  },
  mounted(){

  },
}

</script>
<style lang='scss' scoped>
    .search-box{
        width: 100%;
        position: relative;
        display: inline-block;
        .icons{
            width: 36px;
            cursor: pointer;
            text-align: center;
            display: inline-block;
            height: 36px;
            line-height: 32px;
            position: absolute;
            right: 0;
            top: 0;
            img{
               display: inline-block;
               width: 24px;
               height: 24px;
               vertical-align:middle;
            }
            img:hover{
                opacity: 0.8;
            }
        }
        >>> .el-autocomplete{
            width: 100%;
        }
    }
</style>