<!--没有内容的时候显示图标加文案-->
<template>
  <div class="noContent-wrap" :style="{height: height}">
    <div class="layout-content">
       <img src="@/assets/default_no content@2x.png" :width="width"/>
       <span class="text lightColor">{{content}}</span>   
    </div>
  </div>
</template>

<script>
export default {
  props: {
    content: "" ,//显示的内容
    height:"",  //可显示区域高度
    width: {
      type: String,
      default: "183",
    }//图片显示的宽度
  },  
  data () {
    return {
       
    };
  },
  methods: {},
  mounted(){},

}

</script>
<style lang='scss' scoped>
    .noContent-wrap{
        width: 100%;
        display: flex;
        justify-content: center;
        align-items: center;
        .layout-content{
            text-align: center;
            .text{
                margin-top: 12px;
                display: block;
                text-align: center;
                font-family: SourceHanSansCN-Regular;
                font-size: 14px;
            }
        }
    }
</style>