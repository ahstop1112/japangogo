import { myhttp } from '@/utils/request'

// Mobile OTP注册api
export function mobileOtpEnrollmentApi (data) {
  return myhttp({
    url: '/api/user/log/mobileOtpEnrollment',
    method: 'post',
    data,
    needToken: false
  })
}

// 注销SoftwareToken Api
export function removeSoftwareTokenApi (data) {
  return myhttp({
    url: '/api/user/log/removeSoftwareToken',
    method: 'post',
    data,
    needToken: false
  })
}
