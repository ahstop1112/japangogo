//行情接口管理
import { marketAPI } from '@/utils/request'
import { myhttp } from '@/utils/request'

//行情基本数据
export function getQuot (data) {
  return marketAPI({
    url: '/mktinfo_api/get_quot',
    method: 'post',
    data
  })
}
//行情基本数据 涡轮数据查询
export function getWarrantQuot (data) {
  return marketAPI({
    url: '/mktinfo_api/get_warrant_quot',
    method: 'post',
    data
  })
}
//用户输入股票查询
export function getBkInfo (data) {
  return marketAPI({
    url: '/mktinfo_api/get_bk_info',
    method: 'post',
    data
  })
}

//五日分时均线
export function getFiveTs (data) {
  return marketAPI({
    url: '/mktinfo_api/get_five_ts',
    method: 'post',
    data
  })
}

//分时均线
export function getTimeSharing (data) {
  return marketAPI({
    url: '/mktinfo_api/get_timesharing',
    method: 'post',
    data
  })
}
/*
    {
        "params": {
            "assetId": "002958.SZ"
        },
        "tester":"ibester"
}
*/

//日K 周k 月K
export function getHistoryQuot (data) {
  return marketAPI({
    url: '/mktinfo_api/get_history_quot',
    method: 'post',
    data
  })
}
/*
{
        "params": {
            "adjust": "N",  //N前复权（默认）  B后复权   N不复权
            "assetId": "002958.SZ",//股票代码
            "count": 100,  //条数
            "type": "M"  //D： 日K    W ：周K   M： 月K    Y：年K 
        }
      
    }
*/

//根据股票名称或者代码查询接口
export function getSearchAsset (data) {
  return marketAPI({
    url: '/mktinfo_api/search_asset',
    method: 'post',
    data
  })
}
//mktinfo_api/search_asset   搜索码表  参数（key:关键字  mktCode: SZ/SH/HK/US  limit  搜索返回最多条数 ）

//根据不同市场查询某天是否是交易日
export function getIsTradingDay (data) {
  return marketAPI({
    url: '/mktinfo_api/is_trading_day',
    method: 'post',
    data
  })
}

//查询当前市场下自选股
export function getOptionStock (data) {
  return marketAPI({
    url: '/mktinfo_api/get_option_stock',
    method: 'post',
    data
  })
}
/*
    {
        "params": {
        "sessionId":"b2d59448cfdc43928e614d313b9b7255453387" //用户身份的key
        }
    }
*/

//增加或删除自选股
export function saveOptionStock (data) {
  return marketAPI({
    url: '/mktinfo_api/save_option_stock',
    method: 'post',
    data
  })
}
/*
     "params": {
    "sessionId":"b2d59448cfdc43928e614d313b9b7255453387",
    "operatingType":"add",
    "assetIds":["00070.HK"],
    }
*/

/* MACD指标 */
export function getIdcMacd (data) {
  return marketAPI({
    url: '/mktinfo_api/get_idc_macd',
    method: 'post',
    data
  })
}
/* KDJ指标 */
export function getIdcKdj (data) {
  return marketAPI({
    url: '/mktinfo_api/get_idc_kdj',
    method: 'post',
    data
  })
}
/* BOLL指标 */
export function getIdcBoll (data) {
  return marketAPI({
    url: '/mktinfo_api/get_idc_boll ',
    method: 'post',
    data
  })
}
/* RSI指标 */
export function getIdcRsi (data) {
  return marketAPI({
    url: '/mktinfo_api/get_idc_rsi',
    method: 'post',
    data
  })
}
// EIPO可申購列表api
export function enquiryAllIposByLangApi (data) {
  return myhttp({
    url: '/api/sec/acmgt/eipo/enquiryAllIposByLang',
    method: 'post',
    data,
    needToken: true
  })
}

// EIPO详情api
export function enquiryIpoMasterDetailApi (data) {
  return myhttp({
    url: '/api/sec/acmgt/eipo/enquiryIpoMasterDetail',
    method: 'post',
    data,
    needToken: true
  })
}
// 公司行动查询
export function eceEnquiry (data) {
  return myhttp({
    url: '/api/sec/acmgt/ece/eceEnquiry',
    method: 'post',
    data,
    needToken: true
  })
}
// 查询待答复公司行动数量
export function eceCount (data) {
  return myhttp({
    url: '/api/sec/acmgt/ece/eceCount',
    method: 'post',
    data,
    needToken: true
  })
}
// 登录之后账户信息与权限信息
export function accountEnquiry (data) {
  return myhttp({
    url: '/api/user/accountEnquiry',
    method: 'post',
    data,
    needToken: true
  })
}