import { myhttp } from '@/utils/request'

// 登录-1FAapi
export function login1FaApi (data) {
  return myhttp({
    url: '/api/user/log/login1fa',
    method: 'post',
    data
    // needToken: false // 在这里定义的属性，在请求拦截器中的 config 中可以直接得到
  })
}

// 验证手机号码api(发送OTP)
export function verifyMobileApi (data) {
  return myhttp({
    url: '/api/user/log/verifyMobile',
    method: 'post',
    data,
    needToken: false
  })
}

// 重新发送OTP
export function resendOtpApi (data) {
  return myhttp({
    url: '/api/user/log/resendOtp',
    method: 'post',
    data,
    needToken: false
  })
}

// 登录-2FAapi(验证OTP)
export function login2FaApi ({ otp, deviceId, mobileOtp }) {
  return myhttp({
    url: '/api/user/log/login2fa',
    method: 'post',
    data: {
      otp,
      deviceId,
      mobileOtp
    },
    needToken: false
  })
}
