// import { localGet } from '@/utils/mylocal.js'

const state = {
  currentTitle: '主页', //当前用户的导航
  bgColor: localStorage.getItem('bgColor') || 'bg-Blue', //保存当前颜色类型
  toggleSideBar: true, //侧边栏的收缩,默认是隐藏的
  deviceSidebar: false, //侧边栏再分辨率低于768的时候显示与隐藏
  device: '', //保存当前的设备 <768 mobile 否则 desktop
  lang: localStorage.getItem('language') || 'zh_TW', //当前语言的信息  zhTW  zhCN en
  fixedSide: false, //是否固定侧边栏信息
  isJumpRouter: false, //是否是页面内的菜单跳转(不是菜单点击)
  curStock: {}, //当前所选的股票信息
  updateSelfStock: [], //保存当前自选股的相关assetId
  // user_data: '' || localGet('user_data'),
  role: 'ENTERP',
  quterType: localStorage.getItem('quterType') || 1, //绿涨红跌1还是红涨绿跌2
  activeAccountId:'',//页面默认选择的用户账户
}

export default state
